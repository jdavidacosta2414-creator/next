// Lógica compartida de registro de conductor (móvil).
// Usada por registerDriver y registerConductor.

import { getDriverCategory } from './serviceMatch.ts';
import { ensureCourierId } from './courierId.ts';

// Una misma persona puede registrarse una vez en cada categoría (carro, moto y mensajería) con sus mismos datos,
// en la misma cuenta. Lo único que no se permite es repetir una categoría en la que ya está registrada.
const CATEGORY_NAMES = { carro: 'carro', moto: 'moto', mensajero: 'mensajería' };

// De una lista de perfiles, el que ya ocupa la categoría indicada (los rechazados no cuentan).
export function profileInCategory(profiles, category) {
  return profiles.find((m) => m.approval_status !== 'rechazado' && getDriverCategory(m) === category) || null;
}

// Aviso si la cédula ya está registrada en la categoría indicada; null si esa categoría está libre para la persona.
export async function cedulaCategoryConflict(base44, cedula, category) {
  if (!cedula || !category) return null;
  const res = await base44.asServiceRole.entities.Mobile.filter({ cedula });
  const profiles = Array.isArray(res) ? res : res?.items || [];
  if (!profileInCategory(profiles, category)) return null;
  return `La cédula ${cedula} ya está registrada como conductor de ${CATEGORY_NAMES[category]}. Para un registro nuevo elige otra categoría.`;
}

const onlyDigits = (v) => String(v || '').replace(/\D/g, '');

// De los perfiles que usan una placa, devuelve los que pertenecen a otra persona (otra cédula).
export function plateHoldersOfOtherDrivers(profiles, cedula) {
  const mine = onlyDigits(cedula);
  return profiles.filter((m) => !mine || onlyDigits(m.cedula) !== mine);
}

// Normaliza y trimea los campos de entrada del conductor.
export function extractCarYear(vehicleYear, vehicleModel) {
  const numericYear = Number(vehicleYear);
  if (Number.isInteger(numericYear) && numericYear >= 1950 && numericYear <= 2035) {
    return numericYear;
  }
  const match = String(vehicleModel || '').match(/\b(19\d{2}|20\d{2})\b/);
  if (match) {
    return parseInt(match[1], 10);
  }
  return null;
}

export function normalizeConductorInput(body) {
  const vehicle_type = (body?.vehicle_type || 'moto').toString().trim();
  const rawCarSubtype = (body?.car_subtype || '').toString().trim().toLowerCase();
  const rawPlateType = (body?.plate_type || '').toString().trim().toLowerCase();
  const vehicle_model = (body?.vehicle_model || '').toString().trim();
  const parsedYear = extractCarYear(body?.vehicle_year, vehicle_model);

  return {
    name: (body?.name || '').toString().trim(),
    cedula: (body?.cedula || '').toString().trim(),
    phone: (body?.phone || '').toString().trim(),
    plate: (body?.plate || '').toString().trim().toUpperCase(),
    plate_type: vehicle_type === 'carro' ? (rawPlateType === 'blanca' ? 'blanca' : rawPlateType === 'amarilla' ? 'amarilla' : '') : '',
    vehicle_type,
    driver_category: vehicle_type === 'carro' ? 'carro' : body?.driver_category === 'mensajero' ? 'mensajero' : 'moto',
    car_subtype: vehicle_type === 'carro' ? (rawCarSubtype === 'taxi' ? 'taxi' : rawCarSubtype === 'particular' ? 'particular' : '') : '',
    vehicle_brand: (body?.vehicle_brand || '').toString().trim(),
    vehicle_model,
    vehicle_color: (body?.vehicle_color || (vehicle_type === 'carro' && rawCarSubtype === 'taxi' ? 'Amarillo' : '')).toString().trim(),
    vehicle_year: parsedYear,
    vehicle_photo: (body?.vehicle_photo || '').toString().trim(),
    verification_photo: (body?.verification_photo || '').toString().trim(),
    tarjeta_photo: (body?.tarjeta_photo || '').toString().trim(),
    soat_photo: (body?.soat_photo || '').toString().trim(),
    tecno_photo: (body?.tecno_photo || '').toString().trim(),
    soat_expiry: (body?.soat_expiry || '').toString().trim(),
    tecno_expiry: (body?.tecno_expiry || '').toString().trim(),
    photo_url: (body?.photo_url || '').toString().trim(),
  };
}

// Crea el perfil de móvil para el usuario autenticado (rol de servicio).
// - Asigna el rol 'movil' primero para no dejar perfil huérfano.
// - Falla si la cuenta o la cédula ya tienen perfil en esa categoría, o si la placa es de otro conductor.
// - requirePlate: la placa es obligatoria para registerDriver, opcional para registerConductor.
export async function createConductorProfile(base44, user, data, { requirePlate = true } = {}) {
  const {
    name, cedula, phone, plate, plate_type, vehicle_type, driver_category, car_subtype, vehicle_brand,
    vehicle_model, vehicle_color, vehicle_year, vehicle_photo, verification_photo, tarjeta_photo,
    soat_photo, tecno_photo, soat_expiry, tecno_expiry, photo_url,
  } = data;

  if (!name) throw new Error('El nombre es obligatorio');
  if (requirePlate && !plate) throw new Error('La placa del vehículo es obligatoria');
  if (!verification_photo) throw new Error('La foto de la cédula es obligatoria');

  if (vehicle_type === 'carro') {
    if (!car_subtype || !['particular', 'taxi'].includes(car_subtype)) {
      throw new Error('Selecciona si el carro es Carro particular o Taxi');
    }
    if (!plate_type || !['amarilla', 'blanca'].includes(plate_type)) {
      throw new Error('Selecciona el tipo de placa (Placa amarilla o Placa blanca)');
    }
    if (!vehicle_year || vehicle_year < 2003) {
      throw new Error('Para carros solo se permiten modelos del año 2003 en adelante');
    }
  }

  // La cuenta puede tener un perfil por categoría; lo que no puede es repetir una categoría.
  const byEmail = await base44.asServiceRole.entities.Mobile.filter({ email: user.email });
  if (profileInCategory(byEmail, driver_category)) {
    throw new Error('Ya tienes un perfil de conductor registrado en ' + CATEGORY_NAMES[driver_category]);
  }
  const cedulaConflict = await cedulaCategoryConflict(base44, cedula, driver_category);
  if (cedulaConflict) throw new Error(cedulaConflict);
  // Un registro rechazado de esa misma categoría se corrige sobre el mismo perfil.
  const existingRejected = byEmail.find(
    (m) => m.approval_status === 'rechazado' && getDriverCategory(m) === driver_category
  );

  if (plate) {
    const byPlate = await base44.asServiceRole.entities.Mobile.filter({ plate });
    const otherPlate = plateHoldersOfOtherDrivers(byPlate, cedula).filter((m) => !existingRejected || m.id !== existingRejected.id);
    if (otherPlate.length > 0) throw new Error('La placa ' + plate + ' ya está registrada por otro conductor');
  }

  const finalPhotoUrl = photo_url || user?.photo_url || '';

  // Rol y datos compartidos con el perfil de pasajero (nombre, teléfono, cédula y foto).
  try {
    await base44.asServiceRole.entities.User.update(user.id, {
      role: 'movil',
      display_name: name,
      phone: phone || user?.phone || undefined,
      cedula: cedula || user?.cedula || undefined,
      photo_url: finalPhotoUrl || undefined,
    });
  } catch (e) {
    // Si el dueño de la app no permite cambio de rol, igual sincronizamos sus datos personales y foto.
    try {
      await base44.asServiceRole.entities.User.update(user.id, {
        display_name: name,
        phone: phone || user?.phone || undefined,
        cedula: cedula || user?.cedula || undefined,
        photo_url: finalPhotoUrl || undefined,
      });
    } catch {}
  }

  const mobilePayload = {
    name,
    cedula,
    phone,
    plate: plate || undefined,
    ...(vehicle_type === 'carro' && plate_type ? { plate_type } : {}),
    email: user.email,
    vehicle_type,
    driver_category: driver_category || (vehicle_type === 'carro' ? 'carro' : 'moto'),
    ...(vehicle_type === 'carro' && car_subtype ? { car_subtype } : {}),
    vehicle_brand,
    vehicle_model,
    ...(vehicle_color ? { vehicle_color } : {}),
    ...(vehicle_year ? { vehicle_year } : {}),
    vehicle_photo,
    verification_photo,
    tarjeta_photo,
    ...(soat_photo ? { soat_photo } : {}),
    ...(tecno_photo ? { tecno_photo } : {}),
    ...(soat_expiry ? { soat_expiry } : {}),
    ...(tecno_expiry ? { tecno_expiry } : {}),
    photo_url: finalPhotoUrl,
    status: 'offline',
    approval_status: 'pendiente',
    approval_notes: '',
  };

  const mobile = existingRejected
    ? await base44.asServiceRole.entities.Mobile.update(existingRejected.id, mobilePayload)
    : await base44.entities.Mobile.create(mobilePayload);

  // Todo mensajero recibe al registrarse su ID corto y permanente, con el que los comercios le asignan pedidos.
  // Si no se alcanza a entregar aquí, lo recibe al abrir su perfil.
  await ensureCourierId(base44.asServiceRole, mobile).catch((e) => console.error('courier id', e?.message));

  // Crear notificación en Central para que verifiquen los documentos y activen al conductor
  try {
    await base44.asServiceRole.entities.Incidence.create({
      title: `Conductor pendiente de activación: ${name}`,
      description: `Sección: ${vehicle_type === 'carro' ? 'Carro' : driver_category === 'mensajero' ? 'Mensajero (moto)' : 'Moto'} ${[vehicle_brand, vehicle_model].filter(Boolean).join(' ')} · Placa ${plate || '—'} · Cédula ${cedula || '—'} · Tel ${phone || '—'}. Revisa todos sus documentos en la pestaña Móviles/Conductores para activarlo.`,
      category: 'conductor',
      priority: 'alta',
      status: 'abierta',
      related_mobile_id: mobile.id,
      related_mobile_name: name,
    });
  } catch {}

  return mobile;
}

// Mapa un mensaje de error a un estado HTTP apropiado.
export function statusForError(msg) {
  const m = (msg || '').toLowerCase();
  if (m.includes('obligator') || m.includes('registrad') || m.includes('2003') || m.includes('selecciona') || m.includes('vencid')) return 400;
  return 500;
}
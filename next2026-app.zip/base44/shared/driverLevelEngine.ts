// Motor central en backend de Niveles (Trayectoria Acumulada) y Rendimiento Reciente de Conductores NEXT.
// Todas las decisiones de ascenso, advertencia, periodo de recuperación de 7 días, descenso gradual y
// justificación administrativa de cancelaciones se calculan y auditan aquí con registros reales.
import { isServiceForDriver } from './serviceMatch.ts';

export const MIN_VALID_SAMPLE = 20;
export const RECOVERY_PERIOD_DAYS = 7;
export const RECOVERY_PERIOD_MS = RECOVERY_PERIOD_DAYS * 24 * 60 * 60 * 1000;

export const LEVEL_SPECS: Record<string, any> = {
  bronce: {
    id: 'bronce',
    name: 'Bronce',
    order: 1,
    minServices: 0,
    minDays: 0,
    minAcceptance: 0,
    maxCancellation: 100,
    priorityLabel: 'Prioridad estándar',
  },
  plata: {
    id: 'plata',
    name: 'Plata',
    order: 2,
    minServices: 100,
    minDays: 15,
    minAcceptance: 80,
    maxCancellation: 5,
    priorityLabel: 'Prioridad preferencial',
  },
  oro: {
    id: 'oro',
    name: 'Oro',
    order: 3,
    minServices: 300,
    minDays: 45,
    minAcceptance: 90,
    maxCancellation: 3,
    priorityLabel: 'Máxima prioridad',
  },
};

function parseIsoDate(raw: any): Date | null {
  if (!raw) return null;
  const s = String(raw).trim();
  if (!s) return null;
  const normalized = /([zZ]|[+-]\d{2}:?\d{2})$/.test(s) ? s : `${s.replace(' ', 'T')}Z`;
  const d = new Date(normalized);
  return Number.isNaN(d.getTime()) ? null : d;
}

function toBogotaDateStr(d: Date): string {
  return d.toLocaleDateString('en-CA', { timeZone: 'America/Bogota' });
}

function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

export function checkMeetsLevelTrajectory(levelId: string, completedServices: number, connectedDays: number): boolean {
  const spec = LEVEL_SPECS[levelId] || LEVEL_SPECS.bronce;
  return completedServices >= spec.minServices && connectedDays >= spec.minDays;
}

export function checkMeetsLevelPerformance(
  levelId: string,
  acceptanceRate: number,
  cancellationRate: number,
  hasMinimumSample: boolean
): boolean {
  if (levelId === 'bronce') return true;
  if (!hasMinimumSample) return false;
  const spec = LEVEL_SPECS[levelId];
  if (!spec) return false;
  return acceptanceRate >= spec.minAcceptance && cancellationRate <= spec.maxCancellation;
}

export function checkMeetsFullLevel(
  levelId: string,
  completedServices: number,
  connectedDays: number,
  acceptanceRate: number,
  cancellationRate: number,
  hasMinimumSample: boolean
): boolean {
  if (levelId === 'bronce') return true;
  return (
    checkMeetsLevelTrajectory(levelId, completedServices, connectedDays) &&
    checkMeetsLevelPerformance(levelId, acceptanceRate, cancellationRate, hasMinimumSample)
  );
}

export function derivePerformanceStatus({
  hasMinimumSample,
  acceptanceRate,
  cancellationRate,
  recoveryActive,
}: {
  hasMinimumSample: boolean;
  acceptanceRate: number;
  cancellationRate: number;
  recoveryActive: boolean;
}): string {
  if (!hasMinimumSample) return 'sin_datos_suficientes';
  if (recoveryActive) return 'en_observacion';
  if (acceptanceRate >= 90 && cancellationRate <= 3) return 'excelente';
  if (acceptanceRate >= 80 && cancellationRate <= 5) return 'bueno';
  if (acceptanceRate >= 70 && cancellationRate <= 8) return 'en_observacion';
  return 'necesita_mejorar';
}

export async function createNotificationOnce(
  base44: any,
  {
    mobile,
    dedupeKey,
    category,
    title,
    message,
    howToImprove = '',
    levelContext = '',
  }: {
    mobile: any;
    dedupeKey: string;
    category: string;
    title: string;
    message: string;
    howToImprove?: string;
    levelContext?: string;
  }
) {
  if (!mobile?.id || !dedupeKey) return null;
  const notifEntity = base44.asServiceRole.entities.DriverNotification;
  const existing = await notifEntity
    .filter({ mobile_id: mobile.id, dedupe_key: dedupeKey }, '-created_date', 1)
    .catch(() => []);
  const list = Array.isArray(existing) ? existing : existing?.items || [];
  if (list.length > 0) return list[0];

  return await notifEntity
    .create({
      mobile_id: mobile.id,
      mobile_name: mobile.name || 'Conductor',
      driver_email: (mobile.email || '').trim().toLowerCase(),
      dedupe_key: dedupeKey,
      category,
      title,
      message,
      how_to_improve: howToImprove,
      level_context: levelContext || mobile.current_level || 'bronce',
      read: false,
      dismissed: false,
    })
    .catch(() => null);
}

/**
 * Registra de forma idempotente un evento real de solicitud/servicio para el conductor.
 * Protege contra eventos duplicados usando `event_key` determinístico por (mobile_id, service_id).
 */
export async function recordDriverPerformanceEvent(
  base44: any,
  {
    mobile,
    service,
    eventType,
    cancelReason = '',
    cancelledBy = 'ninguno',
    technicalFailure = false,
  }: {
    mobile: any;
    service: any;
    eventType: string;
    cancelReason?: string;
    cancelledBy?: string;
    technicalFailure?: boolean;
  }
) {
  if (!mobile?.id || !service?.id) return null;

  // Verificar compatibilidad de vehículo: solicitudes de otro tipo de vehículo no afectan indicadores.
  const isCompatible = isServiceForDriver(service, mobile);
  if (!isCompatible && eventType !== 'service_completed') {
    return { skipped: true, reason: 'incompatible_vehicle' };
  }

  const evtEntity = base44.asServiceRole.entities.DriverPerformanceEvent;
  const nowIso = new Date().toISOString();
  const driverEmail = (mobile.email || '').trim().toLowerCase();

  // Clave única por (conductor, servicio) para el ciclo de solicitud/servicio, evitando doble conteo
  const primaryKey = `svc_perf_${mobile.id}_${service.id}`;
  const existingRes = await evtEntity
    .filter({ event_key: primaryKey }, '-created_date', 1)
    .catch(() => []);
  const existingList = Array.isArray(existingRes) ? existingRes : existingRes?.items || [];
  const existing = existingList[0] || null;

  // Caso 1: Oferta enviada por el conductor (contraoferta o postulación en espera de que el pasajero elija).
  // Regla: Las ofertas enviadas al pasajero que el pasajero no selecciona NO perjudican la aceptación.
  if (eventType === 'offer_sent' || eventType === 'offer_not_selected') {
    if (existing) {
      // Si ya fue aceptado/asignado o completado, no sobrescribir con oferta
      if (existing.counts_for_acceptance_numerator || existing.counts_for_cancellation_denominator) {
        return existing;
      }
      return await evtEntity.update(existing.id, {
        event_type: eventType,
        request_status: 'ofertada_no_seleccionada',
        counts_for_acceptance_denominator: false,
        counts_for_acceptance_numerator: false,
        responded_at: nowIso,
      });
    }
    return await evtEntity.create({
      event_key: primaryKey,
      mobile_id: mobile.id,
      mobile_name: mobile.name || 'Conductor',
      driver_email: driverEmail,
      service_id: service.id,
      event_type: eventType,
      request_status: 'ofertada_no_seleccionada',
      counts_for_acceptance_denominator: false,
      counts_for_acceptance_numerator: false,
      counts_for_cancellation_denominator: false,
      counts_for_cancellation_numerator: false,
      received_at: service.created_date || nowIso,
      responded_at: nowIso,
      pickup_address: service.pickup_address || '',
      destination_address: service.destination_address || '',
      technical_failure: Boolean(technicalFailure),
      justified: false,
      justification_status: 'no_aplica',
    });
  }

  // Caso 2: Error técnico comprobado -> no penaliza al conductor
  if (technicalFailure || eventType === 'system_error') {
    if (existing) {
      return await evtEntity.update(existing.id, {
        event_type: 'system_error',
        request_status: 'excluida',
        technical_failure: true,
        counts_for_acceptance_denominator: false,
        counts_for_acceptance_numerator: false,
        counts_for_cancellation_denominator: false,
        counts_for_cancellation_numerator: false,
      });
    }
    return await evtEntity.create({
      event_key: primaryKey,
      mobile_id: mobile.id,
      mobile_name: mobile.name || 'Conductor',
      driver_email: driverEmail,
      service_id: service.id,
      event_type: 'system_error',
      request_status: 'excluida',
      technical_failure: true,
      counts_for_acceptance_denominator: false,
      counts_for_acceptance_numerator: false,
      counts_for_cancellation_denominator: false,
      counts_for_cancellation_numerator: false,
      received_at: service.created_date || nowIso,
      responded_at: nowIso,
      pickup_address: service.pickup_address || '',
      destination_address: service.destination_address || '',
      justified: true,
      justification_status: 'justificada',
    });
  }

  // Caso 3: Rechazo directo o vencimiento sin respuesta de una solicitud válida compatible
  if (eventType === 'request_rejected' || eventType === 'request_expired') {
    if (existing) {
      // Si el conductor ya había enviado una oferta al pasajero y el servicio venció porque el pasajero no eligió,
      // NO penalizar al conductor.
      if (existing.event_type === 'offer_sent' && eventType === 'request_expired') {
        return existing;
      }
      // Si ya estaba aceptado/asignado, no degradar a rechazado
      if (existing.counts_for_acceptance_numerator) {
        return existing;
      }
      return await evtEntity.update(existing.id, {
        event_type: eventType,
        request_status: eventType === 'request_rejected' ? 'rechazada' : 'vencida',
        counts_for_acceptance_denominator: true,
        counts_for_acceptance_numerator: false,
        ...(eventType === 'request_rejected' ? { responded_at: nowIso } : { expired_at: nowIso }),
      });
    }
    return await evtEntity.create({
      event_key: primaryKey,
      mobile_id: mobile.id,
      mobile_name: mobile.name || 'Conductor',
      driver_email: driverEmail,
      service_id: service.id,
      event_type: eventType,
      request_status: eventType === 'request_rejected' ? 'rechazada' : 'vencida',
      counts_for_acceptance_denominator: true,
      counts_for_acceptance_numerator: false,
      counts_for_cancellation_denominator: false,
      counts_for_cancellation_numerator: false,
      received_at: service.created_date || nowIso,
      ...(eventType === 'request_rejected' ? { responded_at: nowIso } : { expired_at: nowIso }),
      pickup_address: service.pickup_address || '',
      destination_address: service.destination_address || '',
      technical_failure: false,
      justified: false,
      justification_status: 'no_aplica',
    });
  }

  // Caso 4: Solicitud aceptada / asignada / completada
  if (
    eventType === 'request_accepted' ||
    eventType === 'service_assigned' ||
    eventType === 'service_completed'
  ) {
    const reqStatus = eventType === 'service_completed' ? 'completada' : 'asignada';
    if (existing) {
      // Si ya tenía una cancelación del conductor registrada en este servicio, no borrarla salvo que haya completado
      const keepDriverCancel =
        existing.event_type === 'cancelled_by_driver' && eventType !== 'service_completed';
      return await evtEntity.update(existing.id, {
        event_type: keepDriverCancel ? 'cancelled_by_driver' : eventType,
        request_status: keepDriverCancel ? 'cancelada_conductor' : reqStatus,
        counts_for_acceptance_denominator: true,
        counts_for_acceptance_numerator: true,
        counts_for_cancellation_denominator: true,
        counts_for_cancellation_numerator: keepDriverCancel
          ? !existing.justified && !existing.technical_failure
          : false,
        responded_at: existing.responded_at || nowIso,
      });
    }
    return await evtEntity.create({
      event_key: primaryKey,
      mobile_id: mobile.id,
      mobile_name: mobile.name || 'Conductor',
      driver_email: driverEmail,
      service_id: service.id,
      event_type: eventType,
      request_status: reqStatus,
      counts_for_acceptance_denominator: true,
      counts_for_acceptance_numerator: true,
      counts_for_cancellation_denominator: true,
      counts_for_cancellation_numerator: false,
      received_at: service.created_date || nowIso,
      responded_at: nowIso,
      pickup_address: service.pickup_address || '',
      destination_address: service.destination_address || '',
      technical_failure: false,
      justified: false,
      justification_status: 'no_aplica',
    });
  }

  // Caso 5: Cancelado por el pasajero después de asignado -> NO perjudica al conductor
  if (eventType === 'cancelled_by_passenger' || cancelledBy === 'pasajero') {
    if (existing) {
      return await evtEntity.update(existing.id, {
        event_type: 'cancelled_by_passenger',
        request_status: 'cancelada_pasajero',
        counts_for_acceptance_denominator: true,
        counts_for_acceptance_numerator: true,
        counts_for_cancellation_denominator: true,
        counts_for_cancellation_numerator: false,
        cancelled_by: 'pasajero',
        cancelled_at: nowIso,
        cancel_reason: cancelReason || service.cancel_reason || 'cancelado_por_pasajero',
      });
    }
    return await evtEntity.create({
      event_key: primaryKey,
      mobile_id: mobile.id,
      mobile_name: mobile.name || 'Conductor',
      driver_email: driverEmail,
      service_id: service.id,
      event_type: 'cancelled_by_passenger',
      request_status: 'cancelada_pasajero',
      counts_for_acceptance_denominator: true,
      counts_for_acceptance_numerator: true,
      counts_for_cancellation_denominator: true,
      counts_for_cancellation_numerator: false,
      received_at: service.created_date || nowIso,
      responded_at: nowIso,
      cancelled_by: 'pasajero',
      cancelled_at: nowIso,
      cancel_reason: cancelReason || service.cancel_reason || 'cancelado_por_pasajero',
      pickup_address: service.pickup_address || '',
      destination_address: service.destination_address || '',
      technical_failure: false,
      justified: false,
      justification_status: 'no_aplica',
    });
  }

  // Caso 6: Cancelado o liberado por el conductor después de haber aceptado el servicio
  if (eventType === 'cancelled_by_driver' || cancelledBy === 'conductor') {
    if (existing) {
      // Idempotencia: si ya estaba registrado como cancelado por el conductor para este servicio, no duplicar.
      // Si un administrador ya lo había marcado como justificado, respetar su justificación.
      const isAlreadyJustified = Boolean(existing.justified || existing.justification_status === 'justificada');
      return await evtEntity.update(existing.id, {
        event_type: 'cancelled_by_driver',
        request_status: 'cancelada_conductor',
        counts_for_acceptance_denominator: true,
        counts_for_acceptance_numerator: true,
        counts_for_cancellation_denominator: true,
        counts_for_cancellation_numerator: !isAlreadyJustified && !existing.technical_failure,
        cancelled_by: 'conductor',
        cancelled_at: existing.cancelled_at || nowIso,
        cancel_reason: cancelReason || existing.cancel_reason || service.cancel_reason || 'liberado_por_conductor',
        justification_status: isAlreadyJustified ? 'justificada' : existing.justification_status === 'no_aplica' ? 'sin_revisar' : existing.justification_status,
      });
    }
    return await evtEntity.create({
      event_key: primaryKey,
      mobile_id: mobile.id,
      mobile_name: mobile.name || 'Conductor',
      driver_email: driverEmail,
      service_id: service.id,
      event_type: 'cancelled_by_driver',
      request_status: 'cancelada_conductor',
      counts_for_acceptance_denominator: true,
      counts_for_acceptance_numerator: true,
      counts_for_cancellation_denominator: true,
      counts_for_cancellation_numerator: true,
      received_at: service.created_date || nowIso,
      responded_at: nowIso,
      cancelled_by: 'conductor',
      cancelled_at: nowIso,
      cancel_reason: cancelReason || service.cancel_reason || 'liberado_por_conductor',
      pickup_address: service.pickup_address || '',
      destination_address: service.destination_address || '',
      technical_failure: false,
      justified: false,
      justification_status: 'sin_revisar',
    });
  }

  return existing;
}

/**
 * Calcula los indicadores de un periodo dado a partir de la lista unificada de eventos reales del conductor.
 */
function computeWindowMetrics(
  unifiedEvents: any[],
  completedServicesList: any[],
  cutoffMs: number | null
) {
  const inWindowEvents = cutoffMs
    ? unifiedEvents.filter((ev) => {
        const dt = parseIsoDate(ev.received_at || ev.created_date);
        return dt ? dt.getTime() >= cutoffMs : false;
      })
    : unifiedEvents;

  const inWindowCompleted = cutoffMs
    ? completedServicesList.filter((s) => {
        const dt = parseIsoDate(s.created_date);
        return dt ? dt.getTime() >= cutoffMs : false;
      })
    : completedServicesList;

  let validRequestsReceived = 0;
  let validRequestsAccepted = 0;
  let validRequestsRejected = 0;
  let validRequestsExpired = 0;
  let offersNotSelected = 0;

  let acceptedServicesCount = 0;
  let driverCancellationsTotal = 0;
  let driverCancellationsJustified = 0;
  let driverCancellationsPenalized = 0;
  let passengerCancellations = 0;

  for (const ev of inWindowEvents) {
    if (ev.technical_failure) continue;

    if (ev.event_type === 'offer_sent' || ev.event_type === 'offer_not_selected') {
      offersNotSelected += 1;
      continue;
    }

    if (ev.counts_for_acceptance_denominator) {
      validRequestsReceived += 1;
      if (ev.counts_for_acceptance_numerator) {
        validRequestsAccepted += 1;
      } else if (ev.event_type === 'request_rejected') {
        validRequestsRejected += 1;
      } else if (ev.event_type === 'request_expired') {
        validRequestsExpired += 1;
      }
    }

    if (ev.counts_for_cancellation_denominator) {
      acceptedServicesCount += 1;
      if (ev.cancelled_by === 'conductor' || ev.event_type === 'cancelled_by_driver') {
        driverCancellationsTotal += 1;
        if (ev.justified || ev.justification_status === 'justificada') {
          driverCancellationsJustified += 1;
        } else if (ev.counts_for_cancellation_numerator) {
          driverCancellationsPenalized += 1;
        }
      } else if (ev.cancelled_by === 'pasajero' || ev.event_type === 'cancelled_by_passenger') {
        passengerCancellations += 1;
      }
    }
  }

  const acceptanceRate =
    validRequestsReceived > 0
      ? round1((validRequestsAccepted / validRequestsReceived) * 100)
      : 100;

  const cancellationRate =
    acceptedServicesCount > 0
      ? round1((driverCancellationsPenalized / acceptedServicesCount) * 100)
      : 0;

  // Calificaciones reales de pasajeros en la ventana
  const ratedInWindow = inWindowCompleted.filter(
    (s) => typeof s.rating === 'number' && s.rating > 0
  );
  const ratingsCount = ratedInWindow.length;
  const avgRating =
    ratingsCount > 0
      ? round1(ratedInWindow.reduce((acc, s) => acc + Number(s.rating || 0), 0) / ratingsCount)
      : 0;

  const validSampleCount = Math.max(validRequestsReceived, acceptedServicesCount);
  const hasMinimumSample = validSampleCount >= MIN_VALID_SAMPLE;

  return {
    validRequestsReceived,
    validRequestsAccepted,
    validRequestsRejected,
    validRequestsExpired,
    offersNotSelected,
    acceptanceRate,
    acceptedServicesCount,
    driverCancellationsTotal,
    driverCancellationsJustified,
    driverCancellationsPenalized,
    passengerCancellations,
    cancellationRate,
    completedCount: inWindowCompleted.length,
    ratingsCount,
    avgRating,
    validSampleCount,
    hasMinimumSample,
  };
}

/**
 * Evalúa y sincroniza el Nivel (Trayectoria) y el Rendimiento (Reciente) de un conductor en el backend.
 * Garantiza que:
 * - Los servicios completados y días conectados históricos jamás disminuyan.
 * - Las decisiones de ascenso/descenso usen la ventana móvil de 30 días y exijan >= 20 registros válidos.
 * - Nunca se baje de nivel de inmediato por un mal día: se active un periodo de recuperación de 7 días.
 * - Si no recupera tras 7 días, baje al nivel inmediato inferior que sí cumpla (ej. Oro -> Plata).
 */
export async function evaluateAndSyncDriverLevel(base44: any, mobileId: string) {
  const mobEntity = base44.asServiceRole.entities.Mobile;
  const srvEntity = base44.asServiceRole.entities.Service;
  const checkInEntity = base44.asServiceRole.entities.DriverCheckIn;
  const evtEntity = base44.asServiceRole.entities.DriverPerformanceEvent;
  const histEntity = base44.asServiceRole.entities.DriverLevelHistory;

  const mobile = await mobEntity.get(mobileId).catch(() => null);
  if (!mobile) return null;

  // 1. Consultar datos reales del conductor en paralelo
  const [completedRes, checkInsRes, driverEventsRes, assignedOrCancelledRes, rejectedServicesRes] =
    await Promise.all([
      srvEntity.filter({ mobile_id: mobileId, status: 'finalizado' }, '-created_date', 500).catch(() => []),
      checkInEntity.filter({ mobile_id: mobileId }, '-date', 500).catch(() => []),
      evtEntity.filter({ mobile_id: mobileId }, '-created_date', 500).catch(() => []),
      srvEntity
        .filter(
          { mobile_id: mobileId, status: { $in: ['asignado', 'en_camino', 'recogida', 'cancelado'] } },
          '-created_date',
          300
        )
        .catch(() => []),
      srvEntity
        .filter({ rejected_by: mobileId }, '-created_date', 200)
        .catch(() => []),
    ]);

  const completedServices = Array.isArray(completedRes) ? completedRes : completedRes?.items || [];
  const checkIns = Array.isArray(checkInsRes) ? checkInsRes : checkInsRes?.items || [];
  const storedEvents = Array.isArray(driverEventsRes) ? driverEventsRes : driverEventsRes?.items || [];
  const assignedOrCancelled = Array.isArray(assignedOrCancelledRes)
    ? assignedOrCancelledRes
    : assignedOrCancelledRes?.items || [];
  const rejectedServices = Array.isArray(rejectedServicesRes)
    ? rejectedServicesRes
    : rejectedServicesRes?.items || [];

  // 2. Calcular trayectoria acumulada histórica (NUNCA disminuye)
  const uniqueDays = new Set<string>();
  for (const c of checkIns) {
    if (c?.date) uniqueDays.add(String(c.date).slice(0, 10));
  }
  for (const s of completedServices) {
    const dt = parseIsoDate(s?.created_date);
    if (dt) uniqueDays.add(toBogotaDateStr(dt));
  }

  const totalCompletedCount = await srvEntity
    .count({ mobile_id: mobileId, status: 'finalizado' })
    .catch(() => completedServices.length);

  const completedHistorical = Math.max(
    Number(mobile.total_completed_services || 0),
    Number(totalCompletedCount || 0),
    completedServices.length
  );
  const connectedDaysHistorical = Math.max(
    Number(mobile.total_connected_days || 0),
    uniqueDays.size
  );

  // 3. Unificar eventos registrados en DriverPerformanceEvent con los servicios reales existentes (sin duplicar por service_id)
  const eventsByServiceId = new Map<string, any>();
  for (const ev of storedEvents) {
    if (!ev?.service_id) continue;
    if (!eventsByServiceId.has(ev.service_id)) {
      eventsByServiceId.set(ev.service_id, ev);
    }
  }

  // Integrar servicios finalizados históricos que aún no tenían fila en DriverPerformanceEvent
  for (const s of completedServices) {
    if (!s?.id || eventsByServiceId.has(s.id)) continue;
    eventsByServiceId.set(s.id, {
      service_id: s.id,
      mobile_id: mobileId,
      event_type: 'service_completed',
      request_status: 'completada',
      counts_for_acceptance_denominator: true,
      counts_for_acceptance_numerator: true,
      counts_for_cancellation_denominator: true,
      counts_for_cancellation_numerator: false,
      cancelled_by: 'ninguno',
      received_at: s.created_date,
      responded_at: s.updated_date || s.created_date,
      technical_failure: false,
      justified: false,
      justification_status: 'no_aplica',
    });
  }

  // Integrar servicios en curso o cancelados donde el conductor estuvo asignado
  const driverCancelReasons = new Set([
    'sin_combustible',
    'llanta_pinchada',
    'llama_pinchada',
    'emergencia',
    'vehiculo_no_enciende',
    'celular_sin_bateria',
  ]);
  for (const s of assignedOrCancelled) {
    if (!s?.id || eventsByServiceId.has(s.id)) continue;
    const isCancelled = s.status === 'cancelado';
    const isByDriver =
      isCancelled &&
      (s.cancelled_by === 'conductor' || driverCancelReasons.has(String(s.cancel_reason || '')));
    eventsByServiceId.set(s.id, {
      service_id: s.id,
      mobile_id: mobileId,
      event_type: isCancelled
        ? isByDriver
          ? 'cancelled_by_driver'
          : 'cancelled_by_passenger'
        : 'service_assigned',
      request_status: isCancelled
        ? isByDriver
          ? 'cancelada_conductor'
          : 'cancelada_pasajero'
        : 'asignada',
      counts_for_acceptance_denominator: true,
      counts_for_acceptance_numerator: true,
      counts_for_cancellation_denominator: true,
      counts_for_cancellation_numerator: isByDriver,
      cancelled_by: isCancelled ? (isByDriver ? 'conductor' : 'pasajero') : 'ninguno',
      cancel_reason: s.cancel_reason || '',
      received_at: s.created_date,
      responded_at: s.updated_date || s.created_date,
      technical_failure: false,
      justified: false,
      justification_status: isByDriver ? 'sin_revisar' : 'no_aplica',
    });
  }

  // Integrar rechazos explícitos compatibles
  for (const s of rejectedServices) {
    if (!s?.id || eventsByServiceId.has(s.id)) continue;
    if (!isServiceForDriver(s, mobile)) continue;
    eventsByServiceId.set(s.id, {
      service_id: s.id,
      mobile_id: mobileId,
      event_type: 'request_rejected',
      request_status: 'rechazada',
      counts_for_acceptance_denominator: true,
      counts_for_acceptance_numerator: false,
      counts_for_cancellation_denominator: false,
      counts_for_cancellation_numerator: false,
      cancelled_by: 'ninguno',
      received_at: s.created_date,
      responded_at: s.updated_date || s.created_date,
      technical_failure: false,
      justified: false,
      justification_status: 'no_aplica',
    });
  }

  const unifiedEvents = Array.from(eventsByServiceId.values());
  const nowMs = Date.now();
  const nowIso = new Date(nowMs).toISOString();

  // 4. Calcular métricas para los 4 periodos consultables: 7d, 30d, 90d y all
  const metrics7d = computeWindowMetrics(unifiedEvents, completedServices, nowMs - 7 * 86400000);
  const metrics30d = computeWindowMetrics(unifiedEvents, completedServices, nowMs - 30 * 86400000);
  const metrics90d = computeWindowMetrics(unifiedEvents, completedServices, nowMs - 90 * 86400000);
  const metricsAll = computeWindowMetrics(unifiedEvents, completedServices, null);

  // Evolución reciente (últimos 7 días día por día)
  const dailyEvolution: any[] = [];
  for (let i = 6; i >= 0; i--) {
    const dayDate = new Date(nowMs - i * 86400000);
    const dayStr = toBogotaDateStr(dayDate);
    const dayCompleted = completedServices.filter((s) => {
      const dt = parseIsoDate(s.created_date);
      return dt && toBogotaDateStr(dt) === dayStr;
    }).length;
    const dayEvents = unifiedEvents.filter((ev) => {
      const dt = parseIsoDate(ev.received_at || ev.created_date);
      return dt && toBogotaDateStr(dt) === dayStr;
    });
    const dayAccepted = dayEvents.filter((e) => e.counts_for_acceptance_numerator).length;
    const dayReceived = dayEvents.filter((e) => e.counts_for_acceptance_denominator).length;
    const dayDriverCancels = dayEvents.filter(
      (e) => e.counts_for_cancellation_numerator && !e.justified && !e.technical_failure
    ).length;
    dailyEvolution.push({
      date: dayStr,
      label: dayDate.toLocaleDateString('es-CO', { weekday: 'short', day: 'numeric', timeZone: 'America/Bogota' }),
      completed: dayCompleted,
      accepted: dayAccepted,
      received: dayReceived,
      driverCancels: dayDriverCancels,
    });
  }

  // 5. Lógica Híbrida de Nivel, Ascenso, Advertencia y Recuperación de 7 Días (usando ventana móvil de 30 días)
  const prevLevel =
    mobile.current_level && LEVEL_SPECS[mobile.current_level]
      ? mobile.current_level
      : 'bronce';
  let newLevel = prevLevel;
  let recoveryActive = Boolean(mobile.recovery_active);
  let recoveryStartedAt = mobile.recovery_started_at || null;
  let recoveryEndsAt = mobile.recovery_ends_at || null;
  let recoveryReason = mobile.recovery_reason || '';
  let recoveryFailingMetrics: string[] = Array.isArray(mobile.recovery_failing_metrics)
    ? mobile.recovery_failing_metrics
    : [];
  let priorityBenefitsActive = true;

  const hasMinSample30d = metrics30d.hasMinimumSample;
  const acc30 = metrics30d.acceptanceRate;
  const cancel30 = metrics30d.cancellationRate;

  const qualifiesOroFull = checkMeetsFullLevel(
    'oro',
    completedHistorical,
    connectedDaysHistorical,
    acc30,
    cancel30,
    hasMinSample30d
  );
  const qualifiesPlataFull = checkMeetsFullLevel(
    'plata',
    completedHistorical,
    connectedDaysHistorical,
    acc30,
    cancel30,
    hasMinSample30d
  );

  const targetPromotionLevel = qualifiesOroFull
    ? 'oro'
    : qualifiesPlataFull
      ? 'plata'
      : 'bronce';

  // Caso A: ASCENSO AUTOMÁTICO cuando cumple TODOS los requisitos de un nivel superior (servicios + días + aceptación + cancelación + muestra >= 20)
  if (LEVEL_SPECS[targetPromotionLevel].order > LEVEL_SPECS[prevLevel].order) {
    newLevel = targetPromotionLevel;
    recoveryActive = false;
    recoveryStartedAt = null;
    recoveryEndsAt = null;
    recoveryReason = '';
    recoveryFailingMetrics = [];
    priorityBenefitsActive = true;

    const spec = LEVEL_SPECS[newLevel];
    await histEntity
      .create({
        mobile_id: mobile.id,
        mobile_name: mobile.name || 'Conductor',
        driver_email: (mobile.email || '').trim().toLowerCase(),
        change_type: 'ascenso',
        previous_level: prevLevel,
        new_level: newLevel,
        reason: `Ascenso automático a Nivel ${spec.name}: cumpliste ${completedHistorical} servicios completados, ${connectedDaysHistorical} días conectados, ${acc30}% de aceptación y ${cancel30}% de cancelaciones.`,
        completed_services: completedHistorical,
        connected_days: connectedDaysHistorical,
        acceptance_rate: acc30,
        cancellation_rate: cancel30,
        avg_rating: metricsAll.avgRating,
        sample_size: metrics30d.validSampleCount,
      })
      .catch(() => {});

    await createNotificationOnce(base44, {
      mobile,
      dedupeKey: `level_up_${newLevel}_${completedHistorical >= 300 ? '300' : '100'}`,
      category: 'ascenso_nivel',
      title: `🏆 ¡Felicitaciones! Subiste a Nivel ${spec.name}`,
      message: `Alcanzaste todos los requisitos de trayectoria (${completedHistorical} servicios y ${connectedDaysHistorical} días conectados) y de rendimiento (${acc30}% de aceptación y ${cancel30}% de cancelaciones). Ya tienes activa tu ${spec.priorityLabel.toLowerCase()}.`,
      howToImprove: `Mantén tu aceptación en mínimo ${spec.minAcceptance}% y tus cancelaciones en máximo ${spec.maxCancellation}% para conservar tus beneficios.`,
      levelContext: newLevel,
    });
  } else if (prevLevel !== 'bronce' && hasMinSample30d) {
    // Caso B: EVALUACIÓN DE MANTENIMIENTO / RECUPERACIÓN / DESCENSO para conductores en Plata u Oro
    const currentSpec = LEVEL_SPECS[prevLevel];
    const meetsCurrentPerf = checkMeetsLevelPerformance(
      prevLevel,
      acc30,
      cancel30,
      hasMinSample30d
    );

    if (meetsCurrentPerf) {
      // Si estaba en periodo de recuperación y ya recuperó sus indicadores -> cancelar advertencia
      if (recoveryActive) {
        recoveryActive = false;
        recoveryStartedAt = null;
        recoveryEndsAt = null;
        recoveryReason = '';
        recoveryFailingMetrics = [];
        priorityBenefitsActive = true;

        await histEntity
          .create({
            mobile_id: mobile.id,
            mobile_name: mobile.name || 'Conductor',
            driver_email: (mobile.email || '').trim().toLowerCase(),
            change_type: 'recuperacion_exitosa',
            previous_level: prevLevel,
            new_level: prevLevel,
            reason: `Recuperaste tus indicadores de Nivel ${currentSpec.name} (${acc30}% aceptación, ${cancel30}% cancelación). Se canceló la advertencia.`,
            completed_services: completedHistorical,
            connected_days: connectedDaysHistorical,
            acceptance_rate: acc30,
            cancellation_rate: cancel30,
            avg_rating: metricsAll.avgRating,
            sample_size: metrics30d.validSampleCount,
          })
          .catch(() => {});

        await createNotificationOnce(base44, {
          mobile,
          dedupeKey: `recovery_resolved_${prevLevel}_${nowIso.slice(0, 10)}`,
          category: 'rendimiento_recuperado',
          title: `✅ ¡Rendimiento recuperado! Conservas tu Nivel ${currentSpec.name}`,
          message: `Tus indicadores volvieron a cumplir los requisitos de Nivel ${currentSpec.name} (${acc30}% de aceptación y ${cancel30}% de cancelaciones). Tu periodo de recuperación finalizó con éxito.`,
          howToImprove: 'Sigue manteniendo este excelente ritmo de servicio.',
          levelContext: prevLevel,
        });
      }
    } else {
      // No cumple el rendimiento requerido por su nivel actual (Plata u Oro)
      const failingList: string[] = [];
      const detailsList: string[] = [];
      if (acc30 < currentSpec.minAcceptance) {
        const diffAcc = round1(currentSpec.minAcceptance - acc30);
        failingList.push('aceptacion');
        detailsList.push(
          `Aceptación actual: ${acc30}% (mínimo exigido en ${currentSpec.name}: ${currentSpec.minAcceptance}%, necesitas subir +${diffAcc}%)`
        );
      }
      if (cancel30 > currentSpec.maxCancellation) {
        const diffCancel = round1(cancel30 - currentSpec.maxCancellation);
        failingList.push('cancelacion');
        detailsList.push(
          `Cancelación actual: ${cancel30}% (máximo permitido en ${currentSpec.name}: ${currentSpec.maxCancellation}%, necesitas bajar -${diffCancel}%)`
        );
      }
      const explanation = detailsList.join(' · ');

      if (!recoveryActive || !recoveryEndsAt) {
        // 1. Iniciar periodo de recuperación de 7 días (nunca bajar de inmediato por un mal día)
        const startDt = new Date(nowMs);
        const endDt = new Date(nowMs + RECOVERY_PERIOD_MS);
        recoveryActive = true;
        recoveryStartedAt = startDt.toISOString();
        recoveryEndsAt = endDt.toISOString();
        recoveryReason = explanation;
        recoveryFailingMetrics = failingList;
        priorityBenefitsActive = true; // Durante los 7 días conserva su nivel y oportunidad de recuperarse

        await histEntity
          .create({
            mobile_id: mobile.id,
            mobile_name: mobile.name || 'Conductor',
            driver_email: (mobile.email || '').trim().toLowerCase(),
            change_type: 'inicio_recuperacion',
            previous_level: prevLevel,
            new_level: prevLevel,
            reason: `Inicio de periodo de recuperación de 7 días en Nivel ${currentSpec.name}. ${explanation}`,
            completed_services: completedHistorical,
            connected_days: connectedDaysHistorical,
            acceptance_rate: acc30,
            cancellation_rate: cancel30,
            avg_rating: metricsAll.avgRating,
            sample_size: metrics30d.validSampleCount,
            recovery_started_at: recoveryStartedAt,
            recovery_ends_at: recoveryEndsAt,
          })
          .catch(() => {});

        await createNotificationOnce(base44, {
          mobile,
          dedupeKey: `recovery_start_${prevLevel}_${recoveryStartedAt.slice(0, 10)}`,
          category: 'inicio_recuperacion',
          title: `⏳ Periodo de recuperación de 7 días (Nivel ${currentSpec.name})`,
          message: `Notamos que tu rendimiento reciente está por debajo de los requisitos de Nivel ${currentSpec.name}. ${explanation}. Tienes 7 días para recuperar tus indicadores sin perder tu nivel.`,
          howToImprove: `Acepta las solicitudes compatibles que recibas y evita cancelar servicios ya aceptados para volver a ${currentSpec.minAcceptance}% de aceptación y máximo ${currentSpec.maxCancellation}% de cancelaciones.`,
          levelContext: prevLevel,
        });
      } else {
        // Ya está en periodo de recuperación: verificar si vencieron los 7 días
        const endDt = parseIsoDate(recoveryEndsAt);
        const endMs = endDt ? endDt.getTime() : nowMs + RECOVERY_PERIOD_MS;

        if (nowMs >= endMs) {
          // 7. Vencieron los 7 días sin recuperar -> evaluar el nivel inferior que sí cumple
          // Ejemplo: Oro que no cumple Oro pero sí cumple Plata -> pasa a Plata, NO directamente a Bronce.
          let fallbackLevel = 'bronce';
          if (
            prevLevel === 'oro' &&
            checkMeetsFullLevel(
              'plata',
              completedHistorical,
              connectedDaysHistorical,
              acc30,
              cancel30,
              hasMinSample30d
            )
          ) {
            fallbackLevel = 'plata';
          }

          newLevel = fallbackLevel;
          recoveryActive = false;
          recoveryStartedAt = null;
          recoveryEndsAt = null;
          recoveryReason = '';
          recoveryFailingMetrics = [];
          priorityBenefitsActive = newLevel !== 'bronce';

          const prevSpec = LEVEL_SPECS[prevLevel];
          const nextSpec = LEVEL_SPECS[newLevel];

          await histEntity
            .create({
              mobile_id: mobile.id,
              mobile_name: mobile.name || 'Conductor',
              driver_email: (mobile.email || '').trim().toLowerCase(),
              change_type: 'descenso',
              previous_level: prevLevel,
              new_level: newLevel,
              reason: `Finalizó el periodo de recuperación de 7 días sin alcanzar los requisitos de Nivel ${prevSpec.name} (${explanation}). Pasas a Nivel ${nextSpec.name} conservando intactos tus ${completedHistorical} servicios y ${connectedDaysHistorical} días conectados históricos.`,
              completed_services: completedHistorical,
              connected_days: connectedDaysHistorical,
              acceptance_rate: acc30,
              cancellation_rate: cancel30,
              avg_rating: metricsAll.avgRating,
              sample_size: metrics30d.validSampleCount,
            })
            .catch(() => {});

          await createNotificationOnce(base44, {
            mobile,
            dedupeKey: `level_down_${prevLevel}_to_${newLevel}_${nowIso.slice(0, 10)}`,
            category: 'descenso_nivel',
            title: `Actualización de tu nivel: Nivel ${nextSpec.name}`,
            message: `Finalizó el periodo de recuperación de 7 días y tus indicadores recientes (${acc30}% aceptación, ${cancel30}% cancelación) no alcanzaron lo requerido para Nivel ${prevSpec.name}. Tu cuenta pasa a Nivel ${nextSpec.name}. Tus ${completedHistorical} servicios y ${connectedDaysHistorical} días conectados históricos se conservan intactos.`,
            howToImprove: `Como ya tienes la trayectoria acumulada (${completedHistorical} servicios y ${connectedDaysHistorical} días), en cuanto subas tu aceptación a ${prevSpec.minAcceptance}% y mantengas tus cancelaciones en máximo ${prevSpec.maxCancellation}%, volverás automáticamente a Nivel ${prevSpec.name}.`,
            levelContext: newLevel,
          });
        } else {
          // Sigue dentro de los 7 días de recuperación -> actualizar detalle y enviar recordatorio no repetitivo cuando falten 3 o 1 día
          recoveryReason = explanation;
          recoveryFailingMetrics = failingList;
          const daysRemaining = Math.max(1, Math.ceil((endMs - nowMs) / 86400000));
          if (daysRemaining === 3 || daysRemaining === 1) {
            await createNotificationOnce(base44, {
              mobile,
              dedupeKey: `recovery_rem_${prevLevel}_${daysRemaining}d_${(recoveryStartedAt || '').slice(0, 10)}`,
              category: 'recordatorio_recuperacion',
              title: `⏳ Te ${daysRemaining === 1 ? 'queda 1 día' : `quedan ${daysRemaining} días`} de recuperación (Nivel ${currentSpec.name})`,
              message: `Recuerda que estás en periodo de recuperación para conservar tu Nivel ${currentSpec.name}. Estado actual: ${explanation}.`,
              howToImprove: `Completa tus próximos servicios sin cancelaciones para alcanzar ${currentSpec.minAcceptance}% de aceptación y <= ${currentSpec.maxCancellation}% de cancelaciones.`,
              levelContext: prevLevel,
            });
          }
        }
      }
    }
  }

  // 6. Notificaciones preventivas y de reconocimiento (sin duplicar)
  const nextLevelId = newLevel === 'bronce' ? 'plata' : newLevel === 'plata' ? 'oro' : null;
  if (nextLevelId) {
    const nextSpec = LEVEL_SPECS[nextLevelId];
    const servicesLeft = Math.max(0, nextSpec.minServices - completedHistorical);
    const daysLeft = Math.max(0, nextSpec.minDays - connectedDaysHistorical);
    if (servicesLeft <= 15 && daysLeft <= 3 && (servicesLeft > 0 || daysLeft > 0)) {
      await createNotificationOnce(base44, {
        mobile,
        dedupeKey: `near_level_${nextLevelId}_${Math.floor(completedHistorical / 10)}`,
        category: 'cerca_de_subir',
        title: `🚀 ¡Estás muy cerca de subir a Nivel ${nextSpec.name}!`,
        message: `Llevas ${completedHistorical}/${nextSpec.minServices} servicios completados y ${connectedDaysHistorical}/${nextSpec.minDays} días conectados.`,
        howToImprove: `Asegúrate también de mantener al menos ${nextSpec.minAcceptance}% de aceptación y máximo ${nextSpec.maxCancellation}% de cancelaciones.`,
        levelContext: newLevel,
      });
    }
  }

  if (hasMinSample30d && acc30 >= 92 && cancel30 <= 2 && completedHistorical >= 20) {
    await createNotificationOnce(base44, {
      mobile,
      dedupeKey: `great_perf_${nowIso.slice(0, 7)}`,
      category: 'buen_rendimiento',
      title: '🌟 ¡Excelente rendimiento este mes!',
      message: `Tu tasa de aceptación es del ${acc30}% y tus cancelaciones son solo del ${cancel30}%. ¡Gracias por brindar un servicio ejemplar en NEXT!`,
      howToImprove: 'Sigue así para aprovechar al máximo tus beneficios de prioridad.',
      levelContext: newLevel,
    });
  }

  const performanceStatus = derivePerformanceStatus({
    hasMinimumSample: hasMinSample30d,
    acceptanceRate: acc30,
    cancellationRate: cancel30,
    recoveryActive,
  });

  // 7. Persistir resumen actualizado en Mobile (solo campos del servidor)
  const mobilePatch = {
    current_level: newLevel,
    total_completed_services: completedHistorical,
    total_connected_days: connectedDaysHistorical,
    acceptance_rate_30d: acc30,
    cancellation_rate_30d: cancel30,
    valid_sample_count_30d: metrics30d.validSampleCount,
    performance_status: performanceStatus,
    priority_benefits_active: priorityBenefitsActive,
    recovery_active: recoveryActive,
    recovery_started_at: recoveryStartedAt,
    recovery_ends_at: recoveryEndsAt,
    recovery_reason: recoveryReason,
    recovery_failing_metrics: recoveryFailingMetrics,
    last_evaluated_at: nowIso,
  };

  await mobEntity.update(mobile.id, mobilePatch).catch(() => {});

  // Calcular días restantes de recuperación si está activo
  let recoveryDaysRemaining = 0;
  if (recoveryActive && recoveryEndsAt) {
    const endDt = parseIsoDate(recoveryEndsAt);
    if (endDt) {
      recoveryDaysRemaining = Math.max(0, Math.ceil((endDt.getTime() - nowMs) / 86400000));
    }
  }

  // Calcular requisitos pendientes para el siguiente nivel
  const nextSpec = nextLevelId ? LEVEL_SPECS[nextLevelId] : null;
  const pendingForNextLevel = nextSpec
    ? {
        nextLevelId: nextSpec.id,
        nextLevelName: nextSpec.name,
        servicesCompleted: completedHistorical,
        servicesRequired: nextSpec.minServices,
        servicesMissing: Math.max(0, nextSpec.minServices - completedHistorical),
        servicesMet: completedHistorical >= nextSpec.minServices,
        daysConnected: connectedDaysHistorical,
        daysRequired: nextSpec.minDays,
        daysMissing: Math.max(0, nextSpec.minDays - connectedDaysHistorical),
        daysMet: connectedDaysHistorical >= nextSpec.minDays,
        acceptanceCurrent: acc30,
        acceptanceRequired: nextSpec.minAcceptance,
        acceptanceDiff: Math.max(0, round1(nextSpec.minAcceptance - acc30)),
        acceptanceMet: hasMinSample30d && acc30 >= nextSpec.minAcceptance,
        cancellationCurrent: cancel30,
        cancellationMax: nextSpec.maxCancellation,
        cancellationDiff: Math.max(0, round1(cancel30 - nextSpec.maxCancellation)),
        cancellationMet: hasMinSample30d && cancel30 <= nextSpec.maxCancellation,
        sampleCurrent: metrics30d.validSampleCount,
        sampleRequired: MIN_VALID_SAMPLE,
        sampleMet: hasMinSample30d,
      }
    : null;

  return {
    mobileId: mobile.id,
    mobileName: mobile.name || 'Conductor',
    currentLevel: newLevel,
    currentLevelSpec: LEVEL_SPECS[newLevel],
    trajectory: {
      completedServices: completedHistorical,
      connectedDays: connectedDaysHistorical,
    },
    pendingForNextLevel,
    recovery: {
      active: recoveryActive,
      startedAt: recoveryStartedAt,
      endsAt: recoveryEndsAt,
      daysRemaining: recoveryDaysRemaining,
      reason: recoveryReason,
      failingMetrics: recoveryFailingMetrics,
    },
    priorityBenefitsActive,
    performanceStatus,
    minValidSample: MIN_VALID_SAMPLE,
    periods: {
      '7d': metrics7d,
      '30d': metrics30d,
      '90d': metrics90d,
      all: metricsAll,
    },
    dailyEvolution,
    driverCancellationEvents: storedEvents
      .filter((e) => e.cancelled_by === 'conductor' || e.event_type === 'cancelled_by_driver')
      .slice(0, 30),
  };
}
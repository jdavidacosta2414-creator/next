// Modelo de Pase de 14 horas laborales del conductor:
//  - Al recargar o activarse el pase en cualquier momento (`now`), el conductor recibe 14 horas continuas
//    a partir de ese instante (`now + 14 horas`) para tomar todos los servicios sin comisión por porcentaje,
//    incluso si esas 14 horas cruzan la medianoche hacia el día siguiente.
//  - Únicamente cuando se cumplen las 14 horas completas (`now >= pass_vence_en`), el pase vence y el saldo
//    se renueva automáticamente a $0.

export const COMMISSION_RATE = 0;
export const PASS_DURATION_HOURS = 14;
export const PASS_DURATION_MS = PASS_DURATION_HOURS * 60 * 60 * 1000;

// Fecha actual o de una fecha dada en formato YYYY-MM-DD en zona horaria de Bogotá.
export function getBogotaDateString(d: Date = new Date()): string {
  return d.toLocaleDateString('en-CA', { timeZone: 'America/Bogota' });
}

// Día en que fue activado el pase del conductor (YYYY-MM-DD en Bogotá).
export function getMobilePassDate(mobile: any): string | null {
  if (!mobile) return null;
  if (mobile.pass_activado_en) {
    try {
      return getBogotaDateString(new Date(mobile.pass_activado_en));
    } catch {}
  }
  if (typeof mobile.pass_date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(mobile.pass_date)) {
    return mobile.pass_date;
  }
  if (mobile.pass_vence_en) {
    try {
      return getBogotaDateString(new Date(new Date(mobile.pass_vence_en).getTime() - 1000));
    } catch {}
  }
  return null;
}

// Calcula la fecha/hora real de vencimiento del pase de 14 horas a partir de su activación.
export function passExpiry(mobile: any): Date | null {
  if (!mobile) return null;
  let fromActivated: Date | null = null;
  if (mobile.pass_activado_en) {
    const act = new Date(mobile.pass_activado_en);
    if (!Number.isNaN(act.getTime())) {
      fromActivated = new Date(act.getTime() + PASS_DURATION_MS);
    }
  }
  let fromVence: Date | null = null;
  if (mobile.pass_vence_en) {
    const v = new Date(mobile.pass_vence_en);
    if (!Number.isNaN(v.getTime())) {
      fromVence = v;
    }
  }
  if (fromActivated && fromVence) {
    return fromActivated.getTime() > fromVence.getTime() ? fromActivated : fromVence;
  }
  return fromVence || fromActivated;
}

// ¿El pase de 14 horas está vigente en este momento?
// Cuenta exactamente 14 horas a partir del momento de la recarga/activación, sin cortarse a medianoche.
export function isPassActive(mobile: any): boolean {
  if (!mobile) return false;
  const expiry = passExpiry(mobile);
  if (!expiry) return false;
  if (Date.now() >= expiry.getTime()) {
    return false;
  }
  return (mobile.balance ?? 0) > 0 || Boolean(mobile.pass_vence_en);
}

// Saldo efectivo del pase: mientras las 14 horas están activas muestra el monto; al cumplirse las 14h vuelve a 0.
export function getEffectiveBalance(mobile: any): number {
  if (!mobile) return 0;
  return isPassActive(mobile) ? Math.max(0, mobile.balance ?? 0) : 0;
}

// ¿El conductor puede tomar servicios ahora? Debe tener su pase de 14h activo y no estar bloqueado.
export function canWork(mobile: any): boolean {
  if (!mobile || mobile.blocked) return false;
  return isPassActive(mobile);
}

// Sin comisión por porcentaje en ningún servicio.
export function effectiveCommissionRate(_mobile: any): number {
  return 0;
}

// Calcula el vencimiento del pase: exactamente 14 horas continuas a partir del momento actual (`now + 14h`).
export function computePassExpiry(now: Date = new Date()): string {
  const expiry = new Date(now.getTime() + PASS_DURATION_MS);
  return expiry.toISOString();
}

export function isStaffRole(user: any): boolean {
  return Boolean(user && ['admin', 'superadmin', 'central'].includes(user.role));
}

export function isMobileOwner(mobile: any, user: any): boolean {
  if (!mobile || !user) return false;
  const mobEmail = typeof mobile.email === 'string' ? mobile.email.trim().toLowerCase() : '';
  const usrEmail = typeof user.email === 'string' ? user.email.trim().toLowerCase() : '';
  if (mobEmail && usrEmail && mobEmail === usrEmail) return true;
  if (mobile.created_by_id && user.id && mobile.created_by_id === user.id) return true;
  return false;
}

// Versión backend: valida que el llamante sea el titular del conductor (o staff) y tenga su pase de 14 horas vigente.
// Si ya se cumplieron las 14 horas, renueva su saldo a 0 automáticamente.
export async function assertCanWork(mobEntity: any, mobile_id: string, user?: any) {
  const mobile = await mobEntity.get(mobile_id).catch(() => null);
  if (!mobile) {
    return { ok: false, error: Response.json({ error: 'Conductor no encontrado' }, { status: 404 }) };
  }
  if (user && !isMobileOwner(mobile, user) && !isStaffRole(user)) {
    return {
      ok: false,
      error: Response.json({ error: 'No tienes permiso para operar este perfil de conductor' }, { status: 403 }),
    };
  }
  if (!isPassActive(mobile) && (mobile.balance ?? 0) > 0) {
    await mobEntity.update(mobile_id, { balance: 0, pass_mode: 'pase' }).catch(() => {});
    mobile.balance = 0;
  }
  if (!canWork(mobile)) {
    return {
      ok: false,
      error: Response.json(
        {
          error: 'Tus 14 horas laborales se cumplieron y tu saldo se renovó a $0. Debes recargar ($7.000 moto / $10.000 carro) para activar tus próximas 14 horas y seguir tomando servicios.',
          needs_recharge: true,
        },
        { status: 403 }
      ),
    };
  }
  return { ok: true, mobile };
}
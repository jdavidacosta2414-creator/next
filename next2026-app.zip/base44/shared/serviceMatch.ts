// Cada sección es individual: carro solo ve carro, moto solo ve transporte en moto
// y mensajero solo ve mensajería. Nunca se mezclan.
export function getServiceCategory(service: any) {
  if (service?.vehicle_type === 'carro') return 'carro';
  if (service?.service_type === 'mensajeria') return 'mensajero';
  return 'moto';
}

export function getDriverCategory(mobile: any) {
  if (mobile?.vehicle_type === 'carro') return 'carro';
  if (mobile?.driver_category === 'mensajero') return 'mensajero';
  return 'moto';
}

export function isServiceForDriver(service: any, mobile: any) {
  return getServiceCategory(service) === getDriverCategory(mobile);
}
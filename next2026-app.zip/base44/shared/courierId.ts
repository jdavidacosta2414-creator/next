import { getDriverCategory } from './serviceMatch.ts';

// ID corto, único y permanente de cada mensajero, y asignación directa de pedidos por ese ID.
//  - Cada mensajero tiene un solo registro en CourierId; su ID nunca cambia ni se reutiliza.
//  - Los IDs se entregan de a uno (turno general): dos mensajeros nunca reciben el mismo.
//  - Para asignar un pedido se toma el turno del mensajero: aunque varios comercios le envíen pedidos
//    en el mismo instante, sus cupos se cuentan uno por uno y nunca pasa del máximo.

export const MAX_ACTIVE_PER_COURIER = 3;
const ACTIVE = ['asignado', 'en_camino', 'recogida'];
const TURN_CODE = 'TURNO';
const TURN_MS = 15000;

const asList = (res: any) => (Array.isArray(res) ? res : res?.items || []);
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));
const randomCode = () => String(100000 + (crypto.getRandomValues(new Uint32Array(1))[0] % 900000));

// Toma el turno exclusivo de un registro: de varias solicitudes simultáneas solo una lo consigue y las demás
// esperan. Si la solicitud se cae, el turno vence solo. Devuelve cuándo vence, o null si no lo consiguió.
async function takeTurn(ids: any, rowId: string, tries: number) {
  for (let i = 0; i < tries; i++) {
    if (i > 0) await sleep(150 + Math.random() * 300);
    const now = Date.now();
    const res = await ids.updateMany({ id: rowId, lock_until: { $lt: now } }, { $set: { lock_until: now + TURN_MS } });
    if (res?.updated) return now + TURN_MS;
  }
  return null;
}

// Devuelve el turno. Si ya está por vencer no se toca, porque otra solicitud pudo haberlo tomado.
async function freeTurn(ids: any, rowId: string, until: number) {
  if (Date.now() < until - 5000) await ids.update(rowId, { lock_until: 0 }).catch(() => {});
}

// Registro único que sirve de turno general para entregar IDs nuevos.
async function generalTurnRow(ids: any) {
  const find = async () => asList(await ids.filter({ code: TURN_CODE }, { sort: 'created_date', limit: 1 }))[0];
  const row = await find();
  if (row) return row;
  await ids.create({
    code: TURN_CODE,
    mobile_name: 'Uso interno: turno para entregar IDs nuevos. No borrar.',
    lock_until: 0,
  });
  return await find();
}

// Devuelve el ID del mensajero; si aún no tiene, se lo entrega. null si el perfil no es de mensajería.
export async function ensureCourierId(sr: any, mobile: any) {
  if (!mobile?.id || getDriverCategory(mobile) !== 'mensajero') return null;
  const ids = sr.entities.CourierId;
  const current = async () =>
    asList(await ids.filter({ mobile_id: mobile.id }, { sort: 'created_date', limit: 1 }))[0]?.code || null;

  const existing = await current();
  if (existing) return existing;

  const turn = await generalTurnRow(ids);
  const until = await takeTurn(ids, turn.id, 20);
  if (!until) throw new Error('No se pudo entregar el ID de mensajero en este momento. Intenta de nuevo.');
  try {
    // Otra solicitud pudo entregárselo mientras se esperaba el turno.
    const again = await current();
    if (again) return again;
    for (let i = 0; i < 50; i++) {
      const code = randomCode();
      const taken = asList(await ids.filter({ code }, { limit: 1 })).length > 0;
      if (taken) continue;
      await ids.create({ code, mobile_id: mobile.id, mobile_name: mobile.name || '', lock_until: 0 });
      return code;
    }
    throw new Error('No se pudo generar un ID de mensajero libre.');
  } finally {
    await freeTurn(ids, turn.id, until);
  }
}

// Asigna un pedido nuevo al mensajero dueño del ID. Devuelve { service, mobile } si quedó asignado,
// { duplicate } si ese mismo pedido ya estaba asignado, o { rejected } si no se pudo: en ese caso el pedido
// no se crea, así que tampoco llega a otros mensajeros.
export async function assignToCourier(sr: any, rawCode: any, order: any) {
  const ids = sr.entities.CourierId;
  const rejected = (status: number, code: string, error: string) => ({ rejected: { status, code, error } });

  const code = String(rawCode ?? '').replace(/\D/g, '');
  const row = /^\d{6}$/.test(code)
    ? asList(await ids.filter({ code }, { sort: 'created_date', limit: 1 }))[0]
    : null;
  const mobile = row?.mobile_id
    ? await sr.entities.Mobile.get(row.mobile_id).catch((e: any) => (e.status === 404 ? null : Promise.reject(e)))
    : null;
  if (!mobile || getDriverCategory(mobile) !== 'mensajero') {
    return rejected(404, 'courier_not_found', 'No existe un mensajero con ese ID. El pedido no se creó.');
  }
  if (mobile.blocked || ['pendiente', 'rechazado'].includes(mobile.approval_status)) {
    return rejected(
      409,
      'courier_unavailable',
      'Ese mensajero no está habilitado para recibir pedidos. El pedido no se creó.'
    );
  }

  const until = await takeTurn(ids, row.id, 10);
  if (!until) {
    return rejected(
      503,
      'courier_busy',
      'NEXT le está asignando otro pedido a ese mensajero en este instante. Intenta de nuevo en unos segundos.'
    );
  }
  let service;
  try {
    // Cuenta todo lo que el mensajero tiene en curso, sin importar de qué comercio o de dónde vino.
    const active = asList(
      await sr.entities.Service.filter({ mobile_id: mobile.id, status: { $in: ACTIVE } }, { limit: 20 })
    );
    const twin = active.find(
      (s: any) => s.business_id === order.business_id && s.external_order_id === order.external_order_id
    );
    if (twin) return { duplicate: twin };
    if (active.length >= MAX_ACTIVE_PER_COURIER) {
      return rejected(
        409,
        'courier_full',
        `Ese mensajero ya tiene ${MAX_ACTIVE_PER_COURIER} servicios en curso, que es el máximo. El pedido no se creó.`
      );
    }
    service = await sr.entities.Service.create({
      ...order,
      status: 'asignado',
      mobile_id: mobile.id,
      mobile_name: mobile.name || '',
      mobile_plate: mobile.plate || '',
      mobile_phone: mobile.phone || '',
      mobile_photo: mobile.photo_url || mobile.vehicle_photo || '',
    });
  } finally {
    await freeTurn(ids, row.id, until);
  }

  // Con un pedido en curso el mensajero queda conectado, para que lo vea en su pestaña "En curso".
  if (mobile.status === 'offline') {
    await sr.entities.Mobile.update(mobile.id, { status: 'disponible' }).catch(() => {});
  }
  return { service, mobile };
}
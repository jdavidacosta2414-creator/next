// NEXT CLUB: reglas de puntos, viajes gratis, referidos y canjes. Todo se valida en servidor
// y los saldos se modifican con actualizaciones condicionales atómicas (sin saldos negativos ni dobles acreditaciones).

export const DEFAULT_CONFIG = {
  key: 'main',
  points_per_1000: 25,
  free_ride_every: 8,
  free_ride_max_value: 7000,
  referral_points_inviter: 100,
  referral_points_new: 100,
  referral_limit: 2,
  earn_enabled: true,
  gifts_enabled: true,
  food_enabled: true,
  free_ride_enabled: true,
  referrals_enabled: true,
};

const STAFF_ROLES = ['admin', 'superadmin', 'central'];
const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

export function isClubAdmin(user) {
  return user?.role === 'admin' || user?.role === 'superadmin';
}

export function calcPoints(amount, per1000 = 25) {
  const a = Math.max(0, Number(amount) || 0);
  return Math.floor((a * Number(per1000)) / 1000);
}

export function randomCode(len = 7) {
  const bytes = crypto.getRandomValues(new Uint8Array(len));
  return Array.from(bytes, (b) => CODE_ALPHABET[b % CODE_ALPHABET.length]).join('');
}

export function normalizePhone(p) {
  const d = String(p || '').replace(/\D/g, '');
  return d.length > 10 ? d.slice(-10) : d;
}

export async function getConfig(sr) {
  const list = await sr.entities.ClubConfig.filter({ key: 'main' }, '-created_date', 1);
  const cfg = Array.isArray(list) ? list[0] : list?.items?.[0];
  return { ...DEFAULT_CONFIG, ...(cfg || {}) };
}

export async function findAccount(sr, userId) {
  const list = await sr.entities.ClubAccount.filter({ user_id: userId }, 'created_date', 1);
  return (Array.isArray(list) ? list[0] : list?.items?.[0]) || null;
}

export async function ensureAccount(sr, user) {
  const existing = await findAccount(sr, user.id);
  if (existing) return existing;
  let code = randomCode();
  for (let i = 0; i < 4; i++) {
    const dup = await sr.entities.ClubAccount.count({ referral_code: code });
    if (!dup) break;
    code = randomCode();
  }
  await sr.entities.ClubAccount.create({
    user_id: user.id,
    user_email: user.email,
    user_name: user.display_name || user.full_name || user.email,
    user_phone: normalizePhone(user.phone),
    balance: 0,
    total_earned: 0,
    total_redeemed: 0,
    transport_rides_count: 0,
    delivery_count: 0,
    free_ride_cycle_count: 0,
    free_rides_earned: 0,
    processed_services: [],
    referral_code: code,
    referral_bonus_count: 0,
    referrals_total: 0,
  });
  // Releer por si se crearon dos cuentas en paralelo: siempre se usa la más antigua
  return await findAccount(sr, user.id);
}

export async function logTx(sr, accId, tx) {
  const acc = await sr.entities.ClubAccount.get(accId);
  return await sr.entities.ClubTransaction.create({
    ...tx,
    user_id: acc.user_id,
    user_name: acc.user_name,
    balance_after: Number(acc.balance || 0),
  });
}

// Acredita puntos (amount > 0) sin condiciones adicionales.
export async function creditPoints(sr, accId, amount, tx) {
  if (amount <= 0) return null;
  await sr.entities.ClubAccount.updateMany({ id: accId }, { $inc: { balance: amount, total_earned: amount } });
  return await logTx(sr, accId, { ...tx, amount });
}

// Descuenta puntos de forma atómica: solo si el saldo alcanza. Devuelve false si no hay saldo suficiente.
export async function debitPoints(sr, accId, amount, tx) {
  const res = await sr.entities.ClubAccount.updateMany(
    { id: accId, balance: { $gte: amount } },
    { $inc: { balance: -amount, total_redeemed: amount } }
  );
  if (!res?.updated) return false;
  await logTx(sr, accId, { ...tx, amount: -amount });
  return true;
}

export async function isInCoverage(sr, address) {
  const list = await sr.entities.CoverageZone.list('-created_date', 1);
  const zone = Array.isArray(list) ? list[0] : list?.items?.[0];
  if (!zone || !zone.active || !zone.neighborhoods?.length) return true;
  const lower = String(address || '').toLowerCase();
  return zone.neighborhoods.some((n) => lower.includes(String(n).toLowerCase()));
}

// Procesa un servicio finalizado: puntos, contador de viaje gratis y uso del viaje gratis. Idempotente.
export async function processServiceForClub(sr, service) {
  if (!service || service.status !== 'finalizado' || !service.created_by_id) return { skipped: 'not_eligible' };
  const creator = await sr.entities.User.get(service.created_by_id).catch(() => null);
  if (!creator || STAFF_ROLES.includes(creator.role)) return { skipped: 'no_passenger' };

  const cfg = await getConfig(sr);
  const acc = await ensureAccount(sr, creator);
  const isTransport = service.service_type !== 'mensajeria';
  const usedFreeRide = Boolean(service.free_ride_id);
  const legacyPoints = service.payment_method === 'redimido_puntos';
  const paid = Math.max(0, Number(service.collected_amount || service.fare || 0) - Number(service.free_ride_discount || 0));
  const points = cfg.earn_enabled && !usedFreeRide && !legacyPoints ? calcPoints(paid, cfg.points_per_1000) : 0;
  const countsForFree = isTransport && !usedFreeRide && !legacyPoints && paid > 0 ? 1 : 0;

  // Bloqueo atómico: el servicio solo se procesa una vez por cuenta
  const lock = await sr.entities.ClubAccount.updateMany(
    { id: acc.id, processed_services: { $ne: service.id } },
    {
      $addToSet: { processed_services: service.id },
      $inc: {
        balance: points,
        total_earned: points,
        transport_rides_count: countsForFree,
        free_ride_cycle_count: cfg.free_ride_enabled ? countsForFree : 0,
        delivery_count: isTransport ? 0 : 1,
      },
    }
  );
  if (!lock?.updated) return { skipped: 'already_processed' };

  if (points > 0) {
    await logTx(sr, acc.id, {
      type: isTransport ? 'carrera' : 'domicilio',
      amount: points,
      service_id: service.id,
      dedupe_key: `svc_${service.id}`,
      description: `${isTransport ? 'Carrera' : 'Domicilio'} de $${paid.toLocaleString('es-CO')}: ${service.pickup_address || ''} → ${service.destination_address || ''}`,
    });
    await sr.entities.Service.update(service.id, { club_points_awarded: points });
  }

  if (usedFreeRide) {
    await sr.entities.ClubFreeRide.updateMany(
      { id: service.free_ride_id, status: 'reservado', used_service_id: service.id },
      {
        $set: {
          status: 'usado',
          used_at: new Date().toISOString(),
          discount_applied: Number(service.free_ride_discount || 0),
        },
      }
    );
  }

  let freeRide = null;
  const every = Number(cfg.free_ride_every) || 8;
  if (cfg.free_ride_enabled && countsForFree) {
    const earn = await sr.entities.ClubAccount.updateMany(
      { id: acc.id, free_ride_cycle_count: { $gte: every } },
      { $inc: { free_ride_cycle_count: -every, free_rides_earned: 1 } }
    );
    if (earn?.updated) {
      const fresh = await sr.entities.ClubAccount.get(acc.id);
      freeRide = await sr.entities.ClubFreeRide.create({
        user_id: acc.user_id,
        user_name: acc.user_name,
        code: `VG-${randomCode(8)}`,
        status: 'disponible',
        max_value: Number(cfg.free_ride_max_value) || 7000,
        cycle_number: Number(fresh.free_rides_earned || 1),
      });
    }
  }
  return { points, freeRide: freeRide?.code || null };
}
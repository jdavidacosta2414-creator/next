// Ubicación de direcciones y ruta por calles para los pedidos que llegan sin coordenadas.
//  - geocodeAddress: convierte una dirección escrita en coordenadas con Google.
//      · Nomenclatura vial ("Cra 9 No 16-25"): solo vale si Google devuelve esa misma calle y placa.
//      · Conjuntos, urbanizaciones, barrios, locales, edificios y demás lugares: se buscan por nombre
//        (sin manzana, casa, torre, apartamento...) y solo vale un resultado que se llame igual.
//    Si no hay coincidencia devuelve null, para no mandar al mensajero a un sitio equivocado.
//  - drivingRoute: ruta por calles entre dos puntos con Mapbox (trazado, distancia y duración).

const CITY = 'Valledupar';
// Zona de operación (Valledupar y alrededores): fuera de ella una coordenada no se acepta.
export const AREA = { minLat: 10.15, maxLat: 10.75, minLng: -73.55, maxLng: -72.95 };

const ROAD_TYPES: [string, string[]][] = [
  ['Calle', ['calle', 'clle', 'cll', 'cle', 'cl', 'c']],
  ['Carrera', ['carrera', 'carr', 'cra', 'crr', 'cr', 'kra', 'krr', 'kr', 'k']],
  ['Diagonal', ['diagonal', 'diag', 'dg']],
  ['Transversal', ['transversal', 'transv', 'trv', 'tv', 'tr']],
  ['Avenida', ['avenida', 'avda', 'av']],
];
const NUM = '\\d+[a-z]?(?:\\s*bis)?(?:\\s+(?:sur|norte|este|oeste))?';
const GRID = new RegExp(
  `^(${ROAD_TYPES.flatMap(([, alias]) => alias).join('|')})\\.?\\s*(${NUM})\\s*(?:#|n[o°º]\\.?|nro\\.?|n[uú]mero|n\\b|\\s)\\s*(${NUM})(?:\\s*[-\\s]\\s*(\\d+))?`,
  'i'
);
// Detalles internos del lugar (manzana, casa, torre, apto...): no sirven para ubicarlo en el mapa.
const UNIT =
  /\b(?:mz|mza|manzana|casa|cs|torre|apto|apt|apartamento|bloque|interior|int|local|lc|piso|lote|lt|oficina|of)\.?\s*#?\s*(?:\d+[a-z]?|[a-z])\b/gi;
// Palabras que no distinguen un lugar de otro.
const GENERIC = new Set(
  'conjunto cerrado residencial urbanizacion urb barrio br edificio ed centro comercial cc c de del la las los el y con en av avenida sector etapa valledupar cesar colombia'.split(
    ' '
  )
);

const cleanNum = (v: string) => v.toLowerCase().replace(/\s+/g, '').replace(/^0+(?=\d)/, '');
const words = (v: string) =>
  String(v || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
    .split(' ')
    .filter(Boolean);

function point(loc: any) {
  const lat = Number(loc?.lat);
  const lng = Number(loc?.lng);
  const inside = lat >= AREA.minLat && lat <= AREA.maxLat && lng >= AREA.minLng && lng <= AREA.maxLng;
  return inside ? { lat: Number(lat.toFixed(6)), lng: Number(lng.toFixed(6)) } : null;
}

async function google(path: string, params: Record<string, string>, key: string) {
  const res = await fetch(
    `https://maps.googleapis.com/maps/api/${path}/json?${new URLSearchParams({ ...params, region: 'co', language: 'es', key })}`,
    { signal: AbortSignal.timeout(8000) }
  );
  const data = await res.json();
  if (data.status !== 'OK' && data.status !== 'ZERO_RESULTS') {
    throw new Error(`${path} ${data.status}: ${data.error_message || ''}`);
  }
  return data.results || [];
}

// Lee una dirección de nomenclatura vial ("Cra 9 No 16-25", "KR 12 14 22"); null si no tiene esa forma.
function parseGrid(value: string) {
  const m = String(value || '').trim().match(GRID);
  if (!m) return null;
  const alias = m[1].toLowerCase();
  return {
    type: ROAD_TYPES.find(([, list]) => list.includes(alias))![0],
    main: cleanNum(m[2]),
    cross: cleanNum(m[3]),
    plate: m[4] != null ? Number(m[4]) : null,
  };
}

export async function geocodeAddress(address: string, googleKey: string) {
  const asked = parseGrid(address);
  if (asked) {
    // Se envía en su forma completa: Google no reconoce abreviaturas como "Kra" o "Cll".
    const full = `${asked.type} ${asked.main.toUpperCase()} # ${asked.cross.toUpperCase()}${asked.plate != null ? `-${asked.plate}` : ''}`;
    const first = (await google('geocode', { address: `${full}, ${CITY}`, components: 'country:CO' }, googleKey))[0];
    const found = parseGrid(String(first?.formatted_address || '').split(',')[0]);
    const same =
      found &&
      found.type === asked.type &&
      found.main === asked.main &&
      found.cross === asked.cross &&
      (asked.plate == null || found.plate === asked.plate);
    return same ? point(first.geometry?.location) : null;
  }

  const name = address.replace(UNIT, ' ').replace(/[,\s]+/g, ' ').trim() || address;
  const wanted = words(name).filter((w) => !GENERIC.has(w));
  const tokens = wanted.length > 0 ? wanted : words(name);
  const written = words(address);
  const has = (list: string[], w: string) =>
    list.some((g) => g === w || (!/\d/.test(g + w) && w.length >= 4 && g.length >= 4 && (g.startsWith(w) || w.startsWith(g))));
  // Se descarta el punto genérico del centro de la ciudad: es lo que Google devuelve cuando no reconoce el lugar.
  const results = (
    await google(
      'place/textsearch',
      { query: /valledupar/i.test(name) ? name : `${name}, ${CITY}`, location: '10.4631,-73.2532', radius: '15000' },
      googleKey
    )
  )
    .slice(0, 8)
    .filter((p: any) => {
      const loc = p.geometry?.location;
      return !(Math.abs(Number(loc?.lat) - 10.47424) < 0.0006 && Math.abs(Number(loc?.lng) + 73.24363) < 0.0006);
    });
  // Primero los lugares que se llaman como lo escrito; después los que tienen todo su nombre dentro de lo escrito
  // (por ejemplo "Mz 2 casa 42 urbanización Santorini al lado de la tienda").
  const byName = results.filter((p: any) => tokens.every((t) => has(words(p.name), t)));
  const contained = results.filter((p: any) => {
    const own = words(p.name).filter((w) => !GENERIC.has(w));
    return own.length > 0 && own.every((w) => has(written, w));
  });
  for (const place of [...byName, ...contained]) {
    const found = point(place.geometry?.location);
    if (found) return found;
  }
  return null;
}

// Ruta por calles. Devuelve null si Mapbox no responde: el pedido sigue y el mapa la calcula al abrirse.
export async function drivingRoute(
  from: { lat: number; lng: number },
  to: { lat: number; lng: number },
  mapboxToken: string
) {
  try {
    const res = await fetch(
      `https://api.mapbox.com/directions/v5/mapbox/driving/${from.lng},${from.lat};${to.lng},${to.lat}?alternatives=false&geometries=polyline&overview=full&steps=false&access_token=${encodeURIComponent(
        mapboxToken
      )}`,
      { signal: AbortSignal.timeout(10000) }
    );
    const route = res.ok ? (await res.json())?.routes?.[0] : null;
    if (!route || typeof route.geometry !== 'string') return null;
    return {
      route_polyline: route.geometry,
      route_distance_m: Math.round(route.distance || 0),
      route_duration_s: Math.round(route.duration || 0),
    };
  } catch (e) {
    console.error('route', e?.message);
    return null;
  }
}
import { haversine } from './distance.ts';
import { isServiceForDriver } from './serviceMatch.ts';

// Tiempo durante el que vale la marca de "app a la vista" del conductor (la app la renueva cada 25 s).
const APP_OPEN_MS = 40000;

// Avisa por notificación push a los conductores cercanos (máx. 5 km) y compatibles con el servicio.
// Orden de prioridad: Oro > Plata > Bronce, y dentro de cada nivel el más cercano primero.
// Quien tiene la app abierta y a la vista ya recibe el aviso dentro de la app, que no cuesta: a ese no se le envía.
export async function pushNewServiceToNearbyDrivers(base44: any, service: any) {
  const driversRes = await base44.asServiceRole.entities.Mobile.filter({
    status: { $in: ['disponible', 'ocupado'] },
    blocked: false,
    vehicle_type: service.vehicle_type,
  });
  const drivers = (Array.isArray(driversRes) ? driversRes : driversRes?.items || []).filter((d: any) =>
    isServiceForDriver(service, d)
  );

  const hasPickupCoords = service.pickup_lat != null && service.pickup_lng != null;
  const nearby: any[] = [];
  let inApp = 0;
  for (const d of drivers) {
    if ((service.rejected_by || []).includes(d.id)) continue;
    let distKm = null;
    if (hasPickupCoords && d.current_lat != null && d.current_lng != null) {
      distKm = haversine(
        Number(service.pickup_lat),
        Number(service.pickup_lng),
        Number(d.current_lat),
        Number(d.current_lng)
      );
      if (distKm > 5) continue;
    }
    // Vale aunque el reloj del celular vaya unos segundos adelantado; con un reloj muy desajustado se envía la notificación.
    if (Math.abs(Date.now() - Number(d.app_open_at || 0)) < APP_OPEN_MS) {
      inApp += 1;
      continue;
    }
    nearby.push({ driver: d, distKm });
  }

  if (nearby.length === 0) return { sent: 0, reason: 'no_drivers', in_app: inApp };

  const levelPriorityScore = (drv: any) => {
    if (drv?.priority_benefits_active === false) return 1;
    if (drv?.current_level === 'oro') return 3;
    if (drv?.current_level === 'plata') return 2;
    return 1;
  };
  nearby.sort((a, b) => {
    const pDiff = levelPriorityScore(b.driver) - levelPriorityScore(a.driver);
    if (pDiff !== 0) return pDiff;
    return (a.distKm ?? 99) - (b.distKm ?? 99);
  });

  const emails = Array.from(
    new Set(nearby.map(({ driver }) => (driver.email || '').trim().toLowerCase()).filter(Boolean))
  );
  const usersRes =
    emails.length > 0
      ? await base44.asServiceRole.entities.User.filter({ email: { $in: emails } }).catch(() => [])
      : [];
  const users = Array.isArray(usersRes) ? usersRes : usersRes?.items || [];
  const userByEmail = new Map(users.map((u: any) => [(u.email || '').trim().toLowerCase(), u]));

  const fareStr = '$' + Number(service.fare || 5000).toLocaleString('es-CO');
  const typeLabel = service.service_type === 'mensajeria' ? 'Mensajería' : 'Transporte';
  const vehIcon = service.vehicle_type === 'carro' ? '🚗' : '🛵';
  const pickupTxt = service.pickup_address || 'Punto de recogida';
  const destTxt = service.destination_address || 'Destino';

  let sent = 0;
  const batchSize = 6;
  for (let i = 0; i < nearby.length; i += batchSize) {
    const slice = nearby.slice(i, i + batchSize);
    const results = await Promise.allSettled(
      slice.map(async ({ driver, distKm }) => {
        const emailKey = (driver.email || '').trim().toLowerCase();
        const matchedUser: any = userByEmail.get(emailKey);
        const userId = matchedUser?.id || driver.created_by_id;
        if (!userId) return false;
        const distLabel =
          distKm != null && Number.isFinite(distKm)
            ? ` · A ${Math.max(0.1, distKm).toFixed(1)} km de ti`
            : '';
        await base44.asServiceRole.integrations.Core.SendPushNotification({
          user_id: userId,
          title: `${vehIcon} Nuevo servicio cerca (${fareStr})`,
          content: `${typeLabel}${distLabel}: ${pickupTxt} → ${destTxt}`,
          action_label: 'Ver servicio',
          action_url: '/movil',
        });
        return true;
      })
    );
    for (const r of results) {
      if (r.status === 'fulfilled' && r.value === true) sent += 1;
    }
  }

  return { sent, total: nearby.length, in_app: inApp };
}

// Usuario de la app al que le llegan las notificaciones de ese conductor.
async function driverUserId(base44: any, mobile: any) {
  const email = (mobile.email || '').trim().toLowerCase();
  const usersRes = email ? await base44.asServiceRole.entities.User.filter({ email }).catch(() => []) : [];
  const users = Array.isArray(usersRes) ? usersRes : usersRes?.items || [];
  return users[0]?.id || mobile.created_by_id;
}

// Avisa por notificación push al conductor que un servicio quedó a su nombre sin que lo vea en pantalla:
// un comercio se lo asignó directamente con su ID, o la app se lo asignó por ser el postulado más cercano (title propio).
export async function pushAssignedOrderToCourier(base44: any, mobile: any, service: any, title = '') {
  const userId = await driverUserId(base44, mobile);
  if (!userId) return { sent: 0 };

  await base44.asServiceRole.integrations.Core.SendPushNotification({
    user_id: userId,
    title: title || `📦 ${service.business_name || 'Un comercio'} te asignó un pedido`,
    content: `${service.pickup_address || 'Recogida'} → ${service.destination_address || 'Destino'} · ${
      service.service_type === 'transporte' ? 'Tarifa' : 'Domicilio'
    } $${Number(
      service.fare || 0
    ).toLocaleString('es-CO')}. Ya está en tu pestaña En curso.`,
    action_label: 'Ver pedido',
    action_url: '/movil',
  });
  return { sent: 1 };
}

// Avisa por notificación push al mensajero que el comercio canceló un pedido que tenía a su nombre.
// Quien tiene la app abierta y a la vista ya recibe el aviso dentro de la app: a ese no se le envía.
export async function pushCancelledOrderToCourier(base44: any, mobile: any, service: any, pickedUp = false) {
  if (Math.abs(Date.now() - Number(mobile.app_open_at || 0)) < APP_OPEN_MS) return { sent: 0, in_app: 1 };
  const userId = await driverUserId(base44, mobile);
  if (!userId) return { sent: 0 };

  const dest = service.destination_address || 'el cliente';
  const reason = service.client_cancel_detail ? ` Motivo: ${service.client_cancel_detail}` : '';
  await base44.asServiceRole.integrations.Core.SendPushNotification({
    user_id: userId,
    title: `❌ ${service.business_name || 'El negocio'} canceló el pedido`,
    content: `${
      pickedUp
        ? `Ya habías recogido el pedido para ${dest}: comunícate con el negocio.`
        : `Ya no vayas a recoger el pedido para ${dest}.`
    }${reason}`,
    action_label: 'Abrir NEXT',
    action_url: '/movil',
  });
  return { sent: 1 };
}
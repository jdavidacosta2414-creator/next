import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { waitUntil, secrets } from 'base44:runtime';
import { geocodeAddress, drivingRoute, AREA } from '../../shared/addressRoute.ts';
import {
  pushNewServiceToNearbyDrivers,
  pushAssignedOrderToCourier,
  pushCancelledOrderToCourier,
} from '../../shared/nearbyDriverPush.ts';
import { assignToCourier } from '../../shared/courierId.ts';

// Conexión NEXT ↔ NEXT Negocios.
//  - create_order / get_order / cancel_order: solo desde el servidor del portal o del comercio, con la clave en el encabezado x-negocios-key.
//    La clave del portal sirve para todos los comercios registrados en la web: cada uno queda conectado con su primer pedido.
//    Un comercio con sistema propio usa su clave individual.
//    create_order acepta courier_id (el ID corto del mensajero) para asignarle el pedido directamente: si ese ID no
//    existe o el mensajero ya no tiene cupo, el pedido se rechaza y no se ofrece a nadie más.
//    Las coordenadas son opcionales: sin ellas NEXT ubica las direcciones y guarda la ruta por calles del pedido.
//    cancel_order cancela un pedido que aún no esté entregado, tenga o no mensajero asignado: al mensajero se le
//    avisa dentro de su app y, si no la tiene a la vista, con una notificación al celular.
//    Un pedido entregado trae delivery_photo_url: la foto que el mensajero tomó al entregar, como constancia para el comercio.
//    Desde que el mensajero recoge el pedido trae pickup_photo_url: la foto que tomó al recogerlo. Se sigue entregando
//    en las consultas posteriores, con el pedido ya entregado o cancelado.
//  - track: público, solo con el código aleatorio del enlace de seguimiento (lectura mínima, caduca).

const ACTIVE = ['asignado', 'en_camino', 'recogida'];
const STATUS_LABELS = {
  pendiente: 'Buscando mensajero',
  asignado: 'Mensajero asignado',
  en_camino: 'Mensajero en camino al comercio',
  recogida: 'Pedido recogido, en ruta al cliente',
  finalizado: 'Pedido entregado',
  cancelado: 'Pedido cancelado',
  rechazado: 'Pedido cancelado',
};
const CONTENT_TYPES = ['comida', 'electronico', 'documentos', 'paquete_pequeno', 'paquete_grande', 'otro'];
const TRACK_HOURS = 24;
const MAX_ORDERS_PER_MINUTE = 20;
const MAX_PORTAL_ORDERS_PER_MINUTE = 60;

const hex = (bytes) => Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
const text = (v, max) => String(v ?? '').trim().slice(0, max);
const numIn = (v, min, max) => {
  const n = Number(v);
  return v != null && v !== '' && Number.isFinite(n) && n >= min && n <= max ? n : null;
};
const asList = (res) => (Array.isArray(res) ? res : res?.items || []);
const getOrNull = (p) => p.catch((e) => (e.status === 404 ? null : Promise.reject(e)));
// Foto de perfil del comercio: solo se acepta un enlace https; cualquier otro valor se ignora.
const logoUrl = (v) => {
  const url = String(v ?? '').trim();
  return url.length <= 500 && /^https:\/\/[^\s"'<>]+$/.test(url) ? url : '';
};

async function sha256Hex(value) {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
  return hex(new Uint8Array(digest));
}

// Comercio registrado en la web: se identifica por el id que le da el portal.
async function findWebBusiness(bp, externalId) {
  return asList(await bp.filter({ external_id: externalId }, { sort: 'created_date', limit: 1 }))[0] || null;
}

// Conecta el comercio con su primer pedido y mantiene al día su nombre, foto de perfil y datos de contacto.
async function connectWebBusiness(bp, business, externalId, body) {
  const profile = {
    name: text(body.business_name, 80),
    phone: text(body.business_phone, 20),
    address: text(body.business_address, 200),
    logo_url: logoUrl(body.business_logo),
  };
  if (!business) {
    const created = await bp.create({ ...profile, external_id: externalId, active: true });
    // Si dos pedidos del mismo comercio nuevo llegan a la vez, ambos quedan con el registro más antiguo y el repetido se borra.
    const first = (await findWebBusiness(bp, externalId)) || created;
    if (first.id !== created.id) await bp.delete(created.id);
    return first;
  }
  const changes = Object.fromEntries(
    Object.entries(profile).filter(([field, value]) => value && value !== (business[field] || ''))
  );
  if (Object.keys(changes).length === 0) return business;
  await bp.update(business.id, changes);
  return { ...business, ...changes };
}

// Enlace https para mostrar una foto guardada en la app (la de perfil del mensajero o las de evidencia de un pedido), o null
// si no hay foto. Son archivos privados: se entrega un enlace temporal que vence en 1 hora (el máximo que permite
// la plataforma), así que cada respuesta trae uno nuevo. Si el enlace no se puede generar, también va null.
async function photoLink(base44, value) {
  const photo = String(value ?? '').trim();
  if (!photo) return null;
  if (/^(https?:|blob:|data:)/i.test(photo)) return /^https:\/\/\S+$/i.test(photo) ? photo : null;
  try {
    const { signed_url } = await base44.asServiceRole.integrations.Core.CreateFileSignedUrl({
      file_uri: photo,
      expires_in: 3600,
    });
    return signed_url || null;
  } catch (e) {
    console.error('photo', e?.message);
    return null;
  }
}

// Mensajero asignado al pedido. Nombre, placa y teléfono salen del pedido, como siempre; la foto de perfil y la
// moto se leen de su perfil y van en null cuando no están registradas.
async function courierView(base44, s) {
  if (!s.mobile_id) return null;
  const m = await getOrNull(base44.asServiceRole.entities.Mobile.get(s.mobile_id));
  return {
    name: s.mobile_name || '',
    plate: s.mobile_plate || '',
    phone: s.mobile_phone || '',
    photo_url: await photoLink(base44, m?.photo_url),
    motorcycle_model: [m?.vehicle_brand, m?.vehicle_model].map((v) => text(v, 60)).filter(Boolean).join(' ') || null,
  };
}

async function orderView(base44, s, appUrl) {
  const [courier, pickupPhoto, deliveryPhoto] = await Promise.all([
    courierView(base44, s),
    photoLink(base44, s.evidence_pickup_photo),
    s.status === 'finalizado' ? photoLink(base44, s.evidence_delivery_photo) : null,
  ]);
  return {
    order_id: s.id,
    external_order_id: s.external_order_id || null,
    status: s.status,
    status_label: STATUS_LABELS[s.status] || s.status,
    tracking_url: `${appUrl}/seguimiento/${s.id}/${s.tracking_token}`,
    tracking_expires_at: s.tracking_expires_at || null,
    fare: Number(s.fare || 0),
    order_value: Number(s.order_value || 0),
    distance_km: s.route_distance_m != null ? Number((s.route_distance_m / 1000).toFixed(1)) : null,
    duration_min: s.route_duration_s != null ? Math.max(1, Math.round(s.route_duration_s / 60)) : null,
    courier,
    // Foto que el mensajero tomó al recoger el pedido en el comercio (null mientras no la haya tomado). Se entrega en
    // cualquier estado posterior, también con el pedido entregado o cancelado.
    pickup_photo_url: pickupPhoto,
    // Foto que el mensajero tomó al entregar: la constancia de entrega para el comercio (null si aún no está entregado).
    delivery_photo_url: deliveryPhoto,
    cancel_reason: s.status === 'cancelado' ? s.cancel_reason || null : null,
    cancelled_by: s.status === 'cancelado' ? s.cancelled_by || null : null,
    cancel_detail: s.status === 'cancelado' ? s.client_cancel_detail || null : null,
    created_at: s.created_date,
    updated_at: s.updated_date,
  };
}

// Tras cancelar un pedido que tenía mensajero: le avisa al celular y, si quedó marcado como ocupado
// y no tiene más servicios en curso, lo deja disponible.
async function releaseCourier(base44, service, pickedUp) {
  const sr = base44.asServiceRole.entities;
  const mobile = await getOrNull(sr.Mobile.get(service.mobile_id));
  if (!mobile) return;
  await pushCancelledOrderToCourier(base44, mobile, service, pickedUp).catch((e) => console.error('push', e?.message));
  if (
    mobile.status === 'ocupado' &&
    (await sr.Service.count({ mobile_id: mobile.id, status: { $in: ACTIVE } })) === 0
  ) {
    await sr.Mobile.update(mobile.id, { status: 'disponible' });
  }
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const srv = base44.asServiceRole.entities.Service;
    const body = await req.json().catch(() => ({}));
    const action = text(body.action, 30);
    const appUrl = (req.headers.get('X-Base44-App-Url') || 'https://next2026-app.base44.app').replace(/\/$/, '');

    // ---- Seguimiento público por código del enlace ----
    if (action === 'track') {
      const orderId = text(body.order_id, 64);
      const token = text(body.token, 128);
      if (!orderId || token.length < 32) return Response.json({ error: 'Enlace no válido' }, { status: 404 });
      const s = await getOrNull(srv.get(orderId));
      if (!s || !s.tracking_token || s.tracking_token !== token) {
        return Response.json({ error: 'Enlace no válido' }, { status: 404 });
      }
      if (!s.tracking_expires_at || new Date(s.tracking_expires_at).getTime() < Date.now()) {
        return Response.json({ error: 'Este enlace de seguimiento ya caducó' }, { status: 410 });
      }
      const isActive = ACTIVE.includes(s.status);
      let courierLocation = null;
      if (isActive && s.mobile_id) {
        const m = await getOrNull(base44.asServiceRole.entities.Mobile.get(s.mobile_id));
        if (m?.current_lat != null && m?.current_lng != null) {
          courierLocation = { lat: Number(m.current_lat), lng: Number(m.current_lng) };
        }
      }
      return Response.json({
        status: s.status,
        status_label: STATUS_LABELS[s.status] || s.status,
        business_name: s.business_name || '',
        pickup: { address: s.pickup_address, lat: s.pickup_lat ?? null, lng: s.pickup_lng ?? null },
        destination: { address: s.destination_address, lat: s.destination_lat ?? null, lng: s.destination_lng ?? null },
        courier: isActive && s.mobile_id
          ? { name: text(s.mobile_name, 60).split(' ')[0] || 'Mensajero', plate: s.mobile_plate || '' }
          : null,
        courier_location: courierLocation,
        route_polyline: s.route_polyline || null,
        route_distance_m: s.route_distance_m ?? null,
        route_duration_s: s.route_duration_s ?? null,
        updated_at: s.updated_date,
      });
    }

    // ---- Operaciones del comercio: requieren su clave ----
    const apiKey = text(req.headers.get('x-negocios-key'), 200);
    if (apiKey.length < 32) return Response.json({ error: 'Falta la clave del comercio' }, { status: 401 });
    const keyHash = await sha256Hex(apiKey);
    const bp = base44.asServiceRole.entities.BusinessPartner;
    const keyOwner = asList(await bp.filter({ key_hash: keyHash, active: true }))[0];
    if (!keyOwner) return Response.json({ error: 'Clave no válida o comercio inactivo' }, { status: 401 });

    // Con la clave del portal, cada llamada indica de cuál comercio de la web es.
    const viaPortal = keyOwner.is_portal === true;
    const webBusinessId = text(body.business_id, 80);
    let partner = keyOwner;
    if (viaPortal) {
      if (!webBusinessId) {
        return Response.json({ error: 'Falta business_id: el identificador del comercio en el portal' }, { status: 400 });
      }
      partner = await findWebBusiness(bp, webBusinessId);
      if (partner && partner.active === false) {
        return Response.json({ error: 'Este comercio está inactivo en NEXT' }, { status: 403 });
      }
    }

    if (action === 'get_order' || action === 'cancel_order') {
      const orderId = text(body.order_id, 64);
      const externalId = text(body.external_order_id, 80);
      if (!orderId && !externalId) {
        return Response.json({ error: 'Envía order_id o external_order_id' }, { status: 400 });
      }
      // Un comercio de la web que aún no ha enviado pedidos no tiene nada que consultar.
      const s = !partner
        ? null
        : orderId
          ? await getOrNull(srv.get(orderId))
          : asList(await srv.filter({ business_id: partner.id, external_order_id: externalId }))[0];
      if (!s || s.business_id !== partner.id) {
        return Response.json({ error: 'Pedido no encontrado' }, { status: 404 });
      }
      if (action === 'get_order') return Response.json(await orderView(base44, s, appUrl));

      // Cancelación por el comercio: por cualquier motivo, con o sin mensajero asignado, mientras no esté entregado.
      // Solo cancela si el pedido sigue pendiente o en curso: así nunca pisa una entrega registrada en ese instante.
      const lock = await srv.updateMany(
        { id: s.id, status: { $in: ['pendiente', ...ACTIVE] } },
        {
          $set: {
            status: 'cancelado',
            cancelled_by: 'negocio',
            cancel_reason: 'otro',
            client_cancel_detail: text(body.reason, 200),
          },
        }
      );
      if (!lock?.updated) {
        const now = (await getOrNull(srv.get(s.id))) || s;
        if (now.status === 'finalizado') {
          return Response.json(
            { error: 'El pedido ya fue entregado y no se puede cancelar', code: 'already_delivered' },
            { status: 409 }
          );
        }
        // Ya estaba cancelado: repetir la cancelación no es un error.
        return Response.json(await orderView(base44, now, appUrl));
      }
      // Actualización normal: quita las postulaciones y avisa en tiempo real a las apps conectadas.
      const cancelled = await srv.update(s.id, { candidates: [] });
      if (cancelled.mobile_id) {
        waitUntil(
          releaseCourier(base44, cancelled, s.status === 'recogida').catch((e) => console.error('cancel', e?.message))
        );
      }
      return Response.json(await orderView(base44, cancelled, appUrl));
    }

    if (action !== 'create_order') {
      return Response.json({ error: 'Acción no reconocida' }, { status: 400 });
    }

    const externalId = text(body.external_order_id, 80);
    const pickupAddress = text(body.pickup_address, 200);
    const destinationAddress = text(body.destination_address, 200);
    const customerName = text(body.customer_name, 80);
    // Una coordenada fuera de la zona de operación no se usa: en su lugar se ubica la dirección escrita.
    const pickupLat = numIn(body.pickup_lat, AREA.minLat, AREA.maxLat);
    const pickupLng = numIn(body.pickup_lng, AREA.minLng, AREA.maxLng);
    const destLat = numIn(body.destination_lat, AREA.minLat, AREA.maxLat);
    const destLng = numIn(body.destination_lng, AREA.minLng, AREA.maxLng);
    const fare = numIn(body.fare, 3000, 500000);
    const orderValue = numIn(body.order_value, 0, 5000000) ?? 0;

    const missing = [];
    if (!externalId) missing.push('external_order_id');
    if (!pickupAddress) missing.push('pickup_address');
    if (!destinationAddress) missing.push('destination_address');
    if (!customerName) missing.push('customer_name');
    if (fare == null) missing.push('fare (entre 3000 y 500000)');
    if (viaPortal && !text(body.business_name, 80)) missing.push('business_name');
    if (missing.length > 0) {
      return Response.json({ error: `Datos faltantes o no válidos: ${missing.join(', ')}` }, { status: 400 });
    }

    const since = new Date(Date.now() - 60 * 1000).toISOString();
    const tooMany = () =>
      Response.json({ error: 'Demasiados pedidos en un minuto. Intenta de nuevo en unos segundos.' }, { status: 429 });

    if (viaPortal) {
      // Tope general del portal: evita saltarse el límite por comercio inventando comercios nuevos.
      const portalRecent = await srv.count({ origin: 'negocios', created_date: { $gte: since } });
      if (portalRecent >= MAX_PORTAL_ORDERS_PER_MINUTE) return tooMany();
      // El pedido ya es válido: aquí queda conectado el comercio (o se actualizan sus datos).
      partner = await connectWebBusiness(bp, partner, webBusinessId, body);
    }

    // Sin duplicados: el mismo número de pedido del mismo comercio devuelve el servicio ya creado
    const existing = asList(await srv.filter({ business_id: partner.id, external_order_id: externalId }))[0];
    if (existing) return Response.json({ ...(await orderView(base44, existing, appUrl)), duplicate: true });

    const recent = await srv.count({ business_id: partner.id, created_date: { $gte: since } });
    if (recent >= MAX_ORDERS_PER_MINUTE) return tooMany();

    // Coordenadas: se usan las que envíe el comercio; si no llegan, se ubican las direcciones.
    const googleKey = secrets.get('GOOGLE_MAPS_API_KEY') || secrets.get('GOOGLE_API_KEY') || '';
    let pickup = pickupLat != null && pickupLng != null ? { lat: pickupLat, lng: pickupLng } : null;
    let dest = destLat != null && destLng != null ? { lat: destLat, lng: destLng } : null;
    try {
      [pickup, dest] = await Promise.all([
        pickup || geocodeAddress(pickupAddress, googleKey),
        dest || geocodeAddress(destinationAddress, googleKey),
      ]);
    } catch (e) {
      console.error('geocode', e?.message);
      return Response.json(
        {
          error: 'NEXT no pudo ubicar las direcciones en este momento. Intenta de nuevo en unos segundos.',
          code: 'geocoder_unavailable',
        },
        { status: 503 }
      );
    }
    if (!pickup || !dest) {
      const which = !pickup
        ? `la dirección de recogida "${pickupAddress}"`
        : `la dirección de destino "${destinationAddress}"`;
      return Response.json(
        {
          error: `No pudimos ubicar con exactitud ${which}. Escríbela con su placa (por ejemplo "Calle 16 # 9-30") o con el nombre del conjunto, barrio o lugar tal como aparece en el mapa. El pedido no se creó.`,
          code: 'address_not_found',
          field: !pickup ? 'pickup_address' : 'destination_address',
        },
        { status: 422 }
      );
    }
    // Ruta por calles entre recogida y destino: queda guardada en el pedido para mostrarla en el mapa.
    const route = await drivingRoute(pickup, dest, secrets.get('MAPBOX_ACCESS_TOKEN') || '');

    const notes = text(body.notes, 200);
    const cop = (n) => `$${n.toLocaleString('es-CO')}`;
    const commentParts = [`Pedido de ${partner.name}`, `Cliente: ${customerName}`];
    if (orderValue > 0) {
      // El mensajero adelanta el pedido en el comercio y al entregar cobra ese valor más el domicilio.
      commentParts.push(
        `Paga ${cop(orderValue)} al comercio al recoger y cobra al cliente ${cop(orderValue + fare)} al entregar (pedido ${cop(orderValue)} + domicilio ${cop(fare)})`
      );
    }
    if (notes) commentParts.push(notes);

    const order = {
      pickup_address: pickupAddress,
      pickup_lat: pickup.lat,
      pickup_lng: pickup.lng,
      destination_address: destinationAddress,
      destination_lat: dest.lat,
      destination_lng: dest.lng,
      ...(route || {}),
      service_type: 'mensajeria',
      vehicle_type: 'moto',
      payment_method: body.payment_method === 'transferencia' ? 'transferencia' : 'efectivo',
      status: 'pendiente',
      origin: 'negocios',
      client_name: customerName,
      client_phone: text(body.customer_phone, 20),
      content_type: CONTENT_TYPES.includes(body.content_type) ? body.content_type : 'comida',
      content_description: text(body.content_description, 200),
      driver_comment: commentParts.join(' · '),
      fare,
      order_value: orderValue,
      rejected_by: [],
      business_id: partner.id,
      business_name: partner.name,
      business_logo: logoUrl(body.business_logo) || partner.logo_url || '',
      external_order_id: externalId,
      tracking_token: hex(crypto.getRandomValues(new Uint8Array(32))),
      tracking_expires_at: new Date(Date.now() + TRACK_HOURS * 60 * 60 * 1000).toISOString(),
    };

    // Asignación directa: el comercio indica el ID del mensajero. Si no se puede asignar (el ID no existe o el
    // mensajero no tiene cupo), el pedido no se crea y por lo tanto tampoco se ofrece a otros mensajeros.
    if (text(body.courier_id, 40)) {
      const direct = await assignToCourier(base44.asServiceRole, body.courier_id, order);
      if (direct.rejected) {
        const { status, code, error } = direct.rejected;
        return Response.json({ error, code }, { status });
      }
      if (direct.duplicate) return Response.json({ ...(await orderView(base44, direct.duplicate, appUrl)), duplicate: true });
      waitUntil(
        pushAssignedOrderToCourier(base44, direct.mobile, direct.service).catch((e) => console.error('push', e?.message))
      );
      return Response.json(await orderView(base44, direct.service, appUrl), { status: 201 });
    }

    const created = await srv.create(order);

    waitUntil(pushNewServiceToNearbyDrivers(base44, created).catch((e) => console.error('push', e?.message)));

    return Response.json(await orderView(base44, created, appUrl), { status: 201 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
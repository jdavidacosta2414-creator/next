import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { ensureAccount, getConfig, debitPoints, isInCoverage, randomCode } from '../../shared/club.ts';

// Canje de un regalo o comida por puntos: valida inventario, saldo y cobertura en el servidor.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    const body = await req.json().catch(() => ({}));
    const rewardId = String(body.reward_id || '');
    const address = String(body.delivery_address || '').trim().slice(0, 200);
    const notes = String(body.notes || '').trim().slice(0, 300);
    if (!rewardId) return Response.json({ error: 'Falta la recompensa' }, { status: 400 });

    const sr = base44.asServiceRole;
    const cfg = await getConfig(sr);
    const reward = await sr.entities.ClubReward.get(rewardId).catch((e) => (e.status === 404 ? null : Promise.reject(e)));
    if (!reward || !reward.active) return Response.json({ error: 'Esta recompensa no está disponible' }, { status: 404 });
    const isFood = reward.category === 'comida';
    if ((isFood && !cfg.food_enabled) || (!isFood && !cfg.gifts_enabled)) {
      return Response.json({ error: 'Los canjes de esta sección están desactivados por ahora' }, { status: 403 });
    }
    if (!address) return Response.json({ error: 'Indica la dirección de entrega' }, { status: 400 });

    let partner = null;
    if (isFood) {
      if (reward.partner_id) {
        partner = await sr.entities.ClubPartner.get(reward.partner_id).catch(() => null);
        if (!partner || !partner.active) return Response.json({ error: 'El comercio aliado no está disponible' }, { status: 409 });
      }
      if (!(await isInCoverage(sr, address))) {
        return Response.json({ error: 'Tu dirección está fuera de la zona de cobertura de NEXT' }, { status: 400 });
      }
    }

    const acc = await ensureAccount(sr, user);
    const cost = Math.max(1, Number(reward.points_cost) || 0);
    if (Number(acc.balance || 0) < cost) {
      return Response.json({ error: `Te faltan ${(cost - Number(acc.balance || 0)).toLocaleString('es-CO')} puntos` }, { status: 400 });
    }

    // Evitar doble canje por toques repetidos
    const since = new Date(Date.now() - 15000).toISOString();
    const recent = await sr.entities.ClubRedemption.count({ user_id: user.id, reward_id: reward.id, created_date: { $gte: since } });
    if (recent > 0) return Response.json({ error: 'Ya registramos este canje, revisa "Mis canjes"' }, { status: 409 });

    const stock = await sr.entities.ClubReward.updateMany({ id: reward.id, stock: { $gt: 0 } }, { $inc: { stock: -1 } });
    if (!stock?.updated) return Response.json({ error: 'Producto agotado' }, { status: 409 });

    const code = `NC-${randomCode(6)}`;
    const now = new Date().toISOString();
    const redemption = await sr.entities.ClubRedemption.create({
      user_id: user.id,
      user_name: acc.user_name,
      user_phone: user.phone || acc.user_phone || '',
      category: reward.category,
      reward_id: reward.id,
      reward_name: reward.name,
      reward_image: reward.image_url || '',
      points: cost,
      code,
      status: 'pendiente',
      delivery_address: address,
      delivery_lat: Number.isFinite(Number(body.delivery_lat)) ? Number(body.delivery_lat) : undefined,
      delivery_lng: Number.isFinite(Number(body.delivery_lng)) ? Number(body.delivery_lng) : undefined,
      notes,
      partner_id: partner?.id || '',
      partner_name: partner?.name || reward.partner_name || '',
      internal_cost: Number(reward.internal_cost || 0),
      delivery_cost: Number(reward.delivery_cost || 0),
      refunded: false,
      status_history: [{ status: 'pendiente', at: now, by: user.email }],
    });

    const ok = await debitPoints(sr, acc.id, cost, {
      type: isFood ? 'canje_comida' : 'canje_regalo',
      redemption_id: redemption.id,
      dedupe_key: `red_${redemption.id}`,
      description: `Canje ${reward.name} (${code})`,
      performed_by: user.email,
    });
    if (!ok) {
      await sr.entities.ClubRedemption.delete(redemption.id);
      await sr.entities.ClubReward.updateMany({ id: reward.id }, { $inc: { stock: 1 } });
      return Response.json({ error: 'No tienes puntos suficientes' }, { status: 400 });
    }

    return Response.json({ success: true, code, redemption_id: redemption.id });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
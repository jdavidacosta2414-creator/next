import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

// Limpia las fotos de evidencia de mensajería que ya cumplieron el período
// de retención de 90 días. La foto de verificación del conductor queda excluida,
// ya que es un dato permanente de identidad.
// Ejecutar periódicamente (ej. diario) vía un workflow programado.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (!['admin', 'superadmin', 'central'].includes(user.role)) {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }
    const today = new Date().toISOString().split('T')[0];

    // Buscar servicios con fecha de expiración de evidencia ya vencida
    const expired = await base44.asServiceRole.entities.Service.filter({
      evidence_expiry_date: { $lte: today }
    }, '-updated_date', 500);

    // Solo limpiar los que efectivamente tienen fotos de evidencia
    const toClean = expired.filter(s => s.evidence_pickup_photo || s.evidence_delivery_photo);

    if (toClean.length > 0) {
      await base44.asServiceRole.entities.Service.bulkUpdate(
        toClean.map(s => ({
          id: s.id,
          evidence_pickup_photo: "",
          evidence_delivery_photo: "",
          evidence_expiry_date: ""
        }))
      );
    }

    return Response.json({
      success: true,
      checked: expired.length,
      cleaned: toClean.length
    });
  } catch (error) {
    return Response.json({ error: error.message || 'Error en limpieza de evidencias' }, { status: 500 });
  }
}
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { isServiceForDriver } from '../../shared/serviceMatch.ts';
import { computePassExpiry } from '../../shared/dailyPass.ts';

// Simulación de carga con datos de prueba (prefijo "SIM-").
// Acciones: report | setup | contention | load | cleanup
// Candado: se niega a crear datos si existen conductores reales (no SIM-) en la base de datos,
// para no mezclar la simulación con producción. Usar con "Test Data" activado.
const PREFIX = 'SIM-';
const CENTER = { lat: 10.4631, lng: -73.2532 };

const rand = (min, max) => min + Math.random() * (max - min);
const jitter = (km) => (Math.random() - 0.5) * 2 * (km / 111);

async function timed(fn) {
  const t0 = Date.now();
  try {
    const res = await fn();
    return { ok: true, ms: Date.now() - t0, data: res?.data ?? res };
  } catch (e) {
    return { ok: false, ms: Date.now() - t0, status: e?.status || e?.response?.status || 0, error: e?.message || 'error' };
  }
}

function stats(list) {
  if (!list.length) return { count: 0 };
  const s = [...list].sort((a, b) => a - b);
  const pct = (p) => s[Math.min(s.length - 1, Math.floor((p / 100) * s.length))];
  return { count: s.length, avg_ms: Math.round(s.reduce((a, b) => a + b, 0) / s.length), p50_ms: pct(50), p95_ms: pct(95), max_ms: s[s.length - 1] };
}

async function listAll(entity, query) {
  const out = [];
  let cursor = undefined;
  for (let i = 0; i < 20; i++) {
    const page = await entity.filter(query, { limit: 500, ...(cursor ? { cursor } : {}) });
    out.push(...(page.items || []));
    if (!page.has_more) break;
    cursor = page.next_cursor;
  }
  return out;
}

function serviceFor(category, i) {
  const pLat = CENTER.lat + jitter(3);
  const pLng = CENTER.lng + jitter(3);
  return {
    client_name: `${PREFIX}Pasajero ${i}`,
    client_phone: `300000${String(i).padStart(4, '0')}`,
    pickup_address: `${PREFIX}Recogida ${i}`,
    destination_address: `${PREFIX}Destino ${i}`,
    pickup_lat: pLat,
    pickup_lng: pLng,
    destination_lat: pLat + jitter(4),
    destination_lng: pLng + jitter(4),
    service_type: category === 'mensajero' ? 'mensajeria' : 'transporte',
    vehicle_type: category === 'carro' ? 'carro' : 'moto',
    payment_method: 'efectivo',
    status: 'pendiente',
    fare: Math.round(rand(5, 15)) * 1000,
    origin: 'link',
  };
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (!['admin', 'superadmin'].includes(user.role)) return Response.json({ error: 'Forbidden' }, { status: 403 });

    const body = await req.json().catch(() => ({}));
    const action = body.action || 'report';
    const sr = base44.asServiceRole.entities;

    const simMobileQuery = { name: { $regex: `^${PREFIX}` } };
    const simServiceQuery = { client_name: { $regex: `^${PREFIX}` } };

    const [simMobiles, totalMobiles, simServices] = await Promise.all([
      sr.Mobile.count(simMobileQuery),
      sr.Mobile.count({}),
      sr.Service.count(simServiceQuery),
    ]);
    const realMobiles = totalMobiles - simMobiles;

    if (action === 'report') {
      return Response.json({ ok: true, realMobiles, simMobiles, simServices, safeToRun: realMobiles === 0 });
    }

    if (action !== 'cleanup' && realMobiles > 0) {
      return Response.json({
        error: 'Bloqueado: hay conductores reales en esta base de datos. Activa "Test Data" y ejecuta la simulación allí.',
        realMobiles,
      }, { status: 409 });
    }

    if (action === 'setup') {
      const total = Math.min(200, Math.max(3, Number(body.drivers) || 150));
      const split = { moto: Math.round(total * 0.47), carro: Math.round(total * 0.33) };
      split.mensajero = total - split.moto - split.carro;
      const now = new Date();
      const vence = computePassExpiry(now);
      const rows = [];
      let n = 0;
      for (const [cat, qty] of Object.entries(split)) {
        for (let k = 0; k < qty; k++) {
          n += 1;
          rows.push({
            name: `${PREFIX}Conductor ${cat} ${n}`,
            email: `sim-driver-${n}@sim.next.test`,
            phone: `310000${String(n).padStart(4, '0')}`,
            plate: `SIM${String(n).padStart(3, '0')}`,
            vehicle_type: cat === 'carro' ? 'carro' : 'moto',
            driver_category: cat,
            approval_status: 'aprobado',
            terms_accepted: true,
            identity_verified: true,
            status: 'disponible',
            blocked: false,
            balance: cat === 'carro' ? 10000 : 7000,
            pass_mode: 'pase',
            pass_activado_en: now.toISOString(),
            pass_vence_en: vence,
            current_lat: CENTER.lat + jitter(4),
            current_lng: CENTER.lng + jitter(4),
          });
        }
      }
      for (let i = 0; i < rows.length; i += 100) {
        await sr.Mobile.bulkCreate(rows.slice(i, i + 100));
      }
      return Response.json({ ok: true, created: rows.length, split });
    }

    const drivers = await listAll(sr.Mobile, simMobileQuery);
    if (action !== 'cleanup' && drivers.length === 0) {
      return Response.json({ error: 'Primero ejecuta la acción setup' }, { status: 400 });
    }
    const byCat = { moto: [], carro: [], mensajero: [] };
    for (const d of drivers) {
      const cat = d.vehicle_type === 'carro' ? 'carro' : d.driver_category === 'mensajero' ? 'mensajero' : 'moto';
      byCat[cat].push(d);
    }
    const pick = (list, k) => [...list].sort(() => Math.random() - 0.5).slice(0, k);

    // Varios conductores intentan tomar el MISMO servicio al mismo tiempo.
    if (action === 'contention') {
      const rounds = Math.min(15, Math.max(1, Number(body.rounds) || 10));
      const contenders = Math.min(6, Math.max(2, Number(body.contenders) || 6));
      const results = [];
      const claimMs = [];
      let doubleAssigned = 0;
      let mismatched = 0;
      let errors = 0;
      for (let r = 0; r < rounds; r++) {
        const svc = await sr.Service.create(serviceFor('moto', 1000 + r));
        const group = pick(byCat.moto, contenders);
        const responses = await Promise.all(
          group.map((d) => timed(() => base44.functions.invoke('claimService', {
            service_id: svc.id, mobile_id: d.id, lat: d.current_lat, lng: d.current_lng,
          })))
        );
        responses.forEach((x) => { claimMs.push(x.ms); if (!x.ok) errors += 1; });
        const winners = responses.filter((x) => x.ok && x.data?.assigned === true);
        const final = await sr.Service.get(svc.id);
        if (winners.length > 1) doubleAssigned += 1;
        const winnerIds = group.filter((_, i) => responses[i].ok && responses[i].data?.assigned).map((d) => d.id);
        if (winnerIds.length === 1 && final.mobile_id !== winnerIds[0]) mismatched += 1;
        results.push({ round: r + 1, winners: winners.length, final_status: final.status, errors: responses.filter((x) => !x.ok).length });
      }
      return Response.json({
        ok: true,
        rounds,
        contenders,
        doubleAssignedRounds: doubleAssigned,
        winnerMismatchRounds: mismatched,
        claimErrors: errors,
        claimLatency: stats(claimMs),
        results,
      });
    }

    // Ciclo completo: crear servicio → 2 conductores compatibles compiten → finalizar.
    if (action === 'load') {
      const total = Math.min(30, Math.max(1, Number(body.services) || 20));
      const mix = ['moto', 'moto', 'moto', 'moto', 'moto', 'carro', 'carro', 'carro', 'mensajero', 'mensajero'];
      const createMs = [];
      const claimMs = [];
      const finalizeMs = [];
      let assigned = 0;
      let wrongCategory = 0;
      let unassigned = 0;
      const errors = {};
      const addErr = (k) => { errors[k] = (errors[k] || 0) + 1; };

      const runOne = async (i) => {
        const cat = mix[Math.floor(Math.random() * mix.length)];
        const c = await timed(() => sr.Service.create(serviceFor(cat, 2000 + i)));
        createMs.push(c.ms);
        if (!c.ok) return addErr('create');
        const svc = c.data;
        const group = pick(byCat[cat], 2);
        const claims = await Promise.all(group.map((d) => timed(() => base44.functions.invoke('claimService', {
          service_id: svc.id, mobile_id: d.id, lat: d.current_lat, lng: d.current_lng,
        }))));
        claims.forEach((x) => { claimMs.push(x.ms); if (!x.ok) addErr(`claim_${x.status}`); });
        const idx = claims.findIndex((x) => x.ok && x.data?.assigned);
        if (idx < 0) { unassigned += 1; return; }
        assigned += 1;
        if (!isServiceForDriver(svc, group[idx])) wrongCategory += 1;
        const f = await timed(() => base44.functions.invoke('finalizeService', { service_id: svc.id }));
        finalizeMs.push(f.ms);
        if (!f.ok) addErr(`finalize_${f.status}`);
      };

      const t0 = Date.now();
      const concurrency = Math.min(3, Math.max(1, Number(body.concurrency) || 3));
      for (let i = 0; i < total; i += concurrency) {
        const batch = [];
        for (let j = i; j < Math.min(total, i + concurrency); j++) batch.push(runOne(j));
        await Promise.allSettled(batch);
      }
      return Response.json({
        ok: true,
        services: total,
        concurrency,
        totalSeconds: Math.round((Date.now() - t0) / 100) / 10,
        assigned,
        unassigned,
        wrongCategory,
        errors,
        createLatency: stats(createMs),
        claimLatency: stats(claimMs),
        finalizeLatency: stats(finalizeMs),
      });
    }

    if (action === 'cleanup') {
      const services = await listAll(sr.Service, simServiceQuery);
      const serviceIds = services.map((s) => s.id);
      const mobileIds = drivers.map((d) => d.id);
      const summary = { services: serviceIds.length, mobiles: mobileIds.length };
      const delBy = async (entity, field, ids, key) => {
        let removed = 0;
        for (let i = 0; i < ids.length; i += 200) {
          const res = await entity.deleteMany({ [field]: { $in: ids.slice(i, i + 200) } });
          removed += Number(res?.deleted ?? 0);
        }
        summary[key] = removed;
      };
      if (mobileIds.length) {
        await delBy(sr.DriverPerformanceEvent, 'mobile_id', mobileIds, 'performanceEvents');
        await delBy(sr.DriverLevelHistory, 'mobile_id', mobileIds, 'levelHistory');
        await delBy(sr.DriverNotification, 'mobile_id', mobileIds, 'driverNotifications');
        await delBy(sr.DriverCheckIn, 'mobile_id', mobileIds, 'checkIns');
        await delBy(sr.WalletTransaction, 'mobile_id', mobileIds, 'walletTransactions');
      }
      if (serviceIds.length) {
        await delBy(sr.ServiceMessage, 'service_id', serviceIds, 'serviceMessages');
        await delBy(sr.Service, 'id', serviceIds, 'servicesDeleted');
      }
      if (mobileIds.length) await delBy(sr.Mobile, 'id', mobileIds, 'mobilesDeleted');
      return Response.json({ ok: true, deleted: summary });
    }

    return Response.json({ error: `Acción no soportada: ${action}` }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { secrets } from 'base44:runtime';
import { assertCanWork } from '../../shared/dailyPass.ts';
import { haversine } from '../../shared/distance.ts';
import { geocodeAddress } from '../../shared/addressRoute.ts';
import { pushAssignedOrderToCourier } from '../../shared/nearbyDriverPush.ts';
import { recordDriverPerformanceEvent, evaluateAndSyncDriverLevel } from '../../shared/driverLevelEngine.ts';

// Servicios de precio fijo (Central por WhatsApp y negocios aliados): quien acepta queda POSTULADO.
// Desde la primera postulación se reciben más durante WINDOW_MS; al cerrar, la app asigna el servicio
// al postulado más cercano al punto de recogida. Nunca se le asigna a quien no se postuló.
const WINDOW_MS = 10000;
// Una postulación más vieja que esto quedó de un intento anterior que no terminó: ya no cuenta.
const STALE_MS = 45000;
const ms = (v) => new Date(v).getTime() || 0;
const sleep = (t) => new Promise((r) => setTimeout(r, t));

const postulantsOf = (service) =>
  (service.candidates || []).filter((c) => c?.mobile_id && Date.now() - ms(c.timestamp) <= STALE_MS);

// El más cercano a la recogida; si empatan (o la dirección de recogida no existe en el mapa), el que se postuló primero.
function pickClosest(postulants, service) {
  const hasPickup = service.pickup_lat != null && service.pickup_lng != null;
  let winner = null;
  let best = Infinity;
  for (const c of postulants) {
    const d = hasPickup ? haversine(service.pickup_lat, service.pickup_lng, c.lat, c.lng) : Infinity;
    if (!winner || d < best || (d === best && ms(c.timestamp) < ms(winner.timestamp))) {
      winner = c;
      best = d;
    }
  }
  return winner;
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { service_id, mobile_id, lat, lng } = await req.json().catch(() => ({}));
    if (!service_id || !mobile_id) {
      return Response.json({ error: 'Missing service_id or mobile_id' }, { status: 400 });
    }

    const srv = base44.asServiceRole.entities.Service;
    const mob = base44.asServiceRole.entities.Mobile;

    // El llamante debe ser titular del perfil Mobile (o staff) y tener su pase vigente para aceptar.
    const pass = await assertCanWork(mob, mobile_id, user);
    if (!pass.ok) return pass.error;
    const me = pass.mobile;

    const read = () => srv.get(service_id).catch((e) => (e.status === 404 ? null : Promise.reject(e)));
    // Respuesta cuando el servicio ya no está pendiente: quedó a mi nombre o se lo quedó otro.
    const outcome = (s, lostToCloser = false) => {
      if (!s) return Response.json({ assigned: false, reason: 'not_found' });
      if (s.mobile_id === mobile_id) return Response.json({ assigned: true, service: s });
      const closer =
        lostToCloser &&
        s.mobile_id &&
        s.pickup_lat != null &&
        s.pickup_lng != null &&
        !['cancelado', 'rechazado'].includes(s.status);
      return Response.json({ assigned: false, reason: closer ? 'closer_driver' : 'already_taken' });
    };

    let service = await read();
    if (!service || service.status !== 'pendiente') return outcome(service);

    // Pedido que llegó sin su punto de recogida en el mapa: la app ubica la dirección y le guarda el punto,
    // para medir la distancia de cada postulado igual que en los demás pedidos.
    if ((service.pickup_lat == null || service.pickup_lng == null) && service.pickup_address) {
      const googleKey = secrets.get('GOOGLE_MAPS_API_KEY') || secrets.get('GOOGLE_API_KEY') || '';
      const point = await geocodeAddress(service.pickup_address, googleKey).catch((e) => {
        console.error('geocode', e?.message);
        return null;
      });
      if (point) await srv.update(service_id, { pickup_lat: point.lat, pickup_lng: point.lng });
    }

    // Postulación ($push no pisa las de otros que se postulan al mismo tiempo). Ubicación: la que envía
    // la app del conductor y, si no la envía, la última que tiene registrada.
    const postulatedAt = Date.now();
    const coord = (v, registered) => (typeof v === 'number' && Number.isFinite(v) ? v : registered);
    await srv.updateMany(
      { id: service_id },
      {
        $push: {
          candidates: {
            mobile_id,
            lat: coord(lat, me.current_lat),
            lng: coord(lng, me.current_lng),
            timestamp: new Date(postulatedAt).toISOString(),
          },
        },
      }
    );

    // La ventana de postulaciones cuenta desde la primera postulación vigente.
    service = await read();
    if (!service || service.status !== 'pendiente') return outcome(service);
    const firstAt = Math.min(postulatedAt, ...postulantsOf(service).map((c) => ms(c.timestamp)));
    await sleep(Math.max(0, firstAt + WINDOW_MS - Date.now()) + 400);

    service = await read();
    if (!service || service.status !== 'pendiente') return outcome(service, true);

    const winner = pickClosest(postulantsOf(service), service) || { mobile_id };
    const iWon = winner.mobile_id === mobile_id;
    // El ganador escribe su propia asignación. Los demás le dan un momento y, si su llamada se cayó,
    // cualquiera de ellos la termina a nombre del ganador.
    if (!iWon) {
      await sleep(900);
      service = await read();
      if (!service || service.status !== 'pendiente') return outcome(service, true);
    }
    const winnerMobile = iWon
      ? me
      : await mob.get(winner.mobile_id).catch((e) => (e.status === 404 ? null : Promise.reject(e)));
    if (!winnerMobile) return Response.json({ assigned: false, reason: 'already_taken' });

    // Solo una llamada logra escribir la asignación: queda condicionada a que el servicio siga pendiente.
    const lock = await srv.updateMany(
      { id: service_id, status: 'pendiente' },
      {
        $set: {
          status: 'asignado',
          mobile_id: winnerMobile.id,
          cancelled_by: null,
          cancel_reason: null,
          client_cancel_detail: null,
        },
      }
    );
    if (!lock?.updated) return outcome(await read(), true);

    // Actualización normal: completa los datos del conductor y avisa en tiempo real a las apps conectadas.
    const assigned = await srv.update(service_id, {
      mobile_name: winnerMobile.name || '',
      mobile_plate: winnerMobile.plate || '',
      mobile_phone: winnerMobile.phone || '',
      mobile_photo: winnerMobile.photo_url || winnerMobile.vehicle_photo || '',
      candidates: [],
    });
    if (iWon) await mob.update(mobile_id, { status: 'disponible' });
    try {
      await recordDriverPerformanceEvent(base44, { mobile: winnerMobile, service: assigned, eventType: 'service_assigned' });
      await evaluateAndSyncDriverLevel(base44, winnerMobile.id);
    } catch {}
    // La llamada del ganador no llegó a terminar: se le avisa al celular que el servicio quedó a su nombre.
    if (!iWon) {
      await pushAssignedOrderToCourier(base44, winnerMobile, assigned, '✅ Servicio asignado: eras el más cercano').catch(() => {});
    }
    return outcome(assigned, true);
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
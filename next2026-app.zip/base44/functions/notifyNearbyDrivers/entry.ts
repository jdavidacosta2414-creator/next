import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { pushNewServiceToNearbyDrivers } from '../../shared/nearbyDriverPush.ts';
import { isMobileOwner, isStaffRole } from '../../shared/dailyPass.ts';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const { action = 'new_service', service_id, sender_type, message } = body;

    if (!service_id) {
      return Response.json({ error: 'Missing service_id' }, { status: 400 });
    }

    const service = await base44.asServiceRole.entities.Service.get(service_id).catch((e) =>
      e.status === 404 ? null : Promise.reject(e)
    );
    if (!service) {
      return Response.json({ sent: 0, reason: 'not_found' });
    }

    const isCreator = Boolean(service.created_by_id && service.created_by_id === user.id);
    const isStaff = isStaffRole(user);

    // Modo 1: Notificación push inmediata cuando hay un nuevo mensaje entre pasajero y conductor
    if (action === 'service_message') {
      const cleanMsg = String(message || '').trim().slice(0, 180);
      if (!cleanMsg) {
        return Response.json({ sent: 0, reason: 'empty_message' });
      }

      if (sender_type === 'cliente') {
        if (!isCreator && !isStaff) {
          return Response.json({ error: 'Forbidden' }, { status: 403 });
        }
        if (!service.mobile_id) {
          return Response.json({ sent: 0, reason: 'no_assigned_driver' });
        }
        const driver = await base44.asServiceRole.entities.Mobile.get(service.mobile_id).catch((e) =>
          e.status === 404 ? null : Promise.reject(e)
        );
        if (!driver) {
          return Response.json({ sent: 0, reason: 'driver_not_found' });
        }

        let targetUserId = driver.created_by_id || null;
        if (!targetUserId && driver.email) {
          const users = await base44.asServiceRole.entities.User.filter({
            email: driver.email.trim().toLowerCase(),
          }).catch(() => []);
          const list = Array.isArray(users) ? users : users?.items || [];
          targetUserId = list[0]?.id || null;
        }

        if (!targetUserId) {
          return Response.json({ sent: 0, reason: 'driver_user_not_found' });
        }

        const passengerLabel = String(service.client_name || user.full_name || 'Pasajero').slice(0, 60);
        await base44.asServiceRole.integrations.Core.SendPushNotification({
          user_id: targetUserId,
          title: `💬 Mensaje de ${passengerLabel}`,
          content: cleanMsg,
          action_label: 'Responder al pasajero',
          action_url: '/movil',
        });

        return Response.json({ sent: 1, mode: 'service_message_to_driver' });
      }

      if (sender_type === 'movil') {
        if (!service.mobile_id) {
          return Response.json({ sent: 0, reason: 'no_assigned_driver' });
        }
        const driver = await base44.asServiceRole.entities.Mobile.get(service.mobile_id).catch((e) =>
          e.status === 404 ? null : Promise.reject(e)
        );
        if (!isMobileOwner(driver, user) && !isStaff) {
          return Response.json({ error: 'Forbidden' }, { status: 403 });
        }
        const targetUserId = service.created_by_id || null;
        if (!targetUserId) {
          return Response.json({ sent: 0, reason: 'passenger_user_not_found' });
        }
        const driverLabel = String(driver?.name || service.mobile_name || 'Tu conductor').slice(0, 60);
        await base44.asServiceRole.integrations.Core.SendPushNotification({
          user_id: targetUserId,
          title: `💬 Mensaje de ${driverLabel}`,
          content: cleanMsg,
          action_label: 'Ver mensaje',
          action_url: `/cliente?service=${service.id}`,
        });
        return Response.json({ sent: 1, mode: 'service_message_to_passenger' });
      }

      return Response.json({ sent: 0, reason: 'unknown_sender_type' });
    }

    // Modo 2: Notificación push inmediata a conductores cercanos cuando entra un nuevo servicio disponible
    if (!isCreator && !isStaff) {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }
    if (service.status !== 'pendiente') {
      return Response.json({ sent: 0, reason: 'not_pending' });
    }

    return Response.json(await pushNewServiceToNearbyDrivers(base44, service));
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
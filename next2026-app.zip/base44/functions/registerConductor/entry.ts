import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { normalizeConductorInput, createConductorProfile, statusForError } from '../../shared/conductorRegistration.ts';

// Crea el perfil de conductor con los tres registros fotográficos verificados
// (cédula, vehículo, foto de perfil) para el usuario autenticado.
// Si se registra como mensajero, recibe aquí mismo su ID corto y permanente.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Debes iniciar sesión para registrarte' }, { status: 401 });
    }

    const data = normalizeConductorInput(await req.json());
    if (!data.verification_photo || !data.vehicle_photo || !data.tarjeta_photo || !data.photo_url) {
      return Response.json({ error: 'Los registros fotográficos de perfil, cédula, tarjeta de propiedad y vehículo con placa son obligatorios' }, { status: 400 });
    }
    if (data.vehicle_type === 'carro' && (!data.soat_photo || !data.tecno_photo)) {
      return Response.json({ error: 'Para carro es obligatorio adjuntar el SOAT y la Revisión Técnico-Mecánica vigentes' }, { status: 400 });
    }

    const mobile = await createConductorProfile(base44, user, data, { requirePlate: true });
    await base44.asServiceRole.entities.User.update(user.id, { onboarded: true });
    return Response.json({ success: true, mobile });
  } catch (error) {
    const msg = error.message || 'Error al registrar el conductor';
    return Response.json({ error: msg }, { status: statusForError(msg) });
  }
}
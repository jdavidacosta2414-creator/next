import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { isPassActive } from '../../shared/dailyPass.ts';
import { recordDriverPerformanceEvent } from '../../shared/driverLevelEngine.ts';

// Cancela automáticamente los servicios pendientes que superan 10 minutos
// y renueva automáticamente a $0 el saldo diario de los conductores cuyo día o pase ya venció.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || !['admin', 'superadmin', 'central'].includes(user.role)) {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }
    const cutoff = new Date(Date.now() - 10 * 60 * 1000).toISOString();

    const rawExpired = await base44.asServiceRole.entities.Service.filter({
      status: 'pendiente',
      created_date: { $lt: cutoff }
    }, '-created_date', 500);

    const cutoffMs = Date.now() - 10 * 60 * 1000;
    const toUtcMs = (val: any) => {
      if (!val) return 0;
      const r = String(val).trim();
      const iso = /([zZ]|[+-]\d{2}:?\d{2})$/.test(r) ? r : `${r.replace(' ', 'T')}Z`;
      return new Date(iso).getTime() || 0;
    };

    // No cancelar solicitudes que fueron liberadas/reasignadas por un conductor hace menos de 10 minutos
    const expired = (Array.isArray(rawExpired) ? rawExpired : rawExpired?.items || []).filter((s: any) => {
      const refMs =
        s.cancelled_by === 'conductor' && s.updated_date
          ? Math.max(toUtcMs(s.created_date), toUtcMs(s.updated_date))
          : toUtcMs(s.created_date);
      return refMs > 0 && refMs < cutoffMs;
    });

    let cancelled = 0;
    if (expired.length > 0) {
      // Para cada solicitud vencida: si un conductor la vio y no respondió, cuenta como vencida sin respuesta;
      // si envió oferta y el pasajero no la seleccionó, no penaliza su aceptación.
      for (const s of expired) {
        const candidateIds = new Set((s.candidates || []).map((c: any) => c?.mobile_id).filter(Boolean));
        const viewedIds = Array.isArray(s.viewed_by) ? s.viewed_by : [];
        for (const mobId of viewedIds) {
          if (!mobId || candidateIds.has(mobId)) continue;
          try {
            const mob = await base44.asServiceRole.entities.Mobile.get(mobId).catch(() => null);
            if (mob) {
              await recordDriverPerformanceEvent(base44, {
                mobile: mob,
                service: s,
                eventType: 'request_expired',
              });
            }
          } catch {}
        }
        await base44.asServiceRole.entities.Service.update(s.id, {
          status: 'cancelado',
          cancelled_by: 'sistema',
          cancel_reason: 'sin_conductor',
          client_cancel_detail: 'Ningún conductor tomó tu servicio en 10 minutos.',
        }).catch(() => {});
        cancelled += 1;
      }
    }

    // Renovar a $0 los saldos diarios de conductores que ya pasaron al siguiente día o cuyo pase venció.
    let resetBalances = 0;
    try {
      const mobilesWithBalance = await base44.asServiceRole.entities.Mobile.filter(
        { balance: { $gt: 0 } },
        '-created_date',
        500
      );
      const list = Array.isArray(mobilesWithBalance) ? mobilesWithBalance : mobilesWithBalance?.items || [];
      for (const m of list) {
        if (!isPassActive(m) && Number(m.balance || 0) > 0) {
          await base44.asServiceRole.entities.Mobile.update(m.id, {
            balance: 0,
            pass_mode: 'pase',
          }).catch(() => {});
          resetBalances += 1;
        }
      }
    } catch {}

    return Response.json({ success: true, cancelled, resetBalances, cutoff });
  } catch (error) {
    return Response.json({ error: error.message || 'Error en limpieza de servicios expirados' }, { status: 500 });
  }
}
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { isMobileOwner, isStaffRole } from '../../shared/dailyPass.ts';
import { getDriverCategory } from '../../shared/serviceMatch.ts';
import { ensureCourierId } from '../../shared/courierId.ts';

// Devuelve el ID corto y permanente de un perfil de mensajero (y se lo entrega si aún no lo tiene).
// Solo lo puede consultar el titular del perfil o el personal de NEXT.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const mobileId = String(body.mobile_id || '').trim();
    if (!mobileId) return Response.json({ error: 'Falta mobile_id' }, { status: 400 });

    const sr = base44.asServiceRole;
    const mobile = await sr.entities.Mobile.get(mobileId).catch((e) => (e.status === 404 ? null : Promise.reject(e)));
    if (!mobile) return Response.json({ error: 'Perfil no encontrado' }, { status: 404 });
    if (!isMobileOwner(mobile, user) && !isStaffRole(user)) {
      return Response.json({ error: 'No tienes permiso para consultar este perfil' }, { status: 403 });
    }
    if (getDriverCategory(mobile) !== 'mensajero') {
      return Response.json({ error: 'Solo los perfiles de mensajería tienen ID de mensajero' }, { status: 400 });
    }

    return Response.json({ courier_id: await ensureCourierId(sr, mobile) });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
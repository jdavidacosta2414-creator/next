import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

// Prevalidación con IA del comprobante de transferencia de una recarga.
// Lee la captura, extrae monto/fecha/referencia/entidad, detecta duplicados
// e inconsistencias, y guarda un veredicto (preaprobada / sospechosa) para
// que Central apruebe o rechace con esa ayuda. No acredita saldo automáticamente.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { request_id } = body;
    if (!request_id) return Response.json({ error: 'request_id requerido' }, { status: 400 });

    const rr = base44.asServiceRole.entities.RechargeRequest;
    const rec = await rr.get(request_id);
    if (!rec) return Response.json({ error: 'Solicitud no encontrada' }, { status: 404 });
    const isStaff = ['admin', 'superadmin', 'central'].includes(user.role);
    if (!isStaff && rec.created_by_id && rec.created_by_id !== user.id) {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }
    if (!rec.transfer_photo) return Response.json({ error: 'Sin comprobante' }, { status: 400 });

    // Firmar la imagen si es un archivo privado para que el modelo pueda leerla.
    let imageUrl = rec.transfer_photo;
    if (!/^https?:\/\//.test(imageUrl)) {
      const signed = await base44.asServiceRole.integrations.Core.CreateFileSignedUrl({ file_uri: imageUrl });
      imageUrl = signed.signed_url;
    }

    const schema = {
      type: 'object',
      properties: {
        amount: { type: 'number', description: 'Monto de la transferencia en COP (solo el número)' },
        date: { type: 'string', description: 'Fecha del comprobante en YYYY-MM-DD si se puede deducir' },
        reference: { type: 'string', description: 'Referencia, ID o código de la transacción' },
        entity: { type: 'string', description: 'Banco o entidad emisora/receptora (Nequi, Daviplata, Bancolombia, PSE, etc.)' },
        is_real: { type: 'boolean', description: 'true si parece un comprobante real y no manipulado' },
        confidence: { type: 'string', enum: ['alta', 'media', 'baja'] },
        flags: { type: 'array', items: { type: 'string' }, description: 'Señales de alerta detectadas' },
        notes: { type: 'string', description: 'Observaciones breves' }
      },
      required: ['is_real', 'confidence']
    };

    const prompt = `Analiza esta imagen de un comprobante de transferencia bancaria o pago (Nequi, Daviplata, Bancolombia, PSE, llave breve, etc.) de Colombia. Extrae los datos visibles: monto, fecha, referencia y entidad. Evalúa si parece un comprobante real y no manipulado. Marca is_real=false si detectas imagen editada, montos alterados, fecha inconsistente, captura genérica de internet, o ausencia de referencia. Responde solo en JSON según el esquema.`;

    const ai = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      file_urls: [imageUrl],
      response_json_schema: schema
    });

    const amount = typeof ai.amount === 'number' ? ai.amount : null;
    const reference = (ai.reference || '').toString().trim();
    const date = (ai.date || '').toString().trim();
    const entity = (ai.entity || '').toString().trim();
    const flags = Array.isArray(ai.flags) ? ai.flags : [];
    const confidence = ai.confidence || 'media';
    const isReal = ai.is_real !== false;

    // Detección de duplicados: misma referencia en otra solicitud.
    let duplicate = false;
    if (reference) {
      const others = await rr.filter({ ai_reference: reference }, { limit: 50 });
      const items = others.items || others;
      if (Array.isArray(items) && items.some((x) => x.id !== request_id)) duplicate = true;
    }

    const amountMismatch = amount != null && rec.amount != null && Math.abs(amount - rec.amount) > 1;

    const suspiciousFlags = [];
    if (!isReal) suspiciousFlags.push('Posible comprobante falso o manipulado');
    if (confidence === 'baja') suspiciousFlags.push('Confianza baja del modelo');
    if (duplicate) suspiciousFlags.push('Referencia duplicada en otra solicitud');
    // Comprobante con fecha de más de 3 días o en el futuro → sospechoso
    if (/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      const days = (Date.now() - new Date(`${date}T12:00:00-05:00`).getTime()) / 86400000;
      if (days > 3) suspiciousFlags.push(`Comprobante con fecha antigua (${date})`);
      if (days < -1) suspiciousFlags.push(`Comprobante con fecha futura (${date})`);
    } else {
      suspiciousFlags.push('No se pudo leer la fecha del comprobante');
    }
    if (amountMismatch) suspiciousFlags.push(`Monto distinto al solicitado (comprobante ${amount}, pedido ${rec.amount})`);

    const aiStatus = suspiciousFlags.length ? 'sospechosa' : 'preaprobada';
    const notes = [ai.notes || '', ...flags, ...suspiciousFlags].filter(Boolean).join(' · ');

    await rr.update(request_id, {
      ai_status: aiStatus,
      ai_amount: amount,
      ai_date: date,
      ai_reference: reference,
      ai_entity: entity,
      ai_notes: notes,
      ai_checked_at: new Date().toISOString()
    });

    return Response.json({ success: true, ai_status: aiStatus, amount, reference, date, entity, flags: suspiciousFlags });
  } catch (error) {
    // Si falla la IA, dejamos la solicitud pendiente para revisión manual.
    return Response.json({ error: error.message }, { status: 500 });
  }
}
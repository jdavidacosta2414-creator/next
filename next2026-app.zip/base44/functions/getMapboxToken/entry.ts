import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { secrets } from 'base44:runtime';

const DEFAULT_MAPBOX_PUBLIC_TOKEN =
  'pk.eyJ1IjoiamVzdXMxNTI0IiwiYSI6ImNtdngyeHY5aDA0c2ozMHBwemtzeG9lODYifQ.Z6gdehNB3sLWvauvUieoLQ';

function normalizeColombiaCoords(rawLat, rawLng) {
  let lat = parseFloat(rawLat);
  let lng = parseFloat(rawLng);
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
  if (lat >= -82.5 && lat <= -66.0 && lng >= -4.6 && lng <= 14.0) {
    const tmp = lat;
    lat = lng;
    lng = tmp;
  }
  if (lat < -4.6 || lat > 14.0 || lng < -82.5 || lng > -66.0) return null;
  return { lat: parseFloat(lat.toFixed(6)), lng: parseFloat(lng.toFixed(6)) };
}

function distanceMeters(lat1, lng1, lat2, lng2) {
  if (
    !Number.isFinite(lat1) ||
    !Number.isFinite(lng1) ||
    !Number.isFinite(lat2) ||
    !Number.isFinite(lng2)
  ) {
    return Infinity;
  }
  const R = 6371000;
  const toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const googleKey =
      secrets.get('GOOGLE_MAPS_API_KEY') || secrets.get('GOOGLE_API_KEY') || '';
    const mapboxSecret = secrets.get('MAPBOX_ACCESS_TOKEN');
    const mapboxToken =
      mapboxSecret && mapboxSecret.startsWith('pk.')
        ? mapboxSecret
        : DEFAULT_MAPBOX_PUBLIC_TOKEN;

    const body = await req.json().catch(() => ({}));
    const action = body?.action || 'token';

    if (action === 'autocomplete' && googleKey) {
      const input = String(body.input || '').trim();
      if (!input) return Response.json({ status: 'ZERO_RESULTS', predictions: [] });
      const city = String(body.city || 'Valledupar').trim();
      const biasLat = parseFloat(body.lat);
      const biasLng = parseFloat(body.lng);
      const radius = Number(body.radius) || 30000;
      const hasBias = Number.isFinite(biasLat) && Number.isFinite(biasLng);
      // locationbias circular de 30 km sin strictbounds (strictBounds: false) y tipos abiertos
      const biasParam = hasBias
        ? `&location=${biasLat},${biasLng}&radius=${radius}&locationbias=circle:${radius}@${biasLat},${biasLng}`
        : '';
      const url = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${encodeURIComponent(
        input
      )}&components=country:co&region=co${biasParam}&language=es&key=${googleKey}`;
      const r = await fetch(url, { signal: AbortSignal.timeout(8000) });
      const data = await r.json();
      let predictions = Array.isArray(data?.predictions) ? data.predictions : [];

      const cityLower = city.toLowerCase();
      const inCityPreds = predictions.filter((p) =>
        String(p?.description || '').toLowerCase().includes(cityLower)
      );
      const outOfCityPreds = predictions.filter(
        (p) => !String(p?.description || '').toLowerCase().includes(cityLower)
      );

      // Si el texto no da resultados en la ciudad del usuario (o da menos de 3), complementar con Text Search de Places (texto + ciudad)
      let textSearchPreds = [];
      if (inCityPreds.length < 3) {
        const queryWithCity = input.toLowerCase().includes(cityLower)
          ? input
          : `${input}, ${city}`;
        const tsBias = hasBias ? `&location=${biasLat},${biasLng}&radius=${radius}` : '';
        const tsUrl = `https://maps.googleapis.com/maps/api/place/textsearch/json?query=${encodeURIComponent(
          queryWithCity
        )}&region=co${tsBias}&language=es&key=${googleKey}`;
        const tsRes = await fetch(tsUrl, { signal: AbortSignal.timeout(8000) }).catch(() => null);
        const tsData = tsRes ? await tsRes.json().catch(() => null) : null;
        if (Array.isArray(tsData?.results) && tsData.results.length > 0) {
          textSearchPreds = tsData.results.slice(0, 8).map((item) => {
            const c = item?.geometry?.location
              ? normalizeColombiaCoords(item.geometry.location.lat, item.geometry.location.lng)
              : null;
            return {
              place_id: item.place_id,
              description: item.formatted_address
                ? `${item.name}, ${item.formatted_address}`
                : item.name,
              structured_formatting: {
                main_text: item.name || item.formatted_address?.split(',')[0] || input,
                secondary_text: item.formatted_address || `${city}, Colombia`,
              },
              geometry: c
                ? {
                    location: { lat: c.lat, lng: c.lng },
                    location_type: item.geometry?.location_type || 'ROOFTOP',
                  }
                : null,
              types: item.types || ['establishment'],
            };
          });
        }
      }

      const seenIds = new Set();
      const merged = [];
      for (const p of [...inCityPreds, ...textSearchPreds, ...outOfCityPreds]) {
        if (!p?.place_id || seenIds.has(p.place_id)) continue;
        seenIds.add(p.place_id);
        merged.push(p);
      }

      return Response.json({
        ...data,
        status: merged.length > 0 ? 'OK' : data?.status || 'ZERO_RESULTS',
        predictions: merged.slice(0, 8),
      });
    }

    if (action === 'text_search' && googleKey) {
      const query = String(body.query || body.input || '').trim();
      if (!query) return Response.json({ status: 'ZERO_RESULTS', results: [] });
      const city = String(body.city || 'Valledupar').trim();
      const fullQuery =
        query.toLowerCase().includes(city.toLowerCase()) ? query : `${query}, ${city}`;
      const biasLat = parseFloat(body.lat);
      const biasLng = parseFloat(body.lng);
      const radius = Number(body.radius) || 30000;
      const hasBias = Number.isFinite(biasLat) && Number.isFinite(biasLng);
      const biasParam = hasBias ? `&location=${biasLat},${biasLng}&radius=${radius}` : '';
      const url = `https://maps.googleapis.com/maps/api/place/textsearch/json?query=${encodeURIComponent(
        fullQuery
      )}&region=co${biasParam}&language=es&key=${googleKey}`;
      const r = await fetch(url, { signal: AbortSignal.timeout(8000) });
      const data = await r.json();
      const rawResults = Array.isArray(data?.results) ? data.results : [];
      const mapped = rawResults
        .map((item) => {
          const coords = item?.geometry?.location
            ? normalizeColombiaCoords(item.geometry.location.lat, item.geometry.location.lng)
            : null;
          if (!coords) return null;
          return {
            place_id: item.place_id,
            name: item.name || item.formatted_address?.split(',')[0] || query,
            formatted_address: item.formatted_address || `${item.name}, ${city}, Colombia`,
            lat: coords.lat,
            lng: coords.lng,
            location_type: item.geometry?.location_type || 'ROOFTOP',
            types: item.types || [],
          };
        })
        .filter(Boolean);
      return Response.json({
        status: mapped.length > 0 ? 'OK' : data.status || 'ZERO_RESULTS',
        error_message: data.error_message || null,
        results: mapped,
      });
    }

    if (action === 'place_details' && googleKey) {
      const placeId = String(body.place_id || '').trim();
      if (!placeId) return Response.json({ error: 'place_id is required' }, { status: 400 });
      const detailsUrl = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${encodeURIComponent(
        placeId
      )}&fields=place_id,name,formatted_address,geometry,types&language=es&region=co&key=${googleKey}`;
      const detRes = await fetch(detailsUrl, { signal: AbortSignal.timeout(8000) }).catch(() => null);
      const detData = detRes ? await detRes.json().catch(() => null) : null;
      const detResult = detData?.result;
      const detCoords = detResult?.geometry?.location
        ? normalizeColombiaCoords(detResult.geometry.location.lat, detResult.geometry.location.lng)
        : null;

      if (detResult && detCoords) {
        return Response.json({
          status: 'OK',
          error_message: null,
          result: {
            place_id: detResult.place_id || placeId,
            name: detResult.name || '',
            formatted_address: detResult.formatted_address || detResult.name || '',
            lat: detCoords.lat,
            lng: detCoords.lng,
            location_type: detResult.geometry?.location_type || 'ROOFTOP',
            types: detResult.types || [],
          },
        });
      }

      const url = `https://maps.googleapis.com/maps/api/geocode/json?place_id=${encodeURIComponent(
        placeId
      )}&language=es&region=co&key=${googleKey}`;
      const r = await fetch(url, { signal: AbortSignal.timeout(8000) });
      const data = await r.json();
      const first = data?.results?.[0];
      const coords = first?.geometry?.location
        ? normalizeColombiaCoords(first.geometry.location.lat, first.geometry.location.lng)
        : null;
      return Response.json({
        status: data.status,
        error_message: data.error_message || null,
        result:
          first && coords
            ? {
                place_id: first.place_id || placeId,
                name: first.address_components?.[0]?.long_name || '',
                formatted_address: first.formatted_address || '',
                lat: coords.lat,
                lng: coords.lng,
                location_type: first.geometry?.location_type || 'ROOFTOP',
                types: first.types || [],
              }
            : null,
      });
    }

    if (action === 'geocode' && googleKey) {
      const address = String(body.address || '').trim();
      if (!address) return Response.json({ error: 'address is required' }, { status: 400 });
      const city = String(body.city || 'Valledupar').trim();
      const fullQuery =
        address.toLowerCase().includes(city.toLowerCase()) || address.includes(',')
          ? address
          : `${address}, ${city}`;
      const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(
        fullQuery
      )}&region=co&components=country:CO&language=es&key=${googleKey}`;
      const r = await fetch(url, { signal: AbortSignal.timeout(8000) });
      const data = await r.json();
      let first = data?.results?.[0];
      let matchedName = '';

      // Si Geocoding devolvió únicamente la ciudad genérica (locality), buscar en Places Autocomplete
      const isGenericLocality =
        first &&
        Array.isArray(first.types) &&
        first.types.includes('locality') &&
        !first.types.includes('street_address') &&
        !first.types.includes('premise') &&
        !first.types.includes('establishment') &&
        !first.types.includes('point_of_interest') &&
        !first.types.includes('neighborhood') &&
        !first.types.includes('sublocality');

      if (!first || isGenericLocality) {
        const autoUrl = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${encodeURIComponent(
          fullQuery
        )}&components=country:co&language=es&key=${googleKey}`;
        const autoRes = await fetch(autoUrl, { signal: AbortSignal.timeout(6000) }).catch(() => null);
        const autoData = autoRes ? await autoRes.json().catch(() => null) : null;
        const topPred = autoData?.predictions?.[0];
        if (topPred?.place_id) {
          matchedName = topPred.structured_formatting?.main_text || topPred.description || '';
          const detUrl = `https://maps.googleapis.com/maps/api/geocode/json?place_id=${encodeURIComponent(
            topPred.place_id
          )}&language=es&region=co&key=${googleKey}`;
          const detRes = await fetch(detUrl, { signal: AbortSignal.timeout(6000) }).catch(() => null);
          const detData = detRes ? await detRes.json().catch(() => null) : null;
          if (detData?.results?.[0]) {
            first = detData.results[0];
          }
        }
      }

      const coords = first?.geometry?.location
        ? normalizeColombiaCoords(first.geometry.location.lat, first.geometry.location.lng)
        : null;
      return Response.json({
        status: first ? 'OK' : data.status,
        error_message: data.error_message || null,
        result:
          first && coords
            ? {
                place_id: first.place_id || null,
                name: matchedName || '',
                formatted_address: first.formatted_address || fullQuery,
                lat: coords.lat,
                lng: coords.lng,
                location_type: first.geometry?.location_type || 'APPROXIMATE',
                types: first.types || [],
                is_generic_locality: Boolean(
                  Array.isArray(first.types) &&
                    first.types.length <= 2 &&
                    first.types.includes('locality') &&
                    first.types.includes('political') &&
                    !matchedName
                ),
              }
            : null,
      });
    }

    if (action === 'reverse' && googleKey) {
      const coords = normalizeColombiaCoords(body.lat, body.lng);
      if (!coords) return Response.json({ error: 'Invalid coordinates' }, { status: 400 });

      const geoUrl = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${coords.lat},${coords.lng}&language=es&region=co&key=${googleKey}`;
      const geoRes = await fetch(geoUrl, { signal: AbortSignal.timeout(4500) }).catch(() => null);
      const data = geoRes ? await geoRes.json().catch(() => ({})) : {};

      const results = Array.isArray(data?.results) ? data.results : [];
      const plusCodeRegex = /\b[A-Z0-9]{4,10}\+[A-Z0-9]{2,5}\b/i;

      // Filtrar resultados de Geocoding descartando Plus Codes y resultados genéricos de ciudad/departamento
      const validGeoResults = results
        .map((item) => {
          const gLat = item?.geometry?.location?.lat;
          const gLng = item?.geometry?.location?.lng;
          const dist = distanceMeters(coords.lat, coords.lng, gLat, gLng);
          return { item, dist };
        })
        .filter(({ item, dist }) => {
          const types = Array.isArray(item?.types) ? item.types : [];
          if (types.includes('plus_code')) return false;
          if (
            types.includes('locality') ||
            types.includes('administrative_area_level_1') ||
            types.includes('administrative_area_level_2') ||
            types.includes('country') ||
            types.includes('postal_code')
          ) {
            return false;
          }
          const firstSegment = String(item?.formatted_address || '').split(',')[0].trim();
          if (!firstSegment || plusCodeRegex.test(firstSegment)) return false;
          if (dist > 85) return false;
          return true;
        });

      const roadPrefixRegex =
        /^(?:calle|cl|cll|carrera|cra|kr|kra|diagonal|diag|dg|transversal|transv|tv|tr|avenida|av)(?:\.|\b)/i;
      const completePlateRegex =
        /#\s*(?:No\.?\s*)?[0-9A-Za-z]+(?:\s*(?:Bis|Sur|Norte|Este|Oeste))?\s*-\s*[0-9A-Za-z]+/i;
      const headlessNumRegex = /^\d+[A-Za-z]?\s*(?:#|No\.?|N°)\s*\d+/i;

      // 1) Priorizar nomenclatura vial válida con prefijo (Calle/Cra./Dg./Tv./Av.) y placa completa '#XX-YY' (<= 65m)
      const exactStreetWithHash = validGeoResults
        .filter(({ item, dist }) => {
          const firstSeg = String(item?.formatted_address || '').split(',')[0].trim();
          const types = item?.types || [];
          if (headlessNumRegex.test(firstSeg)) return false;
          return (
            dist <= 65 &&
            roadPrefixRegex.test(firstSeg) &&
            completePlateRegex.test(firstSeg) &&
            types.some((t) => ['street_address', 'premise', 'subpremise', 'route'].includes(t))
          );
        })
        .sort((a, b) => a.dist - b.dist)[0];

      // 2) Dirección vial o intersección cercana sin números de ruta huérfanos como "80 #21-49" (<= 75m)
      const closeStreetOrRoute = validGeoResults
        .filter(({ item, dist }) => {
          const firstSeg = String(item?.formatted_address || '').split(',')[0].trim();
          const types = item?.types || [];
          if (headlessNumRegex.test(firstSeg)) return false;
          return (
            dist <= 75 &&
            types.some((t) =>
              ['street_address', 'premise', 'subpremise', 'route', 'intersection'].includes(t)
            )
          );
        })
        .sort((a, b) => a.dist - b.dist)[0];

      const fallbackItem = validGeoResults[0]?.item || null;
      const winner = exactStreetWithHash?.item || closeStreetOrRoute?.item || fallbackItem;

      const chosenAddress = winner?.formatted_address || '';
      const chosenPlaceId = winner?.place_id || null;
      const chosenLocType = winner?.geometry?.location_type || 'ROOFTOP';

      return Response.json({
        status: chosenAddress ? 'OK' : data.status || 'ZERO_RESULTS',
        error_message: data.error_message || null,
        result: chosenAddress
          ? {
              place_id: chosenPlaceId,
              formatted_address: chosenAddress,
              lat: coords.lat,
              lng: coords.lng,
              location_type: chosenLocType,
              is_residential_place: false,
            }
          : null,
      });
    }

    return Response.json({
      token: mapboxToken,
      mapboxToken,
      provider: 'mapbox',
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';
import { computePassExpiry, getBogotaDateString } from '../../shared/dailyPass.ts';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Solo la central / administración puede revisar recargas.
    if (!['central', 'superadmin', 'admin'].includes(user.role)) {
      return Response.json({ error: 'No tienes permisos para revisar recargas' }, { status: 403 });
    }

    const body = await req.json();
    const { request_id, action, reject_reason } = body;
    if (!request_id || !['aprobar', 'rechazar'].includes(action)) {
      return Response.json({ error: 'Parámetros inválidos' }, { status: 400 });
    }

    const rr = base44.asServiceRole.entities.RechargeRequest;
    const mob = base44.asServiceRole.entities.Mobile;
    const wt = base44.asServiceRole.entities.WalletTransaction;

    const reqRec = await rr.get(request_id);
    if (!reqRec) return Response.json({ error: 'Solicitud no encontrada' }, { status: 404 });
    if (reqRec.status !== 'pendiente') {
      return Response.json({ error: 'Esta solicitud ya fue revisada' }, { status: 400 });
    }

    if (action === 'rechazar') {
      const updated = await rr.update(request_id, {
        status: 'rechazada',
        verified_by: user.id,
        verified_at: new Date().toISOString(),
        reject_reason: reject_reason || '',
      });
      return Response.json({ success: true, request: updated });
    }

    // Aprobar: activa el pase de 14 horas continuas desde este exacto momento (`now + 14h`), sin comisión por porcentaje.
    const amount = reqRec.amount || 0;
    const mobile = await mob.get(reqRec.mobile_id);
    if (!mobile) return Response.json({ error: 'Conductor no encontrado' }, { status: 404 });

    const now = new Date();
    const vence = computePassExpiry(now);
    const todayDate = getBogotaDateString(now);
    await mob.update(reqRec.mobile_id, {
      pass_mode: 'pase',
      balance: amount,
      pass_date: todayDate,
      pass_activado_en: now.toISOString(),
      pass_vence_en: vence,
    });
    await wt.create({
      mobile_id: reqRec.mobile_id,
      mobile_name: reqRec.mobile_name || mobile.name,
      type: 'recarga',
      amount,
      description: `Pase 14h laborales vía ${reqRec.payment_method || 'transferencia'} (vence ${new Date(vence).toLocaleString('es-CO', { timeZone: 'America/Bogota' })})`,
    });
    const updated = await rr.update(request_id, {
      status: 'aprobada',
      verified_by: user.id,
      verified_at: new Date().toISOString(),
    });
    return Response.json({ success: true, request: updated, new_balance: amount, pass_expires_at: vence });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
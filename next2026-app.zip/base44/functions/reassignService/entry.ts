import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';
import { haversine } from '../../shared/distance.ts';
import { isServiceForDriver } from '../../shared/serviceMatch.ts';
import { isMobileOwner, isStaffRole } from '../../shared/dailyPass.ts';
import { recordDriverPerformanceEvent, evaluateAndSyncDriverLevel } from '../../shared/driverLevelEngine.ts';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { service_id, mobile_id, reason } = await req.json().catch(() => ({}));

    if (!service_id || !mobile_id) {
      return Response.json({ error: 'Missing service_id or mobile_id' }, { status: 400 });
    }

    const srv = base44.asServiceRole.entities.Service;
    const mob = base44.asServiceRole.entities.Mobile;
    const msg = base44.asServiceRole.entities.ServiceMessage;

    const [service, mobile] = await Promise.all([
      srv.get(service_id).catch((e) => (e.status === 404 ? null : Promise.reject(e))),
      mob.get(mobile_id).catch((e) => (e.status === 404 ? null : Promise.reject(e))),
    ]);
    if (!service) return Response.json({ error: 'Service not found' }, { status: 404 });
    if (!mobile) return Response.json({ error: 'Mobile not found' }, { status: 404 });

    if (!isMobileOwner(mobile, user) && !isStaffRole(user)) {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    // Verify the service is assigned to this driver
    if (service.mobile_id !== mobile_id) {
      return Response.json({ error: 'Service not assigned to this mobile' }, { status: 403 });
    }

    const driverName = service.mobile_name || 'El conductor';
    const reasonLabel = REASON_LABELS[reason] || reason || '';
    const validCancelReason = REASON_LABELS[reason] ? reason : 'otro';

    // Reset service to pending and clear mobile fields.
    // No se agrega al móvil a rejected_by: el servicio vuelve a estar
    // disponible para todos, incluido el conductor que lo liberó.
    const updated = await srv.update(service_id, {
      status: 'pendiente',
      mobile_id: '',
      mobile_name: '',
      mobile_plate: '',
      mobile_photo: '',
      mobile_phone: '',
      candidates: [],
      viewed_by: [],
      cancelled_by: 'conductor',
      cancel_reason: validCancelReason,
      client_cancel_detail: `${driverName} canceló el servicio${reasonLabel ? ` (${reasonLabel})` : ''}. Buscando otro conductor cercano.`,
    });

    // Set mobile back to disponible
    await mob.update(mobile_id, { status: 'disponible' });

    // Notificación push inmediata al pasajero informando que el conductor canceló y se busca otro
    if (service.created_by_id) {
      try {
        await base44.asServiceRole.integrations.Core.SendPushNotification({
          user_id: service.created_by_id,
          title: '⚠️ El conductor canceló el servicio',
          content: `${driverName} no pudo continuar${reasonLabel ? ` (${reasonLabel})` : ''}. Estamos buscando otro conductor cercano para ti.`,
          action_label: 'Ver búsqueda',
          action_url: '/cliente',
        });
      } catch {}
    }

    // Registrar cancelación atribuible al conductor (queda disponible para revisión/justificación administrativa)
    try {
      await recordDriverPerformanceEvent(base44, {
        mobile,
        service,
        eventType: 'cancelled_by_driver',
        cancelReason: reason || 'movil_no_disponible',
        cancelledBy: 'conductor',
      });
      await evaluateAndSyncDriverLevel(base44, mobile_id);
    } catch {}

    // Notificar al pasajero por chat que el conductor canceló y se buscará otro.
    try {
      await msg.create({
        service_id,
        sender_type: 'movil',
        sender_name: driverName,
        message: `${driverName} canceló el servicio${reasonLabel ? ` (${reasonLabel})` : ''}. Volveremos a buscar un conductor cercano.`,
      });
    } catch {}

    // Reanunciar a conductores cercanos disponibles.
    try {
      await announceNearbyDrivers(base44, service_id);
    } catch {}

    return Response.json({ reassigned: true, service: updated });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}

const REASON_LABELS = {
  sin_combustible: 'sin combustible',
  llanta_pinchada: 'llanta pinchada',
  emergencia: 'emergencia',
  vehiculo_no_enciende: 'vehículo no enciende',
  celular_sin_bateria: 'celular sin batería',
};

async function announceNearbyDrivers(base44, service_id) {
  const service = await base44.asServiceRole.entities.Service.get(service_id);
  if (!service || service.status !== 'pendiente') return { sent: 0 };

  const drivers = await base44.asServiceRole.entities.Mobile.filter({
    status: 'disponible',
    blocked: false,
    vehicle_type: service.vehicle_type,
  });

  let nearby = drivers.filter((d) => isServiceForDriver(service, d));
  if (service.pickup_lat != null && service.pickup_lng != null) {
    nearby = nearby.filter((d) => {
      if (d.current_lat == null || d.current_lng == null) return true;
      return haversine(service.pickup_lat, service.pickup_lng, d.current_lat, d.current_lng) <= 5;
    });
  }
  if (nearby.length === 0) return { sent: 0 };

  const emails = nearby.map((d) => d.email).filter(Boolean);
  const users = emails.length > 0
    ? await base44.asServiceRole.entities.User.filter({ email: { $in: emails } })
    : [];
  const userByEmail = new Map(users.map((u) => [u.email, u]));

  const fareStr = '$' + Number(service.fare || 5000).toLocaleString('es-CO');
  const typeLabel = service.service_type === 'mensajeria' ? 'Mensajería' : 'Transporte';

  let sent = 0;
  for (const driver of nearby) {
    const u = userByEmail.get(driver.email);
    if (!u) continue;
    try {
      await base44.asServiceRole.integrations.Core.SendPushNotification({
        user_id: u.id,
        title: '🛵 Nueva solicitud disponible',
        content: typeLabel + ' — Tarifa propuesta: ' + fareStr + '. Toca para ver detalles.',
        action_label: 'Ver solicitud',
        action_url: '/movil',
      });
      sent++;
    } catch {}
  }
  return { sent };
}
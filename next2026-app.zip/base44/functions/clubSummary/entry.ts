import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { ensureAccount, getConfig } from '../../shared/club.ts';

// Devuelve la cuenta NEXT CLUB del pasajero (la crea si no existe) y libera viajes gratis reservados en servicios cancelados.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    const sr = base44.asServiceRole;

    const [cfg, acc] = await Promise.all([getConfig(sr), ensureAccount(sr, user)]);

    const reserved = await sr.entities.ClubFreeRide.filter({ user_id: user.id, status: 'reservado' }, '-created_date', 10);
    for (const r of reserved || []) {
      const svc = r.used_service_id
        ? await sr.entities.Service.get(r.used_service_id).catch((e) => (e.status === 404 ? null : Promise.reject(e)))
        : null;
      if (!svc || ['cancelado', 'rechazado'].includes(svc.status)) {
        await sr.entities.ClubFreeRide.updateMany(
          { id: r.id, status: 'reservado' },
          { $set: { status: 'disponible', used_service_id: '' } }
        );
      }
    }

    const available = await sr.entities.ClubFreeRide.filter({ user_id: user.id, status: 'disponible' }, 'created_date', 10);
    const { processed_services, ...account } = acc;
    return Response.json({
      account,
      config: cfg,
      free_rides: (available || []).map((r) => ({ id: r.id, code: r.code, max_value: r.max_value, created_date: r.created_date })),
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
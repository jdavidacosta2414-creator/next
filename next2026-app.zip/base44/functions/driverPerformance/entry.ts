import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { isMobileOwner, isStaffRole } from '../../shared/dailyPass.ts';
import {
  LEVEL_SPECS,
  MIN_VALID_SAMPLE,
  recordDriverPerformanceEvent,
  evaluateAndSyncDriverLevel,
  createNotificationOnce,
} from '../../shared/driverLevelEngine.ts';

const FORBIDDEN_STAT_OVERRIDE_FIELDS = [
  'acceptance_rate',
  'acceptance_rate_30d',
  'cancellation_rate',
  'cancellation_rate_30d',
  'current_level',
  'total_completed_services',
  'total_connected_days',
  'performance_status',
  'priority_benefits_active',
];

export default async function (req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e: any) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json().catch(() => ({}));
    const action = body.action || 'get_driver_summary';
    const isStaff = isStaffRole(user);

    // Protección estricta contra manipulación desde el cliente:
    // Ninguna llamada puede enviar porcentajes de aceptación, cancelación o nivel para forzar su modificación.
    for (const field of FORBIDDEN_STAT_OVERRIDE_FIELDS) {
      if (body[field] !== undefined) {
        return Response.json(
          {
            error:
              'Operación rechazada por seguridad: los indicadores de nivel, aceptación y cancelación se calculan exclusivamente en el backend a partir de eventos reales.',
            code: 'STAT_TAMPERING_BLOCKED',
          },
          { status: 403 }
        );
      }
    }

    const mobEntity = base44.asServiceRole.entities.Mobile;
    const srvEntity = base44.asServiceRole.entities.Service;
    const evtEntity = base44.asServiceRole.entities.DriverPerformanceEvent;
    const histEntity = base44.asServiceRole.entities.DriverLevelHistory;
    const notifEntity = base44.asServiceRole.entities.DriverNotification;

    // 1. Consultar Nivel (Trayectoria) y Rendimiento (Reciente) de un conductor
    if (action === 'get_driver_summary') {
      const { mobile_id } = body;
      if (!mobile_id) {
        return Response.json({ error: 'mobile_id es obligatorio' }, { status: 400 });
      }
      const mobile = await mobEntity.get(mobile_id).catch((e: any) => (e.status === 404 ? null : Promise.reject(e)));
      if (!mobile) {
        return Response.json({ error: 'Conductor no encontrado' }, { status: 404 });
      }
      if (!isMobileOwner(mobile, user) && !isStaff) {
        return Response.json(
          { error: 'No tienes permiso para consultar los indicadores privados de otro conductor' },
          { status: 403 }
        );
      }

      const evaluation = await evaluateAndSyncDriverLevel(base44, mobile_id);
      const [historyRes, notifsRes] = await Promise.all([
        histEntity.filter({ mobile_id }, '-created_date', 30).catch(() => []),
        notifEntity.filter({ mobile_id }, '-created_date', 40).catch(() => []),
      ]);

      return Response.json({
        ok: true,
        evaluation,
        levelHistory: Array.isArray(historyRes) ? historyRes : historyRes?.items || [],
        notifications: Array.isArray(notifsRes) ? notifsRes : notifsRes?.items || [],
      });
    }

    // 2. Registrar evento verificable de solicitud/servicio (rechazo directo, expiración, cancelación pasajero/conductor)
    if (action === 'record_event') {
      const { mobile_id, service_id, event_type, cancel_reason, cancelled_by, technical_failure } = body;
      if (!mobile_id || !service_id || !event_type) {
        return Response.json({ error: 'mobile_id, service_id y event_type son obligatorios' }, { status: 400 });
      }

      // Un conductor no puede auto-marcar una cancelación como justificada desde record_event
      if (body.justified === true && !isStaff) {
        return Response.json(
          { error: 'Solo un administrador puede aprobar una justificación de cancelación' },
          { status: 403 }
        );
      }

      const [mobile, service] = await Promise.all([
        mobEntity.get(mobile_id).catch((e: any) => (e.status === 404 ? null : Promise.reject(e))),
        srvEntity.get(service_id).catch((e: any) => (e.status === 404 ? null : Promise.reject(e))),
      ]);
      if (!mobile) return Response.json({ error: 'Conductor no encontrado' }, { status: 404 });
      if (!service) return Response.json({ error: 'Servicio no encontrado' }, { status: 404 });

      const isOwner = isMobileOwner(mobile, user);
      const isPassenger = Boolean(service.created_by_id && service.created_by_id === user.id);
      if (!isOwner && !isPassenger && !isStaff) {
        return Response.json({ error: 'Forbidden' }, { status: 403 });
      }

      const recorded = await recordDriverPerformanceEvent(base44, {
        mobile,
        service,
        eventType: event_type,
        cancelReason: cancel_reason || '',
        cancelledBy: cancelled_by || 'ninguno',
        technicalFailure: Boolean(technical_failure && isStaff),
      });

      const evaluation = await evaluateAndSyncDriverLevel(base44, mobile_id);
      return Response.json({ ok: true, event: recorded, evaluation });
    }

    // 3. Marcar notificación de nivel/rendimiento como leída o descartada por el conductor
    if (action === 'dismiss_notification') {
      const { notification_id } = body;
      if (!notification_id) {
        return Response.json({ error: 'notification_id es obligatorio' }, { status: 400 });
      }
      const notif = await notifEntity
        .get(notification_id)
        .catch((e: any) => (e.status === 404 ? null : Promise.reject(e)));
      if (!notif) return Response.json({ error: 'Notificación no encontrada' }, { status: 404 });

      const mobile = await mobEntity.get(notif.mobile_id).catch(() => null);
      if (!isMobileOwner(mobile, user) && !isStaff) {
        return Response.json({ error: 'Forbidden' }, { status: 403 });
      }
      const updated = await notifEntity.update(notification_id, { read: true, dismissed: true });
      return Response.json({ ok: true, notification: updated });
    }

    // 4. Panel Administrativo: Supervisión global de Niveles, Rendimiento, Recuperaciones, Cancelaciones y Auditorías
    if (action === 'admin_dashboard') {
      if (!isStaff) {
        return Response.json(
          { error: 'Acceso restringido exclusivamente a administradores y Central' },
          { status: 403 }
        );
      }

      const mobilesRes = await mobEntity.list('-created_date', 200).catch(() => []);
      const mobiles = Array.isArray(mobilesRes) ? mobilesRes : mobilesRes?.items || [];

      // Evaluar en lotes de 6 en paralelo para garantizar datos frescos reales
      const driverSummaries: any[] = [];
      const batchSize = 6;
      for (let i = 0; i < mobiles.length; i += batchSize) {
        const slice = mobiles.slice(i, i + batchSize);
        const results = await Promise.allSettled(
          slice.map(async (m: any) => {
            const ev = await evaluateAndSyncDriverLevel(base44, m.id);
            const p30 = ev?.periods?.['30d'] || {};
            const pAll = ev?.periods?.all || {};
            const nextReq = ev?.pendingForNextLevel;
            const nearPromotion = Boolean(
              nextReq &&
                nextReq.servicesMissing <= 20 &&
                nextReq.daysMissing <= 4 &&
                (nextReq.servicesCompleted >= nextReq.servicesRequired * 0.8 ||
                  nextReq.daysConnected >= nextReq.daysRequired * 0.8)
            );
            const currentSpec = LEVEL_SPECS[ev?.currentLevel || 'bronce'];
            const atRiskOfDemotion = Boolean(
              ev?.currentLevel !== 'bronce' &&
                p30.hasMinimumSample &&
                (ev?.recovery?.active ||
                  p30.acceptanceRate < currentSpec.minAcceptance + 3 ||
                  p30.cancellationRate > Math.max(0, currentSpec.maxCancellation - 1))
            );

            return {
              id: m.id,
              name: m.name || 'Conductor',
              email: m.email || '',
              phone: m.phone || '',
              plate: m.plate || '',
              vehicle_type: m.vehicle_type || 'moto',
              photo_url: m.photo_url || '',
              status: m.status || 'offline',
              currentLevel: ev?.currentLevel || 'bronce',
              priorityLabel: currentSpec.priorityLabel,
              priorityBenefitsActive: ev?.priorityBenefitsActive ?? true,
              completedServices: ev?.trajectory?.completedServices ?? 0,
              connectedDays: ev?.trajectory?.connectedDays ?? 0,
              acceptanceRate30d: p30.acceptanceRate ?? 100,
              cancellationRate30d: p30.cancellationRate ?? 0,
              validSample30d: p30.validSampleCount ?? 0,
              hasMinimumSample30d: Boolean(p30.hasMinimumSample),
              avgRating: pAll.avgRating || p30.avgRating || 0,
              ratingsCount: pAll.ratingsCount || 0,
              performanceStatus: ev?.performanceStatus || 'sin_datos_suficientes',
              recovery: ev?.recovery || { active: false },
              pendingForNextLevel: nextReq,
              nearPromotion,
              atRiskOfDemotion,
              driverCancellationsTotal30d: p30.driverCancellationsTotal ?? 0,
              driverCancellationsJustified30d: p30.driverCancellationsJustified ?? 0,
              driverCancellationsPenalized30d: p30.driverCancellationsPenalized ?? 0,
            };
          })
        );
        for (const r of results) {
          if (r.status === 'fulfilled' && r.value) {
            driverSummaries.push(r.value);
          }
        }
      }

      const [cancelEventsRes, historyRes, notifsRes] = await Promise.all([
        evtEntity
          .filter({ cancelled_by: 'conductor' }, '-created_date', 100)
          .catch(() => []),
        histEntity.list('-created_date', 100).catch(() => []),
        notifEntity.list('-created_date', 100).catch(() => []),
      ]);

      const totals = {
        totalDrivers: driverSummaries.length,
        oro: driverSummaries.filter((d) => d.currentLevel === 'oro').length,
        plata: driverSummaries.filter((d) => d.currentLevel === 'plata').length,
        bronce: driverSummaries.filter((d) => d.currentLevel === 'bronce').length,
        inRecovery: driverSummaries.filter((d) => d.recovery?.active).length,
        nearPromotion: driverSummaries.filter((d) => d.nearPromotion).length,
        atRiskOfDemotion: driverSummaries.filter((d) => d.atRiskOfDemotion).length,
      };

      return Response.json({
        ok: true,
        totals,
        drivers: driverSummaries,
        cancellationEvents: Array.isArray(cancelEventsRes)
          ? cancelEventsRes
          : cancelEventsRes?.items || [],
        levelHistory: Array.isArray(historyRes) ? historyRes : historyRes?.items || [],
        notifications: Array.isArray(notifsRes) ? notifsRes : notifsRes?.items || [],
      });
    }

    // 5. Gestión Administrativa de Cancelaciones Justificadas (con recálculo inmediato y auditoría)
    if (action === 'justify_cancellation') {
      if (!isStaff) {
        return Response.json(
          {
            error:
              'Permiso denegado: solo un administrador puede revisar y justificar cancelaciones de conductores.',
          },
          { status: 403 }
        );
      }

      const {
        event_id,
        service_id,
        mobile_id,
        decision = 'justificada',
        justification_reason,
        admin_observation,
      } = body;

      if (!justification_reason || !String(justification_reason).trim()) {
        return Response.json(
          { error: 'El motivo de la revisión administrativa es obligatorio' },
          { status: 400 }
        );
      }
      if (!admin_observation || !String(admin_observation).trim()) {
        return Response.json(
          { error: 'La observación administrativa es obligatoria para la auditoría' },
          { status: 400 }
        );
      }

      let targetEvent: any = null;
      if (event_id) {
        targetEvent = await evtEntity
          .get(event_id)
          .catch((e: any) => (e.status === 404 ? null : Promise.reject(e)));
      } else if (mobile_id && service_id) {
        const found = await evtEntity
          .filter({ mobile_id, service_id }, '-created_date', 1)
          .catch(() => []);
        const list = Array.isArray(found) ? found : found?.items || [];
        targetEvent = list[0] || null;
      }

      if (!targetEvent) {
        return Response.json({ error: 'Registro de cancelación no encontrado' }, { status: 404 });
      }

      const isApproved = decision === 'justificada';
      const nowIso = new Date().toISOString();
      const adminLabel = user.full_name || user.email || 'Administrador NEXT';

      const updatedEvent = await evtEntity.update(targetEvent.id, {
        justified: isApproved,
        justification_status: isApproved ? 'justificada' : 'rechazada',
        counts_for_cancellation_numerator: !isApproved,
        justification_reason: String(justification_reason).trim(),
        admin_observation: String(admin_observation).trim(),
        reviewed_by_admin: adminLabel,
        reviewed_by_admin_id: user.id || '',
        reviewed_at: nowIso,
      });

      const mobile = await mobEntity.get(targetEvent.mobile_id).catch(() => null);
      const prevLevel = mobile?.current_level || 'bronce';

      // Recalcular inmediatamente el rendimiento y nivel del conductor tras la decisión administrativa
      const evaluation = await evaluateAndSyncDriverLevel(base44, targetEvent.mobile_id);

      // Guardar registro de auditoría en DriverLevelHistory
      await histEntity.create({
        mobile_id: targetEvent.mobile_id,
        mobile_name: mobile?.name || targetEvent.mobile_name || 'Conductor',
        driver_email: (mobile?.email || targetEvent.driver_email || '').trim().toLowerCase(),
        change_type: 'justificacion_cancelacion',
        previous_level: prevLevel,
        new_level: evaluation?.currentLevel || prevLevel,
        reason: isApproved
          ? `Cancelación justificada aprobada por ${adminLabel}. Motivo: ${justification_reason}. Observación: ${admin_observation}. Excluida del cálculo de penalización.`
          : `Solicitud de justificación rechazada por ${adminLabel}. Motivo: ${justification_reason}. Observación: ${admin_observation}.`,
        completed_services: evaluation?.trajectory?.completedServices ?? 0,
        connected_days: evaluation?.trajectory?.connectedDays ?? 0,
        acceptance_rate: evaluation?.periods?.['30d']?.acceptanceRate ?? 100,
        cancellation_rate: evaluation?.periods?.['30d']?.cancellationRate ?? 0,
        avg_rating: evaluation?.periods?.all?.avgRating ?? 0,
        sample_size: evaluation?.periods?.['30d']?.validSampleCount ?? 0,
        admin_name: adminLabel,
        admin_observation: String(admin_observation).trim(),
        service_id: targetEvent.service_id,
      });

      if (isApproved && mobile) {
        await createNotificationOnce(base44, {
          mobile,
          dedupeKey: `justif_approved_${targetEvent.id}`,
          category: 'justificacion_aprobada',
          title: '✅ Cancelación justificada por Administración',
          message: `La administración revisó la cancelación del servicio y la aprobó como justificada (${justification_reason}). Esta cancelación fue excluida de tu tasa de cancelación y tus indicadores fueron recalculados (${evaluation?.periods?.['30d']?.cancellationRate ?? 0}% de cancelación actual).`,
          howToImprove: 'Gracias por reportar oportunamente las novedades operativas.',
          levelContext: evaluation?.currentLevel || prevLevel,
        });
      }

      return Response.json({
        ok: true,
        event: updatedEvent,
        evaluation,
      });
    }

    return Response.json({ error: `Acción no soportada: ${action}` }, { status: 400 });
  } catch (error: any) {
    return Response.json({ error: error.message || 'Internal Server Error' }, { status: 500 });
  }
}
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { isClubAdmin, creditPoints, debitPoints, findAccount } from '../../shared/club.ts';

const STATUSES = ['pendiente', 'aprobado', 'confirmado', 'preparando', 'en_camino', 'entregado', 'cancelado'];

// Operaciones administrativas de NEXT CLUB: estado de canjes (con devolución de puntos) y ajustes de saldo auditados.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (!isClubAdmin(user)) return Response.json({ error: 'Forbidden' }, { status: 403 });
    const body = await req.json().catch(() => ({}));
    const sr = base44.asServiceRole;

    if (body.action === 'update_status') {
      const status = String(body.status || '');
      if (!STATUSES.includes(status)) return Response.json({ error: 'Estado inválido' }, { status: 400 });
      const red = await sr.entities.ClubRedemption.get(body.redemption_id).catch((e) => (e.status === 404 ? null : Promise.reject(e)));
      if (!red) return Response.json({ error: 'Canje no encontrado' }, { status: 404 });
      if (red.status === 'cancelado' || red.status === 'entregado') {
        return Response.json({ error: 'Este canje ya está cerrado' }, { status: 409 });
      }
      const history = [...(red.status_history || []), { status, at: new Date().toISOString(), by: user.email }];

      if (status === 'cancelado') {
        const lock = await sr.entities.ClubRedemption.updateMany(
          { id: red.id, refunded: { $ne: true }, status: { $nin: ['cancelado', 'entregado'] } },
          { $set: { status: 'cancelado', refunded: true, status_history: history } }
        );
        if (!lock?.updated) return Response.json({ error: 'Este canje ya fue cancelado' }, { status: 409 });
        const acc = await findAccount(sr, red.user_id);
        if (acc) {
          await sr.entities.ClubAccount.updateMany({ id: acc.id }, { $inc: { total_redeemed: -Number(red.points) } });
          await sr.entities.ClubAccount.updateMany({ id: acc.id }, { $inc: { total_earned: -Number(red.points) } });
          await creditPoints(sr, acc.id, Number(red.points), {
            type: 'devolucion',
            redemption_id: red.id,
            dedupe_key: `refund_${red.id}`,
            description: `Devolución por cancelación del canje ${red.code} (${red.reward_name})`,
            performed_by: user.email,
          });
        }
        await sr.entities.ClubReward.updateMany({ id: red.reward_id }, { $inc: { stock: 1 } });
        return Response.json({ success: true, refunded: Number(red.points) });
      }

      await sr.entities.ClubRedemption.update(red.id, { status, status_history: history });
      return Response.json({ success: true });
    }

    if (body.action === 'adjust_points') {
      const amount = Math.trunc(Number(body.amount) || 0);
      const reason = String(body.reason || '').trim().slice(0, 200);
      if (!amount || !reason) return Response.json({ error: 'Indica la cantidad y el motivo' }, { status: 400 });
      const acc = await findAccount(sr, String(body.user_id || ''));
      if (!acc) return Response.json({ error: 'Cuenta no encontrada' }, { status: 404 });
      const tx = { type: 'ajuste_admin', description: `Ajuste: ${reason}`, performed_by: user.email };
      if (amount > 0) {
        await creditPoints(sr, acc.id, amount, tx);
      } else {
        const ok = await debitPoints(sr, acc.id, -amount, tx);
        if (!ok) return Response.json({ error: 'El saldo no puede quedar negativo' }, { status: 400 });
      }
      return Response.json({ success: true });
    }

    return Response.json({ error: 'Acción no válida' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
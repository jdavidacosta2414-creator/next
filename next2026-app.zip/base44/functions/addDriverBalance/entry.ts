import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { computePassExpiry, getBogotaDateString } from '../../shared/dailyPass.ts';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { mobile_id, amount, description, use_points_wallet } = body;
    if (!mobile_id) {
      return Response.json({ error: 'Missing mobile_id' }, { status: 400 });
    }

    const mob = base44.asServiceRole.entities.Mobile;
    const wt = base44.asServiceRole.entities.WalletTransaction;

    const mobile = await mob.get(mobile_id);
    if (!mobile) return Response.json({ error: 'Mobile not found' }, { status: 404 });

    const isStaff = ['admin', 'superadmin', 'central'].includes(user.role);
    const isOwner = mobile.email === user.email || mobile.created_by_id === user.id;

    // El pase se activa por 14 horas continuas a partir de este momento (`now + 14h`).
    const minReq = mobile.vehicle_type === 'carro' ? 10000 : 7000;
    const now = new Date();
    const vence = computePassExpiry(now);
    const todayDate = getBogotaDateString(now);

    if (use_points_wallet) {
      if (!isOwner && !isStaff) {
        return Response.json({ error: 'No tienes permiso para activar este pase' }, { status: 403 });
      }
      const currentPtsWallet = Number(mobile.points_wallet_balance ?? 0);
      if (currentPtsWallet < minReq) {
        return Response.json(
          {
            error: `Saldo insuficiente en tu billetera de puntos. Necesitas $${minReq.toLocaleString('es-CO')} y tienes $${currentPtsWallet.toLocaleString('es-CO')}.`,
          },
          { status: 400 }
        );
      }
      const nextPtsWallet = currentPtsWallet - minReq;
      const updatedMob = await mob.update(mobile_id, {
        pass_mode: 'pase',
        balance: minReq,
        points_wallet_balance: nextPtsWallet,
        pass_date: todayDate,
        pass_activado_en: now.toISOString(),
        pass_vence_en: vence,
      });
      await wt.create({
        mobile_id,
        mobile_name: mobile.name,
        type: 'recarga',
        amount: minReq,
        description:
          description ||
          `Pase 14h activado con tu saldo de carreras por puntos (quedan $${nextPtsWallet.toLocaleString('es-CO')} en Cartera)`,
      });
      return Response.json({
        success: true,
        mobile: updatedMob,
        new_balance: minReq,
        points_wallet_balance: nextPtsWallet,
        pass_expires_at: vence,
      });
    }

    if (!isStaff) {
      return Response.json({ error: 'Solo Central o Administración pueden recargar saldo manualmente' }, { status: 403 });
    }

    if (!amount || amount <= 0) {
      return Response.json({ error: 'Invalid amount' }, { status: 400 });
    }

    const updatedMob = await mob.update(mobile_id, {
      pass_mode: 'pase',
      balance: amount,
      pass_date: todayDate,
      pass_activado_en: now.toISOString(),
      pass_vence_en: vence,
    });
    await wt.create({
      mobile_id,
      mobile_name: mobile.name,
      type: 'recarga',
      amount,
      description:
        description ||
        `Pase 14h laborales activado (vence ${new Date(vence).toLocaleString('es-CO', { timeZone: 'America/Bogota' })})`,
    });
    return Response.json({
      success: true,
      mobile: updatedMob,
      new_balance: amount,
      points_wallet_balance: Number(mobile.points_wallet_balance ?? 0),
      pass_expires_at: vence,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
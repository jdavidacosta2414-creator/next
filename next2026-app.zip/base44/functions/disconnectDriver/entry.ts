import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';
import { isMobileOwner, isStaffRole } from '../../shared/dailyPass.ts';

// Desconexión automática del conductor al cerrar la app. Se invoca con
// keepalive desde el evento pagehide. No desconecta si hay un servicio en
// curso (asignado/en_camino/recogida) para no abandonar al pasajero.
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const mobile_id = body?.mobile_id;
    if (!mobile_id) return Response.json({ error: 'Missing mobile_id' }, { status: 400 });

    const mob = base44.asServiceRole.entities.Mobile;
    const srv = base44.asServiceRole.entities.Service;

    const mobile = await mob.get(mobile_id).catch((e) => (e.status === 404 ? null : Promise.reject(e)));
    if (!mobile) return Response.json({ error: 'Mobile not found' }, { status: 404 });
    if (!isMobileOwner(mobile, user) && !isStaffRole(user)) {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }
    if (mobile.status === 'offline') return Response.json({ success: true, already: true });

    // No desconectar si hay un servicio en curso.
    const active = await srv.count({
      mobile_id,
      status: { $in: ['asignado', 'en_camino', 'recogida'] },
    });
    if (active > 0) return Response.json({ success: false, reason: 'active_service' });

    await mob.update(mobile_id, { status: 'offline' });
    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

// Borra todos los registros de prueba (prefijo "PRUEBA-") creados durante la
// prueba de 30 conductores / 50 servicios. Solo admins pueden invocarla.
// Uso: base44.functions.invoke('cleanupTestData', { confirm: true })
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden' }, { status: 403 });

    let body = {};
    try { body = await req.json(); } catch {}
    if (!body.confirm) {
      return Response.json({
        error: 'Confirmación requerida',
        hint: 'Envía { confirm: true } para ejecutar el borrado de registros PRUEBA-'
      }, { status: 400 });
    }

    const PREFIX = 'PRUEBA-';
    const sr = base44.asServiceRole.entities;
    const summary = {};

    // 1) Mobiles de prueba
    const drivers = await sr.Mobile.filter({ name: { $regex: `^${PREFIX}` } }, { limit: 500 });
    const driverIds = (drivers.items || []).map((m) => m.id);
    summary.mobiles = driverIds.length;
    if (driverIds.length) {
      await sr.Mobile.deleteMany({ id: { $in: driverIds } });
    }

    // 2) Servicios de prueba (client_name con prefijo)
    const services = await sr.Service.filter({ client_name: { $regex: `^${PREFIX}` } }, { limit: 1000 });
    const serviceIds = (services.items || []).map((s) => s.id);
    summary.services = serviceIds.length;
    if (serviceIds.length) {
      await sr.Service.deleteMany({ id: { $in: serviceIds } });
    }

    // 3) Transacciones de billetera de los conductores de prueba
    let walletCount = 0;
    if (driverIds.length) {
      const wallet = await sr.WalletTransaction.filter({ mobile_id: { $in: driverIds } }, { limit: 1000 });
      walletCount = (wallet.items || []).length;
      if (walletCount) await sr.WalletTransaction.deleteMany({ mobile_id: { $in: driverIds } });
    }
    summary.walletTransactions = walletCount;

    // 4) Mensajes de servicio asociados
    let msgCount = 0;
    if (serviceIds.length) {
      const msgs = await sr.ServiceMessage.filter({ service_id: { $in: serviceIds } }, { limit: 1000 });
      msgCount = (msgs.items || []).length;
      if (msgCount) await sr.ServiceMessage.deleteMany({ service_id: { $in: serviceIds } });
    }
    summary.serviceMessages = msgCount;

    // 5) Check-ins de los conductores de prueba
    let checkinCount = 0;
    if (driverIds.length) {
      const checkins = await sr.DriverCheckIn.filter({ mobile_id: { $in: driverIds } }, { limit: 1000 });
      checkinCount = (checkins.items || []).length;
      if (checkinCount) await sr.DriverCheckIn.deleteMany({ mobile_id: { $in: driverIds } });
    }
    summary.driverCheckIns = checkinCount;

    // 6) Solicitudes de recarga de los conductores de prueba
    let rechargeCount = 0;
    if (driverIds.length) {
      const recharges = await sr.RechargeRequest.filter({ mobile_id: { $in: driverIds } }, { limit: 1000 });
      rechargeCount = (recharges.items || []).length;
      if (rechargeCount) await sr.RechargeRequest.deleteMany({ mobile_id: { $in: driverIds } });
    }
    summary.rechargeRequests = rechargeCount;

    return Response.json({ ok: true, deleted: summary });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';
import { recordDriverPerformanceEvent, evaluateAndSyncDriverLevel } from '../../shared/driverLevelEngine.ts';

// El pasajero elige un conductor de entre los postulados (candidates) y se le asigna el servicio.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { service_id, mobile_id } = await req.json();
    if (!service_id || !mobile_id) {
      return Response.json({ error: 'Missing service_id or mobile_id' }, { status: 400 });
    }

    const srv = base44.asServiceRole.entities.Service;
    const mob = base44.asServiceRole.entities.Mobile;

    const service = await srv.get(service_id).catch((e) => (e.status === 404 ? null : Promise.reject(e)));
    if (!service) return Response.json({ error: 'Service not found' }, { status: 404 });

    const isCreator = Boolean(service.created_by_id && service.created_by_id === user.id);
    const isStaff = ['admin', 'superadmin', 'central'].includes(user.role);
    if (!isCreator && !isStaff) {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    if (service.status !== 'pendiente') {
      return Response.json({ error: 'Service no longer available' }, { status: 409 });
    }

    const candidate = (service.candidates || []).find((c) => c.mobile_id === mobile_id);
    if (!candidate) return Response.json({ error: 'Candidate not found' }, { status: 404 });

    const mobile = await mob.get(mobile_id).catch(() => null);

    const offeredFare = candidate.offered_fare != null ? candidate.offered_fare : service.fare;

    const assigned = await srv.update(service_id, {
      status: 'asignado',
      mobile_id,
      mobile_name: mobile?.name || '',
      mobile_plate: mobile?.plate || '',
      mobile_phone: mobile?.phone || '',
      mobile_photo: mobile?.photo_url || mobile?.vehicle_photo || '',
      fare: offeredFare,
      candidates: [],
      cancelled_by: null,
      cancel_reason: null,
      client_cancel_detail: null,
    });

    if (mobile?.created_by_id || mobile?.email) {
      try {
        let drvUserId = mobile?.created_by_id || null;
        if (!drvUserId && mobile?.email) {
          const uRes = await base44.asServiceRole.entities.User.filter({
            email: mobile.email.trim().toLowerCase(),
          }).catch(() => []);
          const uList = Array.isArray(uRes) ? uRes : uRes?.items || [];
          drvUserId = uList[0]?.id || null;
        }
        if (drvUserId) {
          await base44.asServiceRole.integrations.Core.SendPushNotification({
            user_id: drvUserId,
            title: '✅ ¡El pasajero aceptó tu oferta!',
            content: `${service.client_name || 'Pasajero'} te eligió por $${Number(offeredFare || 5000).toLocaleString('es-CO')}. Dirígete a ${service.pickup_address || 'el punto de recogida'}.`,
            action_label: 'Ir al servicio',
            action_url: '/movil',
          });
        }
      } catch {}
    }

    await mob.update(mobile_id, { status: 'disponible' });

    // Registrar servicio asignado al conductor elegido; las ofertas de otros candidatos quedan como no seleccionadas (sin penalización)
    try {
      if (mobile) {
        await recordDriverPerformanceEvent(base44, {
          mobile,
          service: assigned,
          eventType: 'service_assigned',
        });
        await evaluateAndSyncDriverLevel(base44, mobile_id);
      }
    } catch {}

    return Response.json({ assigned: true, service: assigned });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { isPassActive, isMobileOwner, isStaffRole } from '../../shared/dailyPass.ts';
import { recordDriverPerformanceEvent, evaluateAndSyncDriverLevel } from '../../shared/driverLevelEngine.ts';
import { processServiceForClub } from '../../shared/club.ts';

const ALLOWED_ACTIVE_STATUSES = ['asignado', 'en_camino', 'recogida'];

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const { service_id, evidence_delivery_photo } = body;
    if (!service_id) return Response.json({ error: 'Missing service_id' }, { status: 400 });

    const srv = base44.asServiceRole.entities.Service;
    const mob = base44.asServiceRole.entities.Mobile;
    const wt = base44.asServiceRole.entities.WalletTransaction;

    const service = await srv.get(service_id).catch((e) => (e.status === 404 ? null : Promise.reject(e)));
    if (!service) return Response.json({ error: 'Service not found' }, { status: 404 });

    const mobile = service.mobile_id
      ? await mob.get(service.mobile_id).catch((e) => (e.status === 404 ? null : Promise.reject(e)))
      : null;

    const isAssignedDriver = isMobileOwner(mobile, user);
    const isPassengerCreator = Boolean(service.created_by_id && service.created_by_id === user.id);
    const isStaff = isStaffRole(user);

    if (!isAssignedDriver && !isPassengerCreator && !isStaff) {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    if (service.status === 'finalizado') {
      // Reintento idempotente: si NEXT CLUB no alcanzó a procesar el servicio, lo procesa ahora (nunca dos veces)
      try { await processServiceForClub(base44.asServiceRole, service); } catch (e) { console.error('club', e?.message); }
      return Response.json({
        success: true,
        service,
        commission: 0,
        new_balance: mobile ? Number(mobile.balance ?? 0) : null,
        points_wallet_balance: mobile ? Number(mobile.points_wallet_balance ?? 0) : 0,
      });
    }

    if (!ALLOWED_ACTIVE_STATUSES.includes(service.status)) {
      return Response.json({ error: 'Service cannot be finalized from its current status' }, { status: 409 });
    }

    // La tarifa cobrada proviene exclusivamente del registro del servicio en el servidor (nunca del cliente)
    const serverFare = Math.max(0, Number(service.fare ?? 5000));
    const amount = serverFare;

    const payload = { status: 'finalizado', collected_amount: amount, commission: 0 };
    if (typeof evidence_delivery_photo === 'string' && evidence_delivery_photo.trim()) {
      payload.evidence_delivery_photo = evidence_delivery_photo.trim();
    }
    if (service.service_type === 'mensajeria') {
      const expiry = new Date();
      expiry.setDate(expiry.getDate() + 90);
      payload.evidence_expiry_date = expiry.toISOString().split('T')[0];
    }

    const updated = await srv.update(service_id, payload);

    let finalBalance = mobile ? Number(mobile.balance ?? 0) : null;
    let finalPointsWallet = mobile ? Number(mobile.points_wallet_balance ?? 0) : 0;

    if (mobile) {
      const mobUpdates = {};
      if (!isPassActive(mobile) && Number(mobile.balance ?? 0) > 0) {
        finalBalance = 0;
        mobUpdates.balance = 0;
        mobUpdates.pass_mode = 'pase';
      }

      // Si el servicio fue redimido por puntos (1 pto = $1 COP), acreditar únicamente el monto validado en servidor
      const redeemedPts = Number(service.points_redeemed || serverFare);
      const creditAmount = Math.max(0, Math.min(serverFare, redeemedPts > 0 ? redeemedPts : serverFare));
      if (service.payment_method === 'redimido_puntos' && creditAmount > 0) {
        finalPointsWallet = Number(mobile.points_wallet_balance ?? 0) + creditAmount;
        mobUpdates.points_wallet_balance = finalPointsWallet;
        await wt.create({
          mobile_id: service.mobile_id,
          mobile_name: mobile.name,
          type: 'recarga',
          amount: creditAmount,
          service_id: service.id,
          description: `Carrera redimida por puntos (+$${creditAmount.toLocaleString('es-CO')} sumados a tu Cartera)`,
        });
      }

      if (Object.keys(mobUpdates).length > 0) {
        await mob.update(service.mobile_id, mobUpdates);
      }

      try {
        await recordDriverPerformanceEvent(base44, {
          mobile,
          service: updated,
          eventType: 'service_completed',
        });
        await evaluateAndSyncDriverLevel(base44, service.mobile_id);
      } catch {}
    }

    let club = null;
    try {
      club = await processServiceForClub(base44.asServiceRole, updated);
    } catch (e) {
      console.error('club', e?.message);
    }

    return Response.json({
      success: true,
      club,
      service: updated,
      commission: 0,
      new_balance: finalBalance,
      points_wallet_balance: finalPointsWallet,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
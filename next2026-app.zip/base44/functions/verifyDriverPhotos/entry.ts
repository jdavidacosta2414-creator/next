import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { cedulaCategoryConflict, plateHoldersOfOtherDrivers } from '../../shared/conductorRegistration.ts';

// Verifica con IA (ESTRICTO) las fotos del registro de conductor:
// - Para moto (3 fotos): 1) cédula, 2) tarjeta de propiedad, 3) foto de la moto con placa visible.
// - Para carro (5 fotos): 1) cédula, 2) tarjeta de propiedad, 3) foto del carro con placa visible, 4) SOAT vigente, 5) Revisión Técnico-Mecánica vigente.
// La foto de perfil no entra aquí ni se compara con la cédula: se revisa sola al subirla (checkDocument) y la valida la Central.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));

    // Verificación en base de datos para impedir que correos, cédulas o placas ya registrados vuelvan a registrarse
    if (body?.action === 'check_registration') {
      const cleanEmail = String(body?.email || '').trim().toLowerCase();
      const cleanCedula = String(body?.cedula || '').trim();
      const cleanPlate = String(body?.plate || '').trim().toUpperCase().replace(/[\s.\-]/g, '');
      const scope = body?.scope || 'pasajero';
      const category = ['carro', 'moto', 'mensajero'].includes(body?.driver_category) ? body.driver_category : '';

      if (cleanEmail) {
        const [uRes, mRes] = await Promise.all([
          base44.asServiceRole.entities.User.filter({ email: cleanEmail }).catch(() => []),
          base44.asServiceRole.entities.Mobile.filter({ email: cleanEmail }).catch(() => []),
        ]);
        const uList = Array.isArray(uRes) ? uRes : uRes?.items || [];
        const mList = Array.isArray(mRes) ? mRes : mRes?.items || [];
        const matchedUser = uList.find((u) => String(u?.email || '').trim().toLowerCase() === cleanEmail);
        const matchedMobile = mList.find((m) => String(m?.email || '').trim().toLowerCase() === cleanEmail);

        if (matchedMobile) {
          return Response.json({
            exists: true,
            verified: true,
            field: 'email',
            error: 'Este correo ya tiene una cuenta de conductor en NEXT. Escribe la contraseña de esa cuenta para continuar con ella.',
          });
        }

        if (matchedUser && (matchedUser.is_verified !== false || matchedUser.onboarded)) {
          return Response.json({
            exists: true,
            verified: true,
            field: 'email',
            error:
              scope === 'conductor'
                ? 'Este correo ya tiene una cuenta en NEXT. Escribe la contraseña de esa cuenta y tu registro como conductor seguirá con ella.'
                : 'Este correo ya tiene una cuenta en NEXT. Escribe la contraseña de esa cuenta y entrarás con ella.',
          });
        }

        if (matchedUser && matchedUser.is_verified === false) {
          return Response.json({
            exists: true,
            verified: false,
            field: 'email',
          });
        }
      }

      if (scope === 'conductor') {
        // Una persona puede registrarse una vez en cada categoría (carro, moto y mensajería); solo se bloquea repetir la misma.
        const cedulaConflict = await cedulaCategoryConflict(base44, cleanCedula, category);
        if (cedulaConflict) {
          return Response.json({ exists: true, verified: true, field: 'cedula', error: cedulaConflict });
        }
        if (cleanPlate) {
          const pRes = await base44.asServiceRole.entities.Mobile.filter({ plate: cleanPlate }).catch(() => []);
          const pList = (Array.isArray(pRes) ? pRes : pRes?.items || []).filter(
            (m) => m.approval_status !== 'rechazado'
          );
          // La misma persona puede usar su placa en sus distintas categorías; otra persona no puede usarla.
          if (plateHoldersOfOtherDrivers(pList, cleanCedula).length > 0) {
            return Response.json({
              exists: true,
              verified: true,
              field: 'plate',
              error: `La placa ${cleanPlate} ya se encuentra registrada en la base de datos.`,
            });
          }
        }
      }

      return Response.json({ exists: false, verified: false });
    }

    // Subida de foto de registro (pasajero o conductor antes de verificar OTP) al almacenamiento privado
    if (body?.action === 'upload_photo') {
      const dataUrl = String(body?.data_url || '').trim();
      const commaIdx = dataUrl.indexOf(',');
      if (!dataUrl.startsWith('data:image/') || commaIdx === -1) {
        return Response.json({ error: 'Formato de imagen inválido' }, { status: 400 });
      }
      const header = dataUrl.slice(0, commaIdx);
      const mimeMatch = header.match(/^data:(image\/[a-zA-Z0-9.+-]+)/);
      const mimeType = mimeMatch ? mimeMatch[1] : 'image/jpeg';
      const base64Data = dataUrl.slice(commaIdx + 1).replace(/\s+/g, '');
      if (!base64Data || base64Data.length > 8_000_000) {
        return Response.json({ error: 'La imagen supera el tamaño máximo permitido' }, { status: 400 });
      }
      const binaryStr = atob(base64Data);
      const bytes = new Uint8Array(binaryStr.length);
      for (let i = 0; i < binaryStr.length; i++) {
        bytes[i] = binaryStr.charCodeAt(i);
      }
      const safeName = String(body?.filename || 'foto.jpg')
        .replace(/[^a-zA-Z0-9._-]/g, '_')
        .replace(/\.\w+$/, '') + '.jpg';
      const file = new File([bytes], safeName, { type: mimeType });
      const { file_uri } = await base44.asServiceRole.integrations.Core.UploadPrivateFile({ file });
      const signed = await base44.asServiceRole.integrations.Core.CreateFileSignedUrl({
        file_uri,
        expires_in: 3600,
      }).catch(() => ({ signed_url: '' }));
      return Response.json({ file_uri, signed_url: signed?.signed_url || '' });
    }

    const rawCedula = (body?.cedula_url || '').toString().trim().slice(0, 2000);
    const rawTarjeta = (body?.tarjeta_url || '').toString().trim().slice(0, 2000);
    const rawVehicle = (body?.vehicle_url || '').toString().trim().slice(0, 2000);
    const rawSoat = (body?.soat_url || '').toString().trim().slice(0, 2000);
    const rawTecno = (body?.tecno_url || '').toString().trim().slice(0, 2000);

    const vehicle_type = body?.vehicle_type === 'carro' ? 'carro' : 'moto';
    const car_subtype = body?.car_subtype === 'taxi' ? 'taxi' : 'particular';
    const plate_type = body?.plate_type === 'blanca' ? 'blanca' : 'amarilla';
    const plate = (body?.plate || '').toString().toUpperCase().replace(/[\s.\-]/g, '').slice(0, 12);
    const cedulaNumber = (body?.cedula || '').toString().replace(/\D/g, '').slice(0, 15);
    const cedulaRules =
      `\nNúmero de cédula escrito por el conductor: "${cedulaNumber}".\n` +
      'Además incluye: cedula_number = número leído en la cédula (imagen 1), solo dígitos ("" si no se lee); ' +
      `cedula_number_match = true SOLO si ese número coincide exactamente con "${cedulaNumber}".\n`;
    const withCedula = (res) => {
      const read = String(res?.cedula_number || '').replace(/\D/g, '');
      // face_match fijo en true: el rostro ya no se compara con la cédula, pero la versión publicada de la app aún espera este campo.
      return { ...res, face_match: true, cedula_number: read, cedula_number_match: !!cedulaNumber && read === cedulaNumber };
    };

    if (!rawCedula || !rawTarjeta || !rawVehicle) {
      return Response.json({ error: 'Faltan fotos obligatorias para verificar (cédula, tarjeta de propiedad y vehículo).' }, { status: 400 });
    }
    if (vehicle_type === 'carro' && (!rawSoat || !rawTecno)) {
      return Response.json({ error: 'Para registrar un carro es obligatorio adjuntar la foto del SOAT y de la Revisión Técnico-Mecánica.' }, { status: 400 });
    }

    const ensureSignedUrl = async (val) => {
      if (!val) return '';
      if (/^https?:\/\//.test(val)) return val;
      const signed = await base44.asServiceRole.integrations.Core.CreateFileSignedUrl({ file_uri: val, expires_in: 300 });
      return signed.signed_url;
    };

    const todayBogota = new Date().toLocaleDateString('en-CA', { timeZone: 'America/Bogota' });

    if (vehicle_type === 'carro') {
      const [cedula_url, tarjeta_url, vehicle_url, soat_url, tecno_url] = await Promise.all([
        ensureSignedUrl(rawCedula),
        ensureSignedUrl(rawTarjeta),
        ensureSignedUrl(rawVehicle),
        ensureSignedUrl(rawSoat),
        ensureSignedUrl(rawTecno),
      ]);

      const modalDesc = car_subtype === 'taxi' ? 'un carro tipo taxi / servicio público' : 'un carro (automóvil particular o servicio público)';
      const prompt =
        `Eres un auditor ESTRICTO de seguridad y cumplimiento documental para una plataforma de transporte en Colombia. Fecha actual en Colombia: ${todayBogota}.\n` +
        'Recibirás CINCO imágenes en este orden exacto:\n' +
        '1) Foto de la cédula de ciudadanía colombiana del conductor.\n' +
        '2) Foto de la tarjeta de propiedad (Licencia de Tránsito) del vehículo.\n' +
        '3) Foto exterior del vehículo donde DEBE verse claramente la placa.\n' +
        '4) Foto de la póliza SOAT (Seguro Obligatorio de Accidentes de Tránsito) de Colombia.\n' +
        '5) Foto del Certificado de Revisión Técnico-Mecánica y de Emisiones Contaminantes de Colombia.\n\n' +
        'REGLA DE RIGUROSIDAD: NO aceptes fotos en blanco, objetos aleatorios, memes, dibujos, pisos, paredes, ni documentos borrosos o ilegibles. Si la persona sube cualquier foto que no sea el documento real, marca false de inmediato.\n' +
        `Placa registrada por el conductor en el formulario: "${plate}" (tipo de placa declarado: placa ${plate_type}; modalidad: ${car_subtype}).\n\n` +
        'Evalúa cada punto y responde SOLO el JSON:\n' +
        '1. cedula_ok: true SOLO si la imagen 1 es una cédula colombiana auténtica y legible.\n' +
        '2. tarjeta_ok: true SOLO si la imagen 2 es una Tarjeta de Propiedad / Licencia de Tránsito colombiana auténtica y legible.\n' +
        '3. extracted_plate: placa leída en la tarjeta de propiedad (imagen 2), en mayúsculas sin espacios ni guiones (o "" si no es legible).\n' +
        `4. plate_match: true SOLO si la placa de la tarjeta de propiedad coincide exactamente con "${plate}".\n` +
        `5. vehicle_ok: true SOLO si la imagen 3 muestra realmente ${modalDesc}.\n` +
        '6. vehicle_plate_visible: true SOLO si en la imagen 3 (foto del carro) se ve claramente la placa física del vehículo.\n' +
        '7. vehicle_extracted_plate: placa leída directamente en la foto del carro (imagen 3), en mayúsculas sin espacios ni guiones (o "" si no se ve).\n' +
        `8. vehicle_plate_match: true SOLO si la placa visible en la foto del carro (imagen 3) coincide exactamente con "${plate}". Si no se ve la placa en el carro o no coincide, marca false.\n` +
        '9. soat_ok: true SOLO si la imagen 4 es un documento o póliza SOAT de Colombia real y legible (impreso o digital oficial con datos de póliza, placa y vigencia).\n' +
        '10. soat_expiry_date: fecha de vencimiento ("vigencia hasta") leída en el SOAT en formato YYYY-MM-DD (o "" si no se logra leer).\n' +
        `11. soat_vigente: true SOLO si soat_ok es true, lograste leer la fecha de vencimiento del SOAT y esa fecha es igual o posterior a hoy (${todayBogota}). Si el SOAT está vencido o no se ve la fecha de vigencia, marca false.\n` +
        `12. soat_plate_match: true SOLO si la placa que figura en el SOAT coincide con "${plate}".\n` +
        '13. tecno_ok: true SOLO si la imagen 5 es un Certificado de Revisión Técnico-Mecánica y de Emisiones Contaminantes de Colombia real y legible.\n' +
        '14. tecno_expiry_date: fecha de vencimiento ("fecha de vencimiento" / "vigencia") leída en la tecnomecánica en formato YYYY-MM-DD (o "" si no se logra leer).\n' +
        `15. tecno_vigente: true SOLO si tecno_ok es true, lograste leer la fecha de vencimiento de la tecnomecánica y esa fecha es igual o posterior a hoy (${todayBogota}). Si está vencida o no se ve la fecha de vigencia, marca false.\n` +
        `16. tecno_plate_match: true SOLO si la placa que figura en la tecnomecánica coincide con "${plate}".\n` +
        '17. vehicle_color: color principal del vehículo leído en el campo COLOR de la tarjeta de propiedad (imagen 2) o visto en la foto del vehículo (imagen 3), en una palabra clara en español (ej. "Amarillo", "Negro", "Rojo", "Blanco", "Gris", "Plata", "Azul", "Verde"). Si es taxi de servicio público, usa "Amarillo".\n' +
        '18. issues: lista clara en español explicando cada documento rechazado, vencido o cuya placa no coincida (vacía si todo está perfecto).' +
        cedulaRules;

      const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
        prompt,
        file_urls: [cedula_url, tarjeta_url, vehicle_url, soat_url, tecno_url],
        response_json_schema: {
          type: 'object',
          properties: {
            cedula_ok: { type: 'boolean' },
            tarjeta_ok: { type: 'boolean' },
            extracted_plate: { type: 'string' },
            plate_match: { type: 'boolean' },
            vehicle_ok: { type: 'boolean' },
            vehicle_plate_visible: { type: 'boolean' },
            vehicle_extracted_plate: { type: 'string' },
            vehicle_plate_match: { type: 'boolean' },
            soat_ok: { type: 'boolean' },
            soat_expiry_date: { type: 'string' },
            soat_vigente: { type: 'boolean' },
            soat_plate_match: { type: 'boolean' },
            tecno_ok: { type: 'boolean' },
            tecno_expiry_date: { type: 'string' },
            tecno_vigente: { type: 'boolean' },
            tecno_plate_match: { type: 'boolean' },
            vehicle_color: { type: 'string' },
            cedula_number: { type: 'string' },
            issues: { type: 'array', items: { type: 'string' } },
          },
          required: [
            'cedula_ok', 'tarjeta_ok', 'extracted_plate', 'plate_match', 'cedula_number',
            'vehicle_ok', 'vehicle_plate_visible', 'vehicle_extracted_plate', 'vehicle_plate_match',
            'soat_ok', 'soat_expiry_date', 'soat_vigente', 'soat_plate_match',
            'tecno_ok', 'tecno_expiry_date', 'tecno_vigente', 'tecno_plate_match', 'vehicle_color', 'issues',
          ],
        },
      });

      return Response.json({ verification: withCedula(result) });
    }

    // Flujo para MOTO (3 fotos: cédula, tarjeta de propiedad y foto de la moto con placa visible)
    const [cedula_url, tarjeta_url, vehicle_url] = await Promise.all([
      ensureSignedUrl(rawCedula),
      ensureSignedUrl(rawTarjeta),
      ensureSignedUrl(rawVehicle),
    ]);

    const prompt =
      `Eres un auditor ESTRICTO de seguridad y cumplimiento documental para una plataforma de transporte en Colombia. Fecha actual: ${todayBogota}.\n` +
      'Recibirás TRES imágenes en este orden exacto:\n' +
      '1) Foto de la cédula de ciudadanía colombiana del conductor.\n' +
      '2) Foto de la tarjeta de propiedad (Licencia de Tránsito) de la motocicleta.\n' +
      '3) Foto exterior de la motocicleta donde DEBE verse claramente la placa.\n\n' +
      'REGLA DE RIGUROSIDAD: NO aceptes fotos en blanco, objetos aleatorios, memes, dibujos, pisos, paredes, ni documentos borrosos o ilegibles. Si la persona sube cualquier foto que no corresponda, marca false de inmediato.\n' +
      `Placa registrada por el conductor en el formulario: "${plate}".\n\n` +
      'Evalúa cada punto y responde SOLO el JSON:\n' +
      '1. cedula_ok: true SOLO si la imagen 1 es una cédula colombiana auténtica y legible.\n' +
      '2. tarjeta_ok: true SOLO si la imagen 2 es una Tarjeta de Propiedad / Licencia de Tránsito colombiana auténtica y legible.\n' +
      '3. extracted_plate: placa leída en la tarjeta de propiedad (imagen 2), en mayúsculas sin espacios ni guiones (o "" si no es legible).\n' +
      `4. plate_match: true SOLO si la placa de la tarjeta de propiedad coincide exactamente con "${plate}".\n` +
      '5. vehicle_ok: true SOLO si la imagen 3 muestra realmente una motocicleta.\n' +
      '6. vehicle_plate_visible: true SOLO si en la imagen 3 (foto de la moto) se ve claramente la placa física instalada en la motocicleta.\n' +
      '7. vehicle_extracted_plate: placa leída directamente en la foto de la motocicleta (imagen 3), en mayúsculas sin espacios ni guiones (o "" si no se ve).\n' +
      `8. vehicle_plate_match: true SOLO si la placa visible en la foto de la motocicleta (imagen 3) coincide exactamente con "${plate}". Si en la foto de la moto no se ve la placa o no concuerda, marca false.\n` +
      '9. vehicle_color: color principal de la motocicleta leído en el campo COLOR de la tarjeta de propiedad (imagen 2) o visto en la foto de la moto (imagen 3), en una palabra clara en español (ej. "Negro", "Rojo", "Azul", "Blanco", "Gris").\n' +
      '10. issues: lista clara en español explicando cada problema encontrado (vacía si todo está perfecto).' +
      cedulaRules;

    const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      file_urls: [cedula_url, tarjeta_url, vehicle_url],
      response_json_schema: {
        type: 'object',
        properties: {
          cedula_ok: { type: 'boolean' },
          tarjeta_ok: { type: 'boolean' },
          extracted_plate: { type: 'string' },
          plate_match: { type: 'boolean' },
          vehicle_ok: { type: 'boolean' },
          vehicle_plate_visible: { type: 'boolean' },
          vehicle_extracted_plate: { type: 'string' },
          vehicle_plate_match: { type: 'boolean' },
          vehicle_color: { type: 'string' },
          cedula_number: { type: 'string' },
          issues: { type: 'array', items: { type: 'string' } },
        },
        required: [
          'cedula_ok', 'tarjeta_ok', 'extracted_plate', 'plate_match', 'cedula_number',
          'vehicle_ok', 'vehicle_plate_visible', 'vehicle_extracted_plate', 'vehicle_plate_match',
          'vehicle_color', 'issues',
        ],
      },
    });

    return Response.json({
      verification: {
        ...withCedula(result),
        soat_ok: true,
        soat_vigente: true,
        soat_plate_match: true,
        tecno_ok: true,
        tecno_vigente: true,
        tecno_plate_match: true,
      },
    });
  } catch (error) {
    return Response.json({ error: error.message || 'Error en la verificación de documentos' }, { status: 500 });
  }
}
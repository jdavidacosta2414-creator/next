import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { ensureAccount, getConfig, creditPoints, logTx, normalizePhone } from '../../shared/club.ts';

const NEW_ACCOUNT_DAYS = 30;

// Registra el código de referido de un pasajero nuevo y entrega las bonificaciones correspondientes.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    const body = await req.json().catch(() => ({}));
    const code = String(body.code || '').trim().toUpperCase();
    if (!code || code.length < 4 || code.length > 12) return Response.json({ error: 'Código inválido' }, { status: 400 });

    const sr = base44.asServiceRole;
    const cfg = await getConfig(sr);
    if (!cfg.referrals_enabled) return Response.json({ error: 'El programa de referidos está desactivado' }, { status: 403 });

    const acc = await ensureAccount(sr, user);
    if (acc.referred_by_code) return Response.json({ error: 'Ya usaste un código de referido' }, { status: 409 });
    if (Date.now() - new Date(user.created_date).getTime() > NEW_ACCOUNT_DAYS * 86400000 ||
        Number(acc.transport_rides_count || 0) + Number(acc.delivery_count || 0) > 0) {
      return Response.json({ error: 'El código de referido solo aplica para cuentas nuevas' }, { status: 400 });
    }

    const phone = normalizePhone(user.phone || acc.user_phone);
    if (phone.length < 10) return Response.json({ error: 'Registra tu número de celular para usar un código' }, { status: 400 });

    const inviters = await sr.entities.ClubAccount.filter({ referral_code: code }, 'created_date', 1);
    const inviter = inviters?.[0];
    if (!inviter) return Response.json({ error: 'Ese código no existe' }, { status: 404 });
    if (inviter.user_id === user.id) return Response.json({ error: 'No puedes usar tu propio código' }, { status: 400 });

    const samePhone = await sr.entities.ClubAccount.filter({ user_phone: phone }, 'created_date', 5);
    if (normalizePhone(inviter.user_phone) === phone || (samePhone || []).some((a) => a.user_id !== user.id)) {
      return Response.json({ error: 'Este número de celular ya está registrado en otra cuenta' }, { status: 409 });
    }

    // Bloqueo atómico: un solo código por usuario
    const lock = await sr.entities.ClubAccount.updateMany(
      { id: acc.id, referred_by_code: { $in: [null, ''] } },
      { $set: { referred_by_code: code, referred_by_user_id: inviter.user_id, user_phone: phone } }
    );
    if (!lock?.updated) return Response.json({ error: 'Ya usaste un código de referido' }, { status: 409 });

    const inviterPts = Number(cfg.referral_points_inviter) || 0;
    const bonus = await sr.entities.ClubAccount.updateMany(
      { id: inviter.id, referral_bonus_count: { $lt: Number(cfg.referral_limit) || 0 } },
      { $inc: { referral_bonus_count: 1, referrals_total: 1, balance: inviterPts, total_earned: inviterPts } }
    );
    if (!bonus?.updated) await sr.entities.ClubAccount.updateMany({ id: inviter.id }, { $inc: { referrals_total: 1 } });
    const inviterGot = bonus?.updated ? inviterPts : 0;
    const newPts = Number(cfg.referral_points_new) || 0;

    const referral = await sr.entities.ClubReferral.create({
      code,
      inviter_user_id: inviter.user_id,
      inviter_name: inviter.user_name,
      invitee_user_id: user.id,
      invitee_name: acc.user_name,
      invitee_phone: phone,
      inviter_points: inviterGot,
      invitee_points: newPts,
    });

    if (inviterGot > 0) {
      await logTx(sr, inviter.id, {
        type: 'referido_invitador',
        amount: inviterGot,
        referral_id: referral.id,
        dedupe_key: `ref_inv_${user.id}`,
        description: `${acc.user_name} se registró con tu código`,
      });
    }
    await creditPoints(sr, acc.id, newPts, {
      type: 'referido_nuevo',
      referral_id: referral.id,
      dedupe_key: `ref_new_${user.id}`,
      description: `Bienvenida por registrarte con el código ${code}`,
    });

    return Response.json({ success: true, points: newPts, inviter_rewarded: inviterGot > 0 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';
import { assertCanWork } from '../../shared/dailyPass.ts';
import { recordDriverPerformanceEvent } from '../../shared/driverLevelEngine.ts';

// El conductor hace una contraoferta: se registra como candidato con su tarifa
// propuesta (offered_fare). No se asigna automáticamente; el pasajero elige
// entre los conductores que hicieron una oferta.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const { service_id, mobile_id, lat, lng, offered_fare } = body;
    const numericFare = Number(offered_fare);
    if (!service_id || !mobile_id || !Number.isFinite(numericFare) || numericFare < 5000 || numericFare > 500000) {
      return Response.json({ error: 'Invalid service_id, mobile_id or offered_fare' }, { status: 400 });
    }

    const srv = base44.asServiceRole.entities.Service;
    const mob = base44.asServiceRole.entities.Mobile;

    // El llamante debe ser titular del perfil Mobile (o staff) y tener su pase vigente para ofertar.
    const pass = await assertCanWork(mob, mobile_id, user);
    if (!pass.ok) return pass.error;

    const service = await srv.get(service_id);
    if (!service) return Response.json({ error: 'Service not found' }, { status: 404 });
    if (service.status !== 'pendiente') {
      return Response.json({ error: 'Service no longer available' }, { status: 409 });
    }

    const now = new Date().toISOString();
    const effectiveFare = service.origin === 'whatsapp' || service.origin === 'negocios' ? Number(service.fare || numericFare) : numericFare;
    const candidates = service.candidates || [];
    const viewedBy = Array.isArray(service.viewed_by) ? service.viewed_by : [];
    const nextViewedBy = viewedBy.includes(mobile_id) ? viewedBy : [...viewedBy, mobile_id];
    const idx = candidates.findIndex((c) => c.mobile_id === mobile_id);

    if (idx >= 0) {
      // El conductor ya había ofertado: reemplaza su oferta anterior.
      const replaced = candidates.map((c) =>
        c.mobile_id === mobile_id ? { ...c, lat, lng, offered_fare: effectiveFare, timestamp: now } : c
      );
      await srv.update(service_id, { candidates: replaced, viewed_by: nextViewedBy });
    } else {
      await srv.update(service_id, {
        candidates: [...candidates, { mobile_id, lat, lng, offered_fare: effectiveFare, timestamp: now }],
        viewed_by: nextViewedBy,
      });
    }

    // Registrar como oferta enviada (si el pasajero no la selecciona, NO perjudica la tasa de aceptación del conductor)
    try {
      await recordDriverPerformanceEvent(base44, {
        mobile: pass.mobile,
        service,
        eventType: 'offer_sent',
      });
    } catch {}

    return Response.json({ offered: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
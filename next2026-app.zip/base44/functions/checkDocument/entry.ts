import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

// Revisión instantánea con IA de UNA foto apenas se sube (registro de conductor, foto de pasajero o comprobante).
// Si la foto no corresponde, está vencida o sus datos no concuerdan, devuelve ok=false con el motivo
// para que la app no deje continuar hasta subir una foto válida.
const KINDS = ['perfil', 'cedula', 'tarjeta', 'soat', 'tecno', 'vehiculo', 'transfer'];

const clean = (v, max = 30) => String(v || '').toUpperCase().replace(/[\s.\-]/g, '').slice(0, max);
const digits = (v) => String(v || '').replace(/\D/g, '').slice(0, 15);

const SCHEMA = {
  type: 'object',
  properties: {
    is_valid_document: { type: 'boolean' },
    extracted_plate: { type: 'string' },
    extracted_cedula: { type: 'string' },
    expiry_date: { type: 'string' },
    transfer_amount: { type: 'number' },
    looks_edited: { type: 'boolean' },
    reason: { type: 'string' },
  },
  required: ['is_valid_document', 'reason'],
};

// La foto de perfil es una selfie normal, no un documento: tiene su propia revisión.
const SELFIE_SCHEMA = {
  type: 'object',
  properties: {
    face_visible: { type: 'boolean' },
    wears_dark_glasses: { type: 'boolean' },
    wears_cap: { type: 'boolean' },
    wears_mask: { type: 'boolean' },
    reason: { type: 'string' },
  },
  required: ['face_visible', 'wears_dark_glasses', 'wears_cap', 'wears_mask', 'reason'],
};

function buildPrompt(kind, today, vehicleType) {
  const strict =
    'Eres un auditor ESTRICTO de documentos en Colombia. Fecha de hoy: ' + today + '. ' +
    'Rechaza (is_valid_document=false) fotos de pantallas con otra cosa, objetos, paisajes, memes, dibujos, fotocopias ilegibles, imágenes borrosas o recortadas donde no se lean los datos. ' +
    'En "reason" explica en español, en una frase corta y amable, por qué se rechaza (o "OK" si es válida). Responde solo el JSON.\n';
  const vehiculo = vehicleType === 'carro' ? 'un carro' : 'una motocicleta';
  switch (kind) {
    case 'perfil':
      return 'Revisa esta foto de perfil de una app de transporte en Colombia. Debe ser una foto normal tipo selfie; ' +
        'NO exijas una foto tipo documento: acepta cualquier fondo, lugar, ángulo natural, sonrisa o expresión. ' +
        'face_visible: true si se ve con claridad el rostro de UNA sola persona real (con luz suficiente, sin estar borroso, muy lejos ni recortado); ' +
        'false si es un dibujo, caricatura, animal, objeto, paisaje, un grupo de personas, o una foto tomada a una pantalla o a otra foto. ' +
        'wears_dark_glasses: true SOLO si lleva gafas oscuras o de sol que no dejan ver los ojos. Las gafas formuladas o de lente transparente, donde los ojos se ven, SÍ están permitidas: con ellas es false y el rostro cuenta como visible. ' +
        'wears_cap: true si lleva gorra, sombrero o casco. ' +
        'wears_mask: true si lleva tapabocas o algo que le tape la cara. ' +
        'reason: frase corta y amable en español con lo que debe corregir (o "OK" si la foto sirve). Responde solo el JSON.';
    case 'cedula':
      return strict + 'La imagen debe ser una CÉDULA DE CIUDADANÍA colombiana (física o digital) donde se lea el número. ' +
        'extracted_cedula: número de cédula leído, solo dígitos ("" si no se lee). is_valid_document=true solo si es una cédula colombiana legible.';
    case 'tarjeta':
      return strict + 'La imagen debe ser una TARJETA DE PROPIEDAD / LICENCIA DE TRÁNSITO colombiana del vehículo (no la cédula, no la licencia de conducción, no el SOAT). ' +
        'extracted_plate: placa leída, mayúsculas sin espacios ni guiones ("" si no se lee). is_valid_document=true solo si es una tarjeta de propiedad legible.';
    case 'soat':
      return strict + 'La imagen debe ser una póliza SOAT colombiana (impresa o digital). ' +
        'extracted_plate: placa que figura en el SOAT. expiry_date: fecha de FIN de vigencia ("vigencia hasta") en formato YYYY-MM-DD ("" si no se lee). ' +
        'is_valid_document=true solo si es un SOAT legible (aunque esté vencido; la vigencia se valida aparte).';
    case 'tecno':
      return strict + 'La imagen debe ser un Certificado de Revisión Técnico-Mecánica y de Emisiones Contaminantes de Colombia. ' +
        'extracted_plate: placa que figura en el certificado. expiry_date: fecha de vencimiento en formato YYYY-MM-DD ("" si no se lee). ' +
        'is_valid_document=true solo si es ese certificado y es legible (aunque esté vencido; la vigencia se valida aparte).';
    case 'vehiculo':
      return strict + `La imagen debe mostrar ${vehiculo} real (no foto de catálogo ni de internet) con la placa física visible. ` +
        'extracted_plate: placa leída en el vehículo ("" si no se ve). is_valid_document=true solo si es ' + vehiculo + ' real y se ve la placa.';
    case 'transfer':
      return strict + 'La imagen debe ser una captura o comprobante de transferencia/pago colombiano (Nequi, Daviplata, Bancolombia, Nu, Llave Bre-B, PSE, etc.) con monto visible. ' +
        'transfer_amount: monto transferido en COP (solo número, 0 si no se lee). looks_edited: true si notas señales de edición (tipografías distintas, números desalineados, recortes, plantillas genéricas). ' +
        'is_valid_document=true solo si es realmente un comprobante de transferencia legible.';
  }
  return strict;
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const kind = String(body?.kind || '');
    const fileUri = String(body?.file_uri || '').trim().slice(0, 500);
    if (!KINDS.includes(kind)) return Response.json({ error: 'Tipo de documento inválido' }, { status: 400 });
    // Solo archivos del almacenamiento privado de la app (no URLs externas arbitrarias)
    if (!fileUri || /^https?:\/\//i.test(fileUri)) {
      return Response.json({ error: 'Archivo inválido' }, { status: 400 });
    }

    const plate = clean(body?.plate, 12);
    const cedula = digits(body?.cedula);
    const amount = Number(body?.amount || 0);
    const vehicleType = body?.vehicle_type === 'carro' ? 'carro' : 'moto';
    const today = new Date().toLocaleDateString('en-CA', { timeZone: 'America/Bogota' });

    const { signed_url } = await base44.asServiceRole.integrations.Core.CreateFileSignedUrl({
      file_uri: fileUri,
      expires_in: 300,
    });

    const ai = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: buildPrompt(kind, today, vehicleType),
      file_urls: [signed_url],
      response_json_schema: kind === 'perfil' ? SELFIE_SCHEMA : SCHEMA,
    });

    const reason = String(ai?.reason || '').trim();
    const fail = (message) => Response.json({ ok: false, message });
    const docNames = {
      perfil: 'La foto de perfil',
      cedula: 'La foto no corresponde a una cédula',
      tarjeta: 'La foto no corresponde a una tarjeta de propiedad',
      soat: 'La foto no corresponde a un SOAT',
      tecno: 'La foto no corresponde a una Revisión Técnico-Mecánica',
      vehiculo: 'La foto del vehículo no es válida',
      transfer: 'La imagen no corresponde a un comprobante de transferencia',
    };

    if (kind === 'perfil') {
      const puesto = [
        ai?.wears_dark_glasses && 'las gafas oscuras',
        ai?.wears_cap && 'la gorra o el casco',
        ai?.wears_mask && 'el tapabocas',
      ].filter(Boolean);
      if (puesto.length > 0) {
        const lista = new Intl.ListFormat('es', { type: 'conjunction' }).format(puesto);
        return fail(`Para la selfie quítate ${lista}, así se ve bien tu rostro.`);
      }
      if (!ai?.face_visible) {
        return fail(`Tómate una selfie normal donde se vea claramente tu rostro. ${reason && reason !== 'OK' ? reason : ''}`.trim());
      }
      return Response.json({ ok: true });
    }

    if (!ai?.is_valid_document) {
      return fail(`${docNames[kind]}. ${reason && reason !== 'OK' ? reason : 'Sube una foto clara del documento correcto.'}`);
    }

    const readPlate = clean(ai?.extracted_plate, 12);
    const expiry = String(ai?.expiry_date || '').trim();

    if (kind === 'cedula') {
      const readCedula = digits(ai?.extracted_cedula);
      if (!readCedula) return fail('No se logra leer el número de la cédula. Toma la foto más cerca y con buena luz.');
      if (cedula && readCedula !== cedula) {
        return fail(`El número de la cédula en la foto (${readCedula}) no coincide con el número que escribiste (${cedula}).`);
      }
      return Response.json({ ok: true, cedula_number: readCedula });
    }

    if (['tarjeta', 'soat', 'tecno', 'vehiculo'].includes(kind)) {
      if (!readPlate) {
        return fail(kind === 'vehiculo'
          ? 'No se ve la placa en la foto del vehículo. Toma la foto donde la placa se lea claramente.'
          : 'No se logra leer la placa en el documento. Toma una foto más clara.');
      }
      if (plate && readPlate !== plate) {
        return fail(`La placa en la foto (${readPlate}) no coincide con la placa que escribiste (${plate}).`);
      }
    }

    if (kind === 'soat' || kind === 'tecno') {
      const label = kind === 'soat' ? 'El SOAT' : 'La Revisión Técnico-Mecánica';
      if (!/^\d{4}-\d{2}-\d{2}$/.test(expiry)) {
        return fail(`No se logra leer la fecha de vencimiento. ${label === 'El SOAT' ? 'Sube un SOAT' : 'Sube una tecnomecánica'} donde se vea la vigencia.`);
      }
      if (expiry < today) {
        return fail(`${label} está vencid${kind === 'soat' ? 'o' : 'a'} desde ${expiry}. Sube ${kind === 'soat' ? 'un SOAT vigente' : 'una tecnomecánica vigente'}.`);
      }
      return Response.json({ ok: true, expiry_date: expiry, extracted_plate: readPlate });
    }

    if (kind === 'transfer') {
      const readAmount = Number(ai?.transfer_amount || 0);
      const warnings = [];
      if (ai?.looks_edited) warnings.push('posible edición');
      if (amount && readAmount && Math.abs(readAmount - amount) > 1) warnings.push(`monto leído ${readAmount}`);
      return Response.json({ ok: true, amount: readAmount, warnings });
    }

    return Response.json({ ok: true, extracted_plate: readPlate });
  } catch (error) {
    return Response.json({ error: error.message || 'Error al revisar el documento' }, { status: 500 });
  }
}
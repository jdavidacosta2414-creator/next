import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

// La Central/Admin confirma con el cliente por WhatsApp que acepta la oferta de
// un conductor y asigna ese conductor con la tarifa acordada. Solo para
// servicios originados en WhatsApp, evitando asignar antes de la confirmación.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin' && user.role !== 'superadmin' && user.role !== 'central') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const { service_id, mobile_id } = await req.json();
    if (!service_id || !mobile_id) {
      return Response.json({ error: 'Missing service_id or mobile_id' }, { status: 400 });
    }

    const srv = base44.asServiceRole.entities.Service;
    const mob = base44.asServiceRole.entities.Mobile;

    const service = await srv.get(service_id);
    if (!service) return Response.json({ error: 'Service not found' }, { status: 404 });
    if (service.status !== 'pendiente') {
      return Response.json({ error: 'Service no longer available' }, { status: 409 });
    }

    const candidate = (service.candidates || []).find((c) => c.mobile_id === mobile_id);
    if (!candidate) return Response.json({ error: 'Candidate not found' }, { status: 404 });

    const mobile = await mob.get(mobile_id).catch(() => null);
    const offeredFare = candidate.offered_fare != null ? candidate.offered_fare : service.fare;

    const assigned = await srv.update(service_id, {
      status: 'asignado',
      mobile_id,
      mobile_name: mobile?.name || '',
      mobile_plate: mobile?.plate || '',
      mobile_phone: mobile?.phone || '',
      mobile_photo: mobile?.photo_url || mobile?.vehicle_photo || '',
      fare: offeredFare,
      candidates: [],
    });

    await mob.update(mobile_id, { status: 'ocupado' });

    return Response.json({ assigned: true, service: assigned });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
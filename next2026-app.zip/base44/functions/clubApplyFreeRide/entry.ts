import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { getConfig } from '../../shared/club.ts';

// Aplica un viaje gratis disponible del pasajero a su servicio de moto recién creado.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    const { service_id } = await req.json().catch(() => ({}));
    if (!service_id) return Response.json({ error: 'Falta el servicio' }, { status: 400 });

    const sr = base44.asServiceRole;
    const cfg = await getConfig(sr);
    if (!cfg.free_ride_enabled) return Response.json({ error: 'Los viajes gratis están desactivados' }, { status: 403 });

    const service = await sr.entities.Service.get(service_id).catch((e) => (e.status === 404 ? null : Promise.reject(e)));
    if (!service) return Response.json({ error: 'Servicio no encontrado' }, { status: 404 });
    if (service.created_by_id !== user.id) return Response.json({ error: 'Forbidden' }, { status: 403 });
    if (service.status !== 'pendiente') return Response.json({ error: 'El servicio ya no está pendiente' }, { status: 409 });
    if (service.service_type !== 'transporte' || service.vehicle_type !== 'moto') {
      return Response.json({ error: 'El viaje gratis solo aplica para carreras en moto' }, { status: 400 });
    }
    if (service.free_ride_id) return Response.json({ error: 'Este servicio ya tiene un viaje gratis' }, { status: 409 });

    const list = await sr.entities.ClubFreeRide.filter({ user_id: user.id, status: 'disponible' }, 'created_date', 1);
    const ride = list?.[0];
    if (!ride) return Response.json({ error: 'No tienes viajes gratis disponibles' }, { status: 404 });

    const claim = await sr.entities.ClubFreeRide.updateMany(
      { id: ride.id, status: 'disponible' },
      { $set: { status: 'reservado', used_service_id: service.id } }
    );
    if (!claim?.updated) return Response.json({ error: 'Este viaje gratis ya fue utilizado' }, { status: 409 });

    const discount = Math.min(Number(service.fare || 0), Number(ride.max_value || cfg.free_ride_max_value));
    await sr.entities.Service.update(service.id, { free_ride_id: ride.id, free_ride_discount: discount });

    return Response.json({ success: true, discount, to_pay: Math.max(0, Number(service.fare || 0) - discount), code: ride.code });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { normalizeConductorInput, createConductorProfile, statusForError } from '../../shared/conductorRegistration.ts';

// Registra el perfil de un conductor (móvil) para el usuario autenticado.
// Si se registra como mensajero, recibe aquí mismo su ID corto y permanente.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Debes iniciar sesión para registrarte como conductor' }, { status: 401 });
    }

    const data = normalizeConductorInput(await req.json());
    const mobile = await createConductorProfile(base44, user, data, { requirePlate: true });
    return Response.json({ success: true, mobile });
  } catch (error) {
    const msg = error.message || 'Error al registrar el conductor';
    return Response.json({ error: msg }, { status: statusForError(msg) });
  }
}
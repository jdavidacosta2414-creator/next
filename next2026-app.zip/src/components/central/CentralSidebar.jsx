import React from 'react';
import {
  LayoutDashboard, Package, Bike, Users, Truck, TrendingUp,
  BarChart3, ShieldAlert, Wallet, CreditCard, MapPin, Link as LinkIcon, MessageCircle, Megaphone, Gift, Award,
} from 'lucide-react';
import NextLogo from '@/components/NextLogo';

// Navegación del panel Central agrupada en secciones operativas.
const SECTIONS = [
  {
    title: 'OPERACIÓN',
    items: [
      { v: 'dashboard', label: 'Resumen', icon: LayoutDashboard },
      { v: 'pendientes', label: 'Servicios', icon: Package, badge: true },
      { v: 'moviles', label: 'Móviles', icon: Bike, mobilesBadge: true },
      { v: 'chat', label: 'Chat', icon: MessageCircle },
    ],
  },
  {
    title: 'GESTIÓN',
    items: [
      { v: 'clientes', label: 'Clientes', icon: Users },
      { v: 'mensajeria', label: 'Mensajería', icon: Truck },
      { v: 'ranking', label: 'Ranking', icon: TrendingUp },
      { v: 'niveles_rendimiento', label: 'Niveles y rendimiento', icon: Award },
      { v: 'reportes', label: 'Reportes', icon: BarChart3 },
      { v: 'incidencias', label: 'Incidencias', icon: ShieldAlert },
      { v: 'recargas', label: 'Recargas', icon: Wallet },
      { v: 'publicidad', label: 'Publicidad', icon: Megaphone },
      { v: 'puntos', label: 'Puntos y compras', icon: Gift, pointsBadge: true },
      { v: 'planilla', label: 'Saldo', icon: CreditCard },
      { v: 'zona', label: 'Zona', icon: MapPin },
      { v: 'link', label: 'Link', icon: LinkIcon },
    ],
  },
];

export default function CentralSidebar({ active, onChange, pendingCount = 0, pendingPointsCount = 0, pendingMobilesCount = 0 }) {
  return (
    <aside className="hidden lg:flex flex-col w-60 h-screen sticky top-0 bg-[#0a0d11] border-r border-white/8 flex-shrink-0">
      {/* Logo */}
      <div className="px-5 py-5 border-b border-white/8">
        <NextLogo size="sm" withGlow={false} />
        <p className="mt-2 text-[10px] text-[#1E6BFF] uppercase tracking-[0.2em] font-medium text-center">
          Central de Operaciones
        </p>
      </div>

      {/* Navegación agrupada */}
      <nav className="flex-1 overflow-y-auto thin-scroll px-3 py-3">
        {SECTIONS.map((section) => (
          <div key={section.title} className="mb-4">
            <p className="px-3 mb-1 text-[10px] font-bold text-[#5A6478] uppercase tracking-wider">{section.title}</p>
            {section.items.map((item) => {
              const Icon = item.icon;
              const isActive = active === item.v;
              return (
                <button
                  key={item.v}
                  onClick={() => onChange(item.v)}
                  className={`w-full flex items-center gap-2.5 h-9 px-3 rounded-lg text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-[#1E6BFF] text-white'
                      : 'text-[#8B95A8] hover:bg-white/5 hover:text-white'
                  }`}
                >
                  <Icon className="w-4 h-4 flex-shrink-0" />
                  <span className="flex-1 text-left">{item.label}</span>
                  {item.badge && pendingCount > 0 && (
                    <span className="inline-flex items-center justify-center min-w-5 h-5 px-1.5 rounded-full text-xs font-bold bg-[#00E5FF] text-[#0B0F1A]">
                      {pendingCount}
                    </span>
                  )}
                  {item.mobilesBadge && pendingMobilesCount > 0 && (
                    <span className="inline-flex items-center justify-center min-w-5 h-5 px-1.5 rounded-full text-xs font-bold bg-amber-400 text-[#0B0F1A]">
                      {pendingMobilesCount}
                    </span>
                  )}
                  {item.pointsBadge && pendingPointsCount > 0 && (
                    <span className="inline-flex items-center justify-center min-w-5 h-5 px-1.5 rounded-full text-xs font-bold bg-amber-400 text-[#0B0F1A]">
                      {pendingPointsCount}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        ))}
      </nav>

      {/* Footer */}
      <div className="px-4 py-4 border-t border-white/8">
        <p className="text-[11px] text-[#5A6478] leading-relaxed text-center">
          Transporte y mensajería<br />en un solo lugar
        </p>
        <p className="mt-1 text-[10px] text-[#00E5FF]/70 font-medium tracking-wide text-center">
          Rápido · Seguro · Confiable
        </p>
      </div>
    </aside>
  );
}
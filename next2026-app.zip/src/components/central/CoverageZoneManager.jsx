import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { MapPin, Plus, X, Shield, Loader2 } from 'lucide-react';

export default function CoverageZoneManager() {
  const [zone, setZone] = useState(null);
  const [newBarrio, setNewBarrio] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      const zones = await base44.entities.CoverageZone.list('-created_date', 1);
      if (zones.length > 0) {
        setZone(zones[0]);
      } else {
        const created = await base44.entities.CoverageZone.create({ neighborhoods: [], active: true });
        setZone(created);
      }
      setLoading(false);
    })();
  }, []);

  const addBarrio = async () => {
    if (!newBarrio.trim()) return;
    setSaving(true);
    const updated = [...(zone.neighborhoods || []), newBarrio.trim()];
    const z = await base44.entities.CoverageZone.update(zone.id, { neighborhoods: updated });
    setZone(z);
    setNewBarrio('');
    setSaving(false);
  };

  const removeBarrio = async (b) => {
    setSaving(true);
    const updated = (zone.neighborhoods || []).filter(x => x !== b);
    const z = await base44.entities.CoverageZone.update(zone.id, { neighborhoods: updated });
    setZone(z);
    setSaving(false);
  };

  const toggleActive = async () => {
    setSaving(true);
    const z = await base44.entities.CoverageZone.update(zone.id, { active: !zone.active });
    setZone(z);
    setSaving(false);
  };

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-[#1E6BFF]" /></div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Shield className="w-4 h-4 text-[#1E6BFF]" />
        <h3 className="text-sm font-semibold text-[#8B8C94]">Zona de cobertura</h3>
      </div>
      <div className={`rounded-xl p-3 border ${zone.active ? 'bg-[#1E6BFF]/10 border-[#1E6BFF]/20' : 'bg-[#0D0D0D] border-[#1F1F1F]'}`}>
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-white">{zone.active ? 'Zona activa' : 'Zona desactivada'}</span>
          <button disabled={saving} onClick={toggleActive}
            className="h-8 px-3 rounded-lg border border-[#262626] text-[#8B8C94] text-xs hover:text-white transition disabled:opacity-50">
            {zone.active ? 'Desactivar' : 'Activar'}
          </button>
        </div>
      </div>
      {zone.active && <p className="text-xs text-[#8B8C94]">Solo se aceptan servicios cuya dirección de recogida coincida con un barrio de la lista.</p>}
      <div className="flex gap-2">
        <input value={newBarrio} onChange={e => setNewBarrio(e.target.value)} onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addBarrio())}
          placeholder="Ej: Chapinero" disabled={saving}
          className="h-10 flex-1 rounded-lg border border-[#262626] bg-[#0A0A0A] px-3 text-sm text-white placeholder:text-[#6B6B6B] focus:outline-none focus:ring-2 focus:ring-[#1E6BFF]/30 disabled:opacity-50" />
        <button onClick={addBarrio} disabled={saving || !newBarrio.trim()}
          className="h-10 w-10 rounded-lg bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-[#FFFFFF] flex items-center justify-center disabled:opacity-50">
          <Plus className="w-4 h-4" />
        </button>
      </div>
      <div className="space-y-2">
        {(zone.neighborhoods || []).length === 0 ? (
          <p className="text-center text-sm text-[#8B8C94] py-4">No hay barrios configurados</p>
        ) : zone.neighborhoods.map(b => (
          <div key={b} className="bg-[#0D0D0D] rounded-xl p-3 border border-[#1F1F1F] flex items-center gap-2">
            <MapPin className="w-4 h-4 text-[#1E6BFF] flex-shrink-0" />
            <span className="text-sm text-white flex-1">{b}</span>
            <button onClick={() => removeBarrio(b)} disabled={saving} className="text-[#6B6B6B] hover:text-red-400 disabled:opacity-50">
              <X className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
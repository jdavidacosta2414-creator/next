import React, { useState, useEffect, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { Search, Phone, Users, RotateCcw, Wallet, Loader2, ChevronDown, Bike, Car, MapPin, X } from 'lucide-react';
import ClientAvatar from '@/components/shared/ClientAvatar';

const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');

function timeAgo(d) {
  if (!d) return '—';
  const mins = Math.floor((Date.now() - new Date(d).getTime()) / 60000);
  if (mins < 60) return `Hace ${mins} min`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `Hace ${hrs} h`;
  const days = Math.floor(hrs / 24);
  return `Hace ${days} d`;
}

const STATUS_LABELS = {
  pendiente: 'Buscando', asignado: 'Asignado', en_camino: 'En camino',
  recogida: 'En recorrido', finalizado: 'Finalizado', cancelado: 'Cancelado',
};
const STATUS_COLORS = {
  pendiente: 'text-[#FFB800]', asignado: 'text-[#00E5FF]', en_camino: 'text-[#1E6BFF]',
  recogida: 'text-[#1E6BFF]', finalizado: 'text-[#00E676]', cancelado: 'text-[#FF5252]',
};

function Kpi({ icon: Icon, value, label, accent }) {
  return (
    <div className="bg-[#161C28] rounded-2xl p-4 border border-white/8">
      <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-3 ${accent}`}>
        <Icon className="w-5 h-5" />
      </div>
      <p className="text-2xl font-bold text-white leading-none">{value}</p>
      <p className="text-xs text-[#8B95A8] mt-1">{label}</p>
    </div>
  );
}

export default function ClientsView() {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [expanded, setExpanded] = useState(null);

  useEffect(() => {
    const load = async () => {
      try {
        const svcs = await base44.entities.Service.list('-created_date', 300);
        setServices(svcs);
      } catch (e) {
        console.error('Clients load error:', e);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const clients = useMemo(() => {
    const map = {};
    services.forEach(s => {
      const key = (s.client_phone || s.client_name || 's/i').trim();
      if (!key) return;
      if (!map[key]) {
        map[key] = {
          key, name: s.client_name || 'Sin nombre', phone: s.client_phone || '',
          photo: s.client_photo || '',
          trips: 0, completed: 0, spent: 0, lastDate: null, services: [],
          transporte: 0, mensajeria: 0,
        };
      }
      const c = map[key];
      if (!c.photo && s.client_photo) c.photo = s.client_photo;
      c.trips += 1;
      if (s.status === 'finalizado') {
        c.completed += 1;
        c.spent += s.collected_amount || s.fare || 5000;
      }
      if (s.service_type === 'mensajeria') c.mensajeria += 1; else c.transporte += 1;
      if (!c.lastDate || new Date(s.created_date) > new Date(c.lastDate)) c.lastDate = s.created_date;
      c.services.push(s);
    });
    return Object.values(map).map(c => ({
      ...c,
      services: c.services.sort((a, b) => new Date(b.created_date) - new Date(a.created_date)).slice(0, 5),
    })).sort((a, b) => b.trips - a.trips);
  }, [services]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return clients;
    return clients.filter(c =>
      c.name.toLowerCase().includes(q) || c.phone.toLowerCase().includes(q)
    );
  }, [clients, query]);

  const recurrentes = clients.filter(c => c.trips > 1).length;
  const gastoTotal = clients.reduce((s, c) => s + c.spent, 0);

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="w-7 h-7 animate-spin text-[#00E5FF]" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* KPIs */}
      <div className="grid grid-cols-3 gap-3">
        <Kpi icon={Users} value={clients.length} label="Clientes" accent="bg-[#1E6BFF]/15 text-[#1E6BFF]" />
        <Kpi icon={RotateCcw} value={recurrentes} label="Recurrentes" accent="bg-[#00E5FF]/15 text-[#00E5FF]" />
        <Kpi icon={Wallet} value={fmtCOP(gastoTotal)} label="Gasto total" accent="bg-[#00E676]/15 text-[#00E676]" />
      </div>

      {/* Buscador */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5A6478]" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Buscar por nombre o teléfono..."
          className="w-full h-11 rounded-xl bg-[#161C28] border border-white/8 pl-10 pr-4 text-sm text-white placeholder:text-[#5A6478] outline-none focus:border-[#00E5FF]/40 transition-colors"
        />
      </div>

      {/* Tabla escritorio */}
      <div className="hidden md:block bg-[#161C28] rounded-2xl border border-white/8 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-white/5 text-[#8B95A8] text-xs uppercase tracking-wide">
              <th className="text-left font-medium px-4 py-3">Cliente</th>
              <th className="text-left font-medium px-4 py-3">Teléfono</th>
              <th className="text-center font-medium px-4 py-3">Viajes</th>
              <th className="text-center font-medium px-4 py-3">Finalizados</th>
              <th className="text-center font-medium px-4 py-3">Gasto</th>
              <th className="text-center font-medium px-4 py-3">Último</th>
              <th className="text-center font-medium px-4 py-3 w-10"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {filtered.length === 0 && (
              <tr><td colSpan={7} className="text-center text-[#8B95A8] py-8">Sin clientes</td></tr>
            )}
            {filtered.map(c => (
              <React.Fragment key={c.key}>
                <tr
                  onClick={() => setExpanded(expanded === c.key ? null : c.key)}
                  className="cursor-pointer hover:bg-white/5 transition-colors"
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2.5">
                      <ClientAvatar photo={c.photo} name={c.name} size="sm" />
                      <span className="text-white font-medium">{c.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-[#8B95A8]">{c.phone || '—'}</td>
                  <td className="px-4 py-3 text-center text-white font-medium">{c.trips}</td>
                  <td className="px-4 py-3 text-center text-[#00E676] font-medium">{c.completed}</td>
                  <td className="px-4 py-3 text-center text-white">{fmtCOP(c.spent)}</td>
                  <td className="px-4 py-3 text-center text-[#8B95A8] text-xs">{timeAgo(c.lastDate)}</td>
                  <td className="px-4 py-3 text-center">
                    <ChevronDown className={`w-4 h-4 text-[#8B95A8] mx-auto transition-transform ${expanded === c.key ? 'rotate-180' : ''}`} />
                  </td>
                </tr>
                {expanded === c.key && (
                  <tr className="bg-black/20">
                    <td colSpan={7} className="px-4 py-3">
                      <div className="grid grid-cols-3 gap-3 mb-3 text-xs">
                        <div className="bg-white/5 rounded-lg p-2.5">
                          <p className="text-[#8B95A8] text-[10px] uppercase">Transporte</p>
                          <p className="text-white font-medium mt-0.5 flex items-center gap-1"><Car className="w-3.5 h-3.5 text-[#1E6BFF]" /> {c.transporte}</p>
                        </div>
                        <div className="bg-white/5 rounded-lg p-2.5">
                          <p className="text-[#8B95A8] text-[10px] uppercase">Mensajería</p>
                          <p className="text-white font-medium mt-0.5 flex items-center gap-1"><Bike className="w-3.5 h-3.5 text-[#00E5FF]" /> {c.mensajeria}</p>
                        </div>
                        <div className="bg-white/5 rounded-lg p-2.5">
                          <p className="text-[#8B95A8] text-[10px] uppercase">Tasa finalización</p>
                          <p className="text-white font-medium mt-0.5">{c.trips ? Math.round((c.completed / c.trips) * 100) : 0}%</p>
                        </div>
                      </div>
                      <p className="text-[10px] text-[#8B95A8] uppercase mb-2">Servicios recientes</p>
                      <div className="space-y-1.5">
                        {c.services.map(s => (
                          <div key={s.id} className="flex items-center gap-2 bg-white/5 rounded-lg p-2 text-xs">
                            <MapPin className="w-3.5 h-3.5 text-[#00E5FF] flex-shrink-0" />
                            <span className="text-white truncate flex-1">{s.pickup_address}</span>
                            <span className="text-[#5A6478] flex-shrink-0">{new Date(s.created_date).toLocaleDateString('es-CO')}</span>
                            <span className={`font-medium flex-shrink-0 ${STATUS_COLORS[s.status] || 'text-[#8B95A8]'}`}>{STATUS_LABELS[s.status] || s.status}</span>
                          </div>
                        ))}
                      </div>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>

      {/* Tarjetas móvil */}
      <div className="md:hidden space-y-2">
        {filtered.length === 0 && <p className="text-center text-[#8B95A8] py-8 text-sm">Sin clientes</p>}
        {filtered.map(c => (
          <div key={c.key} className="bg-[#161C28] rounded-2xl border border-white/8 p-3">
            <div className="flex items-center gap-2.5">
              <ClientAvatar photo={c.photo} name={c.name} size="md" />
              <div className="flex-1 min-w-0">
                <p className="text-white font-medium text-sm truncate">{c.name}</p>
                <p className="text-[11px] text-[#8B95A8]">{c.phone || 'Sin teléfono'}</p>
              </div>
              <a href={c.phone ? `tel:${c.phone}` : '#'} className="w-8 h-8 rounded-full bg-[#1E6BFF]/15 flex items-center justify-center text-[#1E6BFF] flex-shrink-0">
                <Phone className="w-4 h-4" />
              </a>
            </div>
            <div className="grid grid-cols-3 gap-2 mt-3 text-center">
              <div className="bg-white/5 rounded-lg py-1.5">
                <p className="text-white font-bold text-sm">{c.trips}</p>
                <p className="text-[9px] text-[#8B95A8]">Viajes</p>
              </div>
              <div className="bg-white/5 rounded-lg py-1.5">
                <p className="text-[#00E676] font-bold text-sm">{c.completed}</p>
                <p className="text-[9px] text-[#8B95A8]">Finalizados</p>
              </div>
              <div className="bg-white/5 rounded-lg py-1.5">
                <p className="text-white font-bold text-sm">{fmtCOP(c.spent)}</p>
                <p className="text-[9px] text-[#8B95A8]">Gasto</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
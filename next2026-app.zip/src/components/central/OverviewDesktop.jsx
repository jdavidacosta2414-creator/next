import React from 'react';
import MetricsRow from '@/components/central/MetricsRow';
import LiveMap from '@/components/central/LiveMap';
import RealtimePanel from '@/components/central/RealtimePanel';

export default function OverviewDesktop() {
  return (
    <div className="space-y-4">
      <MetricsRow />
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <div className="xl:col-span-2 h-[480px]">
          <LiveMap />
        </div>
        <div className="h-[480px]">
          <RealtimePanel />
        </div>
      </div>
    </div>
  );
}
import React, { useState, useEffect } from 'react';
import { useAuth } from '@/lib/AuthContext';
import { base44 } from '@/api/base44Client';
import {
  Package, Users, TrendingUp, CheckCircle, Clock, XCircle, Wallet,
  Settings, MapPin, AlertTriangle, MessageSquare, ChevronRight, Bike, Loader2
} from 'lucide-react';

const today = () => new Date().toISOString().split('T')[0];
const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');

export default function DailyDashboard({ onNavigate }) {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [services, mobiles] = await Promise.all([
          base44.entities.Service.list('-created_date', 200),
          base44.entities.Mobile.list(),
        ]);
        const todayServices = services.filter(s => s.created_date?.startsWith(today()));
        const todayFinalized = todayServices.filter(s => s.status === 'finalizado');
        setData({
          total: todayServices.length,
          finalizados: todayFinalized.length,
          pendientes: todayServices.filter(s => s.status === 'pendiente').length,
          cancelados: todayServices.filter(s => s.status === 'cancelado').length,
          activos: todayServices.filter(s => ['asignado', 'en_camino', 'recogida'].includes(s.status)).length,
          ingresosHoy: todayFinalized.reduce((s, x) => s + (x.collected_amount || x.fare || 5000), 0),
          activosAhora: mobiles.filter(m => m.status !== 'offline').length,
          totalMoviles: mobiles.length,
        });
      } catch (e) {
        console.error('Dashboard load error:', e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-[#1E6BFF]" /></div>;
  if (!data) return null;

  const STAT_CARDS = [
    { icon: TrendingUp, value: data.total, label: 'Hoy', color: 'text-[#1E6BFF]' },
    { icon: CheckCircle, value: data.finalizados, label: 'Finalizados', color: 'text-[#1E6BFF]' },
    { icon: Clock, value: data.activos, label: 'En curso', color: 'text-[#F59E0B]' },
    { icon: XCircle, value: data.cancelados, label: 'Cancelados', color: 'text-red-400' },
  ];

  const ACCESS_CARDS = [
    { label: 'Servicios disponibles', icon: Package, value: String(data.pendientes), tab: 'pendientes' },
    { label: 'Móviles registrados', icon: Bike, value: String(data.totalMoviles), tab: 'moviles' },
    { label: 'Conductores activos', icon: Users, value: `${data.activosAhora} activos`, tab: 'moviles' },
    { label: 'Ingresos de hoy', icon: Wallet, value: fmtCOP(data.ingresosHoy), tab: 'planilla', highlight: true },
  ];

  const CONFIG_CARDS = [
    { label: 'Gestión de conductores', icon: Users, tab: 'moviles' },
    { label: 'Tarifas y zonas', icon: MapPin, tab: 'zona' },
    { label: 'Ranking de móviles', icon: TrendingUp, tab: 'ranking' },
    { label: 'Generar link', icon: Package, tab: 'link' },
  ];

  const MOTIVATIONAL = ['¡Que tengas un excelente día de trabajo!', 'Cada servicio cuenta. ¡Vamos con todo!', 'La seguridad primero, el servicio siempre.'];

  return (
    <div className="space-y-4">
      <div className="bg-[#0D0D0D] rounded-2xl p-5 border border-[#1F1F1F]">
        <h2 className="text-lg font-bold text-white">Bienvenido, {user?.full_name || user?.email || 'Admin'}</h2>
        <p className="text-sm text-[#8B8C94] mt-1">{MOTIVATIONAL[new Date().getDate() % MOTIVATIONAL.length]}</p>
      </div>

      <div className="grid grid-cols-4 gap-2">
        {STAT_CARDS.map((s, i) => {
          const Icon = s.icon;
          return (
            <div key={i} className="bg-[#0D0D0D] rounded-xl p-3 border border-[#1F1F1F] text-center">
              <Icon className={`w-4 h-4 ${s.color} mx-auto mb-1`} />
              <p className="text-lg font-bold text-white">{s.value}</p>
              <p className="text-[10px] text-[#8B8C94]">{s.label}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-2 gap-3">
        {ACCESS_CARDS.map(card => {
          const Icon = card.icon;
          return (
            <button key={card.label} onClick={() => onNavigate?.(card.tab)}
              className={`rounded-2xl p-4 border text-left transition-transform hover:scale-[1.02] ${card.highlight ? 'bg-[#1E6BFF]/10 border-[#1E6BFF]/30' : 'bg-[#0D0D0D] border-[#1F1F1F]'}`}>
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-2 ${card.highlight ? 'bg-[#1E6BFF]/20 text-[#1E6BFF]' : 'bg-[#1A1A1A] text-[#1E6BFF]'}`}>
                <Icon className="w-5 h-5" />
              </div>
              <p className={`text-sm font-bold ${card.highlight ? 'text-[#1E6BFF]' : 'text-white'}`}>{card.value}</p>
              <p className="text-xs text-[#8B8C94]">{card.label}</p>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-2 gap-3">
        {CONFIG_CARDS.map(card => {
          const Icon = card.icon;
          return (
            <button key={card.label} onClick={() => onNavigate?.(card.tab)}
              className="bg-[#0D0D0D] rounded-2xl p-4 border border-[#1F1F1F] flex items-center gap-2 text-left hover:border-[#1E6BFF]/30 transition-colors">
              <Icon className="w-5 h-5 text-[#8B8C94]" />
              <span className="text-xs font-medium text-white">{card.label}</span>
            </button>
          );
        })}
      </div>

      <div className="space-y-3">
        <button className="w-full bg-[#0D0D0D] rounded-2xl p-4 border border-[#1F1F1F] flex items-center gap-3 text-left hover:border-[#1E6BFF]/30 transition-colors">
          <div className="w-10 h-10 rounded-xl bg-[#1E6BFF]/15 flex items-center justify-center">
            <MessageSquare className="w-5 h-5 text-[#1E6BFF]" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-white">Consultas / Reclamos</p>
            <p className="text-xs text-[#8B8C94]">Responde solicitudes y quejas de clientes</p>
          </div>
          <ChevronRight className="w-4 h-4 text-[#8B8C94]" />
        </button>
        <button className="w-full bg-[#0D0D0D] rounded-2xl p-4 border border-[#1F1F1F] flex items-center gap-3 text-left hover:border-red-500/30 transition-colors">
          <div className="w-10 h-10 rounded-xl bg-red-500/15 flex items-center justify-center">
            <AlertTriangle className="w-5 h-5 text-red-400" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-white">Alertas del sistema</p>
            <p className="text-xs text-[#8B8C94]">Fallas, procesos pendientes y avisos</p>
          </div>
          <ChevronRight className="w-4 h-4 text-[#8B8C94]" />
        </button>
      </div>
    </div>
  );
}
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Copy, Check, Share2, Link as LinkIcon, MessageCircle } from 'lucide-react';

export default function LinkGenerator() {
  const link = `${window.location.origin}/cliente`;
  const [copied, setCopied] = useState(false);
  const copy = () => { navigator.clipboard.writeText(link); setCopied(true); setTimeout(() => setCopied(false), 2000); };
  const share = () => {
    if (navigator.share) navigator.share({ title: 'MotoLink - Solicitar servicio', text: 'Pide tu servicio de moto aquí:', url: link }).catch(() => copy());
    else copy();
  };
  const waLink = `https://wa.me/?text=${encodeURIComponent('Pide tu servicio de moto aquí: ' + link)}`;

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl p-5 shadow-sm border text-center">
        <div className="w-14 h-14 rounded-full bg-blue-50 flex items-center justify-center mx-auto mb-3"><LinkIcon className="w-7 h-7 text-[#0057FF]" /></div>
        <h3 className="font-semibold text-[#1A1A1A] mb-1">Link de solicitud</h3>
        <p className="text-sm text-gray-500 mb-4">Compártelo por WhatsApp con tus clientes</p>
        <div className="bg-gray-50 rounded-lg p-3 mb-3 text-sm text-gray-600 break-all font-mono">{link}</div>
        <Button onClick={copy} className="w-full h-11 bg-[#0057FF] hover:bg-[#0046cc]">{copied ? <><Check className="w-4 h-4 mr-2" />Copiado</> : <><Copy className="w-4 h-4 mr-2" />Copiar link</>}</Button>
      </div>
      <a href={waLink} target="_blank" rel="noreferrer">
        <Button variant="outline" className="w-full h-11"><MessageCircle className="w-4 h-4 mr-2 text-[#00D68F]" />Compartir por WhatsApp</Button>
      </a>
      <Button onClick={share} variant="outline" className="w-full h-11"><Share2 className="w-4 h-4 mr-2" />Compartir...</Button>
    </div>
  );
}
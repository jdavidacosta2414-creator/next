import React, { useState, useEffect, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useMapboxToken } from '@/hooks/useMapboxToken';
import { DEFAULT_CITY } from '@/lib/appCity';
import { Loader2 } from 'lucide-react';
import MapboxMap, { MapboxMarker, MapboxFitBounds } from '@/components/shared/MapboxMap';
import MapTileError from '@/components/shared/MapTileError';

function liveDriverEl(type, status) {
  const color =
    status === 'disponible' ? '#00E676' :
    status === 'ocupado' ? '#FFB800' : '#FF5252';
  const emoji = type === 'carro' ? '🚗' : '🏍️';
  const el = document.createElement('div');
  el.innerHTML = `<div style="width:30px;height:30px;border-radius:50%;background:${color};border:2px solid #0B0F1A;display:flex;align-items:center;justify-content:center;font-size:14px;box-shadow:0 2px 8px rgba(0,0,0,0.45);">${emoji}</div>`;
  return el;
}

const FILTERS = [
  { v: 'todos', label: 'Todos' },
  { v: 'carro', label: 'Carros' },
  { v: 'moto', label: 'Motos' },
];

export default function LiveMap() {
  const token = useMapboxToken();
  const [mobiles, setMobiles] = useState([]);
  const [activeServices, setActiveServices] = useState([]);
  const [filter, setFilter] = useState('todos');
  const [loading, setLoading] = useState(true);
  const [tileError, setTileError] = useState(false);
  const [expanded, setExpanded] = useState(false);

  const LIVE_WINDOW = 3 * 60 * 1000; // 3 min: ventana de latido en tiempo real del conductor
  const REFRESH_MS = 15 * 1000;

  useEffect(() => {
    const load = async () => {
      try {
        // Solo móviles con latido reciente y servicios activos con sus coordenadas exactas guardadas
        const since = new Date(Date.now() - LIVE_WINDOW).toISOString();
        const [mobs, svcs] = await Promise.all([
          base44.entities.Mobile.filter({
            updated_date: { $gte: since },
          }),
          base44.entities.Service.filter(
            { status: { $in: ['pendiente', 'asignado', 'en_camino', 'recogida'] } },
            '-created_date',
            30
          ),
        ]);
        setMobiles(mobs.filter(m => m.current_lat != null && m.status !== 'offline'));
        setActiveServices(
          (Array.isArray(svcs) ? svcs : svcs?.items || []).filter(
            s => s.pickup_lat != null && s.pickup_lng != null
          )
        );
      } catch (e) {
        console.error('LiveMap load error:', e);
      } finally {
        setLoading(false);
      }
    };
    load();
    const interval = setInterval(() => load().catch(() => {}), REFRESH_MS);
    const unsubMob = base44.entities.Mobile.subscribe(() => load().catch(() => {}));
    const unsubSvc = base44.entities.Service.subscribe(() => load().catch(() => {}));
    return () => {
      clearInterval(interval);
      unsubMob();
      unsubSvc();
    };
  }, []);

  const filtered = useMemo(() => {
    return mobiles.filter(m => {
      if (filter === 'carro') return m.vehicle_type === 'carro';
      if (filter === 'moto') return m.vehicle_type !== 'carro';
      return true;
    });
  }, [mobiles, filter]);

  const positions = filtered.map(m => [m.current_lat, m.current_lng]);

  return (
    <div
      className={
        expanded
          ? 'fixed inset-0 z-[2000] bg-[#161C28] flex flex-col w-full h-[100dvh]'
          : 'bg-[#161C28] rounded-2xl border border-white/8 overflow-hidden flex flex-col h-full'
      }
    >
      {/* Barra de filtros */}
      <div className="flex items-center gap-2 px-4 py-3 border-b border-white/8 flex-shrink-0">
        <span className="text-sm font-semibold text-white mr-1">Mapa en vivo</span>
        <div className="flex gap-1.5">
          {FILTERS.map(f => (
            <button
              key={f.v}
              onClick={() => setFilter(f.v)}
              className={`h-8 px-3 rounded-lg text-xs font-medium transition-colors ${
                filter === f.v ? 'bg-[#1E6BFF] text-white' : 'bg-white/5 text-[#8B95A8] hover:text-white'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
        <span className="ml-auto text-xs text-[#8B95A8]">{filtered.length} móviles</span>
      </div>

      {/* Mapa: al tocar cualquier parte del mapa se despliega o repliega en toda la pantalla */}
      <div className="flex-1 relative min-h-[320px] cursor-pointer">
        {loading && (
          <div className="absolute inset-0 flex items-center justify-center bg-[#0B0F1A] z-10">
            <Loader2 className="w-6 h-6 animate-spin text-[#00E5FF]" />
          </div>
        )}
        <MapboxMap
          center={[DEFAULT_CITY.lat, DEFAULT_CITY.lng]}
          zoom={13}
          pitch={expanded ? 0 : 55}
          className="w-full h-full"
          dark
          onMapClick={() => setExpanded((v) => !v)}
          onTileError={() => setTileError(true)}
        >
          {filtered.map(m => (
            <MapboxMarker
              key={m.id}
              lat={parseFloat(m.current_lat)}
              lng={parseFloat(m.current_lng)}
              el={() => liveDriverEl(m.vehicle_type, m.status)}
              interactive={false}
            />
          ))}
          {activeServices.map(s => (
            <React.Fragment key={`svc-${s.id}`}>
              {s.pickup_lat != null && s.pickup_lng != null && (
                <MapboxMarker
                  lat={parseFloat(s.pickup_lat)}
                  lng={parseFloat(s.pickup_lng)}
                  el={() => {
                    const el = document.createElement('div');
                    el.innerHTML = `<div title="${s.pickup_address || ''}" style="width:14px;height:14px;border-radius:50%;background:#1E6BFF;border:2px solid #FFFFFF;box-shadow:0 2px 6px rgba(0,0,0,0.5);"></div>`;
                    return el;
                  }}
                  interactive={false}
                />
              )}
              {s.destination_lat != null && s.destination_lng != null && (
                <MapboxMarker
                  lat={parseFloat(s.destination_lat)}
                  lng={parseFloat(s.destination_lng)}
                  el={() => {
                    const el = document.createElement('div');
                    el.innerHTML = `<div title="${s.destination_address || ''}" style="width:14px;height:14px;border-radius:50%;background:#FF5252;border:2px solid #FFFFFF;box-shadow:0 2px 6px rgba(0,0,0,0.5);"></div>`;
                    return el;
                  }}
                  interactive={false}
                />
              )}
            </React.Fragment>
          ))}
          <MapboxFitBounds
            positions={positions}
            padding={expanded ? 60 : 40}
            singleZoom={14}
            fitKey={expanded ? 'expanded' : 'compact'}
          />
        </MapboxMap>
        {tileError && <MapTileError dark />}
      </div>

      {/* Leyenda */}
      <div className="flex items-center gap-3 px-4 py-2.5 border-t border-white/8 flex-shrink-0 text-[10px] text-[#8B95A8] flex-wrap">
        <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-[#00E676]" /> Disponible</span>
        <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-[#FFB800]" /> En ruta</span>
        <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-[#FF5252]" /> Ocupado</span>
        <span className="flex items-center gap-1.5">🚗 Carro</span>
        <span className="flex items-center gap-1.5">🏍️ Moto</span>
      </div>
    </div>
  );
}
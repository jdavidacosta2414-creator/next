import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Car, Bike, Navigation, Activity, CheckCircle, Loader2 } from 'lucide-react';

const today = () => new Date().toISOString().split('T')[0];

function MetricCard({ icon: Icon, value, label, accent }) {
  return (
    <div className="bg-[#161C28] rounded-2xl p-4 border border-white/8">
      <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-3 ${accent}`}>
        <Icon className="w-5 h-5" />
      </div>
      <p className="text-2xl font-bold text-white leading-none">{value}</p>
      <p className="text-xs text-[#8B95A8] mt-1">{label}</p>
    </div>
  );
}

export default function MetricsRow() {
  const [data, setData] = useState(null);

  useEffect(() => {
    const load = async () => {
      try {
        const [mobiles, services] = await Promise.all([
          base44.entities.Mobile.list(),
          base44.entities.Service.list('-created_date', 200),
        ]);
        const online = mobiles.filter(m => m.status !== 'offline');
        const carros = online.filter(m => m.vehicle_type === 'carro');
        const motos = online.filter(m => m.vehicle_type !== 'carro');
        const enRuta = services.filter(s =>
          ['asignado', 'en_camino', 'recogida'].includes(s.status)
        );
        const activeReq = services.filter(s =>
          ['pendiente', 'asignado', 'en_camino', 'recogida'].includes(s.status)
        );
        const todaySvcs = services.filter(s => s.created_date?.startsWith(today()));
        const done = todaySvcs.filter(s => s.status === 'finalizado');
        setData({
          carros: carros.length,
          motos: motos.length,
          enRuta: enRuta.length,
          activeReq: activeReq.length,
          done: done.length,
        });
      } catch (e) {
        console.error('Metrics load error:', e);
      }
    };
    load();
    const u1 = base44.entities.Mobile.subscribe(() => load().catch(() => {}));
    const u2 = base44.entities.Service.subscribe(() => load().catch(() => {}));
    return () => { u1(); u2(); };
  }, []);

  if (!data) {
    return (
      <div className="flex justify-center py-6">
        <Loader2 className="w-6 h-6 animate-spin text-[#00E5FF]" />
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
      <MetricCard icon={Car} value={data.carros} label="Carros en línea" accent="bg-[#1E6BFF]/15 text-[#1E6BFF]" />
      <MetricCard icon={Bike} value={data.motos} label="Motos en línea" accent="bg-[#00E5FF]/15 text-[#00E5FF]" />
      <MetricCard icon={Navigation} value={data.enRuta} label="En ruta" accent="bg-[#FFB800]/15 text-[#FFB800]" />
      <MetricCard icon={Activity} value={data.activeReq} label="Solicitudes activas" accent="bg-[#00E676]/15 text-[#00E676]" />
      <MetricCard icon={CheckCircle} value={data.done} label="Completados hoy" accent="bg-[#1E6BFF]/15 text-[#1E6BFF]" />
    </div>
  );
}
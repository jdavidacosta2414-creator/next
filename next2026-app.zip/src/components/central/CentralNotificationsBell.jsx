import React, { useState, useEffect, useRef } from 'react';
import { Bell, Shirt, Wallet, Check, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';

const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');

export default function CentralNotificationsBell({ onOpenIncidencias }) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState([]);
  const [walletWithdrawals, setWalletWithdrawals] = useState([]);
  const knownIdsRef = useRef(new Set());
  const initializedRef = useRef(false);

  const load = async () => {
    try {
      const [list, withdrawalsPage] = await Promise.all([
        base44.entities.Incidence.filter(
          { status: { $in: ['abierta', 'en_proceso'] } },
          '-created_date',
          30
        ),
        base44.entities.PassengerWalletTx.filter(
          { type: 'retiro', status: 'pendiente_transferencia' },
          { sort: '-created_date', limit: 30 }
        ),
      ]);
      const rows = Array.isArray(list) ? list : list?.items || [];
      const wRows = withdrawalsPage?.items || [];
      if (initializedRef.current) {
        rows.forEach((r) => {
          if (!knownIdsRef.current.has(r.id)) {
            toast({
              title: r.title || 'Nueva notificación en Central',
              description: r.description || '',
            });
          }
        });
      }
      knownIdsRef.current = new Set(rows.map((r) => r.id));
      initializedRef.current = true;
      setItems(rows);
      setWalletWithdrawals(wRows);
    } catch {}
  };

  useEffect(() => {
    load();
    const unsubInc = base44.entities.Incidence.subscribe(() => load().catch(() => {}));
    const unsubWal = base44.entities.PassengerWalletTx.subscribe(() => load().catch(() => {}));
    return () => {
      unsubInc();
      unsubWal();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const markAttended = async (item, e) => {
    e.stopPropagation();
    try {
      const matchingWithdrawal = walletWithdrawals.find((w) => w.incidence_id === item.id);
      const isWalletWithdraw =
        Boolean(matchingWithdrawal) ||
        (item.title || '').toLowerCase().includes('retiro de billetera');

      if (matchingWithdrawal) {
        await base44.entities.PassengerWalletTx.update(matchingWithdrawal.id, {
          status: 'transferido',
          transferred_at: new Date().toISOString(),
        });
      }

      await base44.entities.Incidence.update(item.id, {
        status: 'resuelta',
        resolution: isWalletWithdraw
          ? 'Puntos redimidos y transferencia realizada a la cuenta del cliente. Billetera en $0.'
          : 'Solicitud de chaqueta registrada por Central (entrega de 10 a 15 días hábiles).',
        resolved_at: new Date().toISOString(),
      });

      if (isWalletWithdraw) {
        toast({
          title: 'Transferencia confirmada',
          description: 'Se notificó al pasajero para verificar la transferencia en su cuenta y su billetera quedó en $0.',
        });
      }
      load();
    } catch {}
  };

  return (
    <div className="relative flex-shrink-0">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-label="Notificaciones de Central"
        className="relative w-9 h-9 rounded-lg bg-white/5 flex items-center justify-center text-white hover:bg-white/10 transition-colors"
      >
        <Bell className="w-5 h-5" />
        {items.length > 0 && (
          <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-[#FF5252] text-white text-[10px] font-extrabold flex items-center justify-center">
            {items.length}
          </span>
        )}
      </button>

      {open && (
        <div className="fixed sm:absolute right-3 sm:right-0 top-14 sm:top-11 w-[calc(100vw-24px)] max-w-sm bg-[#161C28] border border-white/10 rounded-2xl shadow-2xl z-50 overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
            <p className="text-white font-bold text-sm">
              Notificaciones ({items.length})
            </p>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="w-7 h-7 rounded-full bg-white/5 flex items-center justify-center text-[#8B95A8] hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="max-h-80 overflow-y-auto divide-y divide-white/8">
            {items.length === 0 ? (
              <p className="text-center text-xs text-[#8B95A8] py-8">
                No hay notificaciones pendientes
              </p>
            ) : (
              items.map((item) => {
                const isJacket = (item.title || '').toLowerCase().includes('chaqueta');
                const matchingWithdrawal = walletWithdrawals.find((w) => w.incidence_id === item.id);
                const isWalletWithdraw =
                  Boolean(matchingWithdrawal) ||
                  (item.title || '').toLowerCase().includes('retiro de billetera');
                return (
                  <div
                    key={item.id}
                    onClick={() => {
                      setOpen(false);
                      onOpenIncidencias?.();
                    }}
                    className="p-3.5 hover:bg-white/5 cursor-pointer flex items-start gap-3 text-left"
                  >
                    <div className="w-9 h-9 rounded-xl bg-[#1E6BFF]/15 text-[#00E5FF] flex items-center justify-center flex-shrink-0 mt-0.5">
                      {isWalletWithdraw ? <Wallet className="w-4 h-4" /> : <Shirt className="w-4 h-4" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-white font-bold text-xs truncate">
                          {item.title}
                        </p>
                        {isJacket && (
                          <span className="px-2 py-0.5 rounded-full bg-[#00E5FF]/15 text-[#00E5FF] text-[10px] font-bold flex-shrink-0">
                            $35.000
                          </span>
                        )}
                        {matchingWithdrawal && (
                          <span className="px-2 py-0.5 rounded-full bg-[#00E676]/15 text-[#00E676] text-[10px] font-bold flex-shrink-0">
                            {fmtCOP(matchingWithdrawal.amount)}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-[#8B95A8] whitespace-pre-line mt-1 leading-relaxed">
                        {item.description}
                      </p>
                      {isWalletWithdraw && (
                        <button
                          type="button"
                          onClick={(e) => markAttended(item, e)}
                          className="mt-2 inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#00E676]/20 hover:bg-[#00E676]/30 text-[#00E676] text-[11px] font-bold"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Confirmar transferencia</span>
                        </button>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={(e) => markAttended(item, e)}
                      title={isWalletWithdraw ? 'Confirmar transferencia realizada' : 'Marcar como gestionada'}
                      className="w-7 h-7 rounded-lg bg-[#00E676]/15 text-[#00E676] hover:bg-[#00E676]/25 flex items-center justify-center flex-shrink-0"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
}
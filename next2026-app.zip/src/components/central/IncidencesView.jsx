import React, { useState, useEffect, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import {
  AlertTriangle, Search, Plus, Loader2, X, Clock, CheckCircle,
  AlertOctagon, Shield, User, Bike, CreditCard, Server, Flame, Flag
} from 'lucide-react';

const CATEGORY_META = {
  servicio: { label: 'Servicio', icon: Shield, color: 'text-[#1E6BFF] bg-[#1E6BFF]/10' },
  conductor: { label: 'Conductor', icon: Bike, color: 'text-[#00E5FF] bg-[#00E5FF]/10' },
  cliente: { label: 'Cliente', icon: User, color: 'text-[#FFB800] bg-[#FFB800]/10' },
  pago: { label: 'Pago', icon: CreditCard, color: 'text-[#9D5CFF] bg-[#9D5CFF]/10' },
  sistema: { label: 'Sistema', icon: Server, color: 'text-[#00E676] bg-[#00E676]/10' },
};

const PRIORITY_META = {
  baja: { label: 'Baja', icon: Flag, color: 'text-[#8B95A8] bg-white/5' },
  media: { label: 'Media', icon: Flag, color: 'text-[#FFB800] bg-[#FFB800]/10' },
  alta: { label: 'Alta', icon: AlertTriangle, color: 'text-[#FF7A00] bg-[#FF7A00]/10' },
  critica: { label: 'Crítica', icon: Flame, color: 'text-[#FF5252] bg-[#FF5252]/10' },
};

const STATUS_META = {
  abierta: { label: 'Abierta', color: 'text-[#FFB800] bg-[#FFB800]/10' },
  en_proceso: { label: 'En proceso', color: 'text-[#1E6BFF] bg-[#1E6BFF]/10' },
  resuelta: { label: 'Resuelta', color: 'text-[#00E676] bg-[#00E676]/10' },
  cerrada: { label: 'Cerrada', color: 'text-[#8B95A8] bg-white/5' },
};

function timeAgo(dateStr) {
  if (!dateStr) return '';
  const diff = Date.now() - new Date(dateStr).getTime();
  const h = Math.floor(diff / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  if (h > 24) return `Hace ${Math.floor(h / 24)} d`;
  if (h > 0) return `Hace ${h} h`;
  if (m > 0) return `Hace ${m} min`;
  return 'Ahora';
}

export default function IncidencesView() {
  const { toast } = useToast();
  const [incidences, setIncidences] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('todas');
  const [filterPriority, setFilterPriority] = useState('todas');
  const [showForm, setShowForm] = useState(false);
  const [detail, setDetail] = useState(null);

  useEffect(() => {
    const load = async () => {
      try {
        const list = await base44.entities.Incidence.list('-created_date', 200);
        setIncidences(list);
      } catch (e) {
        console.error('Incidences load error:', e);
      } finally {
        setLoading(false);
      }
    };
    load();
    const unsub = base44.entities.Incidence.subscribe(() => load().catch(() => {}));
    return unsub;
  }, []);

  const filtered = useMemo(() => {
    let list = incidences;
    if (filterStatus !== 'todas') list = list.filter(i => i.status === filterStatus);
    if (filterPriority !== 'todas') list = list.filter(i => i.priority === filterPriority);
    const q = query.trim().toLowerCase();
    if (q) {
      list = list.filter(i =>
        (i.title || '').toLowerCase().includes(q) ||
        (i.description || '').toLowerCase().includes(q) ||
        (i.related_mobile_name || '').toLowerCase().includes(q)
      );
    }
    return list;
  }, [incidences, query, filterStatus, filterPriority]);

  const stats = useMemo(() => ({
    total: incidences.length,
    abiertas: incidences.filter(i => i.status === 'abierta' || i.status === 'en_proceso').length,
    criticas: incidences.filter(i => i.priority === 'critica' && i.status !== 'resuelta' && i.status !== 'cerrada').length,
    resueltas: incidences.filter(i => i.status === 'resuelta' || i.status === 'cerrada').length,
  }), [incidences]);

  const handleCreate = async (data) => {
    try {
      await base44.entities.Incidence.create({
        ...data,
        status: 'abierta',
      });
      toast({ description: 'Incidencia registrada' });
      setShowForm(false);
    } catch (e) {
      toast({ description: 'Error al registrar', variant: 'destructive' });
    }
  };

  const handleUpdateStatus = async (id, status) => {
    try {
      await base44.entities.Incidence.update(id, { status });
      if (detail?.id === id) setDetail({ ...detail, status });
      toast({ description: `Estado: ${STATUS_META[status].label}` });
    } catch (e) {
      toast({ description: 'Error al actualizar', variant: 'destructive' });
    }
  };

  const handleResolve = async (id, resolution) => {
    try {
      const page = await base44.entities.PassengerWalletTx.filter(
        { incidence_id: id, type: 'retiro', status: 'pendiente_transferencia' },
        { sort: '-created_date', limit: 5 }
      );
      for (const w of page?.items || []) {
        await base44.entities.PassengerWalletTx.update(w.id, {
          status: 'transferido',
          transferred_at: new Date().toISOString(),
        });
      }
      await base44.entities.Incidence.update(id, {
        status: 'resuelta',
        resolution,
        resolved_at: new Date().toISOString(),
      });
      if (detail?.id === id) setDetail({ ...detail, status: 'resuelta', resolution });
      toast({ description: 'Incidencia resuelta' });
    } catch (e) {
      toast({ description: 'Error al resolver', variant: 'destructive' });
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="w-7 h-7 animate-spin text-[#00E5FF]" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-[#161C28] rounded-2xl p-4 border border-white/8">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center mb-3 bg-white/5 text-[#8B95A8]"><AlertTriangle className="w-5 h-5" /></div>
          <p className="text-2xl font-bold text-white leading-none">{stats.total}</p>
          <p className="text-xs text-[#8B95A8] mt-1">Total</p>
        </div>
        <div className="bg-[#161C28] rounded-2xl p-4 border border-white/8">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center mb-3 bg-[#FFB800]/15 text-[#FFB800]"><Clock className="w-5 h-5" /></div>
          <p className="text-2xl font-bold text-white leading-none">{stats.abiertas}</p>
          <p className="text-xs text-[#8B95A8] mt-1">Activas</p>
        </div>
        <div className="bg-[#161C28] rounded-2xl p-4 border border-white/8">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center mb-3 bg-[#FF5252]/15 text-[#FF5252]"><Flame className="w-5 h-5" /></div>
          <p className="text-2xl font-bold text-white leading-none">{stats.criticas}</p>
          <p className="text-xs text-[#8B95A8] mt-1">Críticas</p>
        </div>
        <div className="bg-[#161C28] rounded-2xl p-4 border border-white/8">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center mb-3 bg-[#00E676]/15 text-[#00E676]"><CheckCircle className="w-5 h-5" /></div>
          <p className="text-2xl font-bold text-white leading-none">{stats.resueltas}</p>
          <p className="text-xs text-[#8B95A8] mt-1">Resueltas</p>
        </div>
      </div>

      {/* Controles */}
      <div className="flex flex-col sm:flex-row gap-3 sm:items-center justify-between">
        <div className="flex flex-wrap gap-2">
          <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}
            className="h-9 rounded-xl bg-[#161C28] border border-white/8 px-3 text-sm text-white outline-none">
            <option value="todas">Todos los estados</option>
            {Object.entries(STATUS_META).map(([v, m]) => <option key={v} value={v}>{m.label}</option>)}
          </select>
          <select value={filterPriority} onChange={(e) => setFilterPriority(e.target.value)}
            className="h-9 rounded-xl bg-[#161C28] border border-white/8 px-3 text-sm text-white outline-none">
            <option value="todas">Toda prioridad</option>
            {Object.entries(PRIORITY_META).map(([v, m]) => <option key={v} value={v}>{m.label}</option>)}
          </select>
        </div>
        <div className="flex gap-2 flex-1 sm:justify-end">
          <div className="relative flex-1 sm:flex-none sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5A6478]" />
            <input value={query} onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar incidencia..."
              className="w-full h-9 rounded-xl bg-[#161C28] border border-white/8 pl-10 pr-4 text-sm text-white placeholder:text-[#5A6478] outline-none focus:border-[#00E5FF]/40" />
          </div>
          <button onClick={() => setShowForm(true)}
            className="h-9 px-4 rounded-xl bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white text-sm font-medium flex items-center gap-1.5 whitespace-nowrap">
            <Plus className="w-4 h-4" /> Nueva
          </button>
        </div>
      </div>

      {/* Lista */}
      <div className="space-y-2">
        {filtered.length === 0 && (
          <div className="text-center py-12 text-[#8B95A8]">
            <AlertOctagon className="w-10 h-10 mx-auto mb-2 text-white/15" />
            <p className="text-sm">No hay incidencias registradas</p>
          </div>
        )}
        {filtered.map(inc => {
          const cat = CATEGORY_META[inc.category] || CATEGORY_META.servicio;
          const pri = PRIORITY_META[inc.priority] || PRIORITY_META.media;
          const st = STATUS_META[inc.status] || STATUS_META.abierta;
          const CatIcon = cat.icon;
          const PriIcon = pri.icon;
          return (
            <div key={inc.id} onClick={() => setDetail(inc)}
              className="bg-[#161C28] rounded-2xl border border-white/8 p-4 cursor-pointer hover:border-white/15 transition-colors">
              <div className="flex items-start gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${cat.color}`}>
                  <CatIcon className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-white font-medium text-sm truncate">{inc.title}</p>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium flex-shrink-0 ${st.color}`}>{st.label}</span>
                  </div>
                  {inc.description && <p className="text-xs text-[#8B95A8] truncate mt-0.5">{inc.description}</p>}
                  <div className="flex items-center gap-2 mt-2 flex-wrap">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium flex items-center gap-1 ${pri.color}`}>
                      <PriIcon className="w-3 h-3" />{pri.label}
                    </span>
                    <span className="text-[10px] text-[#5A6478]">{cat.label}</span>
                    {inc.related_mobile_name && <span className="text-[10px] text-[#5A6478]">· {inc.related_mobile_name}</span>}
                    <span className="text-[10px] text-[#5A6478] ml-auto">{timeAgo(inc.created_date)}</span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Formulario nueva incidencia */}
      {showForm && (
        <IncidenceForm onClose={() => setShowForm(false)} onSubmit={handleCreate} />
      )}

      {/* Modal de detalle */}
      {detail && (
        <IncidenceDetail inc={detail} onClose={() => setDetail(null)}
          onUpdateStatus={handleUpdateStatus} onResolve={handleResolve} />
      )}
    </div>
  );
}

function IncidenceForm({ onClose, onSubmit }) {
  const [form, setForm] = useState({
    title: '', description: '', category: 'servicio', priority: 'media',
    related_mobile_name: '', related_service_id: '',
  });
  const [saving, setSaving] = useState(false);

  const submit = (e) => {
    e.preventDefault();
    if (!form.title.trim()) return;
    setSaving(true);
    onSubmit({
      ...form,
      related_mobile_name: form.related_mobile_name.trim() || undefined,
      related_service_id: form.related_service_id.trim() || undefined,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <form onSubmit={submit} onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-md bg-[#161C28] rounded-2xl border border-white/10 p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-white font-bold text-lg">Nueva incidencia</h3>
          <button type="button" onClick={onClose} className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-white"><X className="w-4 h-4" /></button>
        </div>
        <div className="space-y-3">
          <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })}
            placeholder="Título"
            className="w-full h-10 rounded-xl bg-white/5 border border-white/10 px-3 text-sm text-white placeholder:text-[#5A6478] outline-none focus:border-[#00E5FF]/40" />
          <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })}
            placeholder="Descripción detallada..." rows={3}
            className="w-full rounded-xl bg-white/5 border border-white/10 p-3 text-sm text-white placeholder:text-[#5A6478] outline-none focus:border-[#00E5FF]/40 resize-none" />
          <div className="grid grid-cols-2 gap-3">
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}
              className="h-10 rounded-xl bg-white/5 border border-white/10 px-3 text-sm text-white outline-none">
              {Object.entries(CATEGORY_META).map(([v, m]) => <option key={v} value={v}>{m.label}</option>)}
            </select>
            <select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}
              className="h-10 rounded-xl bg-white/5 border border-white/10 px-3 text-sm text-white outline-none">
              {Object.entries(PRIORITY_META).map(([v, m]) => <option key={v} value={v}>{m.label}</option>)}
            </select>
          </div>
          <input value={form.related_mobile_name} onChange={(e) => setForm({ ...form, related_mobile_name: e.target.value })}
            placeholder="Conductor relacionado (opcional)"
            className="w-full h-10 rounded-xl bg-white/5 border border-white/10 px-3 text-sm text-white placeholder:text-[#5A6478] outline-none focus:border-[#00E5FF]/40" />
          <input value={form.related_service_id} onChange={(e) => setForm({ ...form, related_service_id: e.target.value })}
            placeholder="ID de servicio (opcional)"
            className="w-full h-10 rounded-xl bg-white/5 border border-white/10 px-3 text-sm text-white placeholder:text-[#5A6478] outline-none focus:border-[#00E5FF]/40" />
        </div>
        <button type="submit" disabled={saving}
          className="w-full h-11 mt-4 rounded-xl bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white text-sm font-medium disabled:opacity-50">
          {saving ? 'Guardando...' : 'Registrar incidencia'}
        </button>
      </form>
    </div>
  );
}

function IncidenceDetail({ inc, onClose, onUpdateStatus, onResolve }) {
  const cat = CATEGORY_META[inc.category] || CATEGORY_META.servicio;
  const pri = PRIORITY_META[inc.priority] || PRIORITY_META.media;
  const st = STATUS_META[inc.status] || STATUS_META.abierta;
  const CatIcon = cat.icon;
  const PriIcon = pri.icon;
  const [resolution, setResolution] = useState(inc.resolution || '');

  const isClosed = inc.status === 'resuelta' || inc.status === 'cerrada';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <div className="relative w-full max-w-lg max-h-[85vh] overflow-y-auto thin-scroll bg-[#161C28] rounded-2xl border border-white/10 p-5" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-start gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${cat.color}`}><CatIcon className="w-5 h-5" /></div>
            <div>
              <h3 className="text-white font-bold text-lg">{inc.title}</h3>
              <p className="text-xs text-[#8B95A8]">{new Date(inc.created_date).toLocaleString('es-CO')}</p>
            </div>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-white"><X className="w-4 h-4" /></button>
        </div>

        <div className="flex flex-wrap gap-2 mb-4">
          <span className={`px-2.5 py-1 rounded-full text-[11px] font-medium flex items-center gap-1 ${pri.color}`}><PriIcon className="w-3 h-3" />{pri.label}</span>
          <span className={`px-2.5 py-1 rounded-full text-[11px] font-medium ${st.color}`}>{st.label}</span>
          <span className="px-2.5 py-1 rounded-full text-[11px] font-medium bg-white/5 text-[#8B95A8]">{cat.label}</span>
        </div>

        {inc.description && (
          <div className="bg-white/5 rounded-xl p-3 mb-3">
            <p className="text-[10px] text-[#8B95A8] uppercase mb-1">Descripción</p>
            <p className="text-sm text-white whitespace-pre-wrap">{inc.description}</p>
          </div>
        )}

        {(inc.related_mobile_name || inc.related_service_id) && (
          <div className="bg-white/5 rounded-xl p-3 mb-3">
            <p className="text-[10px] text-[#8B95A8] uppercase mb-1">Relacionado</p>
            {inc.related_mobile_name && <p className="text-sm text-white">Conductor: {inc.related_mobile_name}</p>}
            {inc.related_service_id && <p className="text-xs text-[#8B95A8]">Servicio: {inc.related_service_id}</p>}
          </div>
        )}

        {inc.resolution && (
          <div className="bg-[#00E676]/10 rounded-xl p-3 mb-3">
            <p className="text-[10px] text-[#00E676] uppercase mb-1">Resolución</p>
            <p className="text-sm text-white whitespace-pre-wrap">{inc.resolution}</p>
          </div>
        )}

        {!isClosed && (
          <div className="space-y-3 mt-4">
            <textarea value={resolution} onChange={(e) => setResolution(e.target.value)}
              placeholder="Escribir resolución..." rows={3}
              className="w-full rounded-xl bg-white/5 border border-white/10 p-3 text-sm text-white placeholder:text-[#5A6478] outline-none focus:border-[#00E5FF]/40 resize-none" />
            <div className="flex flex-wrap gap-2">
              {inc.status !== 'en_proceso' && (
                <button onClick={() => onUpdateStatus(inc.id, 'en_proceso')}
                  className="h-9 px-4 rounded-xl bg-[#1E6BFF]/15 text-[#1E6BFF] text-sm font-medium">En proceso</button>
              )}
              <button onClick={() => onResolve(inc.id, resolution)}
                disabled={!resolution.trim()}
                className="h-9 px-4 rounded-xl bg-[#00E676]/15 text-[#00E676] text-sm font-medium disabled:opacity-50">Marcar resuelta</button>
              <button onClick={() => onUpdateStatus(inc.id, 'cerrada')}
                className="h-9 px-4 rounded-xl bg-white/5 text-[#8B95A8] text-sm font-medium ml-auto">Cerrar</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
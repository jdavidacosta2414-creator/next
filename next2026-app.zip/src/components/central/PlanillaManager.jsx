import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { toast } from '@/components/ui/use-toast';
import { safeInvoke } from '@/lib/api-helpers';
import { Plus, ArrowUpCircle, TrendingDown, Loader2, ArrowLeft, History, ShieldAlert } from 'lucide-react';
import { getEffectiveBalance, isPassActive, getPassRemainingInfo, getMinRecharge } from '@/lib/recharge';
import ResolvedAvatar, { preloadStorageUrls } from '@/components/shared/ResolvedAvatar';

const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');

export default function WalletManager() {
  const [mobiles, setMobiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [rechargeId, setRechargeId] = useState(null);
  const [amount, setAmount] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [history, setHistory] = useState(null);

  const load = async () => {
    try {
      const mobs = await base44.entities.Mobile.list();
      preloadStorageUrls(mobs.map((m) => m.photo_url || m.vehicle_photo));
      // Si algún conductor tenía saldo de un día anterior ya vencido, renovarlo a $0 en la base de datos.
      const normalized = await Promise.all(
        mobs.map(async (m) => {
          if (!isPassActive(m) && Number(m.balance || 0) > 0) {
            try {
              return await base44.entities.Mobile.update(m.id, { balance: 0, pass_mode: 'pase' });
            } catch {
              return { ...m, balance: 0 };
            }
          }
          return m;
        })
      );
      setMobiles(normalized);
    } catch (e) {
      console.error('Wallet load error:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    const unsub = base44.entities.Mobile.subscribe(() => load().catch(() => {}));
    return unsub;
  }, []);

  const doRecharge = async (mobileId) => {
    const amt = parseInt(amount) || 0;
    if (amt <= 0) return;
    setSubmitting(true);
    try {
      const result = await safeInvoke('addDriverBalance', { mobile_id: mobileId, amount: amt, description: 'Recarga manual — Central' });
      toast({ title: 'Recarga exitosa', description: `Nuevo saldo: ${fmtCOP(result.new_balance)}` });
      setRechargeId(null);
      setAmount('');
      load();
    } catch (e) {
      toast({ title: 'Error al recargar', description: e.message || 'Intenta de nuevo', variant: 'destructive' });
    } finally {
      setSubmitting(false);
    }
  };

  const showHistory = async (mobile) => {
    try {
      const txns = await base44.entities.WalletTransaction.filter({ mobile_id: mobile.id }, '-created_date', 50);
      setHistory({ mobile, txns });
    } catch (e) {
      console.error('History load error:', e);
    }
  };

  if (history) {
    return (
      <div className="space-y-4">
        <button onClick={() => setHistory(null)} className="flex items-center gap-1.5 text-sm text-[#1E6BFF] font-medium"><ArrowLeft className="w-4 h-4" />Volver</button>
        <div className="bg-[#0D0D0D] rounded-xl p-4 border border-[#1F1F1F]">
          <h3 className="font-semibold text-white">{history.mobile.name}</h3>
          <p className="text-sm text-[#8B8C94]">Saldo actual: <span className="font-bold text-[#1E6BFF]">{fmtCOP(history.mobile.balance)}</span></p>
        </div>
        <h4 className="text-sm font-semibold text-[#8B8C94]">Movimientos</h4>
        {history.txns.length === 0 ? <p className="text-center text-sm text-[#8B8C94] py-4">Sin movimientos</p> :
          history.txns.map(t => (
            <div key={t.id} className="bg-[#0D0D0D] rounded-xl p-3 border border-[#1F1F1F] flex items-center gap-3">
              <div className={`w-9 h-9 rounded-full flex items-center justify-center ${t.type === 'recarga' ? 'bg-[#1E6BFF]/15' : 'bg-red-500/15'}`}>
                {t.type === 'recarga' ? <ArrowUpCircle className="w-5 h-5 text-[#1E6BFF]" /> : <TrendingDown className="w-5 h-5 text-red-400" />}
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-white">{t.description}</p>
                <p className="text-xs text-[#8B8C94]">{new Date(t.created_date).toLocaleDateString('es-CO', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</p>
              </div>
              <span className={`text-sm font-bold ${t.type === 'recarga' ? 'text-[#1E6BFF]' : 'text-red-400'}`}>{t.type === 'recarga' ? '+' : '-'}{fmtCOP(t.amount)}</span>
            </div>
          ))
        }
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="bg-[#1E6BFF]/10 rounded-xl p-3 border border-[#1E6BFF]/20">
        <p className="text-sm text-white font-medium">Billetera de conductores (Saldo diario)</p>
        <p className="text-xs text-[#8B8C94] mt-1">Saldo por día ($7.000 COP moto / $10.000 COP carro, sin comisión por porcentaje). Al pasar al siguiente día se renueva automáticamente a $0.</p>
      </div>
      {loading ? <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-[#1E6BFF]" /></div> :
        mobiles.map(m => (
          <div key={m.id} className="bg-[#0D0D0D] rounded-xl p-4 border border-[#1F1F1F]">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2.5">
                <ResolvedAvatar
                  photo={m.photo_url || m.vehicle_photo}
                  name={m.name}
                  className="w-9 h-9 rounded-full bg-gradient-to-br from-[#1E6BFF] to-[#00E5FF] text-white text-xs font-bold"
                />
                <div>
                  <p className="font-medium text-sm text-white">{m.name}</p>
                  <p className="text-xs text-[#8B8C94]">Placa: {m.plate}</p>
                </div>
                {m.blocked && <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-red-500/15 text-red-400"><ShieldAlert className="w-3 h-3" /></span>}
              </div>
              <div className="text-right">
                <p className="text-lg font-bold text-[#1E6BFF]">{fmtCOP(getEffectiveBalance(m))}</p>
                <p className="text-xs text-[#8B8C94]">Saldo hoy</p>
              </div>
            </div>
            <p className="text-xs text-[#8B8C94] mb-3">
              Pase 14h ({fmtCOP(getMinRecharge(m.vehicle_type))}) ·{' '}
              {isPassActive(m)
                ? `Activo (${getPassRemainingInfo(m).formatted} restantes)`
                : 'Sin pase activo ($0)'}
            </p>
            {rechargeId === m.id ? (
              <div className="flex gap-2">
                <input type="number" min="1000" placeholder="Monto" value={amount}
                  onChange={e => setAmount(e.target.value)}
                  className="h-9 flex-1 rounded-lg border border-[#262626] bg-[#0A0A0A] px-3 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#1E6BFF]/30" />
                <button className="h-9 px-4 rounded-lg bg-[#1E6BFF] hover:bg-[#1E6BFF]/90 text-white text-sm font-medium disabled:opacity-50" disabled={submitting} onClick={() => doRecharge(m.id)}>
                  {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Confirmar'}
                </button>
                <button className="h-9 px-3 rounded-lg border border-[#262626] text-[#8B8C94] text-sm" onClick={() => { setRechargeId(null); setAmount(''); }}>Cancelar</button>
              </div>
            ) : (
              <div className="flex gap-2">
                <button className="h-8 flex-1 rounded-lg bg-[#1E6BFF] hover:bg-[#1E6BFF]/90 text-white text-sm font-medium flex items-center justify-center gap-1" onClick={() => setRechargeId(m.id)}>
                  <Plus className="w-3.5 h-3.5" />Recargar
                </button>
                <button className="h-8 px-3 rounded-lg border border-[#262626] text-[#8B8C94] text-sm flex items-center gap-1" onClick={() => showHistory(m)}>
                  <History className="w-3.5 h-3.5" />Movimientos
                </button>
              </div>
            )}
          </div>
        ))
      }
      {!loading && mobiles.length === 0 && <p className="text-center text-sm text-[#8B8C94] py-8">No hay conductores registrados</p>}
    </div>
  );
}
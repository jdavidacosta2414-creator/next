import React, { useState, useEffect, useRef, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import {
  MessageSquare, Send, Search, Loader2, Bike, ChevronLeft, X, CheckCheck
} from 'lucide-react';
import { useBackButton } from '@/hooks/useBackButton';

function timeShort(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  const today = new Date();
  if (d.toDateString() === today.toDateString()) {
    return d.toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' });
  }
  return d.toLocaleDateString('es-CO', { day: '2-digit', month: '2-digit' });
}

export default function CentralChatView() {
  const { user } = useAuth();
  const [mobiles, setMobiles] = useState([]);
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);

  useBackButton(() => {
    if (selected) {
      setSelected(null);
      return true;
    }
    return false;
  }, true);
  const [query, setQuery] = useState('');
  const [draft, setDraft] = useState('');
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    const load = async () => {
      try {
        const list = await base44.entities.Mobile.list('-created_date', 200);
        setMobiles(list);
      } catch (e) {
        console.error('Chat mobiles load error:', e);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  useEffect(() => {
    const load = async () => {
      try {
        const list = await base44.entities.DriverChat.list('-created_date', 300);
        setMessages(list);
      } catch (e) {
        console.error('Chat messages load error:', e);
      }
    };
    load();
    const unsub = base44.entities.DriverChat.subscribe(() => load().catch(() => {}));
    return unsub;
  }, []);

  // Marcar como leídos los mensajes del conductor seleccionado
  useEffect(() => {
    if (!selected) return;
    const unread = messages.filter(m => m.mobile_id === selected && m.sender_type === 'movil' && !m.read);
    unread.forEach(m => {
      base44.entities.DriverChat.update(m.id, { read: true }).catch(() => {});
    });
  }, [selected, messages]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, selected]);

  const conversations = useMemo(() => {
    const map = new Map();
    mobiles.forEach(m => {
      const msgs = messages.filter(msg => msg.mobile_id === m.id);
      const last = msgs[msgs.length - 1];
      const unread = msgs.filter(msg => msg.sender_type === 'movil' && !msg.read).length;
      map.set(m.id, { mobile: m, lastMessage: last, unread, count: msgs.length });
    });
    let arr = Array.from(map.values());
    const q = query.trim().toLowerCase();
    if (q) arr = arr.filter(c => (c.mobile.name || '').toLowerCase().includes(q));
    arr.sort((a, b) => {
      const aT = a.lastMessage ? new Date(a.lastMessage.created_date).getTime() : 0;
      const bT = b.lastMessage ? new Date(b.lastMessage.created_date).getTime() : 0;
      return bT - aT;
    });
    return arr;
  }, [mobiles, messages, query]);

  const selectedMobile = useMemo(
    () => mobiles.find(m => m.id === selected),
    [mobiles, selected]
  );

  const conversation = useMemo(
    () => messages.filter(m => m.mobile_id === selected).sort((a, b) => new Date(a.created_date) - new Date(b.created_date)),
    [messages, selected]
  );

  const send = async (e) => {
    e.preventDefault();
    if (!draft.trim() || !selected || sending) return;
    const text = draft.trim();
    setDraft('');
    setSending(true);
    try {
      await base44.entities.DriverChat.create({
        mobile_id: selected,
        mobile_name: selectedMobile?.name || '',
        sender_type: 'central',
        message: text,
        read: true,
      });
    } catch (err) {
      setDraft(text);
      console.error('Send error:', err);
    } finally {
      setSending(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="w-7 h-7 animate-spin text-[#00E5FF]" />
      </div>
    );
  }

  return (
    <div className="bg-[#161C28] rounded-2xl border border-white/8 overflow-hidden h-[calc(100vh-220px)] min-h-[400px] flex">
      {/* Lista conversaciones */}
      <div className={`${selected ? 'hidden md:flex' : 'flex'} flex-col w-full md:w-72 lg:w-80 border-r border-white/8 flex-shrink-0`}>
        <div className="p-3 border-b border-white/8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5A6478]" />
            <input value={query} onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar conductor..."
              className="w-full h-9 rounded-xl bg-white/5 border border-white/8 pl-10 pr-3 text-sm text-white placeholder:text-[#5A6478] outline-none focus:border-[#00E5FF]/40" />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto thin-scroll">
          {conversations.length === 0 && (
            <p className="text-center text-[#8B95A8] text-sm py-8">Sin conductores</p>
          )}
          {conversations.map(c => (
            <button key={c.mobile.id} onClick={() => setSelected(c.mobile.id)}
              className={`w-full flex items-center gap-3 px-3 py-3 text-left border-b border-white/5 transition-colors ${selected === c.mobile.id ? 'bg-[#1E6BFF]/15' : 'hover:bg-white/5'}`}>
              <div className="relative flex-shrink-0">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#1E6BFF] to-[#00E5FF] flex items-center justify-center text-white text-sm font-bold">
                  {(c.mobile.name || '?').charAt(0).toUpperCase()}
                </div>
                {c.mobile.status === 'disponible' && <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-[#00E676] border-2 border-[#161C28]" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-white text-sm font-medium truncate">{c.mobile.name}</p>
                  {c.lastMessage && <span className="text-[10px] text-[#5A6478] flex-shrink-0">{timeShort(c.lastMessage.created_date)}</span>}
                </div>
                <p className="text-xs text-[#8B95A8] truncate">
                  {c.lastMessage ? (c.lastMessage.sender_type === 'central' ? 'Tú: ' : '') + c.lastMessage.message : 'Sin mensajes'}
                </p>
              </div>
              {c.unread > 0 && (
                <span className="flex-shrink-0 min-w-5 h-5 px-1.5 rounded-full text-[10px] font-bold bg-[#00E5FF] text-[#0B0F1A] flex items-center justify-center">{c.unread}</span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Panel conversación */}
      <div className={`${selected ? 'flex' : 'hidden md:flex'} flex-col flex-1 min-w-0`}>
        {!selected ? (
          <div className="flex-1 flex flex-col items-center justify-center text-[#5A6478]">
            <MessageSquare className="w-12 h-12 mb-3 text-white/10" />
            <p className="text-sm">Selecciona un conductor para chatear</p>
          </div>
        ) : (
          <>
            <div className="flex items-center gap-3 px-4 py-3 border-b border-white/8 flex-shrink-0">
              <button onClick={() => setSelected(null)} className="md:hidden w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-white">
                <ChevronLeft className="w-5 h-5" />
              </button>
              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#1E6BFF] to-[#00E5FF] flex items-center justify-center text-white text-sm font-bold">
                {(selectedMobile?.name || '?').charAt(0).toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-white text-sm font-medium truncate">{selectedMobile?.name}</p>
                <p className="text-[11px] text-[#8B95A8] flex items-center gap-1">
                  {selectedMobile?.status === 'disponible' ? (
                    <><span className="w-1.5 h-1.5 rounded-full bg-[#00E676]" /> Disponible</>
                  ) : selectedMobile?.status === 'ocupado' ? (
                    <><span className="w-1.5 h-1.5 rounded-full bg-[#FFB800]" /> Ocupado</>
                  ) : (
                    <><span className="w-1.5 h-1.5 rounded-full bg-[#5A6478]" /> Offline</>
                  )}
                  {selectedMobile?.phone && <span className="ml-1">· {selectedMobile.phone}</span>}
                </p>
              </div>
              <a href={selectedMobile?.phone ? `tel:${selectedMobile.phone}` : '#'}
                className="w-9 h-9 rounded-full bg-white/5 flex items-center justify-center text-white hover:bg-white/10">
                <Bike className="w-4 h-4" />
              </a>
            </div>

            <div className="flex-1 overflow-y-auto thin-scroll p-4 space-y-2">
              {conversation.length === 0 && (
                <p className="text-center text-[#5A6478] text-sm py-8">Inicia la conversación con este conductor</p>
              )}
              {conversation.map(msg => {
                const mine = msg.sender_type === 'central';
                return (
                  <div key={msg.id} className={`flex ${mine ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[75%] rounded-2xl px-3.5 py-2 ${mine ? 'bg-gradient-to-br from-[#1E6BFF] to-[#00E5FF] text-white rounded-br-md' : 'bg-white/5 text-white rounded-bl-md'}`}>
                      <p className="text-sm whitespace-pre-wrap break-words">{msg.message}</p>
                      <p className={`text-[9px] mt-0.5 flex items-center gap-1 justify-end ${mine ? 'text-white/70' : 'text-[#5A6478]'}`}>
                        {timeShort(msg.created_date)}
                        {mine && msg.read && <CheckCheck className="w-3 h-3" />}
                      </p>
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            <form onSubmit={send} className="p-3 border-t border-white/8 flex gap-2 flex-shrink-0">
              <input value={draft} onChange={(e) => setDraft(e.target.value)}
                placeholder="Escribe un mensaje..."
                className="flex-1 h-10 rounded-xl bg-white/5 border border-white/8 px-4 text-sm text-white placeholder:text-[#5A6478] outline-none focus:border-[#00E5FF]/40" />
              <button type="submit" disabled={!draft.trim() || sending}
                className="w-10 h-10 rounded-xl bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white flex items-center justify-center disabled:opacity-40 flex-shrink-0">
                {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
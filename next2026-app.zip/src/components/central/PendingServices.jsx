import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import {
  Plus,
  MapPin,
  Navigation,
  Phone,
  CreditCard,
  Loader2,
  X,
  Package,
  Users,
  Link as LinkIcon,
  MessageCircle,
  AlertTriangle,
} from 'lucide-react';
import StatusBadge from '@/components/StatusBadge';
import { isPickupInCoverage } from '@/lib/coverage';
import { useMapboxToken } from '@/hooks/useMapboxToken';
import {
  geocodeAddress,
  searchPlacesValledupar,
  resolvePlaceSelection,
  normalizeColombiaCoords,
} from '@/lib/geocode';
import { joinBarrio } from '@/lib/shortAddress';
import BarrioFields from '@/components/central/BarrioFields';

export default function PendingServices() {
  const [services, setServices] = useState([]);
  const [mobiles, setMobiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [assigning, setAssigning] = useState(null);

  const load = async () => {
    const [svcs, mobs] = await Promise.all([
      base44.entities.Service.filter({ status: 'pendiente' }, '-created_date', 50),
      base44.entities.Mobile.list(),
    ]);
    setServices(svcs);
    setMobiles(mobs.filter((m) => m.status === 'disponible'));
    setLoading(false);
  };

  useEffect(() => {
    load();
    const unsub = base44.entities.Service.subscribe(() => load().catch(() => {}));
    return unsub;
  }, []);

  const assign = async (serviceId, mobileId) => {
    try {
      const m = mobiles.find((x) => x.id === mobileId);
      await base44.entities.Service.update(serviceId, {
        status: 'asignado',
        mobile_id: mobileId,
        mobile_name: m?.name,
        mobile_plate: m?.plate,
        mobile_photo: m?.photo_url || m?.vehicle_photo || '',
        mobile_phone: m?.phone,
      });
      await base44.entities.Mobile.update(mobileId, { status: 'ocupado' });
      setAssigning(null);
      load();
    } catch (e) {
      console.error('Assign error:', e);
      setAssigning(null);
    }
  };

  return (
    <div className="space-y-4">
      <button
        onClick={() => setShowForm((f) => !f)}
        className="w-full h-11 rounded-xl bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-[#FFFFFF] font-semibold text-sm flex items-center justify-center gap-2"
      >
        {showForm ? (
          <>
            <X className="w-4 h-4" />
            Cancelar
          </>
        ) : (
          <>
            <Plus className="w-4 h-4" />
            Cargar servicio de WhatsApp
          </>
        )}
      </button>
      {showForm && (
        <QuickForm
          onDone={() => {
            setShowForm(false);
            load();
          }}
        />
      )}
      <div>
        <h3 className="text-sm font-semibold text-[#8B8C94] mb-2">
          Pendientes por asignar ({services.length})
        </h3>
        {loading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="w-6 h-6 animate-spin text-[#1E6BFF]" />
          </div>
        ) : services.length === 0 ? (
          <p className="text-center text-sm text-[#8B8C94] py-8">No hay servicios pendientes</p>
        ) : (
          services.map((s) => {
            const pLat = s.pickup_lat != null ? parseFloat(s.pickup_lat) : null;
            const pLng = s.pickup_lng != null ? parseFloat(s.pickup_lng) : null;
            const dLat = s.destination_lat != null ? parseFloat(s.destination_lat) : null;
            const dLng = s.destination_lng != null ? parseFloat(s.destination_lng) : null;
            const hasCoords = Number.isFinite(pLat) && Number.isFinite(pLng);
            const trackingLink = `${window.location.origin}/cliente?service=${s.id}`;

            return (
              <div key={s.id} className="bg-[#0D0D0D] rounded-xl p-4 border border-[#1F1F1F] mb-3">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    {s.service_type === 'mensajeria' ? (
                      <Package className="w-4 h-4 text-[#1E6BFF]" />
                    ) : (
                      <Users className="w-4 h-4 text-[#1E6BFF]" />
                    )}
                    <span className="font-medium text-sm text-white">{s.client_name}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {s.origin === 'whatsapp' ? (
                      <MessageCircle className="w-3.5 h-3.5 text-[#8B8C94]" />
                    ) : (
                      <LinkIcon className="w-3.5 h-3.5 text-[#8B8C94]" />
                    )}
                    <StatusBadge status={s.status} />
                  </div>
                </div>
                <div className="space-y-1 text-xs text-[#8B8C94] mb-3">
                  <div className="flex items-start gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-[#1E6BFF] mt-0.5" />
                    <span>{joinBarrio(s.pickup_address, s.pickup_barrio)}</span>
                  </div>
                  <div className="flex items-start gap-1.5">
                    <Navigation className="w-3.5 h-3.5 text-[#F59E0B] mt-0.5" />
                    <span>{joinBarrio(s.destination_address, s.destination_barrio)}</span>
                  </div>
                  {s.client_phone && (
                    <div className="flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-[#8B8C94]" />
                      {s.client_phone}
                    </div>
                  )}
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <CreditCard className="w-3.5 h-3.5 text-[#8B8C94]" />
                    <span>
                      {s.payment_method === 'efectivo' ? 'Efectivo' : 'Transferencia'} ·{' '}
                      <strong className="text-white">
                        ${Number(s.fare || 5000).toLocaleString('es-CO')}
                      </strong>
                    </span>
                    {s.origin === 'whatsapp' && (
                      <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/35 text-emerald-400 text-[10px] font-extrabold">
                        Precio fijo · WhatsApp
                      </span>
                    )}
                  </div>
                  {hasCoords && (
                    <div className="flex items-center gap-2 pt-1 flex-wrap">
                      <a
                        href={
                          Number.isFinite(dLat) && Number.isFinite(dLng)
                            ? `https://www.google.com/maps/dir/?api=1&origin=${pLat},${pLng}&destination=${dLat},${dLng}&travelmode=driving`
                            : `https://www.google.com/maps/search/?api=1&query=${pLat},${pLng}`
                        }
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[11px] font-bold text-[#00E5FF] hover:underline"
                      >
                        Google Maps (GPS)
                      </a>
                      <a
                        href={`https://www.waze.com/ul?ll=${pLat},${pLng}&navigate=yes`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[11px] font-bold text-[#1E6BFF] hover:underline"
                      >
                        Waze (GPS)
                      </a>
                      <a
                        href={`https://wa.me/${(s.client_phone || '').replace(/\D/g, '')}?text=${encodeURIComponent(
                          `Sigue tu servicio en vivo aquí: ${trackingLink}`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[11px] font-bold text-emerald-400 hover:underline"
                      >
                        Link WhatsApp
                      </a>
                    </div>
                  )}
                </div>
                {assigning === s.id ? (
                  <div className="flex gap-2">
                    <select
                      onChange={(e) => e.target.value && assign(s.id, e.target.value)}
                      defaultValue=""
                      className="h-9 text-sm flex-1 rounded-lg border border-[#262626] bg-[#0A0A0A] px-3 text-white focus:outline-none focus:ring-2 focus:ring-[#1E6BFF]/30"
                    >
                      <option value="" disabled>
                        Seleccionar móvil
                      </option>
                      {mobiles.map((m) => (
                        <option key={m.id} value={m.id}>
                          {m.name} — {m.plate}
                        </option>
                      ))}
                    </select>
                    <button
                      onClick={() => setAssigning(null)}
                      className="h-9 px-3 rounded-lg border border-[#262626] text-[#8B8C94] text-sm"
                    >
                      Cancelar
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setAssigning(s.id)}
                    className="w-full h-9 rounded-lg bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-[#FFFFFF] font-semibold text-sm"
                  >
                    Asignar móvil
                  </button>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

function QuickForm({ onDone }) {
  const [form, setForm] = useState({
    client_name: '',
    client_phone: '',
    pickup_address: '',
    pickup_barrio: '',
    destination_address: '',
    destination_barrio: '',
    service_type: 'transporte',
    vehicle_type: 'moto',
    payment_method: 'efectivo',
    fare: 5000,
  });
  const [pickupPlace, setPickupPlace] = useState(null);
  const [destPlace, setDestPlace] = useState(null);
  const [activeField, setActiveField] = useState(null);
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const token = useMapboxToken();

  const currentQuery =
    activeField === 'pickup'
      ? form.pickup_address
      : activeField === 'destination'
      ? form.destination_address
      : '';

  useEffect(() => {
    const q = (currentQuery || '').trim();
    if (!activeField || q.length < 2) {
      setSuggestions([]);
      return;
    }
    let cancelled = false;
    const t = setTimeout(async () => {
      const res = await searchPlacesValledupar(q, token);
      if (!cancelled) setSuggestions(res);
    }, 200);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [currentQuery, activeField, token]);

  const handleSelectSuggestion = async (item) => {
    const resolved = await resolvePlaceSelection(item);
    if (!resolved) return;
    if (activeField === 'pickup') {
      set('pickup_address', resolved.name);
      setPickupPlace(resolved);
    } else if (activeField === 'destination') {
      set('destination_address', resolved.name);
      setDestPlace(resolved);
    }
    setSuggestions([]);
    setActiveField(null);
  };

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const cov = await isPickupInCoverage(form.pickup_address);
      if (!cov.ok) {
        setError(`Fuera de zona de cobertura. Barrios: ${cov.zone.neighborhoods.join(', ')}`);
        setLoading(false);
        return;
      }
      if (!pickupPlace?.lat || !destPlace?.lat) {
        setError('Selecciona una opción de la lista para recogida y destino.');
        setLoading(false);
        return;
      }
      const pCoords = normalizeColombiaCoords(pickupPlace.lat, pickupPlace.lng);
      const dCoords = normalizeColombiaCoords(destPlace.lat, destPlace.lng);

      const created = await base44.entities.Service.create({
        ...form,
        pickup_barrio: form.pickup_barrio.trim(),
        destination_barrio: form.destination_barrio.trim(),
        fare: Number(form.fare) || (form.vehicle_type === 'carro' ? 8000 : 5000),
        origin: 'whatsapp',
        status: 'pendiente',
        rejected_by: [],
        viewed_by: [],
        candidates: [],
        ...(pCoords ? { pickup_lat: parseFloat(pCoords.lat), pickup_lng: parseFloat(pCoords.lng) } : {}),
        ...(dCoords ? { destination_lat: parseFloat(dCoords.lat), destination_lng: parseFloat(dCoords.lng) } : {}),
      });
      if (created?.id) {
        base44.functions.invoke('notifyNearbyDrivers', { service_id: created.id }).catch(() => {});
      }
      onDone();
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={submit} className="bg-[#0D0D0D] rounded-xl p-4 border border-[#1F1F1F] space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <div>
          <label className="text-xs text-[#8B8C94] mb-1 block">Cliente</label>
          <input
            required
            value={form.client_name}
            onChange={(e) => set('client_name', e.target.value)}
            className="h-10 w-full rounded-lg border border-[#262626] bg-[#0A0A0A] px-3 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#1E6BFF]/30"
            placeholder="Nombre"
          />
        </div>
        <div>
          <label className="text-xs text-[#8B8C94] mb-1 block">Teléfono</label>
          <input
            value={form.client_phone}
            onChange={(e) => set('client_phone', e.target.value)}
            className="h-10 w-full rounded-lg border border-[#262626] bg-[#0A0A0A] px-3 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#1E6BFF]/30"
            placeholder="Tel"
          />
        </div>
      </div>
      <div className="relative">
        <label className="text-xs text-[#8B8C94] mb-1 block">Recogida</label>
        <input
          required
          value={form.pickup_address}
          onFocus={() => setActiveField('pickup')}
          onChange={(e) => {
            setActiveField('pickup');
            setPickupPlace(null);
            set('pickup_address', e.target.value);
          }}
          className="h-10 w-full rounded-lg border border-[#262626] bg-[#0A0A0A] px-3 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#1E6BFF]/30"
          placeholder="Dirección de recogida"
        />
      </div>
      <div className="relative">
        <label className="text-xs text-[#8B8C94] mb-1 block">Destino</label>
        <input
          required
          value={form.destination_address}
          onFocus={() => setActiveField('destination')}
          onChange={(e) => {
            setActiveField('destination');
            setDestPlace(null);
            set('destination_address', e.target.value);
          }}
          className="h-10 w-full rounded-lg border border-[#262626] bg-[#0A0A0A] px-3 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#1E6BFF]/30"
          placeholder="Dirección de destino"
        />
      </div>

      {suggestions.length > 0 && (
        <div className="rounded-lg border border-[#262626] bg-[#141923] divide-y divide-white/5 max-h-44 overflow-y-auto">
          {suggestions.map((item, idx) => (
            <button
              key={`${item.place_id || item.name}-${idx}`}
              type="button"
              onClick={() => handleSelectSuggestion(item)}
              className="w-full px-3 py-2 text-left hover:bg-white/5 flex items-center justify-between gap-2"
            >
              <div className="min-w-0">
                <p className="text-xs font-bold text-white truncate">{item.name}</p>
                <p className="text-[10px] text-[#8B8C94] truncate">{item.subtitle}</p>
              </div>
              {item.needsConfirmation && (
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
              )}
            </button>
          ))}
        </div>
      )}

      {(pickupPlace?.needsConfirmation || destPlace?.needsConfirmation) && (
        <p className="text-[11px] text-amber-400 flex items-center gap-1.5 font-semibold">
          <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
          Confirma la ubicación en el mapa
        </p>
      )}

      <BarrioFields
        form={form}
        onChange={set}
        inputClassName="h-10 w-full rounded-lg border border-[#262626] bg-[#0A0A0A] px-3 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#1E6BFF]/30"
      />

      <div className="grid grid-cols-2 gap-2">
        <div>
          <label className="text-xs text-[#8B8C94] mb-1 block">Tipo</label>
          <select
            value={form.service_type}
            onChange={(e) => set('service_type', e.target.value)}
            className="h-10 w-full rounded-lg border border-[#262626] bg-[#0A0A0A] px-3 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#1E6BFF]/30"
          >
            <option value="transporte">Transporte</option>
            <option value="mensajeria">Mensajería</option>
          </select>
        </div>
        <div>
          <label className="text-xs text-[#8B8C94] mb-1 block">Vehículo</label>
          <select
            value={form.vehicle_type}
            onChange={(e) => {
              const vt = e.target.value;
              setForm((f) => ({
                ...f,
                vehicle_type: vt,
                fare: vt === 'carro' && Number(f.fare) <= 5000 ? 8000 : f.fare,
              }));
            }}
            className="h-10 w-full rounded-lg border border-[#262626] bg-[#0A0A0A] px-3 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#1E6BFF]/30"
          >
            <option value="moto">Moto</option>
            <option value="carro">Carro</option>
          </select>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div>
          <label className="text-xs text-[#8B8C94] mb-1 block">Pago</label>
          <select
            value={form.payment_method}
            onChange={(e) => set('payment_method', e.target.value)}
            className="h-10 w-full rounded-lg border border-[#262626] bg-[#0A0A0A] px-3 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#1E6BFF]/30"
          >
            <option value="efectivo">Efectivo</option>
            <option value="transferencia">Transferencia</option>
            <option value="nequi">Nequi</option>
            <option value="daviplata">DaviPlata</option>
            <option value="bancolombia">Bancolombia</option>
            <option value="paga_con_llave">Paga con llave</option>
          </select>
        </div>
        <div>
          <label className="text-xs text-emerald-400 font-semibold mb-1 block">
            Precio fijo WhatsApp (COP)
          </label>
          <input
            type="number"
            min="1000"
            step="500"
            required
            value={form.fare}
            onChange={(e) => set('fare', e.target.value)}
            className="h-10 w-full rounded-lg border border-emerald-500/40 bg-[#0A0A0A] px-3 text-sm font-bold text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
            placeholder="5000"
          />
        </div>
      </div>
      {error && <p className="text-xs text-red-400 bg-red-500/10 rounded-lg p-2">{error}</p>}
      <button
        type="submit"
        disabled={loading}
        className="w-full h-10 rounded-lg bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-[#FFFFFF] font-semibold text-sm flex items-center justify-center gap-2 disabled:opacity-50"
      >
        {loading && <Loader2 className="w-4 h-4 animate-spin" />}Crear servicio
      </button>
    </form>
  );
}
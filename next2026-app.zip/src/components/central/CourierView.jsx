import React, { useState, useEffect, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import {
  Search, Package, Bike, Clock, CheckCircle, Camera, Phone, Loader2,
  MapPin, ArrowRight, CreditCard, Banknote, X
} from 'lucide-react';
import ResolvedAvatar from '@/components/shared/ResolvedAvatar';

const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');

const STATUS_LABELS = {
  pendiente: 'Buscando', asignado: 'Asignado', en_camino: 'En camino',
  recogida: 'En recorrido', finalizado: 'Finalizado', cancelado: 'Cancelado',
};
const STATUS_COLORS = {
  pendiente: 'text-[#FFB800] bg-[#FFB800]/10', asignado: 'text-[#00E5FF] bg-[#00E5FF]/10',
  en_camino: 'text-[#1E6BFF] bg-[#1E6BFF]/10', recogida: 'text-[#1E6BFF] bg-[#1E6BFF]/10',
  finalizado: 'text-[#00E676] bg-[#00E676]/10', cancelado: 'text-[#FF5252] bg-[#FF5252]/10',
};

const CONTENT_LABELS = {
  comida: 'Comida', electronico: 'Electrónico', documentos: 'Documentos',
  paquete_pequeno: 'Paq. pequeño', paquete_grande: 'Paq. grande', otro: 'Otro',
};

function Kpi({ icon: Icon, value, label, accent }) {
  return (
    <div className="bg-[#161C28] rounded-2xl p-4 border border-white/8">
      <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-3 ${accent}`}>
        <Icon className="w-5 h-5" />
      </div>
      <p className="text-2xl font-bold text-white leading-none">{value}</p>
      <p className="text-xs text-[#8B95A8] mt-1">{label}</p>
    </div>
  );
}

export default function CourierView() {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [scope, setScope] = useState('activos');
  const [detail, setDetail] = useState(null);

  useEffect(() => {
    const load = async () => {
      try {
        const svcs = await base44.entities.Service.filter(
          { service_type: 'mensajeria' }, '-created_date', 150
        );
        setServices(svcs);
      } catch (e) {
        console.error('Courier load error:', e);
      } finally {
        setLoading(false);
      }
    };
    load();
    const unsub = base44.entities.Service.subscribe(() => load().catch(() => {}));
    return unsub;
  }, []);

  const filtered = useMemo(() => {
    const activeStatuses = ['pendiente', 'asignado', 'en_camino', 'recogida'];
    const list = services.filter(s =>
      scope === 'activos' ? activeStatuses.includes(s.status) : s.status === 'finalizado'
    );
    const q = query.trim().toLowerCase();
    if (!q) return list;
    return list.filter(s =>
      (s.client_name || '').toLowerCase().includes(q) ||
      (s.pickup_address || '').toLowerCase().includes(q) ||
      (s.destination_address || '').toLowerCase().includes(q) ||
      (s.content_description || '').toLowerCase().includes(q)
    );
  }, [services, scope, query]);

  const stats = useMemo(() => {
    const activeStatuses = ['pendiente', 'asignado', 'en_camino', 'recogida'];
    const activos = services.filter(s => activeStatuses.includes(s.status));
    const finalizados = services.filter(s => s.status === 'finalizado');
    const conEvidencia = finalizados.filter(s => s.evidence_pickup_photo || s.evidence_delivery_photo);
    return {
      total: services.length,
      activos: activos.length,
      finalizados: finalizados.length,
      conEvidencia: conEvidencia.length,
    };
  }, [services]);

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="w-7 h-7 animate-spin text-[#00E5FF]" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Kpi icon={Package} value={stats.total} label="Total mensajería" accent="bg-[#1E6BFF]/15 text-[#1E6BFF]" />
        <Kpi icon={Clock} value={stats.activos} label="En curso" accent="bg-[#FFB800]/15 text-[#FFB800]" />
        <Kpi icon={CheckCircle} value={stats.finalizados} label="Finalizados" accent="bg-[#00E676]/15 text-[#00E676]" />
        <Kpi icon={Camera} value={stats.conEvidencia} label="Con evidencia" accent="bg-[#00E5FF]/15 text-[#00E5FF]" />
      </div>

      {/* Controles */}
      <div className="flex flex-col sm:flex-row gap-3 sm:items-center">
        <div className="flex gap-1.5 bg-[#161C28] rounded-xl p-1 border border-white/8 w-fit">
          <button onClick={() => setScope('activos')}
            className={`h-9 px-4 rounded-lg text-sm font-medium transition ${scope === 'activos' ? 'bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white' : 'text-[#8B95A8]'}`}>
            En curso
          </button>
          <button onClick={() => setScope('historial')}
            className={`h-9 px-4 rounded-lg text-sm font-medium transition ${scope === 'historial' ? 'bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white' : 'text-[#8B95A8]'}`}>
            Historial
          </button>
        </div>
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5A6478]" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar cliente, dirección o contenido..."
            className="w-full h-10 rounded-xl bg-[#161C28] border border-white/8 pl-10 pr-4 text-sm text-white placeholder:text-[#5A6478] outline-none focus:border-[#00E5FF]/40 transition-colors"
          />
        </div>
      </div>

      {/* Tabla escritorio */}
      <div className="hidden md:block bg-[#161C28] rounded-2xl border border-white/8 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-white/5 text-[#8B95A8] text-xs uppercase tracking-wide">
              <th className="text-left font-medium px-4 py-3">Cliente</th>
              <th className="text-left font-medium px-4 py-3">Contenido</th>
              <th className="text-left font-medium px-4 py-3">Ruta</th>
              <th className="text-center font-medium px-4 py-3">Pago</th>
              <th className="text-center font-medium px-4 py-3">Evidencia</th>
              <th className="text-center font-medium px-4 py-3">Estado</th>
              <th className="px-4 py-3 w-10"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {filtered.length === 0 && (
              <tr><td colSpan={7} className="text-center text-[#8B95A8] py-8">Sin servicios de mensajería</td></tr>
            )}
            {filtered.map(s => (
              <tr key={s.id} onClick={() => setDetail(s)}
                className="cursor-pointer hover:bg-white/5 transition-colors">
                <td className="px-4 py-3">
                  <p className="text-white font-medium">{s.client_name || 'Sin nombre'}</p>
                  <p className="text-[11px] text-[#8B95A8]">{s.client_phone || ''}</p>
                  {s.business_name && <p className="text-[11px] text-[#00E5FF]">Negocio: {s.business_name}</p>}
                </td>
                <td className="px-4 py-3">
                  <span className="inline-flex items-center gap-1.5 text-xs text-white">
                    <Package className="w-3.5 h-3.5 text-[#00E5FF]" />
                    {CONTENT_LABELS[s.content_type] || 'Otro'}
                  </span>
                  {s.content_description && (
                    <p className="text-[11px] text-[#8B95A8] truncate max-w-[180px] mt-0.5">{s.content_description}</p>
                  )}
                </td>
                <td className="px-4 py-3 max-w-[260px]">
                  <p className="text-[11px] text-white truncate flex items-center gap-1"><MapPin className="w-3 h-3 text-[#1E6BFF] flex-shrink-0" />{s.pickup_address}</p>
                  <p className="text-[11px] text-[#8B95A8] truncate flex items-center gap-1 pl-4"><ArrowRight className="w-3 h-3 flex-shrink-0" />{s.destination_address}</p>
                </td>
                <td className="px-4 py-3 text-center">
                  <span className="inline-flex items-center gap-1 text-xs text-[#8B95A8]">
                    {s.payment_method === 'transferencia' ? <Banknote className="w-3.5 h-3.5" /> : <CreditCard className="w-3.5 h-3.5" />}
                    {s.payment_method === 'transferencia' ? 'Transf.' : 'Efectivo'}
                  </span>
                  {s.fare != null && <p className="text-[11px] text-white font-medium mt-0.5">{fmtCOP(s.fare)}</p>}
                </td>
                <td className="px-4 py-3 text-center">
                  <div className="flex items-center justify-center gap-1">
                    {s.evidence_pickup_photo ? <Camera className="w-4 h-4 text-[#00E676]" /> : <Camera className="w-4 h-4 text-white/15" />}
                    {s.evidence_delivery_photo ? <Camera className="w-4 h-4 text-[#00E676]" /> : <Camera className="w-4 h-4 text-white/15" />}
                  </div>
                </td>
                <td className="px-4 py-3 text-center">
                  <span className={`inline-block px-2.5 py-1 rounded-full text-[10px] font-medium ${STATUS_COLORS[s.status] || 'text-[#8B95A8]'}`}>
                    {STATUS_LABELS[s.status] || s.status}
                  </span>
                </td>
                <td className="px-4 py-3 text-center text-[#5A6478] text-xs">›</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Tarjetas móvil */}
      <div className="md:hidden space-y-2">
        {filtered.length === 0 && <p className="text-center text-[#8B95A8] py-8 text-sm">Sin servicios de mensajería</p>}
        {filtered.map(s => (
          <div key={s.id} onClick={() => setDetail(s)} className="bg-[#161C28] rounded-2xl border border-white/8 p-3 cursor-pointer">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#1E6BFF] to-[#00E5FF] flex items-center justify-center text-white text-xs font-bold">
                  {(s.client_name || '?').charAt(0).toUpperCase()}
                </div>
                <div>
                  <p className="text-white font-medium text-sm">{s.client_name || 'Sin nombre'}</p>
                  <p className="text-[10px] text-[#8B95A8]">{CONTENT_LABELS[s.content_type] || 'Otro'}{s.business_name ? ` · ${s.business_name}` : ''}</p>
                </div>
              </div>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${STATUS_COLORS[s.status] || 'text-[#8B95A8]'}`}>
                {STATUS_LABELS[s.status] || s.status}
              </span>
            </div>
            <p className="text-[11px] text-white flex items-start gap-1"><MapPin className="w-3 h-3 text-[#1E6BFF] flex-shrink-0 mt-0.5" />{s.pickup_address}</p>
            <p className="text-[11px] text-[#8B95A8] flex items-start gap-1 pl-4"><ArrowRight className="w-3 h-3 flex-shrink-0 mt-0.5" />{s.destination_address}</p>
            {s.content_description && <p className="text-[11px] text-[#5A6478] mt-1 truncate">{s.content_description}</p>}
          </div>
        ))}
      </div>

      {/* Modal de detalle */}
      {detail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={() => setDetail(null)}>
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
          <div className="relative w-full max-w-lg max-h-[85vh] overflow-y-auto thin-scroll bg-[#161C28] rounded-2xl border border-white/10 p-5" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-white font-bold text-lg">Mensajería · {CONTENT_LABELS[detail.content_type] || 'Otro'}</h3>
                <p className="text-xs text-[#8B95A8]">{new Date(detail.created_date).toLocaleString('es-CO')}</p>
              </div>
              <button onClick={() => setDetail(null)} className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="bg-white/5 rounded-xl p-3">
                <p className="text-[10px] text-[#8B95A8] uppercase mb-1">Cliente</p>
                <p className="text-white font-medium text-sm">{detail.client_name || 'Sin nombre'}</p>
                {detail.client_phone && (
                  <a href={`tel:${detail.client_phone}`} className="text-xs text-[#00E5FF] flex items-center gap-1 mt-1">
                    <Phone className="w-3 h-3" />{detail.client_phone}
                  </a>
                )}
              </div>

              {detail.content_description && (
                <div className="bg-white/5 rounded-xl p-3">
                  <p className="text-[10px] text-[#8B95A8] uppercase mb-1">Descripción del contenido</p>
                  <p className="text-sm text-white">{detail.content_description}</p>
                </div>
              )}

              <div className="bg-white/5 rounded-xl p-3 space-y-2">
                <div>
                  <p className="text-[10px] text-[#8B95A8] uppercase mb-1">Recogida</p>
                  <p className="text-sm text-white flex items-start gap-1"><MapPin className="w-3.5 h-3.5 text-[#1E6BFF] flex-shrink-0 mt-0.5" />{detail.pickup_address}</p>
                </div>
                <div>
                  <p className="text-[10px] text-[#8B95A8] uppercase mb-1">Entrega</p>
                  <p className="text-sm text-white flex items-start gap-1"><MapPin className="w-3.5 h-3.5 text-[#00E5FF] flex-shrink-0 mt-0.5" />{detail.destination_address}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-white/5 rounded-xl p-3">
                  <p className="text-[10px] text-[#8B95A8] uppercase mb-1">Pago</p>
                  <p className="text-sm text-white">{detail.payment_method === 'transferencia' ? 'Transferencia' : 'Efectivo'} · {fmtCOP(detail.fare)}</p>
                </div>
                <div className="bg-white/5 rounded-xl p-3">
                  <p className="text-[10px] text-[#8B95A8] uppercase mb-1">Estado</p>
                  <span className={`inline-block px-2.5 py-1 rounded-full text-[11px] font-medium ${STATUS_COLORS[detail.status] || 'text-[#8B95A8]'}`}>
                    {STATUS_LABELS[detail.status] || detail.status}
                  </span>
                </div>
              </div>

              {detail.mobile_name && (
                <div className="bg-white/5 rounded-xl p-3">
                  <p className="text-[10px] text-[#8B95A8] uppercase mb-1">Conductor</p>
                  <p className="text-sm text-white">{detail.mobile_name} · {detail.mobile_plate}</p>
                </div>
              )}

              {(detail.evidence_pickup_photo || detail.evidence_delivery_photo) && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <p className="text-[10px] text-[#8B95A8] uppercase mb-1.5 flex items-center gap-1"><Camera className="w-3 h-3" /> Recogida</p>
                    {detail.evidence_pickup_photo ? (
                      <ResolvedAvatar photo={detail.evidence_pickup_photo} name="Recogida" className="w-full h-28 rounded-xl border border-white/10 bg-white/5" />
                    ) : <p className="text-[11px] text-[#5A6478]">Sin evidencia</p>}
                  </div>
                  <div>
                    <p className="text-[10px] text-[#8B95A8] uppercase mb-1.5 flex items-center gap-1"><Camera className="w-3 h-3" /> Entrega</p>
                    {detail.evidence_delivery_photo ? (
                      <ResolvedAvatar photo={detail.evidence_delivery_photo} name="Entrega" className="w-full h-28 rounded-xl border border-white/10 bg-white/5" />
                    ) : <p className="text-[11px] text-[#5A6478]">Sin evidencia</p>}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
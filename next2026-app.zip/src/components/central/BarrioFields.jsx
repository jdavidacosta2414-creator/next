import React from 'react';

const FIELDS = [
  { key: 'pickup_barrio', label: 'Barrio de recogida' },
  { key: 'destination_barrio', label: 'Barrio de destino' },
];

// Casillas donde la Central escribe el barrio de la recogida y del destino al cargar un servicio de WhatsApp.
// Son opcionales: lo que se escriba es el barrio que ve el conductor junto a cada dirección.
export default function BarrioFields({ form, onChange, inputClassName }) {
  return (
    <div className="grid grid-cols-2 gap-2">
      {FIELDS.map(({ key, label }) => (
        <div key={key}>
          <label htmlFor={key} className="text-xs text-[#8B8C94] mb-1 block">
            {label}
          </label>
          <input
            id={key}
            value={form[key]}
            onChange={(e) => onChange(key, e.target.value)}
            className={inputClassName}
            placeholder="Opcional"
          />
        </div>
      ))}
    </div>
  );
}
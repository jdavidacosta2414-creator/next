import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Bike, Car, MapPin, Loader2, X, FileCheck, Eye, ShieldCheck, Check, AlertTriangle } from 'lucide-react';
import StatusBadge from '@/components/StatusBadge';
import ResolvedAvatar, { preloadStorageUrls, getCachedSignedUrl, resolveStorageUrl } from '@/components/shared/ResolvedAvatar';
import { useToast } from '@/components/ui/use-toast';
import { useBackButton } from '@/hooks/useBackButton';

const CURRENT_YEAR = new Date().getFullYear();
const CAR_YEARS = Array.from(
  { length: Math.max(1, CURRENT_YEAR + 1 - 2003 + 1) },
  (_, idx) => String(CURRENT_YEAR + 1 - idx)
);

function DocThumb({ uri, label }) {
  const [url, setUrl] = useState(() => getCachedSignedUrl(uri) || '');
  const [open, setOpen] = useState(false);
  useBackButton(() => setOpen(false), open);

  useEffect(() => {
    if (!uri) { setUrl(''); return; }
    const cached = getCachedSignedUrl(uri);
    if (cached) {
      setUrl(cached);
      if (!cached.startsWith('blob:')) return;
    }
    let active = true;
    resolveStorageUrl(uri).then((r) => { if (active && r) setUrl(r); }).catch(() => {});
    return () => { active = false; };
  }, [uri]);

  if (!uri) return null;
  return (
    <>
      <button
        type="button"
        onClick={() => url && setOpen(true)}
        className="block w-full rounded-lg overflow-hidden border border-[#262626] bg-[#141414] hover:border-[#00E5FF]/50 transition-colors text-left"
      >
        {url ? (
          <img src={url} alt={label} className="w-full h-24 object-cover" />
        ) : (
          <div className="w-full h-24 flex items-center justify-center text-xs text-[#8B8C94]">Cargando...</div>
        )}
        <p className="text-[10px] font-semibold text-center text-[#E5E7EB] py-1 px-1.5 truncate">{label}</p>
      </button>
      {open && url && (
        <div
          className="fixed inset-0 z-[2600] bg-black/90 flex items-center justify-center p-4"
          onClick={() => setOpen(false)}
        >
          <img
            src={url}
            alt={label}
            className="max-w-[92vw] max-h-[85vh] rounded-2xl object-contain"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </>
  );
}

export default function MobilesList() {
  const { toast } = useToast();
  const [mobiles, setMobiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [expandedDocsId, setExpandedDocsId] = useState(null);
  const [actionBusyId, setActionBusyId] = useState(null);
  const [rejectingId, setRejectingId] = useState(null);
  const [rejectReason, setRejectReason] = useState('');

  useBackButton(() => {
    if (rejectingId) {
      setRejectingId(null);
      setRejectReason('');
      return true;
    }
    if (expandedDocsId) {
      setExpandedDocsId(null);
      return true;
    }
    if (showForm) {
      setShowForm(false);
      return true;
    }
    return false;
  }, true);
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    plate: '',
    vehicle_type: 'moto',
    car_subtype: 'particular',
    plate_type: 'amarilla',
    vehicle_brand: '',
    vehicle_model: '',
    vehicle_year: String(CURRENT_YEAR),
  });

  const load = async () => {
    const list = await base44.entities.Mobile.list();
    preloadStorageUrls(
      list.flatMap((m) => [
        m.photo_url,
        m.vehicle_photo,
        m.verification_photo,
        m.tarjeta_photo,
        m.soat_photo,
        m.tecno_photo,
      ])
    );
    setMobiles(list);
    setLoading(false);
  };

  useEffect(() => {
    load().catch(() => {});
    const u = base44.entities.Mobile.subscribe(() => load().catch(() => {}));
    return u;
  }, []);

  const create = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        name: form.name.trim(),
        email: form.email.trim(),
        phone: form.phone.trim(),
        plate: form.plate.trim().toUpperCase(),
        vehicle_type: form.vehicle_type,
        vehicle_brand: form.vehicle_brand.trim(),
        vehicle_model:
          form.vehicle_type === 'carro'
            ? `${form.vehicle_model.trim()} ${form.vehicle_year}`.trim()
            : form.vehicle_model.trim(),
        ...(form.vehicle_type === 'carro'
          ? {
              car_subtype: form.car_subtype,
              plate_type: form.plate_type,
              vehicle_year: Number(form.vehicle_year),
            }
          : {}),
        status: 'disponible',
        approval_status: 'aprobado',
      };
      await base44.entities.Mobile.create(payload);
      setForm({
        name: '',
        email: '',
        phone: '',
        plate: '',
        vehicle_type: 'moto',
        car_subtype: 'particular',
        plate_type: 'amarilla',
        vehicle_brand: '',
        vehicle_model: '',
        vehicle_year: String(CURRENT_YEAR),
      });
      setShowForm(false);
      load();
    } catch (err) {
      console.error('Create mobile error:', err);
    }
  };

  const approveDriver = async (m) => {
    setActionBusyId(m.id);
    try {
      await base44.entities.Mobile.update(m.id, {
        approval_status: 'aprobado',
        approval_notes: '',
        approved_at: new Date().toISOString(),
        status: 'disponible',
        blocked: false,
      });
      // Cerrar incidencias abiertas de activación de este conductor
      try {
        const inc = await base44.entities.Incidence.filter({
          related_mobile_id: m.id,
          category: 'conductor',
          status: { $in: ['abierta', 'en_proceso'] },
        });
        const list = Array.isArray(inc) ? inc : inc?.items || [];
        await Promise.all(
          list.map((it) =>
            base44.entities.Incidence.update(it.id, {
              status: 'resuelta',
              resolution: 'Documentos verificados y conductor activado por la Central.',
              resolved_at: new Date().toISOString(),
            })
          )
        );
      } catch {}
      toast({
        title: 'Conductor activado',
        description: `${m.name} ya tiene sus documentos aprobados y su cuenta activa para trabajar.`,
      });
      load();
    } catch (err) {
      toast({
        title: 'Error al activar conductor',
        description: err.message || 'Intenta nuevamente.',
        variant: 'destructive',
      });
    } finally {
      setActionBusyId(null);
    }
  };

  const rejectDriver = async (m) => {
    const note = rejectReason.trim() || 'Por favor revisa y vuelve a subir tus documentos de forma clara y legible.';
    setActionBusyId(m.id);
    try {
      await base44.entities.Mobile.update(m.id, {
        approval_status: 'rechazado',
        approval_notes: note,
        status: 'offline',
      });
      setRejectingId(null);
      setRejectReason('');
      toast({
        title: 'Documentos observados / rechazados',
        description: `Se notificó a ${m.name} el motivo para que corrija sus documentos.`,
      });
      load();
    } catch (err) {
      toast({
        title: 'Error al guardar rechazo',
        description: err.message || 'Intenta nuevamente.',
        variant: 'destructive',
      });
    } finally {
      setActionBusyId(null);
    }
  };

  const pendingApprovalList = mobiles.filter((m) => m.approval_status === 'pendiente');
  const activeOrOtherList = mobiles.filter((m) => m.approval_status !== 'pendiente');

  return (
    <div className="space-y-4">
      <button
        onClick={() => setShowForm((f) => !f)}
        className="w-full h-11 rounded-xl bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-[#FFFFFF] font-semibold text-sm flex items-center justify-center gap-2"
      >
        {showForm ? <><X className="w-4 h-4" />Cancelar</> : <><Plus className="w-4 h-4" />Registrar móvil</>}
      </button>

      {showForm && (
        <form onSubmit={create} className="bg-[#0D0D0D] rounded-xl p-4 border border-[#1F1F1F] space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs text-[#8B8C94] mb-1 block">Nombre</label>
              <input required value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} className="h-10 w-full rounded-lg border border-[#262626] bg-[#0A0A0A] px-3 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#1E6BFF]/30" />
            </div>
            <div>
              <label className="text-xs text-[#8B8C94] mb-1 block">Placa</label>
              <input required value={form.plate} onChange={(e) => setForm((f) => ({ ...f, plate: e.target.value.toUpperCase() }))} className="h-10 w-full rounded-lg border border-[#262626] bg-[#0A0A0A] px-3 text-sm text-white uppercase focus:outline-none focus:ring-2 focus:ring-[#1E6BFF]/30" placeholder="ABC12D" />
            </div>
            <div>
              <label className="text-xs text-[#8B8C94] mb-1 block">Email (login)</label>
              <input type="email" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} className="h-10 w-full rounded-lg border border-[#262626] bg-[#0A0A0A] px-3 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#1E6BFF]/30" />
            </div>
            <div>
              <label className="text-xs text-[#8B8C94] mb-1 block">Teléfono</label>
              <input value={form.phone} onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))} className="h-10 w-full rounded-lg border border-[#262626] bg-[#0A0A0A] px-3 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#1E6BFF]/30" />
            </div>
          </div>

          <div>
            <label className="text-xs text-[#8B8C94] mb-1 block">Tipo de vehículo</label>
            <div className="grid grid-cols-2 gap-2">
              {[{ v: 'moto', label: 'Moto', icon: Bike }, { v: 'carro', label: 'Carro', icon: Car }].map((opt) => (
                <button
                  key={opt.v}
                  type="button"
                  onClick={() => setForm((f) => ({ ...f, vehicle_type: opt.v }))}
                  className={`flex items-center justify-center gap-1.5 h-10 rounded-lg border-2 text-sm ${
                    form.vehicle_type === opt.v ? 'border-[#1E6BFF] bg-[#1E6BFF]/10 text-[#1E6BFF]' : 'border-[#262626] text-[#8B8C94]'
                  }`}
                >
                  <opt.icon className="w-4 h-4" />
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {form.vehicle_type === 'carro' && (
            <div className="grid grid-cols-3 gap-2 pt-1">
              <div>
                <label className="text-xs text-[#8B8C94] mb-1 block">Modalidad</label>
                <select
                  value={form.car_subtype}
                  onChange={(e) => setForm((f) => ({ ...f, car_subtype: e.target.value }))}
                  className="h-10 w-full rounded-lg border border-[#262626] bg-[#0A0A0A] px-2 text-xs text-white"
                >
                  <option value="particular">Carro particular</option>
                  <option value="taxi">Taxi</option>
                </select>
              </div>
              <div>
                <label className="text-xs text-[#8B8C94] mb-1 block">Tipo de placa</label>
                <select
                  value={form.plate_type}
                  onChange={(e) => setForm((f) => ({ ...f, plate_type: e.target.value }))}
                  className="h-10 w-full rounded-lg border border-[#262626] bg-[#0A0A0A] px-2 text-xs text-white"
                >
                  <option value="amarilla">Placa amarilla</option>
                  <option value="blanca">Placa blanca</option>
                </select>
              </div>
              <div>
                <label className="text-xs text-[#8B8C94] mb-1 block">Modelo (2003+)</label>
                <select
                  value={form.vehicle_year}
                  onChange={(e) => setForm((f) => ({ ...f, vehicle_year: e.target.value }))}
                  className="h-10 w-full rounded-lg border border-[#262626] bg-[#0A0A0A] px-2 text-xs text-white"
                >
                  {CAR_YEARS.map((yr) => (
                    <option key={yr} value={yr}>{yr}</option>
                  ))}
                </select>
              </div>
            </div>
          )}

          <button type="submit" className="w-full h-10 rounded-lg bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-[#FFFFFF] font-semibold text-sm">
            Crear móvil
          </button>
        </form>
      )}

      {!loading && pendingApprovalList.length > 0 && (
        <div className="rounded-2xl border-2 border-amber-500/40 bg-amber-500/5 p-4 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-amber-400" />
              <div>
                <h3 className="text-sm font-extrabold text-white">
                  Conductores pendientes de activación ({pendingApprovalList.length})
                </h3>
                <p className="text-xs text-[#8B8C94]">
                  Verifica todos sus documentos (foto de perfil, cédula, tarjeta de propiedad, placa y SOAT/Tecnomecánica) antes de activarlos.
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            {pendingApprovalList.map((m) => {
              const isCar = m.vehicle_type === 'carro';
              const isBusy = actionBusyId === m.id;
              const isRejecting = rejectingId === m.id;
              return (
                <div key={m.id} className="bg-[#0D0D0D] rounded-xl p-4 border border-amber-500/30 space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <ResolvedAvatar
                        photo={m.photo_url || m.vehicle_photo}
                        name={m.name}
                        className="w-12 h-12 rounded-full bg-[#1A1A1A] border border-amber-400/50"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="font-bold text-sm text-white">{m.name}</p>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                            Pendiente de activar
                          </span>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-white/5 text-[#8B8C94] border border-white/10">
                            {isCar ? (m.car_subtype === 'taxi' ? 'Taxi' : 'Carro particular') : 'Moto'}
                          </span>
                        </div>
                        <p className="text-xs text-[#8B8C94] mt-0.5">
                          Cédula: <span className="text-white font-semibold">{m.cedula || '—'}</span> · Placa:{' '}
                          <span className="text-white font-semibold">{m.plate || '—'}</span> · Tel:{' '}
                          <span className="text-white font-semibold">{m.phone || '—'}</span>
                        </p>
                        <p className="text-[11px] text-[#8B8C94]">
                          Correo: {m.email || '—'} · Vehículo:{' '}
                          {[m.vehicle_brand, m.vehicle_model, m.vehicle_color].filter(Boolean).join(' ')}
                        </p>
                        {isCar && (m.soat_expiry || m.tecno_expiry) && (
                          <p className="text-[11px] text-[#00E5FF] mt-0.5">
                            {m.soat_expiry ? `SOAT vence: ${m.soat_expiry}` : ''}
                            {m.soat_expiry && m.tecno_expiry ? ' · ' : ''}
                            {m.tecno_expiry ? `Tecnomecánica vence: ${m.tecno_expiry}` : ''}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Documentos cargados siempre visibles para verificación de Central */}
                  <div className="pt-2 border-t border-[#1F1F1F] space-y-2">
                    <p className="text-[11px] font-semibold text-[#00E5FF] flex items-center gap-1.5">
                      <FileCheck className="w-3.5 h-3.5" />
                      Documentos adjuntos (toca cada foto para abrir en tamaño completo)
                    </p>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      <DocThumb uri={m.photo_url} label="Foto de perfil" />
                      <DocThumb uri={m.verification_photo} label="Cédula" />
                      <DocThumb uri={m.tarjeta_photo} label="Tarjeta de propiedad" />
                      {m.soat_photo && <DocThumb uri={m.soat_photo} label="SOAT" />}
                      {m.tecno_photo && <DocThumb uri={m.tecno_photo} label="Tecnomecánica" />}
                      <DocThumb uri={m.vehicle_photo} label="Vehículo (placa)" />
                    </div>
                  </div>

                  {isRejecting ? (
                    <div className="space-y-2 pt-2 border-t border-[#1F1F1F]">
                      <input
                        value={rejectReason}
                        onChange={(e) => setRejectReason(e.target.value)}
                        placeholder="Indica el motivo por el cual rechazas o pides corregir los documentos..."
                        className="h-10 w-full rounded-lg border border-[#262626] bg-[#0A0A0A] px-3 text-xs text-white"
                      />
                      <div className="flex gap-2">
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => rejectDriver(m)}
                          className="flex-1 h-9 rounded-lg bg-red-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 disabled:opacity-50"
                        >
                          {isBusy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : 'Confirmar rechazo'}
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setRejectingId(null);
                            setRejectReason('');
                          }}
                          className="h-9 px-3 rounded-lg border border-[#262626] text-xs text-[#8B8C94]"
                        >
                          Cancelar
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col sm:flex-row gap-2 pt-2">
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => approveDriver(m)}
                        className="flex-1 h-10 rounded-xl bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md disabled:opacity-50"
                      >
                        {isBusy ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <>
                            <Check className="w-4 h-4" />
                            Verificar documentos y Activar conductor
                          </>
                        )}
                      </button>
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => {
                          setRejectingId(m.id);
                          setRejectReason(m.approval_notes || '');
                        }}
                        className="h-10 px-4 rounded-xl border border-red-500/40 text-red-400 hover:bg-red-500/10 font-bold text-xs flex items-center justify-center gap-1.5 disabled:opacity-50"
                      >
                        <AlertTriangle className="w-3.5 h-3.5" />
                        Rechazar / Pedir corrección
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-[#1E6BFF]" />
        </div>
      ) : (
        activeOrOtherList.map((m) => {
          const isCar = m.vehicle_type === 'carro';
          const VehicleIcon = isCar ? Car : Bike;
          const hasDocs = Boolean(
            m.verification_photo || m.tarjeta_photo || m.vehicle_photo || m.soat_photo || m.tecno_photo
          );
          const isExpanded = expandedDocsId === m.id;
          const isRejected = m.approval_status === 'rechazado';

          return (
            <div key={m.id} className="bg-[#0D0D0D] rounded-xl p-4 border border-[#1F1F1F] space-y-3">
              <div className="flex items-center gap-3">
                <ResolvedAvatar
                  photo={m.photo_url || m.vehicle_photo}
                  name={m.name}
                  className="w-11 h-11 rounded-full bg-[#1A1A1A]"
                  fallback={<VehicleIcon className="w-5 h-5 text-[#8B8C94]" />}
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-medium text-sm text-white truncate">{m.name}</p>
                    {isCar ? (
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                          m.car_subtype === 'taxi'
                            ? 'bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-500/40'
                            : 'bg-[#1E6BFF]/15 text-[#1E6BFF] dark:text-[#00E5FF] border-[#1E6BFF]/30'
                        }`}
                      >
                        {m.car_subtype === 'taxi' ? 'Taxi' : 'Carro particular'}
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-white/5 text-[#8B8C94] border border-white/10">
                        Moto
                      </span>
                    )}
                    {isCar && m.plate_type && (
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                          m.plate_type === 'blanca'
                            ? 'bg-slate-200 dark:bg-white/15 text-slate-800 dark:text-white border-slate-300 dark:border-white/40'
                            : 'bg-amber-500/15 text-amber-800 dark:text-amber-300 border-amber-500/40'
                        }`}
                      >
                        <span
                          className={`w-2.5 h-2 rounded-xs inline-block border ${
                            m.plate_type === 'blanca' ? 'bg-white border-slate-500' : 'bg-amber-400 border-amber-700'
                          }`}
                        />
                        Placa {m.plate_type}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-[#8B8C94] mt-0.5">
                    Placa: <span className="text-white font-semibold">{m.plate || '—'}</span>
                    {m.vehicle_brand || m.vehicle_model
                      ? ` · ${[m.vehicle_brand, m.vehicle_model].filter(Boolean).join(' ')}`
                      : ''}
                    {m.phone ? ` · ${m.phone}` : ''}
                  </p>
                  {isCar && (m.soat_expiry || m.tecno_expiry) && (
                    <p className="text-[11px] text-[#00E5FF] mt-0.5">
                      {m.soat_expiry ? `SOAT vence: ${m.soat_expiry}` : ''}
                      {m.soat_expiry && m.tecno_expiry ? ' · ' : ''}
                      {m.tecno_expiry ? `Tecnomecánica vence: ${m.tecno_expiry}` : ''}
                    </p>
                  )}
                  {m.current_lat != null && (
                    <p className="text-xs text-[#1E6BFF] flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3 h-3" />GPS activo
                    </p>
                  )}
                </div>
                <div className="flex flex-col items-end gap-1.5">
                  {isRejected ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-500/15 text-red-400 border border-red-500/30">
                      Documentos rechazados
                    </span>
                  ) : (
                    <StatusBadge status={m.status} />
                  )}
                  <div className="flex items-center gap-1.5">
                    {isRejected && (
                      <button
                        type="button"
                        disabled={actionBusyId === m.id}
                        onClick={() => approveDriver(m)}
                        className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-[#1E6BFF] text-white text-[10px] font-bold"
                      >
                        <Check className="w-3 h-3" />
                        Activar
                      </button>
                    )}
                    {hasDocs && (
                      <button
                        type="button"
                        onClick={() => setExpandedDocsId(isExpanded ? null : m.id)}
                        className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-[10px] font-semibold text-[#00E5FF]"
                      >
                        <Eye className="w-3 h-3" />
                        {isExpanded ? 'Ocultar docs' : 'Ver docs'}
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {isExpanded && hasDocs && (
                <div className="pt-2 border-t border-[#1F1F1F] space-y-2">
                  <p className="text-[11px] font-semibold text-[#8B8C94] flex items-center gap-1.5">
                    <FileCheck className="w-3.5 h-3.5 text-[#00E5FF]" />
                    Documentos y registro fotográfico verificado
                  </p>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    <DocThumb uri={m.verification_photo} label="Cédula" />
                    <DocThumb uri={m.tarjeta_photo} label="Tarjeta de propiedad" />
                    {m.soat_photo && <DocThumb uri={m.soat_photo} label="SOAT" />}
                    {m.tecno_photo && <DocThumb uri={m.tecno_photo} label="Tecnomecánica" />}
                    <DocThumb uri={m.vehicle_photo} label="Vehículo (placa)" />
                  </div>
                </div>
              )}
            </div>
          );
        })
      )}
    </div>
  );
}
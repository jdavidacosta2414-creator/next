import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Star, Loader2, Bike, Car, Award, Zap } from 'lucide-react';
import { DRIVER_TIERS, evaluateDriverTier } from '@/lib/driverTier';

export default function MobileRanking() {
  const [ranking, setRanking] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState('nivel');
  const [tierFilter, setTierFilter] = useState('todos');

  useEffect(() => {
    (async () => {
      const [services, mobiles, checkIns] = await Promise.all([
        base44.entities.Service.list('-created_date', 500),
        base44.entities.Mobile.list('-created_date', 200),
        base44.entities.DriverCheckIn.list('-date', 500).catch(() => []),
      ]);

      const checkInList = Array.isArray(checkIns) ? checkIns : checkIns?.items || [];

      const stats = mobiles.map((m) => {
        const ms = services.filter((s) => s.mobile_id === m.id);
        const completed = ms.filter((s) => s.status === 'finalizado');

        const uniqueDays = new Set();
        checkInList
          .filter((c) => c.mobile_id === m.id && c.date)
          .forEach((c) => uniqueDays.add(String(c.date).slice(0, 10)));
        completed.forEach((s) => {
          if (s.created_date) {
            uniqueDays.add(
              new Date(s.created_date).toLocaleDateString('en-CA', { timeZone: 'America/Bogota' })
            );
          }
        });

        const tierInfo = evaluateDriverTier({
          recentTrips: completed.length,
          recentDays: uniqueDays.size,
        });

        const rated = completed.filter((s) => s.rating != null && s.rating > 0);
        const avg =
          rated.length > 0
            ? rated.reduce((sum, x) => sum + x.rating, 0) / rated.length
            : 0;

        return {
          id: m.id,
          name: m.name,
          plate: m.plate,
          status: m.status,
          vehicle_type: m.vehicle_type,
          total: completed.length,
          recentTrips: completed.length,
          recentDays: uniqueDays.size,
          tier: tierInfo.current,
          rated: rated.length,
          avg: Math.round(avg * 10) / 10,
          cancelled: ms.filter((s) => s.status === 'cancelado').length,
        };
      });

      setRanking(stats);
      setLoading(false);
    })();
  }, []);

  const filtered = ranking.filter((m) =>
    tierFilter === 'todos' ? true : m.tier.id === tierFilter
  );

  const sorted = [...filtered].sort((a, b) => {
    if (sortBy === 'nivel') {
      if (b.tier.order !== a.tier.order) return b.tier.order - a.tier.order;
      return b.recentTrips - a.recentTrips;
    }
    if (sortBy === 'rating') return b.avg - a.avg;
    return b.total - a.total;
  });

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="w-6 h-6 animate-spin text-[#1E6BFF]" />
      </div>
    );
  }

  const medalColors = ['#f59e0b', '#9ca3af', '#cd7f32'];

  return (
    <div className="space-y-4">
      <div className="bg-card rounded-2xl p-4 border border-border space-y-3 shadow-xs">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-[#F59E0B]" />
            <h3 className="text-sm font-bold text-foreground">
              Escala de Niveles y Beneficios de Conductores
            </h3>
          </div>
          <span className="text-[11px] font-semibold px-2.5 py-0.5 rounded-full bg-[#1E6BFF]/15 text-[#1E6BFF]">
            Prioridad por nivel
          </span>
        </div>

        <p className="text-xs text-muted-foreground leading-relaxed">
          El sistema clasifica automáticamente a cada conductor según sus servicios completados y días conectados acumulados, otorgando prioridad progresiva en la recepción de nuevas solicitudes.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          {DRIVER_TIERS.slice()
            .reverse()
            .map((t) => {
              const countInTier = ranking.filter((m) => m.tier.id === t.id).length;
              return (
                <div
                  key={t.id}
                  className="rounded-xl p-3 bg-muted/50 border border-border flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between gap-1 mb-1">
                      <span className="inline-flex items-center gap-1.5 font-extrabold text-xs text-foreground">
                        <span
                          className="w-2.5 h-2.5 rounded-full"
                          style={{ backgroundColor: t.accentColor }}
                        />
                        Nivel {t.name}
                      </span>
                      <span className="text-[11px] font-bold text-primary flex items-center gap-1">
                        <Zap className="w-3 h-3" /> {t.priorityLabel}
                      </span>
                    </div>
                    <p className="text-[11px] text-muted-foreground">
                      {t.minTrips === 0
                        ? 'Base inicial desde el registro'
                        : `Requisito: ≥${t.minTrips} servicios y ≥${t.minDays} días`}
                    </p>
                  </div>
                  <div className="mt-2 pt-2 border-t border-border flex items-center justify-between text-[11px]">
                    <span className="text-muted-foreground">Conductores:</span>
                    <strong className="text-foreground">{countInTier}</strong>
                  </div>
                </div>
              );
            })}
        </div>
      </div>

      <div className="flex flex-wrap gap-1.5">
        {[
          { id: 'todos', label: `Todos (${ranking.length})` },
          { id: 'oro', label: 'Nivel Oro' },
          { id: 'plata', label: 'Nivel Plata' },
          { id: 'bronce', label: 'Nivel Bronce' },
        ].map((f) => (
          <button
            key={f.id}
            onClick={() => setTierFilter(f.id)}
            className={`h-8 px-3 rounded-lg text-xs font-semibold border transition ${
              tierFilter === f.id
                ? 'border-[#1E6BFF] bg-[#1E6BFF]/15 text-white'
                : 'border-[#262626] bg-[#0D0D0D] text-[#8B8C94]'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="flex gap-2">
        <button
          onClick={() => setSortBy('nivel')}
          className={`flex-1 h-9 rounded-lg text-xs font-medium border-2 transition ${
            sortBy === 'nivel'
              ? 'border-[#1E6BFF] bg-[#1E6BFF]/10 text-[#1E6BFF]'
              : 'border-[#262626] text-[#8B8C94]'
          }`}
        >
          Por nivel
        </button>
        <button
          onClick={() => setSortBy('rating')}
          className={`flex-1 h-9 rounded-lg text-xs font-medium border-2 transition ${
            sortBy === 'rating'
              ? 'border-[#1E6BFF] bg-[#1E6BFF]/10 text-[#1E6BFF]'
              : 'border-[#262626] text-[#8B8C94]'
          }`}
        >
          Por calificación
        </button>
        <button
          onClick={() => setSortBy('servicios')}
          className={`flex-1 h-9 rounded-lg text-xs font-medium border-2 transition ${
            sortBy === 'servicios'
              ? 'border-[#1E6BFF] bg-[#1E6BFF]/10 text-[#1E6BFF]'
              : 'border-[#262626] text-[#8B8C94]'
          }`}
        >
          Por servicios
        </button>
      </div>

      {sorted.length === 0 ? (
        <div className="text-center py-12">
          <Bike className="w-10 h-10 text-[#262626] mx-auto mb-2" />
          <p className="text-sm text-[#8B8C94]">No hay conductores en esta categoría</p>
        </div>
      ) : (
        sorted.map((m, i) => {
          const VehicleIcon = m.vehicle_type === 'carro' ? Car : Bike;
          return (
            <div
              key={m.id}
              className="bg-[#0D0D0D] rounded-xl p-4 border border-[#1F1F1F] flex items-center gap-3"
            >
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0"
                style={{
                  backgroundColor: i < 3 ? medalColors[i] + '20' : '#1A1A1A',
                  color: i < 3 ? medalColors[i] : '#8B8C94',
                }}
              >
                {i + 1}
              </div>
              <div className="w-11 h-11 rounded-full bg-[#1A1A1A] flex items-center justify-center flex-shrink-0">
                <VehicleIcon className="w-5 h-5 text-[#8B8C94]" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="font-semibold text-sm text-white truncate">{m.name}</p>
                  <span
                    className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold text-white"
                    style={{ backgroundColor: m.tier.accentColor }}
                  >
                    Nivel {m.tier.name}
                  </span>
                </div>
                <p className="text-xs text-[#8B8C94] mt-0.5">
                  Placa: {m.plate} · <strong className="text-white">{m.recentTrips} servicios</strong> / <strong className="text-white">{m.recentDays} días</strong>
                </p>
              </div>
              <div className="text-right flex-shrink-0">
                {sortBy === 'rating' ? (
                  <>
                    <div className="flex items-center gap-1 justify-end">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                      <span className="font-bold text-sm text-white">{m.avg.toFixed(1)}</span>
                    </div>
                    <p className="text-xs text-[#8B8C94]">{m.rated} calif.</p>
                  </>
                ) : (
                  <>
                    <p className="font-bold text-sm text-white">{m.total}</p>
                    <p className="text-xs text-[#8B8C94]">servicios</p>
                  </>
                )}
              </div>
            </div>
          );
        })
      )}
    </div>
  );
}
import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Phone, Loader2, Activity, Users, MapPin } from 'lucide-react';
import ResolvedAvatar, { preloadStorageUrls } from '@/components/shared/ResolvedAvatar';

const STATUS_LABELS = {
  pendiente: 'Buscando',
  asignado: 'Asignado',
  en_camino: 'En camino',
  recogida: 'En recorrido',
  finalizado: 'Finalizado',
  cancelado: 'Cancelado',
};

const STATUS_COLORS = {
  pendiente: 'text-[#FFB800]',
  asignado: 'text-[#00E5FF]',
  en_camino: 'text-[#1E6BFF]',
  recogida: 'text-[#1E6BFF]',
  finalizado: 'text-[#00E676]',
  cancelado: 'text-[#FF5252]',
};

function minsAgo(d) {
  return d ? Math.max(0, Math.floor((Date.now() - new Date(d).getTime()) / 60000)) : 0;
}

export default function RealtimePanel() {
  const [services, setServices] = useState([]);
  const [mobiles, setMobiles] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [svcs, mobs] = await Promise.all([
          base44.entities.Service.filter(
            { status: { $in: ['pendiente', 'asignado', 'en_camino', 'recogida'] } },
            '-created_date', 12
          ),
          base44.entities.Mobile.list(),
        ]);
        preloadStorageUrls(mobs.map((m) => m.photo_url || m.vehicle_photo));
        setServices(svcs);
        setMobiles(mobs.filter(m => m.status !== 'offline'));
      } catch (e) {
        console.error('RealtimePanel load error:', e);
      } finally {
        setLoading(false);
      }
    };
    load();
    const u1 = base44.entities.Service.subscribe(() => load().catch(() => {}));
    const u2 = base44.entities.Mobile.subscribe(() => load().catch(() => {}));
    return () => { u1(); u2(); };
  }, []);

  return (
    <div className="space-y-4 h-full overflow-y-auto thin-scroll">
      {/* Solicitudes en tiempo real */}
      <div className="bg-[#161C28] rounded-2xl border border-white/8 overflow-hidden">
        <div className="flex items-center gap-2 px-4 py-3 border-b border-white/8">
          <Activity className="w-4 h-4 text-[#00E5FF]" />
          <h3 className="text-sm font-semibold text-white">Solicitudes en tiempo real</h3>
          <span className="ml-auto text-xs text-[#8B95A8]">{services.length}</span>
        </div>
        <div className="max-h-72 overflow-y-auto thin-scroll divide-y divide-white/5">
          {loading && (
            <div className="p-4 text-center"><Loader2 className="w-5 h-5 animate-spin text-[#00E5FF] mx-auto" /></div>
          )}
          {!loading && services.length === 0 && (
            <p className="p-4 text-xs text-[#8B95A8] text-center">Sin solicitudes activas</p>
          )}
          {services.map(s => (
            <div key={s.id} className="px-4 py-2.5">
              <div className="flex items-center justify-between mb-1 gap-2">
                <span className="text-xs text-white font-medium truncate">{s.client_name || 'Cliente'}</span>
                <span className={`text-[10px] font-medium flex-shrink-0 ${STATUS_COLORS[s.status] || 'text-[#8B95A8]'}`}>
                  {STATUS_LABELS[s.status] || s.status}
                </span>
              </div>
              <p className="text-[11px] text-[#8B95A8] flex items-start gap-1 truncate">
                <MapPin className="w-3 h-3 flex-shrink-0 mt-0.5" />{s.pickup_address}
              </p>
              <div className="flex items-center justify-between mt-1 gap-2">
                <span className="text-[10px] text-[#5A6478]">Hace {minsAgo(s.created_date)} min</span>
                <div className="flex items-center gap-2">
                  {s.pickup_lat != null && s.pickup_lng != null && (
                    <a
                      href={`https://www.google.com/maps/search/?api=1&query=${parseFloat(s.pickup_lat)},${parseFloat(s.pickup_lng)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[10px] text-[#00E5FF] hover:underline font-medium"
                    >
                      GPS
                    </a>
                  )}
                  {s.fare != null && (
                    <span className="text-[10px] text-white font-medium">${s.fare.toLocaleString('es-CO')}</span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Conductores activos */}
      <div className="bg-[#161C28] rounded-2xl border border-white/8 overflow-hidden">
        <div className="flex items-center gap-2 px-4 py-3 border-b border-white/8">
          <Users className="w-4 h-4 text-[#00E5FF]" />
          <h3 className="text-sm font-semibold text-white">Conductores activos</h3>
          <span className="ml-auto text-xs text-[#8B95A8]">{mobiles.length}</span>
        </div>
        <div className="max-h-72 overflow-y-auto thin-scroll divide-y divide-white/5">
          {mobiles.slice(0, 10).map(m => (
            <div key={m.id} className="px-4 py-2.5 flex items-center gap-3">
              <ResolvedAvatar
                photo={m.photo_url || m.vehicle_photo}
                name={m.name}
                className="w-8 h-8 rounded-full bg-gradient-to-br from-[#1E6BFF] to-[#00E5FF] text-white text-xs font-bold"
              />
              <div className="flex-1 min-w-0">
                <p className="text-xs text-white font-medium truncate">{m.name}</p>
                <p className="text-[10px] text-[#8B95A8]">
                  {m.plate} ·{' '}
                  {m.vehicle_type === 'carro'
                    ? `${m.car_subtype === 'taxi' ? 'Taxi' : 'Carro particular'}${m.plate_type ? ` (Placa ${m.plate_type})` : ''}`
                    : 'Moto'}
                </p>
              </div>
              <span className={`text-[10px] font-medium flex-shrink-0 ${m.status === 'disponible' ? 'text-[#00E676]' : 'text-[#FFB800]'}`}>
                {m.status === 'disponible' ? 'Libre' : 'Ocupado'}
              </span>
              {m.phone && (
                <a href={`tel:${m.phone}`} className="w-7 h-7 rounded-full bg-[#1E6BFF]/15 flex items-center justify-center text-[#1E6BFF] flex-shrink-0">
                  <Phone className="w-3.5 h-3.5" />
                </a>
              )}
            </div>
          ))}
          {mobiles.length === 0 && !loading && (
            <p className="p-4 text-xs text-[#8B95A8] text-center">Sin conductores activos</p>
          )}
        </div>
      </div>
    </div>
  );
}
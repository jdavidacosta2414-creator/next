import React, { useState, useEffect, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import {
  ResponsiveContainer, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend,
} from 'recharts';
import { TrendingUp, Wallet, CheckCircle, Receipt, Loader2 } from 'lucide-react';

const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');
const dayKey = (d) => new Date(d).toISOString().split('T')[0];
const dayLabel = (key) => {
  const [y, m, d] = key.split('-');
  const dt = new Date(Number(y), Number(m) - 1, Number(d));
  return dt.toLocaleDateString('es-CO', { day: '2-digit', month: 'short' }, { timeZone: 'America/Bogota' });
};

const COLORS = {
  primary: '#1E6BFF',
  accent: '#00E5FF',
  success: '#00E676',
  warning: '#FFB800',
  danger: '#FF5252',
  purple: '#A78BFA',
};

const tooltipStyle = {
  backgroundColor: '#0B111A',
  border: '1px solid rgba(255,255,255,0.1)',
  borderRadius: '0.75rem',
  color: '#fff',
  fontSize: '12px',
};

function Kpi({ icon: Icon, value, label, accent }) {
  return (
    <div className="bg-[#161C28] rounded-2xl p-4 border border-white/8">
      <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-3 ${accent}`}>
        <Icon className="w-5 h-5" />
      </div>
      <p className="text-2xl font-bold text-white leading-none">{value}</p>
      <p className="text-xs text-[#8B95A8] mt-1">{label}</p>
    </div>
  );
}

function ChartCard({ title, children, subtitle }) {
  return (
    <div className="bg-[#161C28] rounded-2xl border border-white/8 p-4">
      <div className="mb-3">
        <h3 className="text-sm font-semibold text-white">{title}</h3>
        {subtitle && <p className="text-[11px] text-[#8B95A8]">{subtitle}</p>}
      </div>
      {children}
    </div>
  );
}

export default function ReportsView() {
  const [services, setServices] = useState([]);
  const [mobiles, setMobiles] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [svcs, mobs] = await Promise.all([
          base44.entities.Service.list('-created_date', 300),
          base44.entities.Mobile.list(),
        ]);
        setServices(svcs);
        setMobiles(mobs);
      } catch (e) {
        console.error('Reports load error:', e);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const data = useMemo(() => {
    const today = new Date();
    const days = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(today.getDate() - i);
      days.push(dayKey(d));
    }

    const byDay = days.map(key => {
      const daySvcs = services.filter(s => s.created_date?.startsWith(key));
      const finalized = daySvcs.filter(s => s.status === 'finalizado');
      const ingresos = finalized.reduce((s, x) => s + (x.collected_amount || x.fare || 5000), 0);
      return {
        key,
        label: dayLabel(key),
        servicios: daySvcs.length,
        finalizados: finalized.length,
        ingresos,
      };
    });

    const last7 = services.filter(s => {
      const k = s.created_date?.slice(0, 10);
      return k && days.includes(k);
    });
    const finalized7 = last7.filter(s => s.status === 'finalizado');
    const ingresos7 = finalized7.reduce((s, x) => s + (x.collected_amount || x.fare || 5000), 0);

    const tipoCount = {
      transporte: last7.filter(s => s.service_type !== 'mensajeria').length,
      mensajeria: last7.filter(s => s.service_type === 'mensajeria').length,
    };

    const estadoCount = {
      finalizado: last7.filter(s => s.status === 'finalizado').length,
      activo: last7.filter(s => ['asignado', 'en_camino', 'recogida'].includes(s.status)).length,
      pendiente: last7.filter(s => s.status === 'pendiente').length,
      cancelado: last7.filter(s => s.status === 'cancelado').length,
    };

    const driverStats = {};
    finalized7.forEach(s => {
      const id = s.mobile_id;
      if (!id) return;
      driverStats[id] = driverStats[id] || { name: s.mobile_name || 'Sin nombre', count: 0, ingresos: 0 };
      driverStats[id].count += 1;
      driverStats[id].ingresos += s.collected_amount || s.fare || 5000;
    });
    const topDrivers = Object.values(driverStats)
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    return {
      byDay,
      kpis: {
        total: last7.length,
        ingresos: ingresos7,
        finalizados: finalized7.length,
        ticket: finalized7.length ? Math.round(ingresos7 / finalized7.length) : 0,
      },
      tipoCount,
      estadoCount,
      topDrivers,
    };
  }, [services]);

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="w-7 h-7 animate-spin text-[#00E5FF]" />
      </div>
    );
  }

  const tipoData = [
    { name: 'Transporte', value: data.tipoCount.transporte, color: COLORS.primary },
    { name: 'Mensajería', value: data.tipoCount.mensajeria, color: COLORS.accent },
  ].filter(d => d.value > 0);

  const estadoData = [
    { name: 'Finalizados', value: data.estadoCount.finalizado, color: COLORS.success },
    { name: 'Activos', value: data.estadoCount.activo, color: COLORS.primary },
    { name: 'Pendientes', value: data.estadoCount.pendiente, color: COLORS.warning },
    { name: 'Cancelados', value: data.estadoCount.cancelado, color: COLORS.danger },
  ].filter(d => d.value > 0);

  return (
    <div className="space-y-4">
      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Kpi icon={TrendingUp} value={data.kpis.total} label="Servicios (7 días)" accent="bg-[#1E6BFF]/15 text-[#1E6BFF]" />
        <Kpi icon={Wallet} value={fmtCOP(data.kpis.ingresos)} label="Ingresos (7 días)" accent="bg-[#00E5FF]/15 text-[#00E5FF]" />
        <Kpi icon={CheckCircle} value={data.kpis.finalizados} label="Finalizados" accent="bg-[#00E676]/15 text-[#00E676]" />
        <Kpi icon={Receipt} value={fmtCOP(data.kpis.ticket)} label="Ticket promedio" accent="bg-[#FFB800]/15 text-[#FFB800]" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Servicios por día */}
        <div className="lg:col-span-2">
          <ChartCard title="Servicios por día" subtitle="Últimos 7 días">
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data.byDay} margin={{ top: 5, right: 10, left: -15, bottom: 0 }}>
                  <defs>
                    <linearGradient id="gradServ" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={COLORS.primary} stopOpacity={0.5} />
                      <stop offset="100%" stopColor={COLORS.primary} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                  <XAxis dataKey="label" stroke="#8B95A8" fontSize={11} tickLine={false} axisLine={false} />
                  <YAxis stroke="#8B95A8" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
                  <Tooltip contentStyle={tooltipStyle} />
                  <Area type="monotone" dataKey="servicios" name="Servicios" stroke={COLORS.primary} strokeWidth={2} fill="url(#gradServ)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>
        </div>

        {/* Distribución por tipo */}
        <ChartCard title="Por tipo de servicio" subtitle="Últimos 7 días">
          <div className="h-64">
            {tipoData.length === 0 ? (
              <p className="text-xs text-[#8B95A8] text-center pt-20">Sin datos</p>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={tipoData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={50} outerRadius={75} paddingAngle={3}>
                    {tipoData.map((d, i) => <Cell key={i} fill={d.color} />)}
                  </Pie>
                  <Tooltip contentStyle={tooltipStyle} />
                  <Legend wrapperStyle={{ fontSize: '11px', color: '#8B95A8' }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </ChartCard>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Ingresos por día */}
        <div className="lg:col-span-2">
          <ChartCard title="Ingresos por día" subtitle="Servicios finalizados · Últimos 7 días">
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data.byDay} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                  <XAxis dataKey="label" stroke="#8B95A8" fontSize={11} tickLine={false} axisLine={false} />
                  <YAxis stroke="#8B95A8" fontSize={11} tickLine={false} axisLine={false} tickFormatter={(v) => (v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v)} />
                  <Tooltip contentStyle={tooltipStyle} formatter={(v) => fmtCOP(v)} />
                  <Bar dataKey="ingresos" name="Ingresos" fill={COLORS.accent} radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>
        </div>

        {/* Distribución por estado */}
        <ChartCard title="Por estado" subtitle="Últimos 7 días">
          <div className="h-64">
            {estadoData.length === 0 ? (
              <p className="text-xs text-[#8B95A8] text-center pt-20">Sin datos</p>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={estadoData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={50} outerRadius={75} paddingAngle={3}>
                    {estadoData.map((d, i) => <Cell key={i} fill={d.color} />)}
                  </Pie>
                  <Tooltip contentStyle={tooltipStyle} />
                  <Legend wrapperStyle={{ fontSize: '11px', color: '#8B95A8' }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </ChartCard>
      </div>

      {/* Top conductores */}
      <ChartCard title="Top conductores" subtitle="Por servicios finalizados · Últimos 7 días">
        <div className="h-64">
          {data.topDrivers.length === 0 ? (
            <p className="text-xs text-[#8B95A8] text-center pt-20">Sin servicios finalizados en el período</p>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.topDrivers} layout="vertical" margin={{ top: 5, right: 20, left: 20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" horizontal={false} />
                <XAxis type="number" stroke="#8B95A8" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
                <YAxis type="category" dataKey="name" stroke="#8B95A8" fontSize={11} tickLine={false} axisLine={false} width={110} />
                <Tooltip contentStyle={tooltipStyle} />
                <Bar dataKey="count" name="Servicios" fill={COLORS.purple} radius={[0, 6, 6, 0]} barSize={22} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </ChartCard>
    </div>
  );
}
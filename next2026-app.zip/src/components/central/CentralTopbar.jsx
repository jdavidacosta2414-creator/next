import React, { useState, useEffect } from 'react';
import { Search, LogOut } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import ThemeToggle from '@/components/ThemeToggle';
import CentralNotificationsBell from '@/components/central/CentralNotificationsBell';
import ResolvedAvatar from '@/components/shared/ResolvedAvatar';

export default function CentralTopbar({ title, onOpenIncidencias }) {
  const { user, logout } = useAuth();
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(t);
  }, []);

  const time = now.toLocaleTimeString('es-CO', {
    hour: '2-digit', minute: '2-digit', hour12: true, timeZone: 'America/Bogota',
  });
  const date = now.toLocaleDateString('es-CO', {
    day: '2-digit', month: 'short', year: 'numeric', timeZone: 'America/Bogota',
  });
  const initial = (user?.full_name || user?.email || 'C').charAt(0).toUpperCase();

  return (
    <header className="sticky top-0 z-20 h-16 bg-[#0B111A]/90 backdrop-blur-lg border-b border-white/8 flex items-center gap-3 px-4 lg:px-6">
      <div className="hidden lg:block flex-shrink-0">
        <h2 className="text-white font-semibold text-base">{title}</h2>
      </div>

      <div className="flex-1 max-w-md hidden md:block">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5A6478]" />
          <input
            placeholder="Buscar servicios, móviles..."
            className="w-full h-10 rounded-xl bg-[#161C28] border border-white/8 pl-10 pr-4 text-sm text-white placeholder:text-[#5A6478] outline-none focus:border-[#00E5FF]/40 transition-colors"
          />
        </div>
      </div>
      <div className="flex-1 lg:hidden" />

      <div className="hidden lg:flex items-center gap-1.5 text-xs text-[#8B95A8] flex-shrink-0">
        <span className="w-1.5 h-1.5 rounded-full bg-[#00E676]" /> En línea
      </div>

      <div className="hidden sm:flex flex-col items-end leading-tight flex-shrink-0">
        <span className="text-sm text-white font-medium">{time}</span>
        <span className="text-[10px] text-[#5A6478] capitalize">{date}</span>
      </div>

      <CentralNotificationsBell onOpenIncidencias={onOpenIncidencias} />

      <ThemeToggle />

      <div className="flex items-center gap-2 pl-2 border-l border-white/8 flex-shrink-0">
        <ResolvedAvatar
          photo={user?.photo_url}
          name={user?.full_name || user?.email || 'C'}
          className="w-9 h-9 rounded-full bg-gradient-to-br from-[#1E6BFF] to-[#00E5FF] text-white font-bold text-sm"
        />
        <div className="hidden sm:block leading-tight">
          <p className="text-sm text-white font-medium">{user?.full_name || 'Central Operativa'}</p>
          <p className="text-[10px] text-[#5A6478]">Administrador</p>
        </div>
      </div>

      <button
        onClick={() => logout()}
        className="w-9 h-9 rounded-lg bg-white/5 flex items-center justify-center text-[#8B95A8] hover:text-red-400 hover:bg-red-500/10 transition-colors flex-shrink-0"
        aria-label="Cerrar sesión"
      >
        <LogOut className="w-4 h-4" />
      </button>
    </header>
  );
}
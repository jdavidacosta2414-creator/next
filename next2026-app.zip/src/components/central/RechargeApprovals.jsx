import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { toast } from '@/components/ui/use-toast';
import { safeInvoke } from '@/lib/api-helpers';
import { PAYMENT_LABELS } from '@/lib/recharge';
import { Check, X, Loader2, ImageOff, Clock } from 'lucide-react';
import { getCachedSignedUrl, resolveStorageUrl } from '@/components/shared/ResolvedAvatar';

const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');

function fmtDate(d) {
  if (!d) return '';
  return new Date(d).toLocaleString('es-CO', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
}

export default function RechargeApprovals() {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionId, setActionId] = useState(null);
  const [rejectId, setRejectId] = useState(null);
  const [photos, setPhotos] = useState({});

  const load = async () => {
    try {
      const list = await base44.entities.RechargeRequest.list('-created_date', 50);
      setRequests(list);
      // Generar URLs firmadas usando caché instantáneo para ver los comprobantes privados.
      list.forEach(async (r) => {
        if (!r.transfer_photo) return;
        const cached = getCachedSignedUrl(r.transfer_photo);
        if (cached) {
          setPhotos((p) => ({ ...p, [r.id]: cached }));
          return;
        }
        const resolved = await resolveStorageUrl(r.transfer_photo);
        if (resolved) setPhotos((p) => ({ ...p, [r.id]: resolved }));
      });
    } catch (e) {
      console.error('Recharge load error:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    const unsub = base44.entities.RechargeRequest.subscribe(() => load().catch(() => {}));
    return unsub;
  }, []);

  const approve = async (id) => {
    setActionId(id);
    try {
      const res = await safeInvoke('reviewRecharge', { request_id: id, action: 'aprobar' });
      toast({ title: 'Recarga aprobada', description: `Nuevo saldo: ${fmtCOP(res.new_balance)}` });
      load();
    } catch (e) {
      toast({ title: 'Error al aprobar', description: e.message || 'Intenta de nuevo', variant: 'destructive' });
    } finally {
      setActionId(null);
    }
  };

  const reject = async (id, reason) => {
    setActionId(id);
    try {
      await safeInvoke('reviewRecharge', { request_id: id, action: 'rechazar', reject_reason: reason });
      toast({ title: 'Solicitud rechazada' });
      setRejectId(null);
      load();
    } catch (e) {
      toast({ title: 'Error al rechazar', description: e.message || 'Intenta de nuevo', variant: 'destructive' });
    } finally {
      setActionId(null);
    }
  };

  const pending = requests.filter((r) => r.status === 'pendiente');
  const reviewed = requests.filter((r) => r.status !== 'pendiente').slice(0, 10);

  if (loading) {
    return <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-[#00E5FF]" /></div>;
  }

  return (
    <div className="space-y-4">
      <div className="bg-[#00E5FF]/10 rounded-xl p-3 border border-[#00E5FF]/20">
        <p className="text-sm text-white font-medium">Verificación de recargas</p>
        <p className="text-xs text-[#8B95A8] mt-1">Revisa los comprobantes de transferencia de los conductores y aprueba el pase diario.</p>
      </div>

      {pending.length === 0 && (
        <div className="text-center py-10">
          <Clock className="w-10 h-10 text-[#00E5FF]/30 mx-auto mb-2" />
          <p className="text-sm text-[#8B95A8]">No hay recargas pendientes</p>
        </div>
      )}

      {pending.map((r) => (
        <div key={r.id} className="bg-[#0D0D0D] rounded-xl p-4 border border-[#1F1F1F]">
          <div className="flex items-center justify-between mb-2">
            <div>
              <p className="font-medium text-sm text-white">{r.mobile_name || 'Conductor'}</p>
              <p className="text-xs text-[#8B8C94]">{fmtDate(r.created_date)}</p>
            </div>
            <div className="text-right">
              <p className="text-lg font-bold text-[#1E6BFF]">{fmtCOP(r.amount)}</p>
              <p className="text-xs text-[#8B8C94]">{PAYMENT_LABELS[r.payment_method] || r.payment_method}</p>
            </div>
          </div>

          <p className="text-xs text-[#8B8C94] mb-2">Comprobante de transferencia:</p>
          <div className="rounded-lg overflow-hidden border border-[#1F1F1F] mb-3 bg-[#0A0A0A]">
            {photos[r.id] ? (
              <img src={photos[r.id]} alt="Comprobante" className="w-full max-h-64 object-contain" />
            ) : (
              <div className="h-32 flex items-center justify-center text-[#5A6478]"><ImageOff className="w-8 h-8" /></div>
            )}
          </div>

          {r.ai_status && r.ai_status !== 'pendiente' && (
            <div className={`rounded-lg p-2.5 mb-3 text-xs border ${r.ai_status === 'preaprobada' ? 'bg-emerald-500/10 border-emerald-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
              <p className={`font-bold flex items-center gap-1.5 ${r.ai_status === 'preaprobada' ? 'text-emerald-300' : 'text-red-300'}`}>
                {r.ai_status === 'preaprobada' ? 'IA: preaprobada' : 'IA: sospechosa, revisar'}
              </p>
              <div className="mt-1 space-y-0.5 text-[#8B8C94]">
                {r.ai_amount != null && <p>Monto detectado: {fmtCOP(r.ai_amount)}</p>}
                {r.ai_reference && <p>Referencia: {r.ai_reference}</p>}
                {r.ai_entity && <p>Entidad: {r.ai_entity}</p>}
                {r.ai_date && <p>Fecha: {r.ai_date}</p>}
                {r.ai_notes && <p className="text-[#A0A8B8] mt-1">{r.ai_notes}</p>}
              </div>
            </div>
          )}

          {rejectId === r.id ? (
            <div className="space-y-2">
              <input
                autoFocus
                placeholder="Motivo del rechazo (opcional)"
                className="w-full h-9 rounded-lg border border-[#262626] bg-[#0A0A0A] px-3 text-sm text-white"
                id={`reject-${r.id}`}
              />
              <div className="flex gap-2">
                <button onClick={() => setRejectId(null)} className="h-9 flex-1 rounded-lg border border-[#262626] text-[#8B8C94] text-sm">Cancelar</button>
                <button
                  disabled={actionId === r.id}
                  onClick={() => reject(r.id, document.getElementById(`reject-${r.id}`).value)}
                  className="h-9 flex-1 rounded-lg bg-red-500 hover:bg-red-500/90 text-white text-sm font-medium disabled:opacity-50"
                >
                  {actionId === r.id ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'Confirmar rechazo'}
                </button>
              </div>
            </div>
          ) : (
            <div className="flex gap-2">
              <button
                onClick={() => setRejectId(r.id)}
                disabled={actionId === r.id}
                className="h-9 flex-1 rounded-lg border border-red-500/30 text-red-400 text-sm font-medium hover:bg-red-500/10 disabled:opacity-50 flex items-center justify-center gap-1"
              >
                <X className="w-4 h-4" />Rechazar
              </button>
              <button
                onClick={() => approve(r.id)}
                disabled={actionId === r.id}
                className="h-9 flex-1 rounded-lg bg-[#1E6BFF] hover:bg-[#1E6BFF]/90 text-white text-sm font-medium disabled:opacity-50 flex items-center justify-center gap-1"
              >
                {actionId === r.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Check className="w-4 h-4" />Aprobar</>}
              </button>
            </div>
          )}
        </div>
      ))}

      {reviewed.length > 0 && (
        <>
          <h4 className="text-sm font-semibold text-[#8B8C94] pt-2">Revisadas recientemente</h4>
          {reviewed.map((r) => (
            <div key={r.id} className="bg-[#0D0D0D] rounded-xl p-3 border border-[#1F1F1F] flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-white">{r.mobile_name}</p>
                <p className="text-xs text-[#8B8C94]">{fmtCOP(r.amount)} · {PAYMENT_LABELS[r.payment_method] || r.payment_method} · {fmtDate(r.verified_at || r.created_date)}</p>
                {r.status === 'rechazada' && r.reject_reason && <p className="text-xs text-red-400 mt-0.5">Rechazada: {r.reject_reason}</p>}
              </div>
              <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${r.status === 'aprobada' ? 'bg-[#1E6BFF]/15 text-[#1E6BFF]' : 'bg-red-500/15 text-red-400'}`}>
                {r.status === 'aprobada' ? 'Aprobada' : 'Rechazada'}
              </span>
            </div>
          ))}
        </>
      )}
    </div>
  );
}
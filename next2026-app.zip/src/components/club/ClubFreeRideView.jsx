import React from 'react';
import { Bike, PartyPopper, Ticket } from 'lucide-react';
import ClubSubHeader from '@/components/club/ClubSubHeader';
import { fmtCOP } from '@/lib/club';

export default function ClubFreeRideView({ account, config, freeRides = [], onBack, onRequestRide }) {
  const every = Number(config?.free_ride_every || 8);
  const cycle = Math.min(every, Number(account?.free_ride_cycle_count || 0));
  const left = every - cycle;
  const max = Number(config?.free_ride_max_value || 7000);

  return (
    <div className="min-h-full bg-background pb-28">
      <ClubSubHeader title="VIAJE GRATIS" subtitle={`Cada ${every} carreras completadas`} onBack={onBack} />
      <div className="p-4 space-y-4">
        <div className="rounded-3xl bg-card border border-border p-5 text-center">
          <p className="text-sm font-bold text-muted-foreground">{cycle} de {every} carreras completadas</p>
          <div className="mt-3 grid grid-cols-8 gap-1.5">
            {Array.from({ length: every }).map((_, i) => (
              <div key={i} className={`aspect-square rounded-xl flex items-center justify-center ${i < cycle ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>
                <Bike className="w-4 h-4" />
              </div>
            ))}
          </div>
          <p className="mt-4 font-extrabold text-foreground">
            {freeRides.length > 0 && cycle === 0
              ? '¡Felicidades! Has ganado un viaje gratis con NEXT'
              : `Te faltan ${left} ${left === 1 ? 'carrera' : 'carreras'} para conseguir tu próximo viaje gratis`}
          </p>
        </div>

        {freeRides.length > 0 ? (
          <div className="space-y-2.5">
            {freeRides.map((r) => (
              <div key={r.id} className="rounded-3xl bg-emerald-500/10 border border-emerald-500/30 p-4 flex items-center gap-3">
                <PartyPopper className="w-8 h-8 text-emerald-600 flex-shrink-0" />
                <div className="min-w-0 flex-1">
                  <p className="font-extrabold text-foreground text-sm">Viaje gratis disponible</p>
                  <p className="text-xs text-muted-foreground">Código {r.code} · cubre hasta {fmtCOP(r.max_value)}</p>
                </div>
              </div>
            ))}
            <button type="button" onClick={onRequestRide} className="w-full h-12 rounded-2xl bg-primary text-primary-foreground font-extrabold">
              Pedir mi moto gratis
            </button>
          </div>
        ) : (
          <div className="rounded-3xl bg-muted p-4 flex items-center gap-3">
            <Ticket className="w-6 h-6 text-muted-foreground flex-shrink-0" />
            <p className="text-xs text-muted-foreground">Aún no tienes viajes gratis. Sigue viajando con NEXT.</p>
          </div>
        )}

        <div className="text-xs text-muted-foreground space-y-1 px-1">
          <p>• Solo cuentan carreras de transporte completadas y pagadas.</p>
          <p>• Los domicilios y las carreras canceladas no cuentan.</p>
          <p>• Cubre un viaje en moto de máximo {fmtCOP(max)}. Si cuesta más, pagas la diferencia.</p>
          <p>• El viaje gratis no genera puntos y se usa una sola vez.</p>
        </div>
      </div>
    </div>
  );
}
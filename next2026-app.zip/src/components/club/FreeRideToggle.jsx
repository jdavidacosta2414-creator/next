import React from 'react';
import { Gift } from 'lucide-react';
import { Switch } from '@/components/ui/switch';

// Opción para usar un viaje gratis de NEXT CLUB al pedir una moto.
export default function FreeRideToggle({ available, checked, onChange, maxValue = 7000, fare = 0 }) {
  if (!available) return null;
  const toPay = Math.max(0, Number(fare || 0) - maxValue);
  return (
    <div className="rounded-2xl bg-emerald-500/10 border border-emerald-500/30 px-3.5 py-2.5 flex items-center gap-3">
      <Gift className="w-5 h-5 text-emerald-600 flex-shrink-0" />
      <div className="min-w-0 flex-1">
        <p className="text-xs font-extrabold text-foreground">Usar mi viaje gratis NEXT CLUB</p>
        <p className="text-[11px] text-muted-foreground">
          {checked
            ? toPay > 0
              ? `Cubre $${maxValue.toLocaleString('es-CO')}. Pagas la diferencia: $${toPay.toLocaleString('es-CO')}`
              : 'Este viaje no te cuesta nada'
            : `Tienes ${available} disponible${available > 1 ? 's' : ''}`}
        </p>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  );
}
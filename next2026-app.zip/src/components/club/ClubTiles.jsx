import React from 'react';
import { Gift, UtensilsCrossed, Bike, Users, History, Package } from 'lucide-react';

const MAIN = [
  { key: 'regalos', label: 'REGALOS', sub: 'Tecnología', Icon: Gift, cls: 'bg-primary/10 text-primary' },
  { key: 'comidas', label: 'COMIDAS', sub: 'Por puntos', Icon: UtensilsCrossed, cls: 'bg-amber-500/15 text-amber-600' },
  { key: 'viaje', label: 'VIAJE GRATIS', sub: 'Cada 8 carreras', Icon: Bike, cls: 'bg-emerald-500/15 text-emerald-600' },
  { key: 'invita', label: 'INVITA Y GANA', sub: 'Gana puntos', Icon: Users, cls: 'bg-violet-500/15 text-violet-600' },
];

export default function ClubTiles({ onOpen }) {
  return (
    <>
      <div className="grid grid-cols-2 gap-3">
        {MAIN.map(({ key, label, sub, Icon, cls }) => (
          <button
            key={key}
            type="button"
            onClick={() => onOpen(key)}
            className="rounded-3xl bg-card border border-border p-4 text-left active:scale-[0.98] transition-transform shadow-sm"
          >
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${cls}`}>
              <Icon className="w-6 h-6" />
            </div>
            <p className="mt-3 font-extrabold text-foreground text-sm">{label}</p>
            <p className="text-xs text-muted-foreground">{sub}</p>
          </button>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-3">
        <button type="button" onClick={() => onOpen('canjes')} className="h-12 rounded-2xl bg-muted flex items-center justify-center gap-2 font-bold text-sm text-foreground">
          <Package className="w-4 h-4" /> Mis canjes
        </button>
        <button type="button" onClick={() => onOpen('historial')} className="h-12 rounded-2xl bg-muted flex items-center justify-center gap-2 font-bold text-sm text-foreground">
          <History className="w-4 h-4" /> Historial
        </button>
      </div>
    </>
  );
}
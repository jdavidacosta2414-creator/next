import React, { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { base44 } from '@/api/base44Client';
import ClubSubHeader from '@/components/club/ClubSubHeader';
import { TX_LABELS, fmtPts } from '@/lib/club';

const PAGE = 30;

export default function ClubHistoryView({ userId, onBack }) {
  const [items, setItems] = useState(null);
  const [cursor, setCursor] = useState(null);
  const [hasMore, setHasMore] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);

  const load = async (next) => {
    const page = await base44.entities.ClubTransaction.filter(
      { user_id: userId },
      { sort: '-created_date', limit: PAGE, ...(next ? { cursor: next } : {}) }
    );
    setItems((prev) => [...(next ? prev || [] : []), ...(page.items || [])]);
    setCursor(page.next_cursor);
    setHasMore(page.has_more);
  };

  useEffect(() => { if (userId) load(); }, [userId]);

  return (
    <div className="min-h-full bg-background pb-28">
      <ClubSubHeader title="Historial de puntos" onBack={onBack} />
      <div className="p-4 space-y-2">
        {items === null ? (
          <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
        ) : items.length === 0 ? (
          <p className="text-center text-sm text-muted-foreground py-12">Aún no tienes movimientos. ¡Tu primera carrera suma puntos!</p>
        ) : (
          items.map((t) => (
            <div key={t.id} className="rounded-2xl bg-card border border-border p-3 flex items-center gap-3">
              <div className="min-w-0 flex-1">
                <p className="font-bold text-sm text-foreground">{TX_LABELS[t.type] || t.type}</p>
                <p className="text-[11px] text-muted-foreground truncate">{t.description}</p>
                <p className="text-[11px] text-muted-foreground">{format(new Date(t.created_date), "d MMM yyyy, h:mm a", { locale: es })}</p>
              </div>
              <div className="text-right flex-shrink-0">
                <p className={`font-black text-sm ${t.amount >= 0 ? 'text-emerald-600' : 'text-red-500'}`}>
                  {t.amount >= 0 ? '+' : ''}{fmtPts(t.amount)}
                </p>
                <p className="text-[10px] text-muted-foreground">Saldo {fmtPts(t.balance_after)}</p>
              </div>
            </div>
          ))
        )}
        {hasMore && (
          <button
            type="button"
            disabled={loadingMore}
            onClick={async () => { setLoadingMore(true); await load(cursor); setLoadingMore(false); }}
            className="w-full h-11 rounded-xl bg-muted font-bold text-sm text-foreground"
          >
            {loadingMore ? 'Cargando...' : 'Ver más'}
          </button>
        )}
      </div>
    </div>
  );
}
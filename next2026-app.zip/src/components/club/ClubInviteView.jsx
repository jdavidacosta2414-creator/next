import React, { useState } from 'react';
import { Share2, Copy, Loader2 } from 'lucide-react';
import ClubSubHeader from '@/components/club/ClubSubHeader';
import { invokeClub, fmtPts } from '@/lib/club';
import { useToast } from '@/components/ui/use-toast';

export default function ClubInviteView({ account, config, onBack, onChanged }) {
  const { toast } = useToast();
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const limit = Number(config?.referral_limit || 2);
  const used = Number(account?.referral_bonus_count || 0);
  const pts = Number(config?.referral_points_inviter || 100);
  const myCode = account?.referral_code || '';
  const link = `${window.location.origin}/vinculate/pasajero?ref=${myCode}`;

  const share = async () => {
    const text = `Únete a NEXT con mi código ${myCode} y gana ${fmtPts(config?.referral_points_new || 100)} puntos: ${link}`;
    if (navigator.share) {
      try { await navigator.share({ title: 'NEXT CLUB', text }); } catch {}
    } else {
      window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
    }
  };

  const copy = async () => {
    try { await navigator.clipboard.writeText(myCode); toast({ description: 'Código copiado' }); } catch {}
  };

  const apply = async () => {
    setError('');
    setLoading(true);
    try {
      const res = await invokeClub('clubApplyReferral', { code: code.trim().toUpperCase() });
      toast({ description: `¡Recibiste ${fmtPts(res.points)} puntos de bienvenida!` });
      onChanged?.();
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-full bg-background pb-28">
      <ClubSubHeader title="INVITA Y GANA" subtitle={`${fmtPts(pts)} puntos por amigo`} onBack={onBack} />
      <div className="p-4 space-y-4">
        <div className="rounded-3xl bg-card border border-border p-5 text-center">
          <p className="text-xs font-bold text-muted-foreground">Tu código personal</p>
          <p className="text-3xl font-black tracking-widest text-primary mt-1">{myCode}</p>
          <div className="grid grid-cols-2 gap-2.5 mt-4">
            <button type="button" onClick={copy} className="h-11 rounded-xl bg-muted font-bold text-sm text-foreground flex items-center justify-center gap-2"><Copy className="w-4 h-4" /> Copiar</button>
            <button type="button" onClick={share} className="h-11 rounded-xl bg-primary text-primary-foreground font-bold text-sm flex items-center justify-center gap-2"><Share2 className="w-4 h-4" /> Compartir</button>
          </div>
          <p className="text-xs text-muted-foreground mt-4">
            Referidos bonificados: <b className="text-foreground">{Math.min(used, limit)} de {limit}</b>
            {used >= limit ? ' · Puedes seguir invitando, pero ya no recibes más puntos.' : ''}
          </p>
        </div>

        {!account?.referred_by_code && (
          <div className="rounded-3xl bg-card border border-border p-4 space-y-2.5">
            <p className="font-extrabold text-sm text-foreground">¿Te invitó alguien?</p>
            <p className="text-xs text-muted-foreground">Escribe su código y recibe {fmtPts(config?.referral_points_new || 100)} puntos. Solo para cuentas nuevas y una sola vez.</p>
            <input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="Código de invitación" className="w-full h-12 rounded-xl bg-muted px-3 text-sm font-bold tracking-wider text-foreground outline-none" />
            {error && <p className="text-xs font-semibold text-red-500">{error}</p>}
            <button type="button" disabled={loading || code.trim().length < 4} onClick={apply} className="w-full h-11 rounded-xl bg-primary text-primary-foreground font-extrabold text-sm flex items-center justify-center gap-2 disabled:opacity-40">
              {loading && <Loader2 className="w-4 h-4 animate-spin" />} Usar código
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
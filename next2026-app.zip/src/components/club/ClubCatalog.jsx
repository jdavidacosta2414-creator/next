import React, { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import ClubSubHeader from '@/components/club/ClubSubHeader';
import ClubRewardCard from '@/components/club/ClubRewardCard';
import ClubRedeemSheet from '@/components/club/ClubRedeemSheet';
import { fmtPts } from '@/lib/club';

export default function ClubCatalog({ category, balance, enabled, defaultAddress, onBack, onRedeemed }) {
  const [items, setItems] = useState(null);
  const [selected, setSelected] = useState(null);
  const isFood = category === 'comida';

  const load = async () => {
    const list = await base44.entities.ClubReward.filter({ category, active: true }, 'sort_order', 50);
    setItems(Array.isArray(list) ? list : list?.items || []);
  };

  useEffect(() => { load(); }, [category]);

  return (
    <div className="min-h-full bg-background pb-28">
      <ClubSubHeader title={isFood ? 'COMIDAS POR PUNTOS' : 'REGALOS'} subtitle={`Tienes ${fmtPts(balance)} puntos`} onBack={onBack} />
      <div className="p-4 space-y-3">
        {isFood && (
          <p className="text-xs text-muted-foreground bg-muted rounded-2xl p-3">
            Reclamas la comida con tus puntos y NEXT te la lleva a domicilio. No pagas la comida otra vez. Solo dentro de la zona de cobertura.
          </p>
        )}
        {!enabled && <p className="text-sm font-bold text-amber-600 bg-amber-500/10 rounded-2xl p-3">Esta sección está pausada por ahora.</p>}
        {items === null ? (
          <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
        ) : items.length === 0 ? (
          <p className="text-center text-sm text-muted-foreground py-12">No hay productos disponibles en este momento.</p>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {items.map((r) => (
              <ClubRewardCard key={r.id} reward={r} balance={enabled ? balance : 0} onClaim={setSelected} />
            ))}
          </div>
        )}
      </div>
      {selected && (
        <ClubRedeemSheet
          reward={selected}
          defaultAddress={defaultAddress}
          onClose={() => setSelected(null)}
          onDone={() => { load(); onRedeemed?.(); }}
        />
      )}
    </div>
  );
}
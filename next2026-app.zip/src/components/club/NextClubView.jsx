import React, { useCallback, useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { useBackButton } from '@/hooks/useBackButton';
import ClubSubHeader from '@/components/club/ClubSubHeader';
import ClubHeader from '@/components/club/ClubHeader';
import ClubTiles from '@/components/club/ClubTiles';
import ClubCatalog from '@/components/club/ClubCatalog';
import ClubFreeRideView from '@/components/club/ClubFreeRideView';
import ClubInviteView from '@/components/club/ClubInviteView';
import ClubHistoryView from '@/components/club/ClubHistoryView';
import ClubMyRedemptions from '@/components/club/ClubMyRedemptions';
import { fetchClubSummary } from '@/lib/club';

export default function NextClubView({ onBack, defaultAddress, onRequestFreeRide }) {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [view, setView] = useState('home');

  const reload = useCallback(() => {
    setError('');
    return fetchClubSummary().then(setData).catch((e) => setError(e.message));
  }, []);

  useEffect(() => { reload(); }, [reload]);

  useBackButton(() => { setView('home'); return true; }, view !== 'home');

  const goHome = () => setView('home');
  const account = data?.account;
  const config = data?.config;

  if (view === 'regalos' || view === 'comidas') {
    const cat = view === 'comidas' ? 'comida' : 'regalo';
    return (
      <ClubCatalog
        category={cat}
        balance={account?.balance}
        enabled={cat === 'comida' ? config?.food_enabled : config?.gifts_enabled}
        defaultAddress={defaultAddress}
        onBack={goHome}
        onRedeemed={reload}
      />
    );
  }
  if (view === 'viaje') {
    return <ClubFreeRideView account={account} config={config} freeRides={data?.free_rides} onBack={goHome} onRequestRide={onRequestFreeRide} />;
  }
  if (view === 'invita') return <ClubInviteView account={account} config={config} onBack={goHome} onChanged={reload} />;
  if (view === 'historial') return <ClubHistoryView userId={account?.user_id} onBack={goHome} />;
  if (view === 'canjes') return <ClubMyRedemptions userId={account?.user_id} onBack={goHome} />;

  return (
    <div className="min-h-full bg-background pb-28">
      <ClubSubHeader title="NEXT CLUB" subtitle="Viaja, acumula puntos y disfruta tus recompensas" onBack={onBack} />
      <div className="p-4 space-y-4">
        {error ? (
          <div className="text-center py-12 space-y-3">
            <p className="text-sm text-muted-foreground">{error}</p>
            <button type="button" onClick={reload} className="h-11 px-6 rounded-xl bg-primary text-primary-foreground font-bold text-sm">Reintentar</button>
          </div>
        ) : !data ? (
          <div className="flex justify-center py-16"><Loader2 className="w-7 h-7 animate-spin text-primary" /></div>
        ) : (
          <>
            <ClubHeader account={account} config={config} />
            <ClubTiles onOpen={setView} />
            <p className="text-[11px] text-muted-foreground text-center px-4">
              Ganas {config.points_per_1000} puntos por cada $1.000 pagados en carreras y domicilios completados. Los puntos no son dinero, no se transfieren ni se retiran.
            </p>
          </>
        )}
      </div>
    </div>
  );
}
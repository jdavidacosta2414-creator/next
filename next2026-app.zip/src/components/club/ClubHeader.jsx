import React from 'react';
import { Copy, Bike, Star } from 'lucide-react';
import { fmtPts } from '@/lib/club';
import { useToast } from '@/components/ui/use-toast';

export default function ClubHeader({ account, config }) {
  const { toast } = useToast();
  const every = Number(config?.free_ride_every || 8);
  const cycle = Math.min(every, Number(account?.free_ride_cycle_count || 0));
  const pct = Math.round((cycle / every) * 100);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(account?.referral_code || '');
      toast({ description: 'Código copiado' });
    } catch {}
  };

  return (
    <div className="rounded-3xl p-5 text-white bg-gradient-to-br from-[#0B439C] via-[#1463FF] to-[#00B8D4] shadow-lg shadow-primary/30">
      <p className="text-xs font-bold uppercase tracking-widest text-white/80">Tus puntos</p>
      <p className="text-4xl font-black leading-tight">{fmtPts(account?.balance)}</p>

      <div className="mt-4 grid grid-cols-2 gap-2.5">
        <div className="rounded-2xl bg-white/15 p-3">
          <div className="flex items-center gap-1.5 text-white/80 text-[11px] font-bold">
            <Bike className="w-3.5 h-3.5" /> Carreras
          </div>
          <p className="text-xl font-extrabold">{fmtPts(account?.transport_rides_count)}</p>
        </div>
        <button type="button" onClick={copy} className="rounded-2xl bg-white/15 p-3 text-left active:scale-[0.98]">
          <div className="flex items-center gap-1.5 text-white/80 text-[11px] font-bold">
            <Copy className="w-3.5 h-3.5" /> Tu código
          </div>
          <p className="text-xl font-extrabold tracking-wider">{account?.referral_code || '—'}</p>
        </button>
      </div>

      <div className="mt-4">
        <div className="flex items-center justify-between text-xs font-bold">
          <span className="flex items-center gap-1"><Star className="w-3.5 h-3.5" /> Próximo viaje gratis</span>
          <span>{cycle} de {every}</span>
        </div>
        <div className="mt-1.5 h-2.5 rounded-full bg-white/20 overflow-hidden">
          <div className="h-full rounded-full bg-white" style={{ width: `${pct}%` }} />
        </div>
      </div>
    </div>
  );
}
import React, { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { base44 } from '@/api/base44Client';
import { Image } from '@/components/ui/image';
import ClubSubHeader from '@/components/club/ClubSubHeader';
import { fmtPts, statusLabel, STATUS_CLS } from '@/lib/club';

export default function ClubMyRedemptions({ userId, onBack }) {
  const [items, setItems] = useState(null);

  useEffect(() => {
    if (!userId) return;
    const load = () =>
      base44.entities.ClubRedemption.filter({ user_id: userId }, { sort: '-created_date', limit: 50 })
        .then((p) => setItems(p.items || []));
    load();
    return base44.entities.ClubRedemption.subscribe((ev) => { if (ev?.data?.user_id === userId) load(); });
  }, [userId]);

  return (
    <div className="min-h-full bg-background pb-28">
      <ClubSubHeader title="Mis canjes" subtitle="Regalos y pedidos de comida" onBack={onBack} />
      <div className="p-4 space-y-2.5">
        {items === null ? (
          <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
        ) : items.length === 0 ? (
          <p className="text-center text-sm text-muted-foreground py-12">Todavía no has reclamado recompensas.</p>
        ) : (
          items.map((r) => (
            <div key={r.id} className="rounded-2xl bg-card border border-border p-3 flex items-center gap-3">
              <Image src={r.reward_image} alt={r.reward_name} className="w-14 h-14 rounded-xl bg-muted flex-shrink-0" />
              <div className="min-w-0 flex-1">
                <p className="font-bold text-sm text-foreground truncate">{r.reward_name}</p>
                <p className="text-[11px] text-muted-foreground">Código {r.code} · {fmtPts(r.points)} pts</p>
                <p className="text-[11px] text-muted-foreground">{format(new Date(r.created_date), 'd MMM yyyy', { locale: es })}</p>
              </div>
              <span className={`text-[10px] font-extrabold px-2 py-1 rounded-full flex-shrink-0 ${STATUS_CLS[r.status] || ''}`}>
                {statusLabel(r.category, r.status)}
              </span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
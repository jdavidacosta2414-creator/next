import React from 'react';
import { ArrowLeft } from 'lucide-react';

export default function ClubSubHeader({ title, subtitle, onBack }) {
  return (
    <div className="sticky top-0 z-20 bg-background shadow-md border-b border-border px-4 py-3 flex items-center gap-3">
      <button
        type="button"
        onClick={onBack}
        className="w-10 h-10 rounded-full bg-muted flex items-center justify-center active:scale-95"
        aria-label="Volver"
      >
        <ArrowLeft className="w-5 h-5 text-foreground" />
      </button>
      <div className="min-w-0">
        <p className="font-extrabold text-foreground text-base leading-tight truncate">{title}</p>
        {subtitle && <p className="text-xs text-muted-foreground truncate">{subtitle}</p>}
      </div>
    </div>
  );
}
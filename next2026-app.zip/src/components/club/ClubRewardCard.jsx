import React from 'react';
import { Image } from '@/components/ui/image';
import { fmtPts } from '@/lib/club';

export default function ClubRewardCard({ reward, balance, onClaim }) {
  const soldOut = Number(reward.stock || 0) <= 0;
  const missing = Math.max(0, Number(reward.points_cost) - Number(balance || 0));
  return (
    <div className="rounded-3xl bg-card border border-border overflow-hidden shadow-sm flex flex-col">
      <Image src={reward.image_url} alt={reward.name} className="w-full h-32 bg-muted" />
      <div className="p-3 flex flex-col flex-1">
        <p className="font-extrabold text-sm text-foreground leading-tight">{reward.name}</p>
        <p className="text-[11px] text-muted-foreground mt-1 line-clamp-2 flex-1">{reward.description}</p>
        <p className="mt-2 text-primary font-black text-base">{fmtPts(reward.points_cost)} pts</p>
        <p className={`text-[11px] font-bold ${soldOut ? 'text-red-500' : 'text-emerald-600'}`}>
          {soldOut ? 'Agotado' : `Disponibles: ${reward.stock}`}
        </p>
        <button
          type="button"
          disabled={soldOut || missing > 0}
          onClick={() => onClaim(reward)}
          className="mt-2 h-10 rounded-xl bg-primary text-primary-foreground font-extrabold text-xs disabled:opacity-40"
        >
          {missing > 0 && !soldOut ? `Faltan ${fmtPts(missing)}` : 'RECLAMAR'}
        </button>
      </div>
    </div>
  );
}
import React, { useState } from 'react';
import { Loader2, X, CheckCircle2 } from 'lucide-react';
import { invokeClub, fmtPts } from '@/lib/club';
import { useBackButton } from '@/hooks/useBackButton';

export default function ClubRedeemSheet({ reward, defaultAddress, onClose, onDone }) {
  const [address, setAddress] = useState(defaultAddress || '');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [code, setCode] = useState('');
  const isFood = reward.category === 'comida';

  useBackButton(() => { onClose(); return true; }, true);

  const confirm = async () => {
    setError('');
    if (!address.trim()) { setError('Escribe la dirección de entrega'); return; }
    setLoading(true);
    try {
      const res = await invokeClub('clubRedeem', { reward_id: reward.id, delivery_address: address.trim(), notes });
      setCode(res.code);
      onDone?.();
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[2500] bg-black/50 flex items-end justify-center" onClick={onClose}>
      <div className="w-full max-w-md bg-card rounded-t-3xl p-5 space-y-3" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <p className="font-extrabold text-foreground">{code ? '¡Canje registrado!' : `Reclamar ${reward.name}`}</p>
          <button type="button" onClick={onClose} className="w-9 h-9 rounded-full bg-muted flex items-center justify-center"><X className="w-4 h-4" /></button>
        </div>
        {code ? (
          <div className="text-center py-3 space-y-2">
            <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
            <p className="text-sm text-muted-foreground">Tu código de canje es</p>
            <p className="text-2xl font-black tracking-widest text-primary">{code}</p>
            <p className="text-xs text-muted-foreground">
              {isFood ? 'NEXT coordina tu domicilio. No pagas nada por la comida.' : 'Te avisaremos cuando tu regalo vaya en camino.'}
            </p>
            <button type="button" onClick={onClose} className="w-full h-12 rounded-2xl bg-primary text-primary-foreground font-extrabold mt-2">Listo</button>
          </div>
        ) : (
          <>
            <p className="text-sm text-muted-foreground">Se descontarán <b className="text-foreground">{fmtPts(reward.points_cost)} puntos</b> de tu saldo.</p>
            <label className="text-xs font-bold text-muted-foreground">Dirección de entrega</label>
            <input value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Ej: Cra 9 # 16-20, barrio Centro" className="w-full h-12 rounded-xl bg-muted px-3 text-sm text-foreground outline-none" />
            <textarea value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={300} placeholder="Indicaciones (opcional)" className="w-full h-20 rounded-xl bg-muted p-3 text-sm text-foreground outline-none resize-none" />
            {error && <p className="text-xs font-semibold text-red-500">{error}</p>}
            <button type="button" disabled={loading} onClick={confirm} className="w-full h-12 rounded-2xl bg-primary text-primary-foreground font-extrabold flex items-center justify-center gap-2 disabled:opacity-50">
              {loading && <Loader2 className="w-4 h-4 animate-spin" />} Confirmar canje
            </button>
          </>
        )}
      </div>
    </div>
  );
}
import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { MapPin, Navigation, Star, Check, CreditCard, Loader2, Users, Package, PhoneCall, XCircle, LogOut, PlusCircle } from 'lucide-react';
import ServiceChat from '@/components/shared/ServiceChat';
import CancelService from '@/components/shared/CancelService';
import DriverMap from '@/components/client/DriverMap';
import ResolvedAvatar from '@/components/shared/ResolvedAvatar';
import InAppVoiceCallModal, { useInAppVoiceCall } from '@/components/shared/InAppVoiceCall';

const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');

const CONTENT_LABELS = {
  comida: 'Comida',
  electronico: 'Electrónico',
  documentos: 'Documentos',
  paquete_pequeno: 'Paquete pequeño',
  paquete_grande: 'Paquete grande',
  otro: 'Otro',
};

const STEP_MAP = { pendiente: 0, asignado: 1, en_camino: 2, recogida: 2, finalizado: 3 };
const STEPS = [
  { label: 'Pendiente', desc: 'En espera de un conductor' },
  { label: 'Asignado', desc: 'Conductor asignado' },
  { label: 'En camino', desc: 'Conductor en movimiento' },
  { label: 'Finalizado', desc: 'Servicio completado' },
];

export default function ServiceTracking({ serviceId }) {
  const [, setSearchParams] = useSearchParams();
  const [service, setService] = useState(null);
  const [showRating, setShowRating] = useState(false);
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const [comment, setComment] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const load = async () => {
      const s = await base44.entities.Service.get(serviceId);
      setService(s);
      if (s.status === 'finalizado' && !s.rating) setShowRating(true);
    };
    load().catch(() => {});
    const unsub = base44.entities.Service.subscribe((event) => {
      if (event.id === serviceId && event.data) {
        setService(prev => prev ? { ...prev, ...event.data } : event.data);
        if (event.data?.status === 'finalizado' && !event.data?.rating) setShowRating(true);
      }
    });
    return unsub;
  }, [serviceId]);

  const submitRating = async () => {
    setSubmitting(true);
    try {
      const updated = await base44.entities.Service.update(serviceId, { rating, rating_comment: comment });
      setService(updated);
      setShowRating(false);
    } catch (e) {
      console.error('Rating error:', e);
    } finally { setSubmitting(false); }
  };

  const voiceCall = useInAppVoiceCall({
    serviceId,
    selfRole: 'cliente',
    selfName: service?.client_name || 'Pasajero',
    peerName: service?.mobile_name || 'Conductor',
    peerPhoto: service?.mobile_photo || '',
    peerSubtitle: service?.mobile_plate ? `Placa ${service.mobile_plate}` : 'Conductor verificado NEXT',
    enabled: Boolean(serviceId && (service?.status === 'asignado' || service?.status === 'en_camino' || service?.status === 'recogida')),
  });

  if (!service) return <div className="flex justify-center py-16"><Loader2 className="w-8 h-8 animate-spin text-[#1E6BFF]" /></div>;

  const stepIdx = STEP_MAP[service.status] ?? 0;
  const ServiceIcon = service.service_type === 'mensajeria' ? Package : Users;

  return (
    <div className="space-y-4">
      {/* Mapa en tiempo real siempre arriba de primero */}
      {(service.status === 'asignado' || service.status === 'en_camino' || service.status === 'recogida') && service.mobile_id && (
        <DriverMap
          mobileId={service.mobile_id}
          pickupLat={service.pickup_lat}
          pickupLng={service.pickup_lng}
          destLat={service.destination_lat}
          destLng={service.destination_lng}
          stops={service.stops}
          pickupAddress={service.pickup_address}
          destAddress={service.destination_address}
          phase={service.status === 'recogida' ? 'to_dest' : 'to_pickup'}
        />
      )}

      {/* Acciones: solicitar otro / cerrar sesión */}
      <div className="flex items-center gap-2">
        <button onClick={() => setSearchParams({})} className="flex-1 h-11 rounded-xl bg-[#121829] border border-white/10 text-white text-sm font-medium flex items-center justify-center gap-2">
          <PlusCircle className="w-4 h-4 text-[#00E5FF]" /> Solicitar otro servicio
        </button>
        <button onClick={() => base44.auth.logout('/')} className="h-11 px-4 rounded-xl bg-[#121829] border border-white/10 text-white text-sm flex items-center gap-2">
          <LogOut className="w-4 h-4 text-[#00E5FF]" /> Salir
        </button>
      </div>

      {/* Tarjeta de servicio con tarifa */}
      <div className="bg-[#0D0D0D] rounded-2xl overflow-hidden border border-[#1F1F1F]">
        <div className="bg-[#0A1F12] px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ServiceIcon className="w-5 h-5 text-[#1E6BFF]" />
            <span className="font-semibold text-white text-sm">{service.service_type === 'mensajeria' ? 'Mensajería' : 'Transporte de persona'}</span>
          </div>
          <span className="text-2xl font-bold text-[#1E6BFF]">{fmtCOP(service.fare || 5000)}</span>
        </div>
        <div className="p-5 space-y-3">
          <div className="flex items-start gap-2.5">
            <div className="w-2 h-2 rounded-full bg-[#1E6BFF] mt-1.5 flex-shrink-0" />
            <div>
              <p className="text-[#8B8C94] text-xs">Recogida</p>
              <p className="text-white text-sm">{service.pickup_address}</p>
            </div>
          </div>
          <div className="flex items-start gap-2.5">
            <div className="w-2 h-2 rounded-full bg-[#F59E0B] mt-1.5 flex-shrink-0" />
            <div>
              <p className="text-[#8B8C94] text-xs">Destino</p>
              <p className="text-white text-sm">{service.destination_address}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 pt-2 border-t border-[#1F1F1F]">
            <CreditCard className="w-4 h-4 text-[#8B8C94]" />
            <span className="text-[#8B8C94] text-sm">Pago: {service.payment_method === 'efectivo' ? 'Efectivo' : 'Transferencia'}</span>
          </div>
          {service.content_type && (
            <div className="flex items-start gap-2 pt-2 border-t border-[#1F1F1F]">
              <Package className="w-4 h-4 text-[#1E6BFF] mt-0.5 flex-shrink-0" />
              <span className="text-[#1E6BFF] font-medium text-sm">{CONTENT_LABELS[service.content_type]}{service.content_description ? ` — ${service.content_description}` : ''}</span>
            </div>
          )}
        </div>
      </div>

      {/* Cancelado */}
      {service.status === 'cancelado' && (
        <div className="bg-red-500/10 rounded-2xl p-5 border border-red-500/20 text-center">
          <XCircle className="w-8 h-8 text-red-400 mx-auto mb-2" />
          <p className="font-semibold text-red-400">Servicio cancelado</p>
        </div>
      )}

      {/* Reasignación */}
      {service.status === 'pendiente' && (service.rejected_by || []).length > 0 && (
        <div className="bg-[#1E6BFF]/10 rounded-2xl p-5 border border-[#1E6BFF]/20 text-center">
          <Loader2 className="w-8 h-8 text-[#1E6BFF] mx-auto mb-2 animate-spin" />
          <p className="font-semibold text-[#1E6BFF]">Buscando un nuevo conductor</p>
          <p className="text-sm text-[#8B8C94] mt-1">El conductor anterior liberó el servicio. Estamos buscando uno nuevo para ti.</p>
        </div>
      )}

      {/* Estado del servicio */}
      <div className="bg-[#0D0D0D] rounded-2xl p-5 border border-[#1F1F1F]">
        <h3 className="font-semibold text-white mb-4">Estado del servicio</h3>
        <div className="space-y-0">
          {STEPS.map((step, i) => (
            <div key={i} className="flex gap-3">
              <div className="flex flex-col items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${i <= stepIdx ? 'bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-[#FFFFFF]' : 'bg-[#1A1A1A] text-[#6B6B6B]'}`}>
                  {i < stepIdx ? <Check className="w-4 h-4" /> : i + 1}
                </div>
                {i < STEPS.length - 1 && <div className={`w-0.5 h-8 ${i < stepIdx ? 'bg-[#1E6BFF]' : 'bg-[#1F1F1F]'}`} />}
              </div>
              <div className="pt-1 pb-6">
                <p className={`font-medium text-sm ${i <= stepIdx ? 'text-white' : 'text-[#6B6B6B]'}`}>{step.label}</p>
                <p className="text-xs text-[#8B8C94]">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Info del conductor */}
      {service.mobile_name && (
        <div className="bg-[#0D0D0D] rounded-2xl p-5 border border-[#1F1F1F]">
          <h3 className="font-semibold text-white mb-3">Tu conductor</h3>
          <div className="flex items-center gap-4">
            <div className="relative">
              <ResolvedAvatar
                photo={service.mobile_photo}
                name={service.mobile_name}
                className="w-20 h-20 rounded-full bg-[#1A1A1A] border-2 border-[#1E6BFF]/30"
                fallback={<ServiceIcon className="w-8 h-8 text-[#8B8C94]" />}
              />
              <span className="absolute -bottom-1 -right-1 bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-[#FFFFFF] rounded-full p-1" title="Conductor verificado">
                <Check className="w-3 h-3" />
              </span>
            </div>
            <div className="flex-1">
              <p className="font-semibold text-base text-white">{service.mobile_name}</p>
              {service.mobile_plate && <p className="text-sm text-[#8B8C94]">Placa: {service.mobile_plate}</p>}
              <span className="inline-flex items-center gap-1 text-xs text-[#1E6BFF] font-medium mt-1">
                <Check className="w-3 h-3" /> Verificado
              </span>
            </div>
            {(service.status === 'asignado' || service.status === 'en_camino' || service.status === 'recogida') && (
              <button
                type="button"
                onClick={() => voiceCall.startCall()}
                title="Llamada segura en la app"
                className="w-11 h-11 rounded-full bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] flex items-center justify-center text-[#FFFFFF] flex-shrink-0"
              >
                <PhoneCall className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>
      )}

      {/* Evidencias (mensajería) */}
      {service.service_type === 'mensajeria' && (service.evidence_pickup_photo || service.evidence_delivery_photo) && (
        <div className="bg-[#0D0D0D] rounded-2xl p-5 border border-[#1F1F1F]">
          <h3 className="font-semibold text-white mb-3">Evidencia del envío</h3>
          <div className="grid grid-cols-2 gap-3">
            {service.evidence_pickup_photo && (
              <div>
                <p className="text-xs text-[#8B8C94] mb-1">Recogida</p>
                <img src={service.evidence_pickup_photo} alt="Evidencia de recogida" className="w-full aspect-square object-cover rounded-xl" />
              </div>
            )}
            {service.evidence_delivery_photo && (
              <div>
                <p className="text-xs text-[#8B8C94] mb-1">Entrega</p>
                <img src={service.evidence_delivery_photo} alt="Evidencia de entrega" className="w-full aspect-square object-cover rounded-xl" />
              </div>
            )}
          </div>
        </div>
      )}

      {/* Chat */}
      {(service.status === 'asignado' || service.status === 'en_camino' || service.status === 'recogida') && service.mobile_id && (
        <ServiceChat serviceId={service.id} senderType="cliente" senderName={service.client_name} />
      )}

      {/* Cancelar */}
      {(service.status === 'pendiente' || service.status === 'asignado') && (
        <CancelService serviceId={service.id} mobileId={service.mobile_id} />
      )}

      {/* Calificación */}
      {showRating && (
        <div className="bg-[#0D0D0D] rounded-2xl p-5 border border-[#1F1F1F]">
          <h3 className="font-semibold text-white mb-1">Califica tu servicio</h3>
          <p className="text-sm text-[#8B8C94] mb-4">¿Cómo estuvo tu experiencia con {service.mobile_name}?</p>
          <div className="flex gap-1 mb-4">
            {[1,2,3,4,5].map(n => (
              <button key={n} type="button" onClick={() => setRating(n)} onMouseEnter={() => setHover(n)} onMouseLeave={() => setHover(0)}>
                <Star className={`w-8 h-8 ${(hover || rating) >= n ? 'fill-amber-400 text-amber-400' : 'text-[#262626]'}`} />
              </button>
            ))}
          </div>
          <textarea value={comment} onChange={e => setComment(e.target.value)} placeholder="Comentario (opcional)"
            className="w-full mb-3 rounded-lg border border-[#262626] bg-[#0A0A0A] px-3 py-2 text-sm text-white placeholder:text-[#6B6B6B] focus:outline-none focus:ring-2 focus:ring-[#1E6BFF]/30" rows={3} />
          <button onClick={submitRating} disabled={rating === 0 || submitting}
            className="w-full h-11 rounded-xl bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-[#FFFFFF] font-bold flex items-center justify-center gap-2 disabled:opacity-50">
            {submitting && <Loader2 className="w-4 h-4 animate-spin" />} Enviar calificación
          </button>
        </div>
      )}

      {service.status === 'finalizado' && service.rating && !showRating && (
        <div className="bg-[#1E6BFF]/10 rounded-2xl p-4 border border-[#1E6BFF]/20 text-center">
          <p className="text-sm text-[#1E6BFF] font-medium">¡Servicio finalizado! Gracias por usar NEXT</p>
          <div className="flex justify-center gap-1 mt-2">
            {[1,2,3,4,5].map(n => <Star key={n} className={`w-5 h-5 ${n <= service.rating ? 'fill-amber-400 text-amber-400' : 'text-[#262626]'}`} />)}
          </div>
        </div>
      )}

      <InAppVoiceCallModal call={voiceCall} />
    </div>
  );
}
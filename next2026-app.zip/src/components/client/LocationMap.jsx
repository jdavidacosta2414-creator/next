import React, { useState, useEffect, useMemo } from 'react';
import { Loader2, Navigation } from 'lucide-react';
import { useMapboxToken } from '@/hooks/useMapboxToken';
import { fetchRoute } from '@/lib/mapRoute';
import { DEFAULT_CITY } from '@/lib/appCity';
import MapboxMap, { MapboxMarker, MapboxRoute, MapboxFitBounds, MapDragPinSync } from '@/components/shared/MapboxMap';
import { gpsMarkerEl, pickupWavingPinEl, destinationPinEl, stopPinEl } from '@/lib/mapboxMarkers';
import DriversLayer from '@/components/client/DriversLayer';
import MapTileError from '@/components/shared/MapTileError';
import { shortAddress } from '@/lib/shortAddress';

export default function LocationMap({
  gps,
  pickup,
  destination,
  stops = [],
  pickupAddress = '',
  destinationAddress = '',
  resolvingPickup = false,
  resolvingDestination = false,
  vehicleType = null,
  onRouteInfo,
  pickMode,
  locked = false,
  onMapClick,
  onPickupDrag,
  onDestinationDrag,
  onStopDrag,
  onPinBubbleClick,
  onInteractStart,
  onInteractEnd,
  hideRouteBadge,
  hidePickupPin = false,
  fitKey = null,
  className,
}) {
  const token = useMapboxToken();
  const [route, setRoute] = useState(null);
  const [tileError, setTileError] = useState(false);
  const [liveDragPoint, setLiveDragPoint] = useState(null);
  const [isDraggingMap, setIsDraggingMap] = useState(false);

  const activeStopIndex =
    typeof pickMode === 'string' && pickMode.startsWith('stop_')
      ? Number(pickMode.replace('stop_', ''))
      : -1;

  const stopsKey = useMemo(
    () =>
      (stops || [])
        .map((s) => (s?.lat != null && s?.lng != null ? `${Number(s.lat).toFixed(4)},${Number(s.lng).toFixed(4)}` : ''))
        .join('|'),
    [stops]
  );

  useEffect(() => {
    setLiveDragPoint(null);
  }, [pickup?.lat, pickup?.lng, destination?.lat, destination?.lng, stopsKey, pickMode, locked]);

  // Permitimos arrastrar/mover pines en pickMode, en home o cuando el usuario está ajustando su ruta
  const canDragPins = Boolean(pickMode) || !locked;

  const dragTarget =
    activeStopIndex >= 0
      ? `stop_${activeStopIndex}`
      : pickMode === 'destination'
      ? 'destination'
      : 'pickup';

  // Coordenadas visuales del marcador durante arrastre (no disparan recálculo de ruta ni fitBounds en vivo)
  const effectivePickup = canDragPins && dragTarget === 'pickup' && liveDragPoint ? liveDragPoint : pickup;
  const effectiveDest = canDragPins && dragTarget === 'destination' && liveDragPoint ? liveDragPoint : destination;
  const effectiveStops = useMemo(
    () =>
      (stops || []).map((s, idx) =>
        canDragPins && dragTarget === `stop_${idx}` && liveDragPoint
          ? { ...s, lat: liveDragPoint.lat, lng: liveDragPoint.lng }
          : s
      ),
    [stops, canDragPins, dragTarget, liveDragPoint]
  );

  const visualPickupPos = effectivePickup ? [effectivePickup.lat, effectivePickup.lng] : null;
  const visualDestPos = effectiveDest ? [effectiveDest.lat, effectiveDest.lng] : null;
  const gpsPos = gps ? [gps.lat, gps.lng] : null;

  // Coordenadas confirmadas para cálculo de ruta y encuadre (evita saltos o bloqueos mientras se arrastra)
  const committedPickupPos = pickup ? [pickup.lat, pickup.lng] : null;
  const committedDestPos = destination ? [destination.lat, destination.lng] : null;
  const committedStopWaypoints = useMemo(
    () =>
      (stops || [])
        .filter((s) => s?.lat != null && s?.lng != null)
        .map((s) => [Number(s.lat), Number(s.lng)]),
    [stops]
  );

  const waypointsKey = committedStopWaypoints.map(([lat, lng]) => `${lat.toFixed(4)},${lng.toFixed(4)}`).join('|');

  useEffect(() => {
    if (!token || !committedPickupPos || !committedDestPos) {
      setRoute(null);
      onRouteInfo?.(null);
      return;
    }
    let alive = true;
    fetchRoute(token, committedPickupPos, committedDestPos, committedStopWaypoints).then((r) => {
      if (!alive) return;
      setRoute(r);
      onRouteInfo?.(r && r.distanceKm != null ? { distanceKm: r.distanceKm, durationMin: r.durationMin } : null);
    });
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token, committedPickupPos?.[0], committedPickupPos?.[1], committedDestPos?.[0], committedDestPos?.[1], waypointsKey]);

  const positions = useMemo(() => {
    if (activeStopIndex >= 0) {
      const st = stops[activeStopIndex];
      const target = st?.lat != null && st?.lng != null ? [st.lat, st.lng] : committedPickupPos;
      return target ? [target] : [];
    }
    if (pickMode === 'destination') {
      const target = committedDestPos || committedPickupPos;
      return target ? [target] : [];
    }
    if (pickMode === 'pickup') {
      return committedPickupPos ? [committedPickupPos] : [];
    }
    const pts = [];
    if (committedPickupPos) pts.push(committedPickupPos);
    committedStopWaypoints.forEach((wp) => pts.push(wp));
    if (committedDestPos) pts.push(committedDestPos);
    return pts;
  }, [
    committedPickupPos,
    committedDestPos,
    committedStopWaypoints,
    pickMode,
    activeStopIndex,
    stops,
  ]);

  const center = committedPickupPos || gpsPos || [DEFAULT_CITY.lat, DEFAULT_CITY.lng];

  if (!token) {
    return (
      <div className={`${className || 'h-40'} bg-muted flex items-center justify-center`}>
        <Loader2 className="w-6 h-6 animate-spin text-[#1E6BFF]" />
      </div>
    );
  }

  const activeDragPoint =
    activeStopIndex >= 0
      ? stops[activeStopIndex]?.lat != null
        ? { lat: stops[activeStopIndex].lat, lng: stops[activeStopIndex].lng }
        : pickup
      : dragTarget === 'destination'
      ? destination || pickup
      : pickup;

  const showPickupBubble = pickMode === 'pickup' || (!pickMode && Boolean(visualPickupPos));
  const showDestBubble = pickMode === 'destination' || (!pickMode && Boolean(visualDestPos));

  return (
    <div className={`${className || 'h-40'} overflow-hidden relative ${pickMode ? 'cursor-crosshair' : ''}`}>
      <MapboxMap
        center={center}
        zoom={15}
        pitch={0}
        className="h-full w-full"
        cursor={pickMode ? 'crosshair' : undefined}
        onMapClick={onMapClick}
        onInteractStart={onInteractStart}
        onInteractEnd={onInteractEnd}
        onTileError={() => setTileError(true)}
      >
        {gpsPos && !hidePickupPin && <MapboxMarker lat={gpsPos[0]} lng={gpsPos[1]} el={gpsMarkerEl} interactive={false} />}
        {visualPickupPos && !hidePickupPin && (
          <MapboxMarker
            lat={visualPickupPos[0]}
            lng={visualPickupPos[1]}
            el={() =>
              pickupWavingPinEl(
                isDraggingMap && dragTarget === 'pickup'
                  ? 'Moviendo en el mapa...'
                  : resolvingPickup
                  ? 'Ubicando dirección...'
                  : shortAddress(pickupAddress) || 'Ubicando dirección...',
                'Punto de recogida',
                showPickupBubble
              )
            }
            labelTitle="Punto de recogida"
            labelAddress={
              isDraggingMap && dragTarget === 'pickup'
                ? 'Moviendo en el mapa...'
                : resolvingPickup
                ? 'Ubicando dirección...'
                : shortAddress(pickupAddress) || 'Ubicando dirección...'
            }
            showBubble={showPickupBubble}
            anchor="bottom"
            draggable={canDragPins && (!pickMode || pickMode === 'pickup')}
            interactive={Boolean(onPinBubbleClick)}
            onClick={onPinBubbleClick ? () => onPinBubbleClick('pickup') : undefined}
            onDragStart={canDragPins ? () => setIsDraggingMap(true) : undefined}
            onDragEnd={
              canDragPins
                ? (pt) => {
                    setIsDraggingMap(false);
                    onPickupDrag?.(pt);
                  }
                : undefined
            }
          />
        )}

        {/* Marcadores de paradas intermedias (1, 2, 3) */}
        {effectiveStops.map((stop, idx) => {
          if (stop?.lat == null || stop?.lng == null) return null;
          const isThisStopPick = activeStopIndex === idx;
          const showStopBubble = isThisStopPick || (!pickMode && Boolean(stop.address));
          const stopAddr =
            isDraggingMap && isThisStopPick
              ? 'Moviendo en el mapa...'
              : shortAddress(stop.address) || stop.address || `Parada ${idx + 1}`;
          return (
            <MapboxMarker
              key={`stop-${idx}`}
              lat={stop.lat}
              lng={stop.lng}
              el={() => stopPinEl(idx + 1, stopAddr, showStopBubble)}
              labelTitle={`Parada ${idx + 1}`}
              labelAddress={stopAddr}
              showBubble={showStopBubble}
              anchor="bottom"
              draggable={isThisStopPick}
              interactive={Boolean(onPinBubbleClick)}
              onClick={onPinBubbleClick ? () => onPinBubbleClick(`stop_${idx}`) : undefined}
              onDragStart={isThisStopPick ? () => setIsDraggingMap(true) : undefined}
              onDragEnd={
                isThisStopPick
                  ? (pt) => {
                      setIsDraggingMap(false);
                      onStopDrag?.(idx, pt);
                    }
                  : undefined
              }
            />
          );
        })}

        {visualDestPos && (
          <MapboxMarker
            lat={visualDestPos[0]}
            lng={visualDestPos[1]}
            el={() =>
              destinationPinEl(
                isDraggingMap && dragTarget === 'destination'
                  ? 'Moviendo en el mapa...'
                  : resolvingDestination
                  ? 'Ubicando dirección...'
                  : shortAddress(destinationAddress) || 'Selecciona destino',
                'Punto de llegada',
                showDestBubble
              )
            }
            labelTitle="Punto de llegada"
            labelAddress={
              isDraggingMap && dragTarget === 'destination'
                ? 'Moviendo en el mapa...'
                : resolvingDestination
                ? 'Ubicando dirección...'
                : shortAddress(destinationAddress) || 'Selecciona destino'
            }
            showBubble={showDestBubble}
            anchor="bottom"
            draggable={pickMode === 'destination' || !locked}
            interactive={Boolean(onPinBubbleClick)}
            onClick={onPinBubbleClick ? () => onPinBubbleClick('destination') : undefined}
            onDragStart={
              pickMode === 'destination' || !locked ? () => setIsDraggingMap(true) : undefined
            }
            onDragEnd={
              pickMode === 'destination' || !locked
                ? (pt) => {
                    setIsDraggingMap(false);
                    onDestinationDrag?.(pt);
                  }
                : undefined
            }
          />
        )}
        <MapDragPinSync
          enabled={canDragPins}
          activePoint={activeDragPoint}
          onMove={(pt) => {
            setIsDraggingMap(true);
            setLiveDragPoint(pt);
          }}
          onMoveEnd={(pt) => {
            setIsDraggingMap(false);
            setLiveDragPoint(pt);
            if (activeStopIndex >= 0) {
              onStopDrag?.(activeStopIndex, pt);
            } else if (dragTarget === 'destination') {
              onDestinationDrag?.(pt);
            } else {
              onPickupDrag?.(pt);
            }
          }}
        />
        {route?.coords && (
          <MapboxRoute
            coords={route.coords}
            color="#1E6BFF"
            casingColor="#0A2E73"
            width={6}
            opacity={0.96}
          />
        )}
        <DriversLayer center={center} vehicleType={vehicleType} />
        <MapboxFitBounds
          positions={positions}
          padding={hideRouteBadge ? { top: 120, bottom: 365, left: 68, right: 68 } : { top: 85, bottom: 250, left: 56, right: 56 }}
          singleZoom={pickMode ? 15 : 16}
          singlePadding={pickMode ? { top: 40, bottom: 70 } : { top: 60, bottom: 260 }}
          fitKey={fitKey}
        />
      </MapboxMap>
      {tileError && <MapTileError />}
      {route?.distanceKm != null && !hideRouteBadge && (
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-[450] bg-card border border-border shadow-lg rounded-full px-3 py-1.5 flex items-center gap-1.5 pointer-events-none">
          <Navigation className="w-3.5 h-3.5 text-[#1E6BFF]" />
          <span className="text-xs font-bold text-foreground">
            {route.durationMin != null ? `${route.durationMin} min · ` : ''}
            {route.distanceKm.toFixed(1)} km
          </span>
        </div>
      )}
    </div>
  );
}
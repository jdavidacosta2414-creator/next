import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import {
  Bike,
  Car,
  Minus,
  Plus,
  Send,
  Loader2,
  Package,
  Users,
  MapPin,
  Search,
  Route as RouteIcon,
  LocateFixed,
  Crosshair,
  AlertTriangle,
} from 'lucide-react';
import { isPickupInCoverage } from '@/lib/coverage';
import LocationMap from '@/components/client/LocationMap';
import ClientMenu from '@/components/client/ClientMenu';
import { useMapboxToken } from '@/hooks/useMapboxToken';
import { DEFAULT_CITY } from '@/lib/appCity';
import {
  geocodeAddress,
  reverseGeocodeValledupar,
  searchPlacesValledupar,
  resolvePlaceSelection,
  normalizeColombiaCoords,
} from '@/lib/geocode';

const fmtCOP = (n) => '$' + Number(n).toLocaleString('es-CO');
const FARE_MIN = { moto: 5000, carro: 8000 };

export default function RequestForm() {
  const [, setSearchParams] = useSearchParams();
  const { user } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const [form, setForm] = useState({
    client_name: user?.display_name || user?.full_name || '',
    client_phone: user?.phone || '',
    pickup_address: '',
    destination_address: '',
    service_type: 'transporte',
    vehicle_type: 'moto',
    payment_method: 'efectivo',
    fare: FARE_MIN.moto,
    content_type: '',
    content_description: '',
  });

  useEffect(() => {
    if (!user) return;
    setForm((f) => ({
      ...f,
      client_name: f.client_name || user.display_name || user.full_name || '',
      client_phone: f.client_phone || user.phone || '',
    }));
  }, [user]);

  const [payOpen, setPayOpen] = useState(false);
  const [coords, setCoords] = useState(null);
  const [pickupTouched, setPickupTouched] = useState(false);
  const [pickupPoint, setPickupPoint] = useState({ lat: DEFAULT_CITY.lat, lng: DEFAULT_CITY.lng });
  const [destPoint, setDestPoint] = useState(null);
  const [pickupPlace, setPickupPlace] = useState(null);
  const [destPlace, setDestPlace] = useState(null);
  const [pickupUnverified, setPickupUnverified] = useState(false);
  const [destUnverified, setDestUnverified] = useState(false);
  const [activeField, setActiveField] = useState(null);
  const [suggestions, setSuggestions] = useState([]);
  const [routeKm, setRouteKm] = useState(null);
  const [pickMode, setPickMode] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const token = useMapboxToken();
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  useEffect(() => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      async (p) => {
        const c =
          normalizeColombiaCoords(p.coords.latitude, p.coords.longitude) || {
            lat: parseFloat(p.coords.latitude),
            lng: parseFloat(p.coords.longitude),
          };
        setCoords(c);
        if (!pickupTouched) setPickupPoint(c);
        if (token && !pickupTouched) {
          reverseGeocodeValledupar(c.lat, c.lng, token)
            .then((addr) => {
              if (addr) {
                setForm((f) => ({ ...f, pickup_address: addr }));
                setPickupPlace({
                  place_id: `gps_${c.lat}_${c.lng}`,
                  name: addr,
                  formatted_address: `${addr}, Colombia`,
                  lat: c.lat,
                  lng: c.lng,
                  location_type: 'ROOFTOP',
                  isPrecise: true,
                  needsConfirmation: false,
                });
              }
            })
            .catch(() => {});
        }
      },
      () => {},
      { timeout: 8000, enableHighAccuracy: true }
    );
  }, [token, pickupTouched]);

  const geocode = async (address) => {
    if (!address) return null;
    return geocodeAddress(address, token, { userCoords: coords });
  };

  const reverseGeocode = async (lat, lng) => {
    return reverseGeocodeValledupar(lat, lng, token);
  };

  const locateMe = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      async (p) => {
        const c =
          normalizeColombiaCoords(p.coords.latitude, p.coords.longitude) || {
            lat: parseFloat(p.coords.latitude),
            lng: parseFloat(p.coords.longitude),
          };
        setCoords(c);
        setPickupPoint(c);
        setPickupTouched(true);
        setPickupUnverified(false);
        const addr = await reverseGeocode(c.lat, c.lng);
        if (addr) {
          set('pickup_address', addr);
          setPickupPlace({
            place_id: `gps_${c.lat}_${c.lng}`,
            name: addr,
            formatted_address: `${addr}, Colombia`,
            lat: c.lat,
            lng: c.lng,
            location_type: 'ROOFTOP',
            isPrecise: true,
            needsConfirmation: false,
          });
        }
      },
      () => {},
      { timeout: 10000, enableHighAccuracy: true, maximumAge: 0 }
    );
  };

  const handleMapClick = async ({ lat, lng }) => {
    if (!pickMode) return;
    const c = normalizeColombiaCoords(lat, lng) || { lat: parseFloat(lat), lng: parseFloat(lng) };
    const addr = await reverseGeocode(c.lat, c.lng);
    if (pickMode === 'pickup') {
      setPickupPoint(c);
      setPickupTouched(true);
      setPickupUnverified(false);
      if (addr) {
        set('pickup_address', addr);
        setPickupPlace({
          place_id: `pin_pickup_${c.lat}_${c.lng}`,
          name: addr,
          formatted_address: `${addr}, Colombia`,
          lat: c.lat,
          lng: c.lng,
          location_type: 'ROOFTOP',
          isPrecise: true,
          needsConfirmation: false,
        });
      }
    } else {
      setDestPoint(c);
      setDestUnverified(false);
      if (addr) {
        set('destination_address', addr);
        setDestPlace({
          place_id: `pin_dest_${c.lat}_${c.lng}`,
          name: addr,
          formatted_address: `${addr}, Colombia`,
          lat: c.lat,
          lng: c.lng,
          location_type: 'ROOFTOP',
          isPrecise: true,
          needsConfirmation: false,
        });
      }
    }
    setPickMode(null);
  };

  const handlePickupDrag = async ({ lat, lng }) => {
    const c = normalizeColombiaCoords(lat, lng) || { lat: parseFloat(lat), lng: parseFloat(lng) };
    setPickupPoint(c);
    setPickupTouched(true);
    setPickupUnverified(false);
    const addr = await reverseGeocode(c.lat, c.lng);
    if (addr) {
      set('pickup_address', addr);
      setPickupPlace({
        place_id: `pin_pickup_${c.lat}_${c.lng}`,
        name: addr,
        formatted_address: `${addr}, Colombia`,
        lat: c.lat,
        lng: c.lng,
        location_type: 'ROOFTOP',
        isPrecise: true,
        needsConfirmation: false,
      });
    }
  };

  const handleDestDrag = async ({ lat, lng }) => {
    const c = normalizeColombiaCoords(lat, lng) || { lat: parseFloat(lat), lng: parseFloat(lng) };
    setDestPoint(c);
    setDestUnverified(false);
    const addr = await reverseGeocode(c.lat, c.lng);
    if (addr) {
      set('destination_address', addr);
      setDestPlace({
        place_id: `pin_dest_${c.lat}_${c.lng}`,
        name: addr,
        formatted_address: `${addr}, Colombia`,
        lat: c.lat,
        lng: c.lng,
        location_type: 'ROOFTOP',
        isPrecise: true,
        needsConfirmation: false,
      });
    }
  };

  const currentQuery =
    activeField === 'pickup'
      ? form.pickup_address
      : activeField === 'destination'
      ? form.destination_address
      : '';

  useEffect(() => {
    const q = (currentQuery || '').trim();
    if (!activeField || q.length < 2) {
      setSuggestions([]);
      return;
    }
    let cancelled = false;
    const t = setTimeout(async () => {
      const res = await searchPlacesValledupar(q, token, { userCoords: coords });
      if (!cancelled) setSuggestions(res);
    }, 180);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [currentQuery, activeField, token, coords]);

  const handleSelectSuggestion = async (item) => {
    const resolved = await resolvePlaceSelection(item);
    if (!resolved) return;
    const c = normalizeColombiaCoords(resolved.lat, resolved.lng) || {
      lat: parseFloat(resolved.lat),
      lng: parseFloat(resolved.lng),
    };
    if (activeField === 'pickup') {
      setPickupTouched(true);
      setPickupPlace(resolved);
      setPickupPoint(c);
      setPickupUnverified(Boolean(resolved.needsConfirmation));
      set('pickup_address', resolved.name);
    } else if (activeField === 'destination') {
      setDestPlace(resolved);
      setDestPoint(c);
      setDestUnverified(Boolean(resolved.needsConfirmation));
      set('destination_address', resolved.name);
    }
    setSuggestions([]);
    setActiveField(null);
  };

  const adjustFare = (delta) => set('fare', Math.max(FARE_MIN[form.vehicle_type], form.fare + delta));
  const selectVehicle = (v) => {
    set('vehicle_type', v);
    if (v === 'carro') set('service_type', 'transporte');
    set('fare', FARE_MIN[v]);
  };

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      if (!form.pickup_address) {
        setError('Indica tu punto de recogida.');
        setLoading(false);
        return;
      }
      if (!form.destination_address) {
        setError('Indica a dónde vas.');
        setLoading(false);
        return;
      }
      if (form.service_type === 'mensajeria' && !form.content_type) {
        setError('Selecciona qué vas a enviar.');
        setLoading(false);
        return;
      }
      const cov = await isPickupInCoverage(form.pickup_address);
      if (!cov.ok) {
        setError('Lo sentimos, no cubrimos esa zona. Contáctanos por WhatsApp.');
        setLoading(false);
        return;
      }

      const finalPick =
        (pickupPlace?.lat != null && pickupPlace?.lng != null
          ? { lat: parseFloat(pickupPlace.lat), lng: parseFloat(pickupPlace.lng) }
          : null) || pickupPoint;
      const finalDest =
        (destPlace?.lat != null && destPlace?.lng != null
          ? { lat: parseFloat(destPlace.lat), lng: parseFloat(destPlace.lng) }
          : null) || destPoint;

      if (!finalPick || !finalDest) {
        setError('Selecciona una opción de la lista o elige el punto en el mapa.');
        setLoading(false);
        return;
      }

      finalPick = normalizeColombiaCoords(finalPick?.lat, finalPick?.lng) || finalPick;
      finalDest = normalizeColombiaCoords(finalDest?.lat, finalDest?.lng) || finalDest;

      const svc = await base44.entities.Service.create({
        client_name: form.client_name,
        client_phone: form.client_phone,
        pickup_address: form.pickup_address,
        destination_address: form.destination_address,
        service_type: form.service_type,
        vehicle_type: form.vehicle_type,
        payment_method: form.payment_method,
        fare: form.fare,
        origin: 'link',
        status: 'pendiente',
        rejected_by: [],
        ...(form.service_type === 'mensajeria'
          ? { content_type: form.content_type, content_description: form.content_description || null }
          : {}),
        ...(finalPick
          ? { pickup_lat: parseFloat(finalPick.lat), pickup_lng: parseFloat(finalPick.lng) }
          : {}),
        ...(finalDest
          ? { destination_lat: parseFloat(finalDest.lat), destination_lng: parseFloat(finalDest.lng) }
          : {}),
      });
      setSearchParams({ service: svc.id });
      base44.functions.invoke('notifyNearbyDrivers', { service_id: svc.id }).catch(() => {});
    } finally {
      setLoading(false);
    }
  };

  const PAYMENTS = [
    { v: 'efectivo', label: 'Efectivo', icon: '💵' },
    { v: 'transferencia', label: 'Transferencia', icon: '🏦' },
  ];

  return (
    <div className="relative min-h-screen bg-[#0B0F1A] max-w-md mx-auto flex flex-col overflow-hidden">
      <div className="h-[38vh] relative flex-shrink-0">
        <LocationMap
          gps={coords}
          pickup={pickupPoint}
          destination={destPoint}
          pickupAddress={form.pickup_address}
          destinationAddress={form.destination_address}
          vehicleType={form.vehicle_type}
          onRouteInfo={(info) => setRouteKm(info?.distanceKm ?? null)}
          pickMode={pickMode}
          onMapClick={handleMapClick}
          onPickupDrag={handlePickupDrag}
          onDestinationDrag={handleDestDrag}
          className="h-full w-full rounded-none border-0"
        />
        {pickMode && (
          <div className="absolute top-3 left-1/2 -translate-x-1/2 z-[1000] bg-[#121829] border border-[#1E6BFF]/40 rounded-full px-4 py-2 flex items-center gap-2 shadow-lg">
            <Crosshair className="w-4 h-4 text-[#00E5FF]" />
            <span className="text-xs font-medium text-white">
              Toca el mapa o arrastra el marcador para fijar el punto {pickMode === 'pickup' ? 'A' : 'B'}
            </span>
            <button type="button" onClick={() => setPickMode(null)} className="text-xs text-[#8B95A8] ml-1">
              ✕
            </button>
          </div>
        )}
      </div>

      <form
        onSubmit={submit}
        className="relative z-10 -mt-6 bg-[#121829] rounded-t-[28px] border-t border-white/10 flex-1 flex flex-col shadow-2xl overflow-hidden"
      >
        <div className="flex items-center justify-between px-5 pt-3 pb-2 flex-shrink-0">
          <button
            type="button"
            onClick={() => setMenuOpen(true)}
            aria-label="Menú"
            className="w-9 h-9 rounded-xl bg-white/5 border border-white/10 flex flex-col items-center justify-center gap-[3px] hover:bg-white/10 transition-colors"
          >
            <span className="block w-4 h-0.5 bg-white rounded" />
            <span className="block w-4 h-0.5 bg-white rounded" />
            <span className="block w-4 h-0.5 bg-white rounded" />
          </button>
          <div className="w-9 h-1.5 rounded-full bg-white/15" />
          <button
            type="button"
            onClick={locateMe}
            aria-label="Usar mi ubicación actual"
            title="Usar mi ubicación actual"
            className="px-2.5 h-9 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center gap-1.5 text-xs text-[#00E5FF] font-semibold hover:bg-white/10 transition-colors"
          >
            <LocateFixed className="w-4 h-4 text-[#00E5FF]" />
            <span>Usar mi ubicación actual</span>
          </button>
        </div>

        <div className="px-5 pb-6 overflow-y-auto no-scrollbar flex-1">
          <div className="space-y-4">
            {/* 1. Recogida */}
            <div>
              <label className="text-[10px] font-medium text-[#5A6478] tracking-wider mb-1.5 block">
                RECOGIDA
              </label>
              <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-2xl px-3 h-12">
                <MapPin className="w-4 h-4 text-[#00E5FF] flex-shrink-0" />
                <input
                  value={form.pickup_address}
                  onFocus={() => setActiveField('pickup')}
                  onChange={(e) => {
                    setActiveField('pickup');
                    setPickupTouched(true);
                    setPickupPlace(null);
                    set('pickup_address', e.target.value);
                  }}
                  placeholder={
                    coords && !pickupTouched ? 'Usando tu ubicación actual' : '¿Dónde te recogemos?'
                  }
                  className="flex-1 min-w-0 bg-transparent text-sm text-white placeholder:text-[#5A6478] outline-none"
                />
              </div>
            </div>

            {/* 2. Destino */}
            <div>
              <label className="text-[10px] font-medium text-[#5A6478] tracking-wider mb-1.5 block">
                DESTINO
              </label>
              <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-2xl px-3 h-12">
                <Search className="w-4 h-4 text-[#5A6478] flex-shrink-0" />
                <input
                  value={form.destination_address}
                  onFocus={() => setActiveField('destination')}
                  onChange={(e) => {
                    setActiveField('destination');
                    setDestPlace(null);
                    set('destination_address', e.target.value);
                  }}
                  placeholder="¿A dónde vas?"
                  className="flex-1 min-w-0 bg-transparent text-sm text-white placeholder:text-[#5A6478] outline-none"
                />
              </div>
              {routeKm != null && (
                <p className="text-xs text-[#00E5FF] mt-1.5 flex items-center gap-1.5">
                  <RouteIcon className="w-3.5 h-3.5" /> Recorrido aproximado: {routeKm.toFixed(1)} km
                </p>
              )}
            </div>

            {/* Autocompletado de lugares */}
            {suggestions.length > 0 && (
              <div className="rounded-2xl border border-white/10 bg-[#161C28] divide-y divide-white/5 max-h-48 overflow-y-auto">
                {suggestions.map((item, idx) => (
                  <button
                    key={`${item.place_id || item.name}-${idx}`}
                    type="button"
                    onClick={() => handleSelectSuggestion(item)}
                    className="w-full px-3.5 py-2.5 text-left hover:bg-white/5 flex items-center justify-between gap-2"
                  >
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-white truncate">{item.name}</p>
                      <p className="text-[10px] text-[#8B95A8] truncate">{item.subtitle}</p>
                    </div>
                    {item.needsConfirmation && (
                      <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0" />
                    )}
                  </button>
                ))}
              </div>
            )}

            {(pickupUnverified || destUnverified) && (
              <div className="rounded-xl bg-amber-500/15 border border-amber-500/40 px-3 py-2 flex items-center justify-between gap-2 text-xs text-amber-300 font-semibold">
                <span className="flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0" />
                  Confirma la ubicación en el mapa
                </span>
                <button
                  type="button"
                  onClick={() => setPickMode(destUnverified ? 'destination' : 'pickup')}
                  className="px-2.5 py-1 rounded-lg bg-amber-400 text-slate-950 font-bold text-[11px]"
                >
                  Ajustar
                </button>
              </div>
            )}

            {/* Marcar puntos manualmente en el mapa */}
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setPickMode('pickup')}
                className={`h-10 rounded-xl border flex items-center justify-center gap-1.5 text-xs font-medium ${
                  pickMode === 'pickup'
                    ? 'border-[#1E6BFF] bg-[#1E6BFF]/10 text-white'
                    : 'border-white/10 text-[#8B95A8]'
                }`}
              >
                <Crosshair className="w-3.5 h-3.5" /> Marcar A en mapa
              </button>
              <button
                type="button"
                onClick={() => setPickMode('destination')}
                className={`h-10 rounded-xl border flex items-center justify-center gap-1.5 text-xs font-medium ${
                  pickMode === 'destination'
                    ? 'border-[#1E6BFF] bg-[#1E6BFF]/10 text-white'
                    : 'border-white/10 text-[#8B95A8]'
                }`}
              >
                <Crosshair className="w-3.5 h-3.5" /> Marcar B en mapa
              </button>
            </div>

            {/* 3. Vehículo */}
            <div>
              <label className="text-[10px] font-medium text-[#5A6478] tracking-wider mb-1.5 block">
                VEHÍCULO
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => selectVehicle('moto')}
                  className={`p-3 rounded-2xl border-2 transition flex flex-col items-center gap-1 ${
                    form.vehicle_type === 'moto' ? 'border-[#00E5FF] bg-[#00E5FF]/5' : 'border-white/10'
                  }`}
                >
                  <Bike
                    className={`w-6 h-6 ${
                      form.vehicle_type === 'moto' ? 'text-[#1E6BFF]' : 'text-[#5A6478]'
                    }`}
                  />
                  <span
                    className={`text-sm font-bold ${
                      form.vehicle_type === 'moto' ? 'text-white' : 'text-[#8B95A8]'
                    }`}
                  >
                    Moto
                  </span>
                  <span className="text-[10px] text-[#5A6478]">Desde {fmtCOP(FARE_MIN.moto)}</span>
                </button>
                <button
                  type="button"
                  onClick={() => selectVehicle('carro')}
                  className={`p-3 rounded-2xl border-2 transition flex flex-col items-center gap-1 ${
                    form.vehicle_type === 'carro'
                      ? 'border-[#00E5FF] bg-[#00E5FF]/5'
                      : 'border-white/10'
                  }`}
                >
                  <Car
                    className={`w-6 h-6 ${
                      form.vehicle_type === 'carro' ? 'text-[#1E6BFF]' : 'text-[#5A6478]'
                    }`}
                  />
                  <span
                    className={`text-sm font-bold ${
                      form.vehicle_type === 'carro' ? 'text-white' : 'text-[#8B95A8]'
                    }`}
                  >
                    Carro
                  </span>
                  <span className="text-[10px] text-[#5A6478]">Desde {fmtCOP(FARE_MIN.carro)}</span>
                </button>
              </div>
            </div>

            {/* Tipo de servicio (solo moto) */}
            {form.vehicle_type === 'moto' && (
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => set('service_type', 'transporte')}
                  className={`p-2.5 rounded-xl border-2 flex items-center justify-center gap-1.5 ${
                    form.service_type === 'transporte'
                      ? 'border-[#00E5FF] bg-[#00E5FF]/5'
                      : 'border-white/10'
                  }`}
                >
                  <Users
                    className={`w-4 h-4 ${
                      form.service_type === 'transporte' ? 'text-[#1E6BFF]' : 'text-[#5A6478]'
                    }`}
                  />
                  <span
                    className={`text-xs font-medium ${
                      form.service_type === 'transporte' ? 'text-white' : 'text-[#8B95A8]'
                    }`}
                  >
                    Transporte
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => set('service_type', 'mensajeria')}
                  className={`p-2.5 rounded-xl border-2 flex items-center justify-center gap-1.5 ${
                    form.service_type === 'mensajeria'
                      ? 'border-[#00E5FF] bg-[#00E5FF]/5'
                      : 'border-white/10'
                  }`}
                >
                  <Package
                    className={`w-4 h-4 ${
                      form.service_type === 'mensajeria' ? 'text-[#1E6BFF]' : 'text-[#5A6478]'
                    }`}
                  />
                  <span
                    className={`text-xs font-medium ${
                      form.service_type === 'mensajeria' ? 'text-white' : 'text-[#8B95A8]'
                    }`}
                  >
                    Mensajería
                  </span>
                </button>
              </div>
            )}

            {/* Contenido mensajería */}
            {form.service_type === 'mensajeria' && (
              <div className="space-y-2">
                <label className="text-[10px] font-medium text-[#5A6478] tracking-wider block">
                  ¿QUÉ VAS A ENVIAR?
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { v: 'comida', label: 'Comida' },
                    { v: 'electronico', label: 'Electrónico' },
                    { v: 'documentos', label: 'Documentos' },
                    { v: 'paquete_pequeno', label: 'Paq. pequeño' },
                    { v: 'paquete_grande', label: 'Paq. grande' },
                    { v: 'otro', label: 'Otro' },
                  ].map((opt) => (
                    <button
                      key={opt.v}
                      type="button"
                      onClick={() => set('content_type', opt.v)}
                      className={`p-2 rounded-lg border text-center ${
                        form.content_type === opt.v
                          ? 'border-[#00E5FF] bg-[#00E5FF]/5 text-white'
                          : 'border-white/10 text-[#8B95A8]'
                      }`}
                    >
                      <span className="text-xs font-medium">{opt.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Método de pago */}
            <div>
              <label className="text-[10px] font-medium text-[#5A6478] tracking-wider mb-1.5 block">
                MÉTODO DE PAGO
              </label>
              <div className="space-y-2">
                <button
                  type="button"
                  onClick={() => setPayOpen(!payOpen)}
                  className={`w-full flex items-center justify-between p-3 rounded-xl border-2 ${
                    payOpen ? 'border-[#00E5FF]' : 'border-[#00E5FF] bg-[#00E5FF]/5'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-[#00E5FF] flex items-center justify-center text-sm">
                      {PAYMENTS.find((p) => p.v === form.payment_method)?.icon}
                    </div>
                    <span className="text-sm font-bold text-white">
                      {PAYMENTS.find((p) => p.v === form.payment_method)?.label}
                    </span>
                  </div>
                </button>
                {payOpen &&
                  PAYMENTS.filter((p) => p.v !== form.payment_method).map((opt) => (
                    <button
                      key={opt.v}
                      type="button"
                      onClick={() => {
                        set('payment_method', opt.v);
                        setPayOpen(false);
                      }}
                      className="w-full flex items-center justify-between p-3 rounded-xl border border-white/10"
                    >
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-sm">
                          {opt.icon}
                        </div>
                        <span className="text-sm font-medium text-[#8B95A8]">{opt.label}</span>
                      </div>
                      <div className="w-5 h-5 rounded-full border-2 border-white/20" />
                    </button>
                  ))}
              </div>
            </div>

            {/* Propón tu tarifa */}
            <div>
              <label className="text-[10px] font-medium text-[#5A6478] tracking-wider mb-1.5 block">
                PROPÓN TU TARIFA
              </label>
              <div className="flex items-center justify-between bg-white/5 rounded-2xl p-3 border border-white/10">
                <button
                  type="button"
                  onClick={() => adjustFare(-500)}
                  className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center"
                >
                  <Minus className="w-5 h-5 text-white" />
                </button>
                <span className="text-2xl font-bold text-[#00E5FF]">{fmtCOP(form.fare)}</span>
                <button
                  type="button"
                  onClick={() => adjustFare(500)}
                  className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center"
                >
                  <Plus className="w-5 h-5 text-white" />
                </button>
              </div>
              <p className="text-[10px] text-[#5A6478] mt-1.5">
                Tarifa mínima {fmtCOP(FARE_MIN[form.vehicle_type])}
              </p>
            </div>

            {/* Datos del cliente */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] font-medium text-[#5A6478] tracking-wider mb-1.5 block">
                  TU NOMBRE
                </label>
                <input
                  required
                  value={form.client_name}
                  onChange={(e) => set('client_name', e.target.value)}
                  placeholder="Nombre"
                  className="w-full h-11 bg-white/5 border border-white/10 rounded-xl px-3 text-sm text-white placeholder:text-[#5A6478] outline-none focus:border-[#00E5FF]"
                />
              </div>
              <div>
                <label className="text-[10px] font-medium text-[#5A6478] tracking-wider mb-1.5 block">
                  TELÉFONO
                </label>
                <input
                  value={form.client_phone}
                  onChange={(e) => set('client_phone', e.target.value)}
                  placeholder="300 123 4567"
                  className="w-full h-11 bg-white/5 border border-white/10 rounded-xl px-3 text-sm text-white placeholder:text-[#5A6478] outline-none focus:border-[#00E5FF]"
                />
              </div>
            </div>

            {error && (
              <p className="text-sm text-red-400 bg-red-500/10 rounded-lg p-3 text-center">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full h-14 bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white font-bold rounded-2xl flex items-center justify-center gap-2 disabled:opacity-50 shadow-lg shadow-[#1E6BFF]/30"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Buscando...
                </>
              ) : (
                <>
                  <Send className="w-5 h-5" />
                  BUSCAR CONDUCTORES
                </>
              )}
            </button>
          </div>
        </div>
      </form>

      {menuOpen && (
        <ClientMenu
          user={user}
          onClose={() => setMenuOpen(false)}
          onLogin={() => {
            setMenuOpen(false);
            window.location.href = '/';
          }}
        />
      )}
    </div>
  );
}
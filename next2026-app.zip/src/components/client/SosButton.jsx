import React, { useState } from 'react';
import { ShieldAlert, Phone, MapPin, Loader2, X, Share2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

// Botón de emergencia para el cliente: abre un diálogo con la línea de
// emergencias (123) y la ubicación actual para compartirla rápidamente.
export default function SosButton() {
  const [open, setOpen] = useState(false);
  const [loc, setLoc] = useState(null);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleSos = () => {
    setOpen(true);
    setLoading(true);
    setLoc(null);
    navigator.geolocation?.getCurrentPosition(
      (p) => { setLoc({ lat: p.coords.latitude, lng: p.coords.longitude }); setLoading(false); },
      () => setLoading(false),
      { timeout: 8000, enableHighAccuracy: true }
    );
  };

  const share = async () => {
    if (!loc) return;
    const url = `https://www.google.com/maps?q=${loc.lat},${loc.lng}`;
    try {
      if (navigator.share) {
        await navigator.share({ title: 'Mi ubicación', text: 'Necesito ayuda', url });
      } else {
        await navigator.clipboard.writeText(url);
        toast({ description: 'Ubicación copiada al portapapeles.' });
      }
    } catch {}
  };

  return (
    <>
      <button
        onClick={handleSos}
        className="w-full flex items-center justify-center gap-2 h-12 rounded-xl bg-red-500/15 text-red-400 text-sm font-bold border border-red-500/30 hover:bg-red-500/20 transition-colors"
      >
        <ShieldAlert className="w-5 h-5" /> SOS · Emergencia
      </button>

      {open && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4" onClick={() => setOpen(false)}>
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
          <div className="relative w-full max-w-sm bg-[#121829] rounded-3xl p-6 border border-red-500/30 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center">
                  <ShieldAlert className="w-6 h-6 text-red-400" />
                </div>
                <h3 className="text-white font-bold text-lg">Emergencia SOS</h3>
              </div>
              <button onClick={() => setOpen(false)} className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-sm text-[#8B95A8] mb-4">
              Si estás en peligro, llama a la línea de emergencias y comparte tu ubicación con quien pueda ayudarte.
            </p>
            <a
              href="tel:123"
              className="w-full flex items-center justify-center gap-2 h-12 rounded-xl bg-red-500 text-white font-bold mb-3 shadow-lg shadow-red-500/30"
            >
              <Phone className="w-5 h-5" /> Llamar 123 · Emergencias
            </a>
            <div className="bg-white/5 rounded-xl p-3 mb-3">
              <p className="text-xs text-[#8B95A8] flex items-center gap-1.5 mb-1">
                <MapPin className="w-3.5 h-3.5 text-[#00E5FF]" /> Tu ubicación actual
              </p>
              {loading ? (
                <p className="text-xs text-white flex items-center gap-1.5">
                  <Loader2 className="w-3.5 h-3.5 animate-spin" /> Obteniendo ubicación...
                </p>
              ) : loc ? (
                <p className="text-xs text-white font-mono">{loc.lat.toFixed(5)}, {loc.lng.toFixed(5)}</p>
              ) : (
                <p className="text-xs text-[#8B95A8]">No disponible</p>
              )}
            </div>
            <button
              onClick={share}
              disabled={!loc}
              className="w-full flex items-center justify-center gap-2 h-11 rounded-xl border border-[#00E5FF]/30 text-[#00E5FF] text-sm font-medium disabled:opacity-50 hover:bg-[#00E5FF]/10 transition-colors"
            >
              <Share2 className="w-4 h-4" /> Compartir ubicación
            </button>
          </div>
        </div>
      )}
    </>
  );
}
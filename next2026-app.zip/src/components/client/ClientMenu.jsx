import React, { useState, useEffect } from 'react';
import { X, LogOut, History, FileText, MapPin, ChevronDown, User, Shield, Bike, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import SosButton from '@/components/client/SosButton';

const STATUS_LABELS = {
  pendiente: 'Buscando',
  asignado: 'Asignado',
  en_camino: 'En camino',
  recogida: 'En recorrido',
  finalizado: 'Finalizado',
  cancelado: 'Cancelado',
  rechazado: 'Sin conductor',
};

export default function ClientMenu({ user, onClose, onLogin }) {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openSection, setOpenSection] = useState(null);

  useEffect(() => {
    if (!user) { setLoading(false); return; }
    base44.entities.Service.filter({ created_by_id: user.id }, '-created_date', 50)
      .then(setServices).catch(() => {}).finally(() => setLoading(false));
  }, [user]);

  const initials = (user?.full_name || user?.email || '?').trim().charAt(0).toUpperCase();
  const finished = services.filter(s => s.status === 'finalizado');

  const [checkingDriver, setCheckingDriver] = useState(false);

  // Cambiar a modo conductor: si ya tiene perfil de conductor va directo al panel
  // (interfaz de servicios disponibles); si no, al registro. La decisión se basa
  // en la existencia real del perfil (no en el rol cacheado, que puede estar
  // desactualizado tras un registro reciente). La navegación recarga la app y
  // refresca el rol, dejando pasar la validación de la ruta /movil.
  const switchToDriver = async () => {
    setCheckingDriver(true);
    try {
      let hasProfile = false;
      if (user?.email) {
        const mobs = await base44.entities.Mobile.filter({ email: user.email });
        hasProfile = mobs.length > 0;
      }
      onClose?.();
      window.location.href = hasProfile ? '/movil' : '/vinculate/conductor';
    } catch {
      onClose?.();
      window.location.href = '/vinculate/conductor';
    } finally {
      setCheckingDriver(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-[82%] max-w-xs h-full bg-[#121829] border-r border-white/10 flex flex-col animate-in slide-in-from-left">
        {/* Encabezado de perfil */}
        <div className="p-5 bg-gradient-to-br from-[#1E6BFF]/25 to-[#00E5FF]/10 border-b border-white/10">
          <div className="flex items-center justify-between mb-3">
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[#1E6BFF] to-[#00E5FF] flex items-center justify-center text-white font-bold text-2xl">
              {initials}
            </div>
            <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
          <p className="text-white font-bold text-base">{user?.full_name || 'Invitado'}</p>
          <p className="text-[#8B95A8] text-xs truncate">{user?.email || 'Sin sesión'}</p>
          <div className="flex gap-2 mt-3">
            <div className="flex-1 bg-white/5 rounded-xl px-3 py-2 text-center">
              <p className="text-white font-bold text-lg">{finished.length}</p>
              <p className="text-[10px] text-[#8B95A8]">Viajes</p>
            </div>
            <div className="flex-1 bg-white/5 rounded-xl px-3 py-2 text-center">
              <p className="text-white font-bold text-lg">{services.length}</p>
              <p className="text-[10px] text-[#8B95A8]">Solicitudes</p>
            </div>
          </div>
        </div>

        {/* Cuerpo */}
        <div className="flex-1 overflow-y-auto no-scrollbar px-3 py-3 space-y-2">
          {!user && (
            <button onClick={onLogin} className="w-full flex items-center gap-3 p-3 rounded-xl bg-[#1E6BFF]/15 text-[#00E5FF] text-sm font-medium">
              <User className="w-5 h-5" /> Iniciar sesión
            </button>
          )}

          {/* Historial */}
          <button onClick={() => setOpenSection(openSection === 'history' ? null : 'history')}
            className="w-full flex items-center justify-between p-3 rounded-xl bg-white/5 hover:bg-white/10">
            <div className="flex items-center gap-3">
              <History className="w-5 h-5 text-[#00E5FF]" />
              <span className="text-white text-sm font-medium">Historial de viajes</span>
            </div>
            <ChevronDown className={`w-4 h-4 text-[#8B95A8] transition-transform ${openSection === 'history' ? 'rotate-180' : ''}`} />
          </button>
          {openSection === 'history' && (
            <div className="space-y-2 px-1">
              {loading && <p className="text-xs text-[#8B95A8] p-3">Cargando...</p>}
              {!loading && services.length === 0 && <p className="text-xs text-[#8B95A8] p-3">Aún no tienes viajes.</p>}
              {services.map(s => (
                <div key={s.id} className="bg-white/5 rounded-xl p-3 border border-white/8">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] text-[#8B95A8]">{new Date(s.created_date).toLocaleDateString('es-CO')}</span>
                    <span className="text-[10px] font-medium text-[#00E5FF]">{STATUS_LABELS[s.status] || s.status}</span>
                  </div>
                  <p className="text-xs text-white flex items-start gap-1.5"><MapPin className="w-3 h-3 text-[#00E5FF] mt-0.5 flex-shrink-0" />{s.pickup_address}</p>
                  <p className="text-xs text-[#8B95A8] flex items-start gap-1.5 mt-1 pl-4">→ {s.destination_address}</p>
                </div>
              ))}
            </div>
          )}

          {/* Términos */}
          <button onClick={() => setOpenSection(openSection === 'terms' ? null : 'terms')}
            className="w-full flex items-center justify-between p-3 rounded-xl bg-white/5 hover:bg-white/10">
            <div className="flex items-center gap-3">
              <FileText className="w-5 h-5 text-[#00E5FF]" />
              <span className="text-white text-sm font-medium">Términos y condiciones</span>
            </div>
            <ChevronDown className={`w-4 h-4 text-[#8B95A8] transition-transform ${openSection === 'terms' ? 'rotate-180' : ''}`} />
          </button>
          {openSection === 'terms' && (
            <div className="bg-white/5 rounded-xl p-3 border border-white/8 text-[11px] text-[#8B95A8] leading-relaxed space-y-2">
              <p><b className="text-white">1. Servicio.</b> NEXT conecta a usuarios con conductores de moto y carro para transporte y mensajería. La solicitud es privada y para uso personal.</p>
              <p><b className="text-white">2. Tarifa.</b> La tarifa se acuerda con el conductor al momento de la solicitud. El pago se realiza directamente al conductor según el método elegido.</p>
              <p><b className="text-white">3. Conducta.</b> El usuario se compromete a dar datos correctos de recogida y destino, y a tratar con respeto al conductor.</p>
              <p><b className="text-white">4. Cancelación.</b> Puedes cancelar antes de que el conductor llegue al punto de recogida sin costo.</p>
              <p><b className="text-white">5. Responsabilidad.</b> NEXT es una plataforma de intermediación. La responsabilidad del traslado y la mensajería es del conductor asignado.</p>
            </div>
          )}

          <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5">
            <Shield className="w-5 h-5 text-[#00E5FF]" />
            <span className="text-[#8B95A8] text-xs">Tu información es privada y segura.</span>
          </div>

          {user && (
            <>
              <button
                onClick={switchToDriver}
                disabled={checkingDriver}
                className="w-full flex items-center gap-3 p-3 rounded-xl bg-[#1E6BFF]/10 border border-[#1E6BFF]/20 hover:bg-[#1E6BFF]/15 transition-colors disabled:opacity-60"
              >
                {checkingDriver ? <Loader2 className="w-5 h-5 text-[#1E6BFF] animate-spin" /> : <Bike className="w-5 h-5 text-[#1E6BFF]" />}
                <span className="text-white text-sm font-medium">Cambiar a modo conductor</span>
              </button>
              <SosButton />
            </>
          )}
        </div>

        {/* Cerrar sesión */}
        {user && (
          <div className="p-3 border-t border-white/10">
            <button onClick={() => base44.auth.logout('/')}
              className="w-full flex items-center justify-center gap-2 h-11 rounded-xl bg-red-500/10 text-red-400 text-sm font-medium">
              <LogOut className="w-4 h-4" /> Cerrar sesión
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
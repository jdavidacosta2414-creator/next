import React, { useState, useEffect, useRef } from 'react';
import { MapboxMarker } from '@/components/shared/MapboxMap';
import { topDownCarMarkerEl, topDownMotoMarkerEl } from '@/lib/mapboxMarkers';
import { base44 } from '@/api/base44Client';

// Ventana de latido en tiempo real (3 min): solo aparecen conductores realmente conectados
// con la app activa (useDriverTracking envía latido cada 25s).
const LIVE_WINDOW_MS = 3 * 60 * 1000;
const REFRESH_MS = 15 * 1000;

function parseUtcMs(dateStr) {
  if (!dateStr) return 0;
  const s = String(dateStr);
  const iso = s.endsWith('Z') || /[+-]\d{2}:\d{2}$/.test(s) ? s : s + 'Z';
  const t = new Date(iso).getTime();
  return Number.isNaN(t) ? 0 : t;
}

function isLiveConnectedDriver(m, now = Date.now()) {
  if (!m || m.status !== 'disponible' || m.blocked) return false;
  if (m.current_lat == null || m.current_lng == null) return false;
  const updatedMs = parseUtcMs(m.updated_date);
  if (!updatedMs) return false;
  return now - updatedMs <= LIVE_WINDOW_MS;
}

function bearingBetween(lat1, lng1, lat2, lng2) {
  const toRad = (d) => (d * Math.PI) / 180;
  const toDeg = (r) => (r * 180) / Math.PI;
  const φ1 = toRad(lat1);
  const φ2 = toRad(lat2);
  const Δλ = toRad(lng2 - lng1);
  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
  return (toDeg(Math.atan2(y, x)) + 360) % 360;
}

export default function DriversLayer({ vehicleType = null }) {
  const [drivers, setDrivers] = useState([]);
  const prevCoordsRef = useRef({});

  const refresh = async () => {
    try {
      const since = new Date(Date.now() - LIVE_WINDOW_MS).toISOString();
      const mobs = await base44.entities.Mobile.filter(
        {
          status: 'disponible',
          updated_date: { $gte: since },
        },
        {
          sort: '-updated_date',
          limit: 40,
          fields: ['id', 'status', 'blocked', 'vehicle_type', 'current_lat', 'current_lng', 'updated_date'],
        }
      );
      const now = Date.now();
      const list = Array.isArray(mobs) ? mobs : mobs?.items || [];
      const realDrivers = list
        .filter((m) => isLiveConnectedDriver(m, now))
        .map((m) => {
          const prev = prevCoordsRef.current[m.id];
          let heading = prev?.heading ?? 0;
          if (prev && (prev.lat !== m.current_lat || prev.lng !== m.current_lng)) {
            heading = bearingBetween(prev.lat, prev.lng, m.current_lat, m.current_lng);
          }
          prevCoordsRef.current[m.id] = { lat: m.current_lat, lng: m.current_lng, heading };
          return {
            id: m.id,
            vehicle_type: m.vehicle_type || 'moto',
            current_lat: m.current_lat,
            current_lng: m.current_lng,
            heading,
            updated_date: m.updated_date,
          };
        });

      setDrivers(realDrivers);
    } catch {
      // Conservar últimos conductores conectados si falla una lectura puntual
    }
  };

  useEffect(() => {
    refresh();
    const interval = setInterval(refresh, REFRESH_MS);

    const unsub = base44.entities.Mobile.subscribe((event) => {
      const m = event.data;
      setDrivers((prev) => {
        if (event.type === 'delete') return prev.filter((d) => d.id !== event.id);
        if (!m) return prev;
        const idx = prev.findIndex((d) => d.id === event.id);
        // Al recibir un evento en tiempo real por suscripción, el móvil acaba de reportar estado
        if (m.status === 'disponible' && !m.blocked && m.current_lat != null && m.current_lng != null) {
          const old = prevCoordsRef.current[m.id];
          const heading =
            old && (old.lat !== m.current_lat || old.lng !== m.current_lng)
              ? bearingBetween(old.lat, old.lng, m.current_lat, m.current_lng)
              : old?.heading ?? 0;
          prevCoordsRef.current[m.id] = { lat: m.current_lat, lng: m.current_lng, heading };
          const updatedDriver = {
            id: m.id,
            vehicle_type: m.vehicle_type || 'moto',
            current_lat: m.current_lat,
            current_lng: m.current_lng,
            heading,
            updated_date: m.updated_date || new Date().toISOString(),
          };
          if (idx === -1) return [updatedDriver, ...prev];
          const copy = [...prev];
          copy[idx] = updatedDriver;
          return copy;
        }
        return idx === -1 ? prev : prev.filter((d) => d.id !== event.id);
      });
    });

    return () => {
      clearInterval(interval);
      unsub();
    };
  }, []);

  const visibleDrivers = vehicleType
    ? drivers.filter((d) => (d.vehicle_type || 'moto') === vehicleType)
    : drivers;

  return (
    <>
      {visibleDrivers.map((d) => (
        <MapboxMarker
          key={d.id}
          lat={d.current_lat}
          lng={d.current_lng}
          rotation={d.heading}
          smooth
          el={() => (d.vehicle_type === 'carro' ? topDownCarMarkerEl(32) : topDownMotoMarkerEl(30))}
          interactive={false}
        />
      ))}
    </>
  );
}
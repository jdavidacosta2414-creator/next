import React, { useState, useEffect, useMemo, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useBackButton } from '@/hooks/useBackButton';
import {
  Navigation,
  Layers,
  LocateFixed,
  CornerUpLeft,
  CornerUpRight,
  ArrowUp,
  Wallet,
  ChevronRight,
  AlertTriangle,
  Camera,
  Construction,
  X,
} from 'lucide-react';
import { useMapboxToken, DEFAULT_MAPBOX_TOKEN } from '@/hooks/useMapboxToken';
import MapboxMap, {
  MapboxMarker,
  MapboxDrivingRoute,
  MapboxFitBounds,
  MapboxFollowCenter,
} from '@/components/shared/MapboxMap';
import {
  stopPinEl,
  topDownCarMarkerEl,
  topDownMotoMarkerEl,
  bluePulsePointEl,
  redDestinationPinEl,
} from '@/lib/mapboxMarkers';
import MapTileError from '@/components/shared/MapTileError';
import { shortAddress } from '@/lib/shortAddress';
import { getActiveTurnInstruction, clearRouteCache, snapDriverToRoute } from '@/lib/mapRoute';
import {
  getAllRoadHazards,
  addRoadHazardReport,
  findNearestUpcomingHazard,
  roadHazardMarkerEl,
} from '@/lib/roadHazardsValledupar';
import { useToast } from '@/components/ui/use-toast';

function bearingBetween(lat1, lng1, lat2, lng2) {
  const toRad = (d) => (d * Math.PI) / 180;
  const toDeg = (r) => (r * 180) / Math.PI;
  const φ1 = toRad(lat1);
  const φ2 = toRad(lat2);
  const Δλ = toRad(lng2 - lng1);
  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
  return (toDeg(Math.atan2(y, x)) + 360) % 360;
}

// Proyecta un punto adelante del vehículo según su rumbo (en metros) para que la cámara
// muestre siempre la ruta azul por delante del carro y el carro quede arriba de la tarjeta inferior.
function projectPointAhead(lat, lng, bearingDeg = 0, metersAhead = 65) {
  const rad = (Number(bearingDeg || 0) * Math.PI) / 180;
  const dLat = (metersAhead * Math.cos(rad)) / 111320;
  const cosLat = Math.max(0.2, Math.cos((Number(lat) * Math.PI) / 180));
  const dLng = (metersAhead * Math.sin(rad)) / (111320 * cosLat);
  return [Number(lat) + dLat, Number(lng) + dLng];
}

function distanceMeters(lat1, lng1, lat2, lng2) {
  const R = 6371000;
  const toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function shortestAngleDelta(fromDeg, toDeg) {
  return ((toDeg - fromDeg + 540) % 360) - 180;
}

function routeBearingAt(coords, lat, lng) {
  if (!coords || coords.length < 2) return null;
  let minDist = Infinity;
  let idx = 0;
  for (let i = 0; i < coords.length; i++) {
    const d = (coords[i][0] - lat) ** 2 + (coords[i][1] - lng) ** 2;
    if (d < minDist) {
      minDist = d;
      idx = i;
    }
  }
  let targetIdx = Math.min(idx + 1, coords.length - 1);
  for (let j = idx + 1; j < coords.length; j++) {
    const dist = distanceMeters(coords[idx][0], coords[idx][1], coords[j][0], coords[j][1]);
    targetIdx = j;
    if (dist >= 22) break;
  }
  if (targetIdx === idx && idx > 0) {
    return bearingBetween(coords[idx - 1][0], coords[idx - 1][1], coords[idx][0], coords[idx][1]);
  }
  return bearingBetween(coords[idx][0], coords[idx][1], coords[targetIdx][0], coords[targetIdx][1]);
}

function computeAdaptiveStreetZoom(coords, lat, lng) {
  if (!coords || coords.length < 3 || lat == null || lng == null) return 16.5;
  let minDist = Infinity;
  let idx = 0;
  for (let i = 0; i < coords.length; i++) {
    const d = (coords[i][0] - lat) ** 2 + (coords[i][1] - lng) ** 2;
    if (d < minDist) {
      minDist = d;
      idx = i;
    }
  }
  const nextIdx = Math.min(idx + 1, coords.length - 1);
  if (nextIdx === idx) return 16.5;

  const baseHeading = bearingBetween(
    coords[idx][0],
    coords[idx][1],
    coords[nextIdx][0],
    coords[nextIdx][1]
  );

  let walkedMeters = 0;
  let maxTurnAngle = 0;
  for (let j = idx; j < coords.length - 1 && walkedMeters < 110; j++) {
    const segDist = distanceMeters(
      coords[j][0],
      coords[j][1],
      coords[j + 1][0],
      coords[j + 1][1]
    );
    walkedMeters += segDist;
    if (segDist > 2) {
      const segHeading = bearingBetween(
        coords[j][0],
        coords[j][1],
        coords[j + 1][0],
        coords[j + 1][1]
      );
      const turn = Math.abs(shortestAngleDelta(baseHeading, segHeading));
      if (turn > maxTurnAngle) maxTurnAngle = turn;
    }
  }

  if (maxTurnAngle >= 35) return 17.2;
  if (maxTurnAngle >= 15) return 16.8;
  return 16.4;
}

export default function DriverMap({
  mobileId,
  initialDriverLat = null,
  initialDriverLng = null,
  initialVehicleType = null,
  initialVehicleColor = '',
  initialIsTaxi = false,
  driverEarnings = 0,
  onOpenEarnings,
  pickupLat,
  pickupLng,
  destLat,
  destLng,
  stops = [],
  pickupAddress = '',
  destAddress = '',
  phase = 'to_pickup',
  onRoutesUpdate = null,
}) {
  const { toast } = useToast();
  const [driverPos, setDriverPos] = useState(() =>
    initialDriverLat != null && initialDriverLng != null
      ? [Number(initialDriverLat), Number(initialDriverLng)]
      : null
  );
  const [vehicleType, setVehicleType] = useState(initialVehicleType || 'moto');
  const [vehicleColor, setVehicleColor] = useState(initialVehicleColor || '');
  const [isTaxiOrYellow, setIsTaxiOrYellow] = useState(Boolean(initialIsTaxi));
  const [tileError, setTileError] = useState(false);
  const [toPickupRoute, setToPickupRoute] = useState(null);
  const [toDestRoute, setToDestRoute] = useState(null);
  const [gpsHeading, setGpsHeading] = useState(null);
  const [following, setFollowing] = useState(true);
  const [recenterTick, setRecenterTick] = useState(1);
  const [routeRefreshSignal, setRouteRefreshSignal] = useState(0);
  const [reroutingBanner, setReroutingBanner] = useState(false);
  const [showHazardsLayer, setShowHazardsLayer] = useState(true);
  const [reportMenuOpen, setReportMenuOpen] = useState(false);
  const [mapExpanded, setMapExpanded] = useState(false);
  const [hazards, setHazards] = useState(() => getAllRoadHazards());
  const [overviewFitTick, setOverviewFitTick] = useState(1);

  useBackButton(() => {
    if (reportMenuOpen) {
      setReportMenuOpen(false);
      return true;
    }
    if (mapExpanded) {
      setMapExpanded(false);
      return true;
    }
    return false;
  }, true);
  const prevGpsPosRef = useRef(null);
  const hasLocalGpsRef = useRef(false);
  const snappedSegIdxRef = useRef(0);
  const spokenHazardIdsRef = useRef(new Set());
  const hookToken = useMapboxToken();
  const token = hookToken || DEFAULT_MAPBOX_TOKEN;
  const onRoutesRef = useRef(onRoutesUpdate);
  onRoutesRef.current = onRoutesUpdate;

  useEffect(() => {
    const syncHazards = () => setHazards(getAllRoadHazards());
    window.addEventListener('next-road-hazards-updated', syncHazards);
    return () => window.removeEventListener('next-road-hazards-updated', syncHazards);
  }, []);

  useEffect(() => {
    onRoutesRef.current?.({
      driverPos,
      toPickupRoute,
      toDestRoute,
    });
  }, [driverPos, toPickupRoute, toDestRoute]);

  useEffect(() => {
    if (!mobileId) return;
    let alive = true;
    (async () => {
      try {
        const m = await base44.entities.Mobile.get(mobileId);
        if (!alive || !m) return;
        if (m.vehicle_type) setVehicleType(m.vehicle_type);
        if (m.vehicle_color) setVehicleColor(m.vehicle_color);
        setIsTaxiOrYellow(m.car_subtype === 'taxi');
        if (!hasLocalGpsRef.current && m.current_lat != null && m.current_lng != null) {
          setDriverPos([Number(m.current_lat), Number(m.current_lng)]);
        }
      } catch {}
    })();
    const unsub = base44.entities.Mobile.subscribe((event) => {
      if (event.id === mobileId && event.data) {
        if (event.data.vehicle_type) setVehicleType(event.data.vehicle_type);
        if (event.data.vehicle_color != null) setVehicleColor(event.data.vehicle_color);
        if (event.data.car_subtype != null) {
          setIsTaxiOrYellow(event.data.car_subtype === 'taxi');
        }
        // Evitar que el eco retrasado de la base de datos mueva el carro hacia atrás cuando el GPS local está activo
        if (!hasLocalGpsRef.current && event.data.current_lat != null && event.data.current_lng != null) {
          const nextLat = Number(event.data.current_lat);
          const nextLng = Number(event.data.current_lng);
          const prev = prevGpsPosRef.current;
          if (!prev || distanceMeters(prev[0], prev[1], nextLat, nextLng) > 6) {
            if (prev) {
              setGpsHeading(bearingBetween(prev[0], prev[1], nextLat, nextLng));
            }
            prevGpsPosRef.current = [nextLat, nextLng];
            setDriverPos([nextLat, nextLng]);
          }
        }
      }
    });
    return () => {
      alive = false;
      unsub();
    };
  }, [mobileId]);

  useEffect(() => {
    if (!navigator.geolocation) return;
    let lastSyncedAt = 0;
    let lastSyncedPos = null;
    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        if (pos?.coords?.latitude != null && pos?.coords?.longitude != null) {
          hasLocalGpsRef.current = true;
          const nextLat = pos.coords.latitude;
          const nextLng = pos.coords.longitude;
          const prev = prevGpsPosRef.current;
          const movedM = prev ? distanceMeters(prev[0], prev[1], nextLat, nextLng) : Infinity;
          // Ignorar micro-saltos del GPS (< 3.5 m) cuando el vehículo está detenido o en semáforo
          if (movedM < 3.5) return;

          if (
            typeof pos.coords.heading === 'number' &&
            !Number.isNaN(pos.coords.heading) &&
            pos.coords.heading >= 0 &&
            (pos.coords.speed == null || pos.coords.speed > 1.2)
          ) {
            setGpsHeading(pos.coords.heading);
          } else if (prev && movedM >= 6) {
            setGpsHeading(bearingBetween(prev[0], prev[1], nextLat, nextLng));
          }
          prevGpsPosRef.current = [nextLat, nextLng];
          setDriverPos([nextLat, nextLng]);

          const now = Date.now();
          const movedSinceSync = lastSyncedPos
            ? distanceMeters(lastSyncedPos[0], lastSyncedPos[1], nextLat, nextLng)
            : Infinity;
          if (mobileId && movedSinceSync >= 6 && now - lastSyncedAt >= 2000) {
            lastSyncedAt = now;
            lastSyncedPos = [nextLat, nextLng];
            base44.entities.Mobile.update(mobileId, {
              current_lat: nextLat,
              current_lng: nextLng,
            }).catch(() => {});
          }
        }
      },
      () => {},
      { enableHighAccuracy: true, maximumAge: 1500, timeout: 8000 }
    );
    return () => {
      try {
        navigator.geolocation.clearWatch(watchId);
      } catch {}
    };
  }, [mobileId]);

  const pickupPos =
    pickupLat != null && pickupLng != null ? [Number(pickupLat), Number(pickupLng)] : null;
  const destPos =
    destLat != null && destLng != null ? [Number(destLat), Number(destLng)] : null;
  const stopWaypoints = useMemo(
    () =>
      (stops || [])
        .filter((s) => s?.lat != null && s?.lng != null)
        .map((s) => [Number(s.lat), Number(s.lng)]),
    [stops]
  );

  const effectiveVehiclePos = useMemo(() => {
    if (driverPos) return driverPos;
    if (pickupPos) return pickupPos;
    if (destPos) return destPos;
    return [10.4631, -73.2532];
  }, [driverPos, pickupPos, destPos]);

  const hasSeparateDriverToPickup = useMemo(() => {
    if (!driverPos || !pickupPos) return false;
    return (
      Math.abs(driverPos[0] - pickupPos[0]) > 0.00015 ||
      Math.abs(driverPos[1] - pickupPos[1]) > 0.00015
    );
  }, [driverPos, pickupPos]);

  const activeRoute = useMemo(() => {
    if (phase === 'to_pickup' && hasSeparateDriverToPickup && toPickupRoute?.coords?.length > 1) {
      return toPickupRoute;
    }
    return toDestRoute || toPickupRoute;
  }, [phase, hasSeparateDriverToPickup, toPickupRoute, toDestRoute]);

  useEffect(() => {
    snappedSegIdxRef.current = 0;
  }, [activeRoute?.coords]);

  // Ajusta el vehículo exactamente sobre el eje de la ruta activa mientras circula por ella
  // para que el carro quede fijo y alineado con la vía sin moverse hacia los lados.
  const routeSnap = useMemo(() => {
    if (!effectiveVehiclePos || !activeRoute?.coords || activeRoute.coords.length < 2) {
      return null;
    }
    const snap = snapDriverToRoute(
      activeRoute.coords,
      effectiveVehiclePos[0],
      effectiveVehiclePos[1],
      snappedSegIdxRef.current
    );
    if (snap.onRoute) {
      snappedSegIdxRef.current = Math.max(snappedSegIdxRef.current, snap.segIndex);
    }
    return snap;
  }, [effectiveVehiclePos, activeRoute?.coords]);

  const displayVehiclePos = useMemo(() => {
    if (routeSnap?.onRoute && routeSnap.snappedPos) {
      return routeSnap.snappedPos;
    }
    return effectiveVehiclePos;
  }, [routeSnap, effectiveVehiclePos]);

  const bearing = useMemo(() => {
    if (!displayVehiclePos) return 0;
    // Mientras el conductor va sobre la ruta, fijar el rumbo al sentido de la calle de la ruta
    if (routeSnap?.onRoute && activeRoute?.coords?.length > 1) {
      const b = routeBearingAt(
        activeRoute.coords,
        displayVehiclePos[0],
        displayVehiclePos[1]
      );
      if (b != null && !Number.isNaN(b)) return b;
    }
    if (gpsHeading != null && !Number.isNaN(gpsHeading)) {
      return ((gpsHeading % 360) + 360) % 360;
    }
    if (activeRoute?.coords?.length > 1) {
      const b = routeBearingAt(
        activeRoute.coords,
        displayVehiclePos[0],
        displayVehiclePos[1]
      );
      if (b != null && !Number.isNaN(b)) return b;
    }
    const target =
      phase === 'to_pickup' && hasSeparateDriverToPickup
        ? pickupPos
        : stopWaypoints[0] || destPos || pickupPos;
    if (target) {
      return bearingBetween(
        displayVehiclePos[0],
        displayVehiclePos[1],
        target[0],
        target[1]
      );
    }
    return 0;
  }, [
    routeSnap,
    gpsHeading,
    displayVehiclePos,
    activeRoute,
    phase,
    hasSeparateDriverToPickup,
    pickupPos,
    stopWaypoints,
    destPos,
  ]);

  const adaptiveZoom = useMemo(() => {
    if (!effectiveVehiclePos) return 16.5;
    return computeAdaptiveStreetZoom(
      activeRoute?.coords,
      effectiveVehiclePos[0],
      effectiveVehiclePos[1]
    );
  }, [activeRoute?.coords, effectiveVehiclePos]);

  const upcomingHazard = useMemo(
    () => findNearestUpcomingHazard(effectiveVehiclePos),
    [effectiveVehiclePos, hazards]
  );

  // Aviso por voz cuando el conductor se acerca a una cámara de fotomulta o calle en construcción
  useEffect(() => {
    if (!upcomingHazard?.id || spokenHazardIdsRef.current.has(upcomingHazard.id)) return;
    spokenHazardIdsRef.current.add(upcomingHazard.id);
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        const msg =
          upcomingHazard.type === 'fotomulta'
            ? `Atención: cámara de fotomulta a ${upcomingHazard.distanceMeters} metros. Límite ${upcomingHazard.speedLimit || 50} kilómetros por hora.`
            : `Atención: vía en construcción a ${upcomingHazard.distanceMeters} metros.`;
        const u = new SpeechSynthesisUtterance(msg);
        u.lang = 'es-ES';
        u.rate = 1.08;
        window.speechSynthesis.speak(u);
      } catch {}
    }
  }, [upcomingHazard]);

  const handleReportHazard = (type) => {
    const pos = effectiveVehiclePos;
    if (!pos) return;
    addRoadHazardReport({
      type,
      lat: pos[0],
      lng: pos[1],
    });
    clearRouteCache();
    setHazards(getAllRoadHazards());
    setReportMenuOpen(false);
    setReroutingBanner(true);
    setRouteRefreshSignal((s) => s + 1);
    setTimeout(() => setReroutingBanner(false), 3000);
    toast({
      title:
        type === 'fotomulta'
          ? '📸 Cámara de fotomulta marcada en el mapa'
          : '🚧 Calle tapada marcada · Recalculando ruta',
      description:
        type === 'fotomulta'
          ? 'Se alertará al pasar por este punto.'
          : 'El mapa buscará automáticamente la mejor vía alterna.',
    });
  };

  const turnInstruction = getActiveTurnInstruction(
    activeRoute,
    effectiveVehiclePos,
    phase === 'to_dest' ? destAddress : pickupAddress
  );

  const TurnIcon =
    turnInstruction.maneuver?.includes('left')
      ? CornerUpLeft
      : turnInstruction.maneuver === 'straight'
      ? ArrowUp
      : CornerUpRight;

  const lookAheadCenter = useMemo(() => {
    if (!displayVehiclePos) return [10.4631, -73.2532];
    return displayVehiclePos;
  }, [displayVehiclePos]);

  const allPointsForOverview = useMemo(
    () => [
      displayVehiclePos,
      ...(pickupPos ? [pickupPos] : []),
      ...stopWaypoints,
      ...(destPos ? [destPos] : []),
    ],
    [displayVehiclePos, pickupPos, stopWaypoints, destPos]
  );

  return (
    <div
      className={`isolate w-full overflow-hidden ${
        mapExpanded
          ? 'fixed inset-0 z-[1550] h-full w-full max-w-md mx-auto'
          : 'relative z-0 h-[70dvh] min-h-[420px] border-b border-border shadow-sm'
      }`}
      data-testid="driver-active-map"
    >
      <MapboxMap
        center={following ? lookAheadCenter : displayVehiclePos}
        zoom={following ? 16.6 : 15}
        pitch={following ? 50 : 0}
        bearing={following ? bearing : 0}
        onMapClick={() => setMapExpanded((v) => !v)}
        onDragStart={() => setFollowing(false)}
        className="h-full w-full overflow-hidden"
        onTileError={() => setTileError(true)}
      >
        {/* Vehículo del conductor fijo sobre el eje de la ruta en su color real registrado */}
        {displayVehiclePos && (
          <MapboxMarker
            key={`drv-self-${vehicleType}-${vehicleColor}-${isTaxiOrYellow}`}
            lat={displayVehiclePos[0]}
            lng={displayVehiclePos[1]}
            el={() =>
              vehicleType === 'carro'
                ? topDownCarMarkerEl(38, vehicleColor || isTaxiOrYellow)
                : topDownMotoMarkerEl(35)
            }
            rotation={bearing}
            alignWithMap={following}
            interactive={false}
          />
        )}

        {/* Punto de recogida */}
        {pickupPos && (
          <MapboxMarker
            lat={pickupPos[0]}
            lng={pickupPos[1]}
            el={() => bluePulsePointEl()}
            anchor="center"
            interactive={false}
          />
        )}

        {/* Paradas intermedias */}
        {(stops || []).map((st, idx) =>
          st?.lat != null && st?.lng != null ? (
            <MapboxMarker
              key={`stop-${idx}`}
              lat={st.lat}
              lng={st.lng}
              el={() => stopPinEl(idx + 1, shortAddress(st.address) || st.address, false)}
              labelTitle={`Parada ${idx + 1}`}
              labelAddress={shortAddress(st.address) || st.address}
              showBubble={false}
              anchor="bottom"
              interactive={false}
            />
          ) : null
        )}

        {/* Punto de destino */}
        {destPos && (
          <MapboxMarker
            lat={destPos[0]}
            lng={destPos[1]}
            el={() => redDestinationPinEl()}
            anchor="bottom"
            interactive={false}
          />
        )}

        {/* Marcadores de Fotomultas 📸 y Calles en obra / construcción 🚧 */}
        {showHazardsLayer &&
          hazards.map((hz) => (
            <MapboxMarker
              key={hz.id}
              lat={hz.lat}
              lng={hz.lng}
              el={() => roadHazardMarkerEl(hz)}
              anchor="bottom"
              interactive={false}
            />
          ))}

        {/* Ruta hacia punto de recogida con recálculo automático si el conductor toma otra calle */}
        {phase === 'to_pickup' && driverPos && pickupPos && hasSeparateDriverToPickup && (
          <MapboxDrivingRoute
            from={driverPos}
            to={pickupPos}
            color="#1463FF"
            width={6}
            opacity={0.96}
            refreshSignal={routeRefreshSignal}
            trimFromPos={driverPos}
            onReroute={() => {
              setReroutingBanner(true);
              setTimeout(() => setReroutingBanner(false), 2600);
            }}
            onRouteInfo={setToPickupRoute}
          />
        )}

        {/* Ruta hacia destino final con recálculo automático y desvío de calles en obra */}
        {pickupPos && destPos && (
          <MapboxDrivingRoute
            from={phase === 'to_dest' && driverPos ? driverPos : pickupPos}
            to={destPos}
            waypoints={stopWaypoints}
            color="#1463FF"
            width={6}
            opacity={0.94}
            refreshSignal={routeRefreshSignal}
            trimFromPos={phase === 'to_dest' ? driverPos : null}
            onReroute={() => {
              setReroutingBanner(true);
              setTimeout(() => setReroutingBanner(false), 2600);
            }}
            onRouteInfo={setToDestRoute}
          />
        )}

        {following && lookAheadCenter && (
          <MapboxFollowCenter
            center={lookAheadCenter}
            bearing={bearing}
            pitch={50}
            zoom={16.6}
            padding={{ top: 165, bottom: 35, left: 0, right: 0 }}
            recenterKey={recenterTick}
            following={following}
          />
        )}

        {!following && allPointsForOverview.length > 0 && (
          <MapboxFitBounds
            positions={allPointsForOverview}
            padding={{ top: 135, bottom: 95, left: 45, right: 65 }}
            singleZoom={15.5}
            fitKey={`drv-overview-${overviewFitTick}-${phase}`}
          />
        )}
      </MapboxMap>

      {/* Cabecera flotante sobre el mapa:
          1) Píldoras superiores: "● Conectado" (verde) y "👛 $12.500 >" (blanca)
          2) Banner azul de navegación: "Gira a la izquierda en Calle 18 F · 300 m" */}
      <div className="absolute top-2.5 inset-x-3 z-20 space-y-2 pointer-events-none">
        <div className="flex items-center justify-between gap-2">
          <div className="pointer-events-auto inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#22C55E] text-white text-xs font-extrabold shadow-lg">
            <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
            <span>Conectado</span>
          </div>

          <button
            type="button"
            onClick={() => onOpenEarnings?.()}
            className="pointer-events-auto inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white dark:bg-card text-[#0F172A] dark:text-white text-xs font-extrabold shadow-lg border border-slate-200/80 dark:border-border active:scale-95 transition-transform"
          >
            <Wallet className="w-3.5 h-3.5 text-[#0F172A] dark:text-white" />
            <span>${Number(driverEarnings || 0).toLocaleString('es-CO')}</span>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          </button>
        </div>

        {/* Banner azul de giro paso a paso */}
        <div className="pointer-events-auto rounded-2xl bg-[#0B439C] text-white px-4 py-2.5 shadow-xl border border-white/15 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center flex-shrink-0">
              <TurnIcon className="w-5 h-5 text-white stroke-[2.8]" />
            </div>
            <div className="min-w-0">
              <p className="text-[15px] font-extrabold leading-tight truncate">
                {reroutingBanner ? 'Recalculando ruta...' : turnInstruction.actionTitle}
              </p>
              <p className="text-xs text-white/85 font-medium truncate">
                {reroutingBanner
                  ? 'Ajustando al nuevo camino del conductor'
                  : `en ${turnInstruction.streetName}`}
              </p>
            </div>
          </div>
          <span className="text-base font-black whitespace-nowrap flex-shrink-0">
            {turnInstruction.distanceText}
          </span>
        </div>

        {/* Alerta en vivo si hay Fotomulta cercana o Calle tapada por construcción */}
        {(upcomingHazard || activeRoute?.avoidedConstruction) && (
          <div
            className={`pointer-events-auto rounded-xl px-3 py-1.5 shadow-md flex items-center justify-between gap-2 text-xs font-extrabold ${
              upcomingHazard?.type === 'fotomulta'
                ? 'bg-amber-400 text-slate-950'
                : 'bg-orange-600 text-white'
            }`}
          >
            <div className="flex items-center gap-1.5 truncate">
              <AlertTriangle className="w-4 h-4 flex-shrink-0" />
              <span className="truncate">
                {upcomingHazard
                  ? `${upcomingHazard.type === 'fotomulta' ? '📸' : '🚧'} ${upcomingHazard.title} a ${upcomingHazard.distanceMeters} m`
                  : '🚧 Ruta optimizada evitando calle en construcción'}
              </span>
            </div>
            {upcomingHazard?.speedLimit && (
              <span className="px-1.5 py-0.5 rounded bg-slate-950 text-amber-300 text-[10px] font-black flex-shrink-0">
                {upcomingHazard.speedLimit} km/h
              </span>
            )}
          </div>
        )}
      </div>

      {/* 3 botones circulares flotantes a la derecha del mapa */}
      <div className="absolute right-3 bottom-9 z-20 flex flex-col gap-2">
        <button
          type="button"
          onClick={() => {
            setFollowing(true);
            setRecenterTick((t) => t + 1);
          }}
          data-testid="driver-recenter-3d-btn"
          title="Centrar guía en el carro"
          className={`w-10 h-10 rounded-full shadow-lg border flex items-center justify-center active:scale-95 transition-all ${
            following
              ? 'bg-[#1463FF] text-white border-[#1463FF]'
              : 'bg-white text-[#1463FF] border-slate-200'
          }`}
        >
          <Navigation className="w-4 h-4 fill-current" />
        </button>

        <button
          type="button"
          onClick={() => setReportMenuOpen((v) => !v)}
          title="Capas viales: Fotomultas y Calles en obra"
          className={`w-10 h-10 rounded-full shadow-lg border flex items-center justify-center active:scale-95 transition-all ${
            reportMenuOpen
              ? 'bg-[#0B439C] text-white border-[#0B439C]'
              : 'bg-white text-slate-800 border-slate-200'
          }`}
        >
          <Layers className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={() => {
            setFollowing(false);
            setOverviewFitTick((t) => t + 1);
          }}
          title="Ver ruta completa / Centrar"
          className="w-10 h-10 rounded-full bg-white text-slate-800 shadow-lg border border-slate-200 flex items-center justify-center active:scale-95 transition-transform"
        >
          <LocateFixed className="w-4 h-4" />
        </button>
      </div>

      {/* Menú rápido de inteligencia vial: reportar calle tapada por construcción o fotomulta y recalcular */}
      {reportMenuOpen && (
        <div className="absolute right-14 bottom-8 z-30 w-64 rounded-2xl bg-white dark:bg-card shadow-2xl border border-slate-200 dark:border-border p-3 space-y-2 animate-in fade-in zoom-in-95 duration-150">
          <div className="flex items-center justify-between">
            <p className="text-xs font-extrabold text-[#0F172A] dark:text-white">
              Asistente vial del mapa
            </p>
            <button
              type="button"
              onClick={() => setReportMenuOpen(false)}
              className="w-6 h-6 rounded-full bg-slate-100 dark:bg-muted flex items-center justify-center text-slate-500"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
          <button
            type="button"
            onClick={() => handleReportHazard('construccion')}
            className="w-full flex items-center gap-2.5 p-2 rounded-xl bg-orange-500/10 hover:bg-orange-500/20 text-orange-700 dark:text-orange-300 text-xs font-bold text-left"
          >
            <Construction className="w-4 h-4 flex-shrink-0" />
            <span>Marcar calle tapada / obra y desviar ruta</span>
          </button>
          <button
            type="button"
            onClick={() => handleReportHazard('fotomulta')}
            className="w-full flex items-center gap-2.5 p-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-700 dark:text-amber-300 text-xs font-bold text-left"
          >
            <Camera className="w-4 h-4 flex-shrink-0" />
            <span>Marcar cámara de fotomulta aquí</span>
          </button>
          <button
            type="button"
            onClick={() => {
              clearRouteCache();
              setReroutingBanner(true);
              setRouteRefreshSignal((s) => s + 1);
              setReportMenuOpen(false);
              setTimeout(() => setReroutingBanner(false), 2200);
            }}
            className="w-full flex items-center justify-center gap-1.5 py-2 rounded-xl bg-[#EAF2FF] dark:bg-[#1E6BFF]/20 text-[#0B439C] dark:text-sky-300 text-xs font-extrabold"
          >
            <Navigation className="w-3.5 h-3.5" />
            <span>Recalcular mejor ruta ahora</span>
          </button>
          <label className="flex items-center justify-between pt-1 border-t border-border text-[11px] text-muted-foreground font-semibold cursor-pointer">
            <span>Mostrar alertas en el mapa</span>
            <input
              type="checkbox"
              checked={showHazardsLayer}
              onChange={(e) => setShowHazardsLayer(e.target.checked)}
              className="accent-[#0B439C]"
            />
          </label>
        </div>
      )}

      {mapExpanded && (
        <div className="absolute bottom-5 inset-x-4 z-20 flex justify-center pointer-events-none">
          <button
            type="button"
            onClick={() => setMapExpanded(false)}
            className="pointer-events-auto px-5 h-11 rounded-full bg-[#0B439C] text-white text-xs font-extrabold shadow-2xl border border-white/25 flex items-center justify-center gap-2 active:scale-95 transition-transform"
          >
            Ver panel del servicio
          </button>
        </div>
      )}

      {tileError && <MapTileError />}
    </div>
  );
}
import React from "react";
import NextLogo from "@/components/NextLogo";
import ThemeToggle from "@/components/ThemeToggle";

export default function AuthLayout({ title, subtitle, footer, children }) {
  return (
    <div className="min-h-screen bg-white dark:bg-black flex flex-col px-6 py-8 max-w-md mx-auto w-full">
      <div className="flex justify-end mb-8">
        <ThemeToggle />
      </div>
      <div className="text-center mb-8">
        <div className="flex justify-center mb-5">
          <NextLogo size="md" />
        </div>
        <h1 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white">{title}</h1>
        {subtitle && <p className="text-gray-500 dark:text-[#A0A0A0] mt-2 text-sm">{subtitle}</p>}
      </div>
      <div className="rounded-2xl">
        {children}
      </div>
      {footer && (
        <p className="text-center text-sm text-gray-500 dark:text-[#A0A0A0] mt-6">{footer}</p>
      )}
    </div>
  );
}
import React, { useState } from 'react';
import {
  ChevronLeft, Bell, MapPin, Languages, FileText, Info, Mail,
  Facebook, Instagram, Music2, LogOut, Trash2, Loader2, ShieldAlert, Layers, Volume2, VolumeX,
} from 'lucide-react';
import { isServiceAlertMuted, setServiceAlertMuted } from '@/hooks/useNewServiceAlert';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useTheme } from '@/lib/ThemeContext';
import { useToast } from '@/components/ui/use-toast';
import TermsModal from '@/components/driver/TermsModal';
import ConfigModal from '@/components/driver/ConfigModal';
import { isFloatingBubbleEnabled, setFloatingBubbleEnabled } from '@/components/shared/NextFloatingBubble';
import { useBackButton } from '@/hooks/useBackButton';

const LANG_LABELS = { es: 'Español', en: 'English', pt: 'Português', fr: 'Français' };

const APP_VERSION = '1.1';
const SUPPORT_EMAIL = 'soportenextapp@gmail.com';

const SOCIAL_LINKS = {
  facebook: 'https://www.facebook.com/nexttransporteymensajeria',
  instagram: 'https://www.instagram.com/nexttransporteymensajeria',
  tiktok: 'https://www.tiktok.com/@nextmensajeriatransport',
};

// Pantalla de configuración del conductor. Usa tokens de tema (claro/oscuro).
export default function DriverConfig({ onBack }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const { theme, setTheme } = useTheme();
  const [termsOpen, setTermsOpen] = useState(false);
  const [modal, setModal] = useState(null);
  const [deleteOpen, setDeleteOpen] = useState(false);

  useBackButton(
    () => {
      if (deleteOpen) {
        setDeleteOpen(false);
        return true;
      }
      if (termsOpen) {
        setTermsOpen(false);
        return true;
      }
      if (modal) {
        setModal(null);
        return true;
      }
      return false;
    },
    true
  );
  const [deletingAccount, setDeletingAccount] = useState(false);
  const [lang, setLang] = useState(() => {
    try { return localStorage.getItem('motolink-lang') || 'es'; } catch { return 'es'; }
  });
  const [floatingBubble, setFloatingBubble] = useState(() => isFloatingBubbleEnabled());
  const [alertMuted, setAlertMuted] = useState(() => isServiceAlertMuted());
  const openUrl = (url) => window.open(url, '_blank', 'noopener,noreferrer');

  const toggleAlertSound = () => {
    const next = !alertMuted;
    setAlertMuted(next);
    setServiceAlertMuted(next);
    toast({
      title: next ? 'Avisos de servicios silenciados' : 'Avisos de servicios con sonido',
      description: next
        ? 'Los servicios nuevos solo vibrarán y aparecerán en pantalla.'
        : 'Escucharás el tono de aviso con cada servicio nuevo.',
    });
  };

  const toggleFloatingBubble = () => {
    const next = !floatingBubble;
    setFloatingBubble(next);
    setFloatingBubbleEnabled(next);
    toast({
      title: next ? 'Burbuja flotante NEXT activada' : 'Burbuja flotante desactivada',
      description: next
        ? 'La burbuja con el logo NEXT permanecerá visible y podrás moverla por toda la pantalla.'
        : 'Puedes volver a activarla cuando quieras desde Configuración.',
    });
  };

  const selectLang = (v) => {
    setLang(v);
    try { localStorage.setItem('motolink-lang', v); } catch {}
    setModal(null);
  };

  const requestAccountDeletion = async () => {
    setDeletingAccount(true);
    try {
      await base44.entities.Incidence.create({
        title: `Solicitud de eliminación de cuenta (${user?.email || 'Usuario'})`,
        description: `El titular ${user?.display_name || user?.full_name || user?.email || 'Usuario'} (ID: ${user?.id || 'N/A'}, Tel: ${user?.phone || 'N/A'}) solicitó la eliminación de su cuenta y supresión de datos personales conforme a la política de privacidad y Google Play.`,
        category: user?.role === 'movil' ? 'conductor' : 'cliente',
        priority: 'alta',
        status: 'abierta',
      });
      toast({
        title: 'Solicitud de eliminación registrada',
        description: 'Tu solicitud fue enviada a Central para procesar la baja de tu cuenta y datos personales.',
      });
      setDeleteOpen(false);
      setTimeout(() => base44.auth.logout('/'), 1200);
    } catch {
      window.location.href = `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent('Solicitud de eliminación de cuenta NEXT')}`;
      setDeleteOpen(false);
    } finally {
      setDeletingAccount(false);
    }
  };

  const Row = ({ icon: Icon, title, value, onClick }) => (
    <button onClick={onClick} className="w-full flex items-center gap-3 px-4 py-3.5 text-left border-b border-border last:border-0">
      <Icon className="w-5 h-5 text-foreground flex-shrink-0" />
      <div className="flex-1 min-w-0">
        <p className="text-foreground text-sm font-medium">{title}</p>
        {value && <p className="text-muted-foreground text-xs truncate">{value}</p>}
      </div>
      <ChevronLeft className="w-4 h-4 text-muted-foreground rotate-180" />
    </button>
  );

  return (
    <div className="fixed inset-0 z-[1800] bg-background flex flex-col max-w-md mx-auto w-full overflow-y-auto pb-[56px]">
      {/* Encabezado */}
      <div className="flex items-center gap-3 px-4 pt-5 pb-3 flex-shrink-0">
        <button onClick={onBack} className="w-10 h-10 flex items-center justify-center">
          <ChevronLeft className="w-6 h-6 text-foreground" />
        </button>
        <h1 className="text-foreground font-bold text-lg">Configuración de la aplicación</h1>
      </div>

      <div className="flex-1 px-4 pb-6 space-y-4">
        {/* Tarjeta 1: preferencias */}
        <div className="bg-card rounded-2xl shadow-sm overflow-hidden">
          <Row
            icon={Layers}
            title="Burbuja flotante NEXT (Superposición)"
            value={floatingBubble ? 'Activada · Estilo Messenger / Telegram' : 'Desactivada'}
            onClick={toggleFloatingBubble}
          />
          <Row
            icon={alertMuted ? VolumeX : Volume2}
            title="Sonido de servicios nuevos"
            value={alertMuted ? 'Silenciado · solo vibración' : 'Activado · tono de aviso'}
            onClick={toggleAlertSound}
          />
          <Row icon={Bell} title="Apariencia" value={theme === 'dark' ? 'Oscuro' : 'Claro'} onClick={() => setModal('apariencia')} />
          <Row icon={MapPin} title="Unidades de distancia" value="Kilómetros" onClick={() => setModal('unidades')} />
          <Row icon={Languages} title="Idioma" value={LANG_LABELS[lang]} onClick={() => setModal('idioma')} />
        </div>

        {/* Tarjeta 2: info */}
        <div className="bg-card rounded-2xl shadow-sm overflow-hidden">
          <Row icon={FileText} title="Documentos legales" onClick={() => setTermsOpen(true)} />
          <Row icon={Info} title="Versión de la aplicación" value={APP_VERSION} />
        </div>

        {/* Tarjeta 3: contacto + redes */}
        <div className="bg-card rounded-2xl shadow-sm overflow-hidden">
          <Row icon={Mail} title="Correo de soporte" value={SUPPORT_EMAIL} onClick={() => window.location.href = `mailto:${SUPPORT_EMAIL}`} />
          <Row icon={Facebook} title="Facebook" value="NEXT" onClick={() => openUrl(SOCIAL_LINKS.facebook)} />
          <Row icon={Instagram} title="Instagram" value="@nexttransporteymensajeria" onClick={() => openUrl(SOCIAL_LINKS.instagram)} />
          <Row icon={Music2} title="TikTok" value="@nextmensajeriatransport" onClick={() => openUrl(SOCIAL_LINKS.tiktok)} />
        </div>

        {/* Cuenta */}
        <div className="bg-card rounded-2xl shadow-sm overflow-hidden">
          <Row icon={LogOut} title="Cerrar sesión" onClick={() => base44.auth.logout('/')} />
          <Row icon={Trash2} title="Eliminar mi cuenta y datos" value="Derecho de supresión (Habeas Data)" onClick={() => setDeleteOpen(true)} />
        </div>

        <div className="bg-primary/10 rounded-2xl px-4 py-3">
          <p className="text-primary text-xs">
            Algunas configuraciones se movieron para simplificar las cosas. Pulsa para ver más.
          </p>
        </div>
      </div>

      {termsOpen && <TermsModal onClose={() => setTermsOpen(false)} />}

      {deleteOpen && (
        <div className="fixed inset-0 z-[1900] bg-black/60 backdrop-blur-xs flex items-center justify-center p-4" onClick={() => !deletingAccount && setDeleteOpen(false)}>
          <div className="bg-card border border-border rounded-3xl p-5 w-full max-w-sm space-y-4 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-destructive/15 text-destructive flex items-center justify-center flex-shrink-0">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-foreground font-bold text-base">Eliminar cuenta y datos</h3>
                <p className="text-muted-foreground text-xs">Ley 1581 de 2012 · Políticas de Google Play</p>
              </div>
            </div>
            <p className="text-muted-foreground text-xs leading-relaxed">
              Al confirmar, registraremos tu solicitud formal de eliminación de cuenta y supresión de datos personales (incluyendo fotos de verificación y perfil) y cerraremos tu sesión actual.
            </p>
            <div className="flex gap-2.5 pt-1">
              <button
                type="button"
                disabled={deletingAccount}
                onClick={() => setDeleteOpen(false)}
                className="flex-1 h-11 rounded-xl bg-muted text-foreground font-bold text-xs"
              >
                Cancelar
              </button>
              <button
                type="button"
                disabled={deletingAccount}
                onClick={requestAccountDeletion}
                className="flex-1 h-11 rounded-xl bg-destructive text-destructive-foreground font-bold text-xs flex items-center justify-center gap-1.5 disabled:opacity-50"
              >
                {deletingAccount ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Confirmar baja'}
              </button>
            </div>
          </div>
        </div>
      )}

      {modal === 'apariencia' && (
        <ConfigModal
          title="Apariencia"
          options={[{ value: 'light', label: 'Claro' }, { value: 'dark', label: 'Oscuro' }]}
          value={theme}
          onSelect={(v) => { setTheme(v); setModal(null); }}
          onClose={() => setModal(null)}
        />
      )}
      {modal === 'unidades' && (
        <ConfigModal
          title="Unidades de distancia"
          message="La aplicación usará kilómetros."
          onClose={() => setModal(null)}
        />
      )}
      {modal === 'idioma' && (
        <ConfigModal
          title="Idioma"
          options={[
            { value: 'es', label: 'Español' },
            { value: 'en', label: 'English' },
            { value: 'pt', label: 'Português' },
            { value: 'fr', label: 'Français' },
          ]}
          value={lang}
          onSelect={selectLang}
          onClose={() => setModal(null)}
        />
      )}
    </div>
  );
}
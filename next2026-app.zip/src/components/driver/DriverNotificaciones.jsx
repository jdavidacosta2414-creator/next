import React, { useState, useEffect, useMemo } from 'react';
import { ChevronLeft, Bell, Trash2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';

function fmtDate(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  const pad = (n) => String(n).padStart(2, '0');
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function getDismissedDriverNotifs(mobileId) {
  const key = `next_driver_dismissed_notifs_${mobileId || 'anon'}`;
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) || [] : [];
  } catch {
    return [];
  }
}

export function saveDismissedDriverNotifs(mobileId, ids) {
  const unique = Array.from(new Set(ids));
  const key = `next_driver_dismissed_notifs_${mobileId || 'anon'}`;
  try {
    localStorage.setItem(key, JSON.stringify(unique));
  } catch {}
  window.dispatchEvent(new CustomEvent('next-driver-notifs-updated', { detail: { dismissedIds: unique } }));
  return unique;
}

const GOAL_LABELS = {
  dias_conectado: 'Racha de días conectado',
  viajes_dia: 'Meta de viajes del día',
  viajes_semana: 'Meta de viajes de la semana',
};

// Sección "Notificaciones" del menú del conductor.
export default function DriverNotificaciones({ mobile, user, onBack }) {
  const welcomeDate = mobile?.created_date || new Date().toISOString();
  const [dismissedIds, setDismissedIds] = useState(() => getDismissedDriverNotifs(mobile?.id));
  const [rewardNotifs, setRewardNotifs] = useState([]);
  const [referralNotifs, setReferralNotifs] = useState([]);
  const [levelPerfNotifs, setLevelPerfNotifs] = useState([]);

  useEffect(() => {
    setDismissedIds(getDismissedDriverNotifs(mobile?.id));
  }, [mobile?.id]);

  useEffect(() => {
    if (!mobile?.id) return;
    const loadClaims = async () => {
      try {
        const res = await base44.entities.RewardClaim.filter(
          { scope: 'conductor', mobile_id: mobile.id },
          '-created_date',
          30
        );
        const list = res?.items || (Array.isArray(res) ? res : []);
        const mapped = [];
        list.forEach((c) => {
          const goalLabel = GOAL_LABELS[c.goal_type] || 'Meta cumplida';
          if (c.status === 'entregado') {
            mapped.push({
              id: `driver-reward-${c.id}-entregado`,
              title: '¡Bono acreditado en tu Cartera! 🏆',
              body: `Cumpliste tu meta (${goalLabel}) y se acreditó automáticamente "${c.reward}" en tu Cartera.`,
              date: fmtDate(c.updated_date || c.created_date),
            });
          } else if (c.status === 'postulado') {
            mapped.push({
              id: `driver-reward-${c.id}-postulado`,
              title: '¡Te postulaste a una recompensa! 🎯',
              body: `Estás postulado a "${c.reward}" (${goalLabel}). Al cumplir la meta se acreditará automáticamente en tu Cartera.`,
              date: fmtDate(c.created_date),
            });
          } else if (c.status === 'pendiente') {
            mapped.push({
              id: `driver-reward-${c.id}-pendiente`,
              title: '¡Has adquirido una recompensa! 🎁',
              body: `Adquiriste la recompensa "${c.reward}" (${goalLabel}).`,
              date: fmtDate(c.created_date),
            });
          }
        });
        setRewardNotifs(mapped);
      } catch (e) {}
    };
    loadClaims();
    const unsub = base44.entities.RewardClaim.subscribe(() => loadClaims().catch(() => {}));
    return unsub;
  }, [mobile?.id]);

  useEffect(() => {
    if (!mobile?.id && !user?.id) return;
    const loadReferrals = async () => {
      try {
        const page = await base44.entities.PointsTransaction.filter(
          {
            status: 'aprobado',
            type: 'referido_aprobado',
          },
          { sort: '-created_date', limit: 30 }
        );
        const list = (page?.items || []).filter(
          (tx) =>
            tx.referrer_mobile_id === mobile?.id ||
            tx.user_id === mobile?.id ||
            (user?.id && tx.user_id === user.id)
        );
        setReferralNotifs(
          list.map((tx) => ({
            id: `driver-ref-${tx.id}-aprobado`,
            title: `¡Ganaste +${tx.amount} puntos por referido! 🤝`,
            body: `Central aprobó el registro de tu referido${tx.referred_user_name ? ` (${tx.referred_user_name})` : ''} y se abonaron +${tx.amount} puntos ($${tx.amount} COP) en tu Billetera de Puntos.`,
            date: fmtDate(tx.updated_date || tx.created_date),
          }))
        );
      } catch (e) {}
    };
    loadReferrals();
    const unsub = base44.entities.PointsTransaction.subscribe(() => loadReferrals().catch(() => {}));
    return unsub;
  }, [mobile?.id, user?.id]);

  useEffect(() => {
    if (!mobile?.id) return;
    const loadLevelNotifs = async () => {
      try {
        const res = await base44.entities.DriverNotification.filter(
          { mobile_id: mobile.id },
          '-created_date',
          40
        );
        const list = res?.items || (Array.isArray(res) ? res : []);
        setLevelPerfNotifs(
          list
            .filter((n) => !n.dismissed)
            .map((n) => ({
              id: `drv-notif-${n.id}`,
              dbId: n.id,
              title: n.title,
              body: n.message,
              howToImprove: n.how_to_improve || '',
              date: fmtDate(n.created_date),
            }))
        );
      } catch {}
    };
    loadLevelNotifs();
    const unsub = base44.entities.DriverNotification.subscribe(() => loadLevelNotifs().catch(() => {}));
    return unsub;
  }, [mobile?.id]);

  const baseItems = useMemo(
    () => [
      ...levelPerfNotifs,
      ...rewardNotifs,
      ...referralNotifs,
      {
        id: 'welcome',
        title: '¡Bienvenido al equipo NEXT! 🏍️🚗',
        body: 'Tu cuenta de conductor fue activada con éxito. Ya puedes conectarte, activar tu pase de 14 horas y recibir solicitudes en tu ciudad.',
        date: fmtDate(welcomeDate),
      },
    ],
    [levelPerfNotifs, rewardNotifs, referralNotifs, welcomeDate]
  );

  const items = useMemo(
    () => baseItems.filter((n) => !dismissedIds.includes(n.id)),
    [baseItems, dismissedIds]
  );

  const remove = (id) => {
    setDismissedIds((prev) => saveDismissedDriverNotifs(mobile?.id, [...prev, id]));
  };

  const clearAll = () => {
    setDismissedIds((prev) =>
      saveDismissedDriverNotifs(mobile?.id, [...prev, ...baseItems.map((n) => n.id)])
    );
  };

  const label = items.length === 1 ? '1 notificación' : `${items.length} notificaciones`;

  return (
    <div className="min-h-screen bg-background flex flex-col max-w-md mx-auto w-full pb-16">
      <div className="flex items-center gap-3 px-4 pt-5 pb-3">
        <button onClick={onBack} className="w-10 h-10 flex items-center justify-center">
          <ChevronLeft className="w-6 h-6 text-foreground" />
        </button>
        <h1 className="text-foreground font-bold text-lg">Notificaciones</h1>
      </div>

      <div className="flex-1 px-4 pb-6">
        <div className="flex flex-col items-center text-center mb-6 mt-2">
          <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-3">
            <Bell className="w-7 h-7 text-primary" />
          </div>
          <h2 className="text-foreground font-bold text-xl">Notificaciones</h2>
          <p className="text-muted-foreground text-sm">Avisos de tus recompensas, referidos y actividad.</p>
        </div>

        <div className="flex items-center justify-between mb-3">
          <p className="text-foreground font-bold text-sm">{label}</p>
          {items.length > 0 && (
            <button onClick={clearAll} className="text-destructive font-bold text-sm">Borrar todo</button>
          )}
        </div>

        {items.length === 0 ? (
          <div className="bg-card rounded-2xl p-8 text-center shadow-sm border border-border">
            <p className="text-muted-foreground text-sm">No tienes notificaciones.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {items.map((n) => (
              <div key={n.id} className="bg-card rounded-2xl p-4 shadow-sm border border-border">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <p className="text-foreground font-bold text-sm">{n.title}</p>
                    <p className="text-muted-foreground text-sm mt-1 leading-relaxed">{n.body}</p>
                    {n.howToImprove && (
                      <p className="text-primary text-xs font-semibold mt-1.5 leading-relaxed">
                        💡 {n.howToImprove}
                      </p>
                    )}
                    <p className="text-muted-foreground text-xs mt-2">{n.date}</p>
                  </div>
                  <button type="button" aria-label="Eliminar notificación" onClick={() => remove(n.id)} className="flex-shrink-0 p-1">
                    <Trash2 className="w-5 h-5 text-destructive" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
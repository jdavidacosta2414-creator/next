import React from 'react';

// Radar visual: anillos concéntricos + barrido giratorio + puntos.
// `active` activa la animación del barrido; en tema claro los anillos son azulados.
export default function Radar({ active = true }) {
  return (
    <div className="relative w-[224px] h-[224px] mx-auto">
      {/* Resplandor de fondo */}
      <div className="absolute inset-2 rounded-full bg-gradient-to-br from-[#EAF3FF] via-[#F0F9FF] to-transparent dark:from-sky-950/40 dark:via-blue-950/20 dark:to-transparent" />
      {/* Anillos concéntricos */}
      <div className="absolute inset-0 rounded-full border-2 border-[#BAE6FD] dark:border-sky-500/30 shadow-[inset_0_0_24px_rgba(2,132,199,0.08)]" />
      <div className="absolute inset-[30px] rounded-full border-2 border-[#BAE6FD]/90 dark:border-sky-500/25" />
      <div className="absolute inset-[60px] rounded-full border-2 border-[#7DD3FC]/80 dark:border-sky-400/25" />
      {/* Cruces */}
      <div className="absolute top-1/2 left-0 right-0 h-px bg-[#BAE6FD]/80 dark:bg-sky-500/25" />
      <div className="absolute left-1/2 top-0 bottom-0 w-px bg-[#BAE6FD]/80 dark:bg-sky-500/25" />
      {/* Punto central (ubicación del conductor) */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-gradient-to-br from-[#0B45B4] to-[#00B8FF] border-2 border-white dark:border-slate-900 shadow-[0_0_0_6px_rgba(11,69,180,0.18)]" />
      {/* Puntos dispersos (solicitudes) */}
      <span className="absolute w-2.5 h-2.5 rounded-full bg-[#0284C7] shadow-[0_0_8px_rgba(2,132,199,0.6)]" style={{ top: '26%', left: '60%' }} />
      <span className="absolute w-2.5 h-2.5 rounded-full bg-[#00B8FF] shadow-[0_0_8px_rgba(0,184,255,0.6)]" style={{ top: '68%', left: '34%' }} />
      <span className="absolute w-2 h-2 rounded-full bg-[#1E6BFF]" style={{ top: '44%', left: '24%' }} />
      {/* Barrido giratorio */}
      {active && (
        <div
          className="absolute inset-0 origin-center animate-spin"
          style={{
            animationDuration: '3.2s',
            background: 'conic-gradient(from 0deg, rgba(11,69,180,0.28) 0deg, rgba(0,184,255,0) 65deg, rgba(0,184,255,0) 360deg)',
            borderRadius: '9999px',
          }}
        />
      )}
    </div>
  );
}
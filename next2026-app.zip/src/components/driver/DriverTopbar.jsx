import React from 'react';
import { Menu, TrendingUp } from 'lucide-react';
import { cn } from '@/lib/utils';

const fmtCOP = (n) =>
  '$' + Number(n || 0).toLocaleString('es-CO', { maximumFractionDigits: 0 });

// Barra superior del conductor con identidad visual NEXT:
// - Botón de menú a la izquierda
// - Botón Conectado / Desconectado (en rojo cuando está desconectado)
// - Contador en vivo de ganancias acumuladas por servicios finalizados
export default function DriverTopbar({
  status,
  totalEarnings = 0,
  onMenu,
  onToggleConnect,
  onOpenEarnings,
}) {
  const isOffline = status === 'offline';

  return (
    <div className="sticky top-0 z-20 relative bg-gradient-to-r from-[#062B6E] via-[#0B3C8C] to-[#0E56B8] px-3 pt-2.5 pb-4 flex-shrink-0 shadow-md">
      <div className="flex items-center justify-between gap-2">
        <button
          onClick={onMenu}
          aria-label="Menú"
          className="w-10 h-10 rounded-full bg-white dark:bg-slate-800 border border-white/25 shadow-md flex items-center justify-center flex-shrink-0 active:scale-95 transition-transform"
        >
          <Menu className="w-5 h-5 text-slate-900 dark:text-white stroke-[2.5]" />
        </button>

        <button
          onClick={onToggleConnect}
          className={cn(
            'h-9 px-4 rounded-full text-xs font-extrabold tracking-wide flex items-center gap-2 transition-all active:scale-95 flex-shrink-0',
            isOffline
              ? 'bg-gradient-to-r from-[#DC2626] to-[#EF4444] text-white border border-red-300/60 shadow-[0_0_16px_rgba(239,68,68,0.55)]'
              : 'bg-gradient-to-r from-[#00B8FF] to-[#1E6BFF] text-white border border-white/50 shadow-[0_0_16px_rgba(0,212,255,0.55)]'
          )}
        >
          <span
            className={cn(
              'w-2 h-2 rounded-full',
              isOffline
                ? 'bg-white shadow-[0_0_6px_#ffffff]'
                : 'bg-[#3DDC84] shadow-[0_0_8px_#3DDC84] animate-pulse'
            )}
          />
          <span>{isOffline ? 'Desconectado' : 'Conectado'}</span>
        </button>

        <button
          type="button"
          onClick={onOpenEarnings}
          aria-label="Ver ganancias"
          className="h-9 px-3 rounded-2xl bg-[#041738]/85 border border-[#3DDC84]/50 shadow-sm flex items-center gap-1.5 active:scale-95 transition-transform min-w-0"
        >
          <div className="w-5 h-5 rounded-full bg-[#3DDC84]/20 flex items-center justify-center flex-shrink-0">
            <TrendingUp className="w-3 h-3 text-[#3DDC84]" />
          </div>
          <div className="text-left leading-none min-w-0">
            <p className="text-[8.5px] font-extrabold uppercase tracking-wider text-sky-200">
              Ganancias
            </p>
            <p className="text-xs font-black text-[#3DDC84] truncate mt-0.5">
              {fmtCOP(totalEarnings)}
            </p>
          </div>
        </button>
      </div>

      <svg
        viewBox="0 0 400 22"
        preserveAspectRatio="none"
        className="absolute -bottom-[14px] left-0 w-full h-[18px] pointer-events-none"
      >
        <path
          d="M0,0 L400,0 L400,6 Q300,22 200,10 Q100,-2 0,14 Z"
          fill="#0A3A86"
        />
      </svg>
    </div>
  );
}
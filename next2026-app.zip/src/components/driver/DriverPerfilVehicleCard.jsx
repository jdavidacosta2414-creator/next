import React, { useState, useEffect } from 'react';
import { Bike, Car, Hash, FileCheck } from 'lucide-react';
import { getCachedSignedUrl, resolveStorageUrl } from '@/components/shared/ResolvedAvatar';
import { useBackButton } from '@/hooks/useBackButton';

function PrivatePhotoThumb({ uri, label }) {
  const [url, setUrl] = useState(() => getCachedSignedUrl(uri) || '');
  const [open, setOpen] = useState(false);
  useBackButton(() => setOpen(false), open);

  useEffect(() => {
    if (!uri) {
      setUrl('');
      return;
    }
    const cached = getCachedSignedUrl(uri);
    if (cached) {
      setUrl(cached);
      if (!cached.startsWith('blob:')) return;
    }
    let mounted = true;
    resolveStorageUrl(uri)
      .then((resolved) => {
        if (mounted && resolved) setUrl(resolved);
      })
      .catch(() => {});
    return () => {
      mounted = false;
    };
  }, [uri]);

  if (!url) return null;

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="rounded-xl overflow-hidden border border-slate-200 dark:border-border bg-slate-50 dark:bg-muted/40 text-left active:scale-[0.98] transition-transform"
      >
        <img src={url} alt={label} loading="eager" decoding="sync" className="w-full h-24 object-cover" />
        <p className="text-[11px] font-bold text-center py-1 text-muted-foreground truncate px-2">
          {label}
        </p>
      </button>
      {open && (
        <div
          className="fixed inset-0 z-[2500] bg-black/90 flex items-center justify-center p-4"
          onClick={() => setOpen(false)}
        >
          <img
            src={url}
            alt={label}
            className="max-w-[92vw] max-h-[85vh] rounded-2xl object-contain"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </>
  );
}

export default function DriverPerfilVehicleCard({
  vehicleType,
  carSubtype,
  plate,
  plateType,
  brand,
  model,
  color,
  vehiclePhoto,
  tarjetaPhoto,
  verificationPhoto,
  soatPhoto,
  tecnoPhoto,
  soatExpiry,
  tecnoExpiry,
}) {
  const isCar = vehicleType === 'carro';
  const vehicleLabel = isCar
    ? carSubtype === 'taxi' || plateType === 'blanca'
      ? 'Servicio público / Taxi'
      : 'Carro particular'
    : 'Motocicleta';

  return (
    <div className="bg-white dark:bg-card rounded-2xl p-4 border border-sky-100 dark:border-border shadow-xs space-y-3">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <h3 className="text-xs font-extrabold uppercase tracking-wider text-[#062B60] dark:text-sky-300">
          Datos del vehículo
        </h3>
        <div className="flex items-center gap-1.5 flex-wrap">
          {isCar && plateType && (
            <span
              className={`px-2.5 py-0.5 rounded-lg text-[11px] font-extrabold border ${
                plateType === 'blanca'
                  ? 'bg-slate-100 dark:bg-white/15 text-slate-800 dark:text-white border-slate-300 dark:border-white/30'
                  : 'bg-amber-400/20 text-amber-800 dark:text-amber-300 border-amber-400/50'
              }`}
            >
              Placa {plateType} ({plateType === 'blanca' ? 'Público' : 'Particular'})
            </span>
          )}
          {plate && (
            <span className="px-3 py-1 rounded-lg bg-[#EAF3FF] dark:bg-sky-950/70 border border-[#1E6BFF]/30 text-[#062B60] dark:text-sky-200 font-black text-xs tracking-wider uppercase">
              Placa: {plate}
            </span>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        <div className="rounded-xl bg-slate-50 dark:bg-muted/50 p-3 border border-slate-100 dark:border-border">
          <div className="flex items-center gap-2 text-muted-foreground text-[11px] font-semibold">
            {isCar ? (
              <Car className="w-4 h-4 text-[#1E6BFF]" />
            ) : (
              <Bike className="w-4 h-4 text-[#1E6BFF]" />
            )}
            <span>Tipo de vehículo</span>
          </div>
          <p className="text-sm font-extrabold text-foreground mt-1">
            {vehicleLabel}
          </p>
        </div>

        <div className="rounded-xl bg-slate-50 dark:bg-muted/50 p-3 border border-slate-100 dark:border-border">
          <div className="flex items-center gap-2 text-muted-foreground text-[11px] font-semibold">
            <Hash className="w-4 h-4 text-[#1E6BFF]" />
            <span>Placa registrada</span>
          </div>
          <p className="text-sm font-extrabold text-foreground mt-1 uppercase">
            {plate || 'No registrada'}
          </p>
        </div>

        <div className="rounded-xl bg-slate-50 dark:bg-muted/50 p-3 border border-slate-100 dark:border-border">
          <p className="text-[11px] font-semibold text-muted-foreground">Marca</p>
          <p className="text-sm font-extrabold text-foreground mt-1 truncate">
            {brand || 'No registrada'}
          </p>
        </div>

        <div className="rounded-xl bg-slate-50 dark:bg-muted/50 p-3 border border-slate-100 dark:border-border">
          <p className="text-[11px] font-semibold text-muted-foreground">Modelo / Línea</p>
          <p className="text-sm font-extrabold text-foreground mt-1 truncate">
            {model || 'No registrado'}
          </p>
        </div>

        {color && (
          <div className="col-span-2 rounded-xl bg-slate-50 dark:bg-muted/50 p-3 border border-slate-100 dark:border-border">
            <p className="text-[11px] font-semibold text-muted-foreground">Color del vehículo (Tarjeta de propiedad)</p>
            <p className="text-sm font-extrabold text-foreground mt-0.5 capitalize">
              {color}
            </p>
          </div>
        )}
      </div>

      {isCar && (soatExpiry || tecnoExpiry) && (
        <div className="grid grid-cols-2 gap-2.5">
          {soatExpiry && (
            <div className="rounded-xl bg-sky-50/70 dark:bg-sky-950/30 p-2.5 border border-sky-200/60 dark:border-sky-800/40">
              <p className="text-[10px] font-bold uppercase text-muted-foreground">Vigencia SOAT</p>
              <p className="text-xs font-extrabold text-foreground mt-0.5">{soatExpiry}</p>
            </div>
          )}
          {tecnoExpiry && (
            <div className="rounded-xl bg-sky-50/70 dark:bg-sky-950/30 p-2.5 border border-sky-200/60 dark:border-sky-800/40">
              <p className="text-[10px] font-bold uppercase text-muted-foreground">Vigencia Tecnomecánica</p>
              <p className="text-xs font-extrabold text-foreground mt-0.5">{tecnoExpiry}</p>
            </div>
          )}
        </div>
      )}

      {(vehiclePhoto || tarjetaPhoto || verificationPhoto || soatPhoto || tecnoPhoto) && (
        <div className="pt-2 border-t border-slate-100 dark:border-border space-y-2">
          <p className="text-[11px] font-bold text-muted-foreground flex items-center gap-1.5">
            <FileCheck className="w-3.5 h-3.5 text-[#1E6BFF]" />
            Documentos privados verificados (enlace seguro temporal)
          </p>
          <div className="grid grid-cols-2 gap-2.5">
            {verificationPhoto && (
              <PrivatePhotoThumb uri={verificationPhoto} label="Cédula (Privada)" />
            )}
            {tarjetaPhoto && (
              <PrivatePhotoThumb uri={tarjetaPhoto} label="Tarjeta de propiedad" />
            )}
            {soatPhoto && (
              <PrivatePhotoThumb uri={soatPhoto} label="SOAT vigente" />
            )}
            {tecnoPhoto && (
              <PrivatePhotoThumb uri={tecnoPhoto} label="Tecnomecánica vigente" />
            )}
            {vehiclePhoto && (
              <PrivatePhotoThumb uri={vehiclePhoto} label="Vehículo (placa)" />
            )}
          </div>
        </div>
      )}
    </div>
  );
}
import React from 'react';
import {
  Banknote,
  Smartphone,
  Gift,
  TrendingUp,
  Bike,
  Car,
  Package,
} from 'lucide-react';
import DriverGoalCard from '@/components/driver/DriverGoalCard';

const fmtCOP = (n) =>
  '$' + Number(n || 0).toLocaleString('es-CO', { maximumFractionDigits: 0 });

export default function DriverEarningsBreakdown({
  period,
  vehicleType,
  chartBuckets,
  paymentStats,
  serviceTypeStats,
  dailyGoal,
  goalAmount,
  netEarnings,
  onSaveDailyGoal,
}) {
  const isCar = vehicleType === 'carro';
  const maxBucket = Math.max(...chartBuckets.map((b) => b.amount), 1);

  const periodTitle =
    period === 'dia'
      ? 'Ingresos por franja del día'
      : period === 'semana'
        ? 'Ingresos día por día (Lun - Dom)'
        : 'Ingresos semana por semana del mes';

  return (
    <div className="space-y-3.5">
      {/* Gráfico de barras del periodo */}
      <div className="bg-white dark:bg-card rounded-2xl p-4 border border-sky-100 dark:border-border shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="w-7 h-7 rounded-lg bg-[#EAF3FF] dark:bg-sky-950/60 flex items-center justify-center">
              <TrendingUp className="w-4 h-4 text-[#1E6BFF] dark:text-sky-400" />
            </span>
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-[#062B60] dark:text-sky-300">
              {periodTitle}
            </h3>
          </div>
        </div>

        <div className="grid grid-flow-col auto-cols-fr gap-2 items-end h-32 pt-4 pb-1 px-1">
          {chartBuckets.map((b) => {
            const heightPct = b.amount > 0 ? Math.max(14, Math.round((b.amount / maxBucket) * 100)) : 6;
            return (
              <div key={b.key} className="flex flex-col items-center justify-end h-full gap-1 min-w-0">
                <span className="text-[10px] font-bold text-[#062B60] dark:text-sky-300 truncate max-w-full">
                  {b.amount > 0 ? `${Math.round(b.amount / 1000)}k` : '$0'}
                </span>
                <div className="w-full max-w-[34px] flex-1 flex items-end bg-slate-100 dark:bg-muted/50 rounded-t-lg overflow-hidden p-0.5">
                  <div
                    className={`w-full rounded-t-md transition-all ${
                      b.amount > 0
                        ? 'bg-gradient-to-t from-[#062B60] via-[#1E6BFF] to-[#00B8FF]'
                        : 'bg-slate-200 dark:bg-slate-700'
                    }`}
                    style={{ height: `${heightPct}%` }}
                  />
                </div>
                <span className="text-[10px] font-extrabold text-foreground truncate">
                  {b.label}
                </span>
                <span className="text-[9px] font-medium text-muted-foreground">
                  {b.count} {b.count === 1 ? 'viaje' : 'viajes'}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Cómo recibiste tu dinero */}
      <div className="bg-white dark:bg-card rounded-2xl p-4 border border-sky-100 dark:border-border shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-extrabold uppercase tracking-wider text-[#062B60] dark:text-sky-300">
            Cómo recibiste tus ingresos
          </h3>
          <span className="text-[11px] font-bold text-[#1E6BFF] dark:text-sky-400">
            100% para ti
          </span>
        </div>

        <div className="grid grid-cols-3 gap-2">
          <div className="rounded-xl bg-slate-50 dark:bg-muted/40 p-2.5 border border-slate-100 dark:border-border">
            <div className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
              <Banknote className="w-4 h-4 flex-shrink-0" />
              <span className="text-[11px] font-bold truncate">Efectivo</span>
            </div>
            <p className="text-sm font-black text-foreground mt-1 truncate">
              {fmtCOP(paymentStats.efectivo)}
            </p>
            <p className="text-[10px] text-muted-foreground">
              {paymentStats.efectivoCount} {paymentStats.efectivoCount === 1 ? 'viaje' : 'viajes'}
            </p>
          </div>

          <div className="rounded-xl bg-slate-50 dark:bg-muted/40 p-2.5 border border-slate-100 dark:border-border">
            <div className="flex items-center gap-1.5 text-[#1E6BFF] dark:text-sky-400">
              <Smartphone className="w-4 h-4 flex-shrink-0" />
              <span className="text-[11px] font-bold truncate">Digital</span>
            </div>
            <p className="text-sm font-black text-foreground mt-1 truncate">
              {fmtCOP(paymentStats.digital)}
            </p>
            <p className="text-[10px] text-muted-foreground">
              {paymentStats.digitalCount} {paymentStats.digitalCount === 1 ? 'viaje' : 'viajes'}
            </p>
          </div>

          <div className="rounded-xl bg-slate-50 dark:bg-muted/40 p-2.5 border border-slate-100 dark:border-border">
            <div className="flex items-center gap-1.5 text-sky-600 dark:text-sky-300">
              <Gift className="w-4 h-4 flex-shrink-0" />
              <span className="text-[11px] font-bold truncate">Puntos</span>
            </div>
            <p className="text-sm font-black text-foreground mt-1 truncate">
              {fmtCOP(paymentStats.puntos)}
            </p>
            <p className="text-[10px] text-muted-foreground">
              {paymentStats.puntosCount} {paymentStats.puntosCount === 1 ? 'viaje' : 'viajes'}
            </p>
          </div>
        </div>

        {/* Tipo de servicio según el vehículo registrado */}
        {isCar ? (
          <div className="pt-1">
            <div className="flex items-center justify-between rounded-xl bg-[#EAF3FF]/60 dark:bg-sky-950/40 px-3.5 py-2.5 border border-sky-200/60 dark:border-sky-800/40">
              <div className="flex items-center gap-2.5 min-w-0">
                <Car className="w-4 h-4 text-[#062B60] dark:text-sky-300 flex-shrink-0" />
                <div className="min-w-0">
                  <p className="text-xs font-bold text-[#062B60] dark:text-sky-200 truncate">
                    Servicios de Carro
                  </p>
                  <p className="text-[10px] text-muted-foreground">
                    {serviceTypeStats.transporteCount} viajes realizados
                  </p>
                </div>
              </div>
              <span className="text-sm font-extrabold text-[#062B60] dark:text-white">
                {fmtCOP(serviceTypeStats.transporteAmount)}
              </span>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2 pt-1">
            <div className="flex items-center justify-between rounded-xl bg-[#EAF3FF]/60 dark:bg-sky-950/40 px-3 py-2 border border-sky-200/60 dark:border-sky-800/40">
              <div className="flex items-center gap-2 min-w-0">
                <Bike className="w-4 h-4 text-[#062B60] dark:text-sky-300 flex-shrink-0" />
                <div className="min-w-0">
                  <p className="text-[11px] font-bold text-[#062B60] dark:text-sky-200 truncate">
                    Transporte
                  </p>
                  <p className="text-[10px] text-muted-foreground">
                    {serviceTypeStats.transporteCount} viajes
                  </p>
                </div>
              </div>
              <span className="text-xs font-extrabold text-[#062B60] dark:text-white">
                {fmtCOP(serviceTypeStats.transporteAmount)}
              </span>
            </div>

            <div className="flex items-center justify-between rounded-xl bg-[#EAF3FF]/60 dark:bg-sky-950/40 px-3 py-2 border border-sky-200/60 dark:border-sky-800/40">
              <div className="flex items-center gap-2 min-w-0">
                <Package className="w-4 h-4 text-[#062B60] dark:text-sky-300 flex-shrink-0" />
                <div className="min-w-0">
                  <p className="text-[11px] font-bold text-[#062B60] dark:text-sky-200 truncate">
                    Mensajería
                  </p>
                  <p className="text-[10px] text-muted-foreground">
                    {serviceTypeStats.mensajeriaCount} envíos
                  </p>
                </div>
              </div>
              <span className="text-xs font-extrabold text-[#062B60] dark:text-white">
                {fmtCOP(serviceTypeStats.mensajeriaAmount)}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Meta personalizable del conductor */}
      <DriverGoalCard
        period={period}
        dailyGoal={dailyGoal}
        goalAmount={goalAmount}
        netEarnings={netEarnings}
        onSaveDailyGoal={onSaveDailyGoal}
      />
    </div>
  );
}
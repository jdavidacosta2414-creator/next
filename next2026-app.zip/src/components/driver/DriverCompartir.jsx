import React, { useState, useEffect, useCallback } from 'react';
import {
  ChevronLeft,
  Share2,
  Gift,
  Copy,
  MessageCircle,
  Link as LinkIcon,
  ShieldCheck,
  Sparkles,
  Users,
  CheckCircle2,
  Clock,
  Send,
  Loader2,
} from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { toast } from '@/components/ui/use-toast';
import {
  REFERRAL_POINTS,
  getReferralCodeFromId,
  registerReferralClaim,
  syncMyReferralCodeOwner,
} from '@/lib/referrals';

const APP_URL = 'https://next2026-app.base44.app';

// Sección "Compartir app" para Pasajero y Conductor:
// Ganan +100 puntos por cada referido que se registre con su código/enlace
// cuando Central apruebe el referido.
export default function DriverCompartir({ mobile, user: propUser, onBack }) {
  const { user: authUser } = useAuth();
  const user = propUser || authUser;
  const code = getReferralCodeFromId(mobile?.id || user?.id) || 'NEXT100';
  const shareUrl = `${APP_URL}/registro?ref=${code}`;
  const shareText = `¡Únete a NEXT! Transporte y mensajería rápida y segura. Regístrate con mi código de referido ${code} aquí: ${shareUrl}`;
  const waLink = `whatsapp://send?text=${encodeURIComponent(shareText)}`;

  const [myReferrals, setMyReferrals] = useState([]);
  const [friendCode, setFriendCode] = useState('');
  const [linkingCode, setLinkingCode] = useState(false);
  const [alreadyUsedCode, setAlreadyUsedCode] = useState(user?.referral_code || '');

  const loadReferrals = useCallback(async () => {
    try {
      await syncMyReferralCodeOwner({ user, mobile });
      const codes = Array.from(
        new Set([getReferralCodeFromId(mobile?.id), getReferralCodeFromId(user?.id)].filter(Boolean))
      );
      if (codes.length === 0) return;
      const page = await base44.entities.PointsTransaction.filter(
        {
          referrer_code: { $in: codes },
          type: { $in: ['referido_pendiente', 'referido_aprobado'] },
        },
        { sort: '-created_date', limit: 30 }
      );
      setMyReferrals((page?.items || []).filter((r) => r.status !== 'rechazado'));
    } catch {}
  }, [mobile, user]);

  useEffect(() => {
    if (user?.referral_code) setAlreadyUsedCode(user.referral_code);
  }, [user?.referral_code]);

  useEffect(() => {
    loadReferrals();
    const unsub = base44.entities.PointsTransaction.subscribe(() => loadReferrals().catch(() => {}));
    return unsub;
  }, [loadReferrals]);

  const copyCode = async () => {
    try {
      await navigator.clipboard.writeText(code);
      toast({ title: 'Código copiado', description: `Tu código ${code} está listo para compartir.` });
    } catch {}
  };

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      toast({ title: 'Enlace copiado', description: 'Compártelo con tus amigos para ganar +100 puntos.' });
    } catch {}
  };

  const submitFriendCode = async (e) => {
    e.preventDefault();
    const clean = friendCode.trim().toUpperCase();
    if (!clean || clean.length < 4) {
      toast({ title: 'Ingresa un código válido' });
      return;
    }
    if (clean === code) {
      toast({ title: 'No puedes usar tu propio código', variant: 'destructive' });
      return;
    }
    setLinkingCode(true);
    try {
      const role = mobile?.plate ? 'conductor' : 'pasajero';
      const res = await registerReferralClaim({
        referralCode: clean,
        newUser: user,
        newUserName: mobile?.name || user?.display_name || user?.full_name || user?.email || 'Usuario NEXT',
        newRole: role,
        newMobileId: mobile?.id,
      });
      if (res) {
        if (user?.id) {
          await base44.auth.updateMe({ referral_code: clean }).catch(() => {});
        }
        setAlreadyUsedCode(clean);
        setFriendCode('');
        toast({
          title: '¡Código de referido vinculado! 🎉',
          description: `Enviamos el referido a Central para aprobar los +${REFERRAL_POINTS} puntos.`,
        });
      }
    } catch {
      toast({ title: 'No se pudo vincular el código', variant: 'destructive' });
    } finally {
      setLinkingCode(false);
    }
  };

  const approvedCount = myReferrals.filter((r) => r.status === 'aprobado').length;
  const pendingCount = myReferrals.filter((r) => r.status === 'pendiente').length;
  const totalEarnedPts = approvedCount * REFERRAL_POINTS;

  return (
    <div className="fixed inset-0 z-[1800] bg-background flex flex-col max-w-md mx-auto w-full overflow-y-auto overflow-x-hidden pb-24">
      <div className="flex items-center gap-3 px-4 pt-5 pb-3 flex-shrink-0">
        <button onClick={onBack} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-muted">
          <ChevronLeft className="w-6 h-6 text-foreground" />
        </button>
        <h1 className="text-foreground font-bold text-lg">Compartir y ganar</h1>
      </div>

      <div className="flex-1 px-4 pb-6 space-y-4">
        {/* Banner principal +100 puntos */}
        <div className="rounded-3xl bg-gradient-to-br from-[#1E6BFF] to-[#0a3aa8] p-5 text-white shadow-lg">
          <div className="flex items-center justify-between gap-3 mb-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 text-xs font-extrabold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-[#00E5FF]" /> Programa de referidos
            </span>
            <Share2 className="w-5 h-5 text-white/80" />
          </div>
          <h2 className="text-xl font-extrabold leading-tight">
            Gana +{REFERRAL_POINTS} puntos por cada referido
          </h2>
          <p className="text-white/85 text-xs mt-1.5 leading-relaxed">
            Tanto pasajeros como conductores ganan <span className="font-bold text-white">+{REFERRAL_POINTS} puntos (${REFERRAL_POINTS} COP)</span> por cada persona que se registre en la app con su código o enlace cuando Central apruebe el referido.
          </p>
          <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-white/15 text-center">
            <div>
              <p className="text-[10px] text-white/75 uppercase">Aprobados</p>
              <p className="text-lg font-extrabold">{approvedCount}</p>
            </div>
            <div>
              <p className="text-[10px] text-white/75 uppercase">Pendientes</p>
              <p className="text-lg font-extrabold">{pendingCount}</p>
            </div>
            <div>
              <p className="text-[10px] text-white/75 uppercase">Puntos ganados</p>
              <p className="text-lg font-extrabold text-[#00E5FF]">+{totalEarnedPts}</p>
            </div>
          </div>
        </div>

        {/* Tarjeta de código y botones para compartir */}
        <div className="bg-card rounded-3xl p-5 shadow-sm border border-border space-y-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
              <Gift className="w-4 h-4 text-primary" />
            </div>
            <p className="text-foreground font-bold text-sm">Tu código de referido</p>
          </div>
          <p className="text-muted-foreground text-xs leading-relaxed">
            Comparte este código o tu enlace directo. Cuando tu invitado se registre, el referido quedará listo para que Central lo apruebe y te acredite +{REFERRAL_POINTS} puntos.
          </p>

          <div className="flex items-center justify-between border-2 border-dashed border-primary/30 rounded-xl px-4 py-3 bg-muted/30">
            <p className="text-foreground font-extrabold text-xl tracking-wider">{code}</p>
            <button
              type="button"
              onClick={copyCode}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-primary px-2.5 py-1.5 rounded-lg bg-primary/10"
            >
              <Copy className="w-4 h-4" /> Copiar
            </button>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex-1 h-px bg-border" />
            <span className="text-muted-foreground text-xs">Compartir enlace directo</span>
            <div className="flex-1 h-px bg-border" />
          </div>

          <a
            href={waLink}
            className="w-full h-12 rounded-2xl bg-[#25D366] text-white font-bold text-sm flex items-center justify-between px-4 shadow-sm"
          >
            <span className="flex items-center gap-2">
              <MessageCircle className="w-5 h-5" /> Compartir por WhatsApp
            </span>
            <span>›</span>
          </a>
          <button
            type="button"
            onClick={copyLink}
            className="w-full h-12 rounded-2xl bg-[#1E6BFF] text-white font-bold text-sm flex items-center justify-between px-4 shadow-sm"
          >
            <span className="flex items-center gap-2">
              <LinkIcon className="w-5 h-5" /> Copiar enlace de invitación
            </span>
            <span>›</span>
          </button>

          <div className="flex items-start gap-2 pt-1">
            <ShieldCheck className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-foreground font-bold text-xs">Tus datos están seguros</p>
              <p className="text-muted-foreground text-xs">Solo compartimos tu código de referido, no tu información personal.</p>
            </div>
          </div>
        </div>

        {/* Lista de referidos registrados con mi código */}
        {myReferrals.length > 0 && (
          <div className="bg-card rounded-3xl p-4 shadow-sm border border-border space-y-2.5">
            <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
              <Users className="w-4 h-4 text-primary" /> Mis referidos ({myReferrals.length})
            </p>
            <div className="space-y-2">
              {myReferrals.map((r) => {
                const isApproved = r.status === 'aprobado';
                return (
                  <div
                    key={r.id}
                    className="flex items-center justify-between gap-2 rounded-2xl bg-muted/40 border border-border px-3.5 py-2.5"
                  >
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-foreground truncate">
                        {r.referred_user_name || 'Nuevo referido'}
                      </p>
                      <p className="text-[11px] text-muted-foreground capitalize">
                        Registrado como {r.referred_role || 'pasajero'}
                      </p>
                    </div>
                    {isApproved ? (
                      <span className="inline-flex items-center gap-1 text-xs font-extrabold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full flex-shrink-0">
                        <CheckCircle2 className="w-3.5 h-3.5" /> +{r.amount || REFERRAL_POINTS} pts
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-600 dark:text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-full flex-shrink-0">
                        <Clock className="w-3.5 h-3.5" /> Pendiente Central
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Opción para ingresar el código de quien me invitó si no lo puse al registrarme */}
        {!alreadyUsedCode && (
          <form
            onSubmit={submitFriendCode}
            className="bg-card rounded-3xl p-5 shadow-sm border border-border space-y-3 text-center"
          >
            <p className="text-sm font-bold text-foreground">¿Alguien te invitó a NEXT?</p>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Si olvidaste escribir su código al registrarte, ingrésalo aquí para que gane +{REFERRAL_POINTS} puntos cuando Central lo apruebe:
            </p>
            <div className="flex flex-col gap-2.5 pt-1">
              <input
                value={friendCode}
                onChange={(e) => setFriendCode(e.target.value.toUpperCase())}
                placeholder="CÓDIGO DE QUIEN TE INVITÓ"
                className="w-full min-w-0 h-11 rounded-2xl bg-muted px-4 text-sm font-extrabold text-center text-foreground uppercase tracking-wider border border-border outline-none focus:border-primary"
              />
              <button
                type="submit"
                disabled={linkingCode || !friendCode.trim()}
                className="w-full h-11 rounded-2xl bg-[#1E6BFF] text-white font-bold text-sm flex items-center justify-center gap-2 shadow-sm disabled:opacity-50 active:scale-[0.99] transition-transform"
              >
                {linkingCode ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                <span>Vincular código</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
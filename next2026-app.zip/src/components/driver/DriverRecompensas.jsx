import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import {
  ChevronLeft,
  Gift,
  Flame,
  Route,
  CalendarDays,
  Check,
  Loader2,
  Sparkles,
  Wallet,
  Target,
} from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import {
  DRIVER_STREAK_MILESTONES,
  DRIVER_STREAK_REWARDS,
  DRIVER_DAILY_TRIP_GOAL,
  DRIVER_WEEKLY_TRIP_GOAL,
  DRIVER_DAILY_REWARD,
  DRIVER_WEEKLY_REWARD,
  weekBounds,
  dayBounds,
  evaluateAndAutoCreditDriverRewards,
  parseRewardCOP,
} from '@/lib/rewards';

// Pantalla automatizada de recompensas del conductor:
// - Permite al conductor postularse a cualquier meta activa (7, 10, 20 o 30 días conectados, viajes del día o de la semana).
// - En cuanto el conductor cumple la meta (recarga activa + servicio tomado en los días requeridos),
//   la aplicación acredita automáticamente el bono en su Cartera sin esperar aprobación manual.
export default function DriverRecompensas({ mobile, onBack, onMobileUpdate }) {
  const [data, setData] = useState({
    daily: 0,
    weekly: 0,
    streak: 0,
    rechargedToday: false,
    tookServiceToday: false,
    config: {
      streakRewards: { ...DRIVER_STREAK_REWARDS },
      dailyGoal: DRIVER_DAILY_TRIP_GOAL,
      dailyReward: DRIVER_DAILY_REWARD,
      weeklyGoal: DRIVER_WEEKLY_TRIP_GOAL,
      weeklyReward: DRIVER_WEEKLY_REWARD,
    },
  });
  const [claims, setClaims] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busyKey, setBusyKey] = useState(null);

  const load = useCallback(async () => {
    if (!mobile?.id) return;
    try {
      const res = await evaluateAndAutoCreditDriverRewards(mobile);
      if (res.credited?.length > 0) {
        const refreshedMob = await base44.entities.Mobile.get(mobile.id).catch(() => null);
        if (refreshedMob) onMobileUpdate?.(refreshedMob);
        res.credited.forEach((c) => {
          toast({
            title: '¡Bono acreditado automáticamente en tu Cartera! 🎉',
            description: `Cumpliste la meta (${c.goal}) y se abonó "${c.reward}" directamente a tu Cartera.`,
          });
        });
        window.dispatchEvent(new CustomEvent('next-driver-notifs-updated'));
      }
      const claimList = await base44.entities.RewardClaim.filter(
        { scope: 'conductor', mobile_id: mobile.id },
        '-created_date',
        60
      );
      setData((prev) => ({
        daily: res.daily ?? prev.daily,
        weekly: res.weekly ?? prev.weekly,
        streak: res.streak ?? prev.streak,
        rechargedToday: res.rechargedToday ?? prev.rechargedToday,
        tookServiceToday: res.tookServiceToday ?? prev.tookServiceToday,
        config: res.config || prev.config,
      }));
      setClaims(claimList?.items || claimList || []);
    } catch (e) {}
    setLoading(false);
  }, [mobile, onMobileUpdate]);

  useEffect(() => {
    load();
  }, [load]);

  const getClaimRecord = (goalType, periodKey) =>
    claims.find((c) => c.goal_type === goalType && c.period_key === periodKey);

  // Postularse a una recompensa (cuando aún está en progreso) o acreditarla de inmediato si ya cumplió la meta
  const handlePostularOrCredit = async (goalType, periodKey, goal, reward, reached) => {
    if (busyKey) return;
    setBusyKey(periodKey);
    try {
      const existing = getClaimRecord(goalType, periodKey);
      if (reached) {
        const bonusCOP = parseRewardCOP(reward);
        if (existing) {
          await base44.entities.RewardClaim.update(existing.id, {
            status: 'entregado',
            reward,
          });
        } else {
          await base44.entities.RewardClaim.create({
            scope: 'conductor',
            mobile_id: mobile.id,
            mobile_name: mobile.name || 'Conductor',
            goal_type: goalType,
            period_key: periodKey,
            goal,
            reward,
            status: 'entregado',
          });
        }
        if (bonusCOP > 0) {
          await base44.entities.WalletTransaction.create({
            mobile_id: mobile.id,
            mobile_name: mobile.name || 'Conductor',
            type: 'recarga',
            amount: bonusCOP,
            description: `Recompensa automática acreditada (${reward})`,
          }).catch(() => {});
          const freshMob = await base44.entities.Mobile.get(mobile.id).catch(() => mobile);
          const nextWallet = Number(freshMob?.points_wallet_balance || 0) + bonusCOP;
          const updatedMob = await base44.entities.Mobile.update(mobile.id, {
            points_wallet_balance: nextWallet,
          });
          onMobileUpdate?.(updatedMob);
        }
        toast({
          title: '¡Bono acreditado en tu Cartera! 🎉',
          description: `Se abonó "${reward}" automáticamente en tu Cartera.`,
        });
      } else if (!existing) {
        await base44.entities.RewardClaim.create({
          scope: 'conductor',
          mobile_id: mobile.id,
          mobile_name: mobile.name || 'Conductor',
          goal_type: goalType,
          period_key: periodKey,
          goal,
          reward,
          status: 'postulado',
        });
        toast({
          title: '¡Te postulaste a esta recompensa! 🎯',
          description: `Cuando cumplas la meta (${goal}), la app acreditará automáticamente "${reward}" en tu Cartera.`,
        });
      }
      window.dispatchEvent(new CustomEvent('next-driver-notifs-updated'));
      await load();
    } catch (e) {}
    setBusyKey(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-7 h-7 animate-spin text-primary" />
      </div>
    );
  }

  const cfg = data.config;
  const dailyPct = Math.min(100, Math.round((data.daily / cfg.dailyGoal) * 100));
  const weeklyPct = Math.min(100, Math.round((data.weekly / cfg.weeklyGoal) * 100));
  const todayKey = dayBounds().key;
  const weekKey = weekBounds().key;
  const creditedCount = claims.filter((c) => c.status === 'entregado').length;

  const dailyClaim = getClaimRecord('viajes_dia', todayKey);
  const weeklyClaim = getClaimRecord('viajes_semana', weekKey);

  return (
    <div className="min-h-screen bg-background w-full max-w-md mx-auto pb-12">
      {/* Encabezado */}
      <div className="px-4 pt-5 pb-4 bg-gradient-to-br from-primary to-[#005e8c] text-white">
        <div className="flex items-center gap-3 mb-4">
          <button
            onClick={onBack}
            className="w-9 h-9 rounded-full bg-white/15 flex items-center justify-center active:scale-95"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <Gift className="w-5 h-5" />
            <h1 className="text-lg font-bold">Puntos y recompensas</h1>
          </div>
        </div>
        <div className="flex items-end justify-between">
          <div>
            <p className="text-white/70 text-xs font-medium uppercase tracking-wider">
              Días conectado
            </p>
            <div className="flex items-end gap-1.5 mt-0.5">
              <span className="text-4xl font-extrabold leading-none">{data.streak}</span>
              <span className="text-sm font-medium mb-1">días seguidos</span>
            </div>
          </div>
          <div className="text-right">
            <p className="text-white/70 text-[11px]">Bonos acreditados</p>
            <p className="text-xl font-bold">{creditedCount}</p>
          </div>
        </div>
      </div>

      <div className="px-4 py-4 space-y-5">
        {/* Banner explicativo de acreditación automática */}
        <div className="rounded-2xl bg-[#EAF3FF] dark:bg-sky-950/50 border border-[#1E6BFF]/30 p-3.5 flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#1E6BFF] text-white flex items-center justify-center flex-shrink-0 mt-0.5">
            <Wallet className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <p className="text-xs font-extrabold text-[#062B60] dark:text-sky-200">
              Acreditación 100% automática en tu Cartera
            </p>
            <p className="text-[11px] text-slate-600 dark:text-muted-foreground mt-0.5 leading-relaxed">
              Postúlate a las recompensas de la semana. Apenas cumplas los <span className="font-bold text-foreground">7, 10, 20 o 30 días conectados</span> (con recarga + servicio), la aplicación te abona el bono automáticamente en tu Cartera.
            </p>
          </div>
        </div>

        {/* Racha de días conectado: 7, 10, 20 y 30 días */}
        <section>
          <div className="flex items-center gap-2 mb-2">
            <Flame className="w-4 h-4 text-orange-500" />
            <p className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider">
              Racha de días conectado (7, 10, 20 y 30 días)
            </p>
          </div>
          <div className="rounded-2xl border border-border bg-card p-4 space-y-3.5">
            <div className="rounded-xl bg-primary/5 border border-primary/15 p-3 space-y-2">
              <p className="text-xs font-bold text-foreground">
                ¿Cómo cuenta un día conectado?
              </p>
              <p className="text-[11px] text-muted-foreground leading-relaxed">
                Para que el día sume a tu meta debes <span className="font-bold text-foreground">hacer tu recarga</span> y <span className="font-bold text-foreground">realizar al menos un servicio</span> en el día.
              </p>
              <div className="grid grid-cols-2 gap-2 pt-1">
                <div
                  className={`rounded-lg px-2.5 py-1.5 text-[11px] font-bold flex items-center gap-1.5 border ${
                    data.rechargedToday
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-600 dark:text-emerald-400'
                      : 'bg-muted/60 border-border text-muted-foreground'
                  }`}
                >
                  <Check className="w-3.5 h-3.5 flex-shrink-0" />
                  <span>1. Recarga activa</span>
                </div>
                <div
                  className={`rounded-lg px-2.5 py-1.5 text-[11px] font-bold flex items-center gap-1.5 border ${
                    data.tookServiceToday
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-600 dark:text-emerald-400'
                      : 'bg-muted/60 border-border text-muted-foreground'
                  }`}
                >
                  <Check className="w-3.5 h-3.5 flex-shrink-0" />
                  <span>2. Tomar servicio</span>
                </div>
              </div>
            </div>

            {DRIVER_STREAK_MILESTONES.map((m) => {
              const reached = data.streak >= m;
              const pk = `streak-${m}`;
              const rec = getClaimRecord('dias_conectado', pk);
              const isCredited = rec?.status === 'entregado';
              const isPostulado = rec?.status === 'postulado' || rec?.status === 'pendiente';
              const reward = cfg.streakRewards[m] || DRIVER_STREAK_REWARDS[m];
              const pct = Math.min(100, Math.round((data.streak / m) * 100));

              return (
                <div
                  key={m}
                  className="rounded-2xl border border-border bg-muted/25 p-3.5 space-y-2.5"
                >
                  <div className="flex items-center justify-between gap-2.5">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div
                        className={`w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0 ${
                          isCredited || reached
                            ? 'bg-emerald-500/15 text-emerald-500'
                            : isPostulado
                              ? 'bg-[#1E6BFF]/15 text-[#1E6BFF]'
                              : 'bg-muted text-muted-foreground/50'
                        }`}
                      >
                        <Flame className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-extrabold text-foreground leading-tight">
                          {m} días conectados
                        </p>
                        <p className="text-xs font-extrabold text-[#1E6BFF] dark:text-sky-400 mt-0.5">
                          {reward}
                        </p>
                      </div>
                    </div>
                    {isCredited ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-extrabold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full flex-shrink-0">
                        <Check className="w-3.5 h-3.5" /> Acreditado
                      </span>
                    ) : reached ? (
                      <button
                        type="button"
                        onClick={() => handlePostularOrCredit('dias_conectado', pk, m, reward, true)}
                        disabled={busyKey === pk}
                        className="h-8 px-3 rounded-xl bg-emerald-500 text-slate-950 text-xs font-extrabold active:scale-95 disabled:opacity-60 flex-shrink-0"
                      >
                        Acreditar bono
                      </button>
                    ) : isPostulado ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-[#1E6BFF] dark:text-sky-300 bg-[#1E6BFF]/15 px-2.5 py-1 rounded-full flex-shrink-0">
                        <Target className="w-3.5 h-3.5" /> Postulado
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handlePostularOrCredit('dias_conectado', pk, m, reward, false)}
                        disabled={busyKey === pk}
                        className="h-8 px-3 rounded-xl bg-[#1E6BFF] text-white text-xs font-bold active:scale-95 disabled:opacity-60 flex-shrink-0"
                      >
                        Postularme
                      </button>
                    )}
                  </div>

                  {/* Barra de avance hacia la meta */}
                  <div className="space-y-1">
                    <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] transition-all"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                    <p className="text-[10px] text-muted-foreground">
                      Progreso: <span className="font-bold text-foreground">{Math.min(data.streak, m)} de {m} días</span> · Se acredita automáticamente al cumplir los {m} días.
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Viajes del día */}
        <section>
          <div className="flex items-center gap-2 mb-2">
            <Route className="w-4 h-4 text-primary" />
            <p className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider">
              Meta de viajes de hoy
            </p>
          </div>
          <div className="rounded-2xl border border-border bg-card p-4">
            <div className="flex items-end justify-between mb-2">
              <p className="text-sm font-bold text-foreground">
                {data.daily} de {cfg.dailyGoal} viajes
              </p>
              <p className="text-xs font-extrabold text-[#1E6BFF] dark:text-sky-400">
                {cfg.dailyReward}
              </p>
            </div>
            <div className="h-2.5 rounded-full bg-muted overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-primary to-[#33b8e8] transition-all"
                style={{ width: `${dailyPct}%` }}
              />
            </div>
            <div className="mt-3 flex items-center justify-between gap-2">
              {dailyClaim?.status === 'entregado' ? (
                <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-600 dark:text-emerald-400">
                  <Check className="w-4 h-4" /> Bono acreditado hoy en tu Cartera
                </span>
              ) : dailyClaim ? (
                <span className="inline-flex items-center gap-1 text-xs font-bold text-[#1E6BFF] dark:text-sky-300">
                  <Target className="w-4 h-4" /> Postulado · Te faltan {Math.max(0, cfg.dailyGoal - data.daily)} viajes hoy (se acredita automático)
                </span>
              ) : (
                <>
                  <p className="text-[11px] text-muted-foreground">
                    Faltan <span className="font-bold text-foreground">{Math.max(0, cfg.dailyGoal - data.daily)}</span> viajes hoy.
                  </p>
                  <button
                    type="button"
                    onClick={() =>
                      handlePostularOrCredit(
                        'viajes_dia',
                        todayKey,
                        cfg.dailyGoal,
                        cfg.dailyReward,
                        data.daily >= cfg.dailyGoal
                      )
                    }
                    disabled={busyKey === todayKey}
                    className="h-8 px-3 rounded-xl bg-[#1E6BFF] text-white text-xs font-bold active:scale-95 disabled:opacity-60 flex-shrink-0"
                  >
                    Postularme
                  </button>
                </>
              )}
            </div>
          </div>
        </section>

        {/* Viajes de la semana */}
        <section>
          <div className="flex items-center gap-2 mb-2">
            <CalendarDays className="w-4 h-4 text-violet-500" />
            <p className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider">
              Meta semanal de viajes
            </p>
          </div>
          <div className="rounded-2xl border border-border bg-card p-4">
            <div className="flex items-end justify-between mb-2">
              <p className="text-sm font-bold text-foreground">
                {data.weekly} de {cfg.weeklyGoal} viajes
              </p>
              <p className="text-xs font-extrabold text-violet-500">
                {cfg.weeklyReward}
              </p>
            </div>
            <div className="h-2.5 rounded-full bg-muted overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-violet-500 to-fuchsia-500 transition-all"
                style={{ width: `${weeklyPct}%` }}
              />
            </div>
            <div className="mt-3 flex items-center justify-between gap-2">
              {weeklyClaim?.status === 'entregado' ? (
                <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-600 dark:text-emerald-400">
                  <Check className="w-4 h-4" /> Bono semanal acreditado en tu Cartera
                </span>
              ) : weeklyClaim ? (
                <span className="inline-flex items-center gap-1 text-xs font-bold text-violet-500">
                  <Target className="w-4 h-4" /> Postulado · Te faltan {Math.max(0, cfg.weeklyGoal - data.weekly)} viajes esta semana
                </span>
              ) : (
                <>
                  <p className="text-[11px] text-muted-foreground">
                    Faltan <span className="font-bold text-foreground">{Math.max(0, cfg.weeklyGoal - data.weekly)}</span> viajes esta semana.
                  </p>
                  <button
                    type="button"
                    onClick={() =>
                      handlePostularOrCredit(
                        'viajes_semana',
                        weekKey,
                        cfg.weeklyGoal,
                        cfg.weeklyReward,
                        data.weekly >= cfg.weeklyGoal
                      )
                    }
                    disabled={busyKey === weekKey}
                    className="h-8 px-3 rounded-xl bg-violet-500 text-white text-xs font-bold active:scale-95 disabled:opacity-60 flex-shrink-0"
                  >
                    Postularme
                  </button>
                </>
              )}
            </div>
          </div>
        </section>

        <div className="flex items-start gap-2 bg-primary/5 border border-primary/10 rounded-xl p-3">
          <Sparkles className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
          <p className="text-[11px] text-muted-foreground leading-relaxed">
            Las recompensas se actualizan semanalmente para incentivar tu trabajo. Postúlate a la meta que quieras alcanzar y, apenas cumplas los días o viajes, la aplicación acreditará automáticamente el bono en tu Cartera.
          </p>
        </div>
      </div>
    </div>
  );
}
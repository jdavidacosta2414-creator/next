import React from 'react';
import {
  Award,
  Zap,
  Calendar,
  CheckCircle2,
  Star,
  TrendingUp,
  ShieldCheck,
  ChevronLeft,
  AlertTriangle,
  Activity,
  ChevronRight,
  Clock,
  Lock,
} from 'lucide-react';
import { DRIVER_TIERS, MIN_VALID_SAMPLE } from '@/lib/driverTier';

function fmtDateShort(iso) {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleDateString('es-CO', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      timeZone: 'America/Bogota',
    });
  } catch {
    return '—';
  }
}

// Sección NIVEL: Trayectoria acumulada del conductor (Bronce, Plata, Oro) y beneficios.
// Mantiene los indicadores históricos separados de servicios y días conectados sin combinarlos en un porcentaje inventado.
export default function DriverPriority({
  mobile,
  tierInfo,
  totalTrips,
  totalReviews,
  avgRating,
  onBack,
  onOpenRendimiento,
}) {
  const current = tierInfo?.current || DRIVER_TIERS[0];
  const next = tierInfo?.next || null;
  const driverName = mobile?.name || 'Conductor NEXT';

  // Los servicios completados y días conectados son históricos acumulados (nunca disminuyen)
  const completedTrips = Math.max(
    Number(tierInfo?.recentTrips ?? 0),
    Number(mobile?.total_completed_services ?? 0),
    Number(totalTrips ?? 0)
  );
  const connectedDays = Math.max(
    Number(tierInfo?.recentDays ?? 0),
    Number(mobile?.total_connected_days ?? 0)
  );

  const acceptance30d = Number(tierInfo?.acceptanceRate ?? mobile?.acceptance_rate_30d ?? 100);
  const cancellation30d = Number(tierInfo?.cancellationRate ?? mobile?.cancellation_rate_30d ?? 0);
  const sampleCount30d = Number(tierInfo?.validSampleCount ?? mobile?.valid_sample_count_30d ?? 0);
  const hasMinSample = sampleCount30d >= MIN_VALID_SAMPLE;
  const recovery = tierInfo?.recovery || { active: Boolean(mobile?.recovery_active) };
  const levelHistory = Array.isArray(tierInfo?.levelHistory) ? tierInfo.levelHistory : [];

  // Barras independientes para servicios y días conectados hacia el siguiente nivel
  const nextServicesTarget = next ? next.minTrips : current.minTrips || 300;
  const nextDaysTarget = next ? next.minDays : current.minDays || 45;
  const servicesBarPct =
    nextServicesTarget > 0
      ? Math.min(100, Math.round((completedTrips / nextServicesTarget) * 100))
      : 100;
  const daysBarPct =
    nextDaysTarget > 0
      ? Math.min(100, Math.round((connectedDays / nextDaysTarget) * 100))
      : 100;

  const servicesMissing = next ? Math.max(0, next.minTrips - completedTrips) : 0;
  const daysMissing = next ? Math.max(0, next.minDays - connectedDays) : 0;

  const nextAccMet = next ? hasMinSample && acceptance30d >= next.minAcceptance : true;
  const nextCancelMet = next ? hasMinSample && cancellation30d <= next.maxCancellation : true;

  const headerGradient =
    current.id === 'oro'
      ? 'from-[#78350F] via-[#B45309] to-[#F59E0B] border-amber-300/45'
      : current.id === 'plata'
        ? 'from-[#1E293B] via-[#475569] to-[#94A3B8] border-slate-300/45'
        : 'from-[#5C240E] via-[#9A3412] to-[#CD7F32] border-amber-500/35';

  return (
    <div className="min-h-screen bg-background">
      {onBack && (
        <div className="sticky top-0 z-20 flex items-center justify-between gap-3 px-4 h-14 bg-card border-b border-border/60">
          <div className="flex items-center gap-2.5 min-w-0">
            <button
              type="button"
              onClick={onBack}
              aria-label="Volver"
              className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-muted transition-colors"
            >
              <ChevronLeft className="w-6 h-6 text-foreground" />
            </button>
            <div className="min-w-0">
              <h1 className="text-foreground font-extrabold text-base truncate">
                Mi Nivel y Beneficios
              </h1>
              <p className="text-[11px] text-muted-foreground truncate">
                Trayectoria acumulada de {driverName}
              </p>
            </div>
          </div>

          {onOpenRendimiento && (
            <button
              type="button"
              onClick={onOpenRendimiento}
              className="h-9 px-3 rounded-full bg-primary/12 text-primary font-extrabold text-xs flex items-center gap-1 flex-shrink-0"
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Rendimiento</span>
            </button>
          )}
        </div>
      )}

      <div className="px-4 pt-4 pb-28 space-y-4">
        {/* Aviso de Periodo de Recuperación de 7 Días si está activo */}
        {recovery?.active && (
          <div className="rounded-3xl border-2 border-amber-500/45 bg-amber-500/10 p-4 space-y-2">
            <div className="flex items-start gap-2.5">
              <AlertTriangle className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <p className="text-sm font-extrabold text-foreground">
                    Periodo de recuperación activo ({recovery.daysRemaining ?? 7}{' '}
                    {(recovery.daysRemaining ?? 7) === 1 ? 'día restante' : 'días restantes'})
                  </p>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-500 text-slate-950">
                    Conservas tu Nivel {current.name}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                  {recovery.reason ||
                    `Tu rendimiento de los últimos 30 días bajó del mínimo de Nivel ${current.name}. Tienes 7 días para recuperar tus indicadores y conservar tu nivel y prioridad.`}
                </p>
                {onOpenRendimiento && (
                  <button
                    type="button"
                    onClick={onOpenRendimiento}
                    className="mt-2.5 inline-flex items-center gap-1 text-xs font-extrabold text-amber-600 dark:text-amber-300 underline"
                  >
                    Ver qué debo mejorar en Rendimiento <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Tarjeta principal del nivel actual (Bronce cobre, Plata metálico u Oro dorado) */}
        <div
          className={`relative overflow-hidden rounded-3xl p-5 text-white shadow-[0_12px_30px_rgba(15,23,42,0.28)] bg-gradient-to-br ${headerGradient} border`}
        >
          <div className="pointer-events-none absolute -top-8 -right-8 w-32 h-20 bg-white/15 -rotate-45 transform" />
          <div className="pointer-events-none absolute -bottom-8 -left-8 w-32 h-20 bg-white/10 -rotate-45 transform" />

          <div className="relative z-10 flex items-start justify-between gap-3">
            <div className="min-w-0">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-black/25 border border-white/25 text-white mb-2">
                <Award className="w-3.5 h-3.5" /> Trayectoria acumulada
              </span>
              <p className="text-xs text-white/85 font-semibold truncate">{driverName}</p>
              <h2 className="text-3xl font-black tracking-tight mt-0.5">
                Tu nivel: {current.name.toUpperCase()}
              </h2>
              <p className="text-white/90 text-xs mt-1">{current.priorityTitle}</p>
            </div>

            <div className="px-3 py-2 rounded-2xl bg-black/30 border border-white/25 text-right backdrop-blur-xs flex-shrink-0">
              <p className="text-[10px] uppercase tracking-wider text-white/80 font-semibold">
                Prioridad
              </p>
              <p className="text-xs font-extrabold flex items-center justify-end gap-1 mt-0.5 text-white">
                <Zap className="w-3.5 h-3.5" /> {current.priorityLabel}
              </p>
            </div>
          </div>

          <p className="relative z-10 text-xs text-white/95 mt-3 leading-relaxed">
            {current.benefit}
          </p>

          {/* Indicadores históricos acumulados separados (nunca se borran ni disminuyen) */}
          <div className="relative z-10 grid grid-cols-2 gap-2.5 mt-4 pt-3 border-t border-white/20">
            <div className="bg-black/25 border border-white/15 rounded-2xl p-3">
              <p className="text-[11px] text-white/85 font-medium">
                Servicios completados
              </p>
              <p className="text-2xl font-black mt-0.5">
                {completedTrips.toLocaleString('es-CO')}
              </p>
              <p className="text-[10px] text-white/75 mt-0.5">Histórico acumulado</p>
            </div>
            <div className="bg-black/25 border border-white/15 rounded-2xl p-3">
              <p className="text-[11px] text-white/85 font-medium">Días conectados</p>
              <p className="text-2xl font-black mt-0.5">
                {connectedDays.toLocaleString('es-CO')}
              </p>
              <p className="text-[10px] text-white/75 mt-0.5">Histórico acumulado</p>
            </div>
          </div>
        </div>

        {/* Progreso detallado e independiente hacia el siguiente nivel */}
        {next ? (
          <div className="bg-card rounded-3xl border border-border shadow-xs p-5 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <div>
                <h3 className="text-foreground font-extrabold text-base">
                  Progreso hacia Nivel {next.name}
                </h3>
                <p className="text-muted-foreground text-xs">
                  Para subir a {next.name} debes cumplir simultáneamente trayectoria y rendimiento
                </p>
              </div>
              <span
                className="px-3 py-1 rounded-full text-xs font-extrabold text-white flex-shrink-0"
                style={{ backgroundColor: next.accentColor }}
              >
                Meta: {next.name}
              </span>
            </div>

            {/* Barra 1 independiente: Servicios completados */}
            <div className="bg-muted/40 border border-border rounded-2xl p-3.5 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-foreground">Servicios completados</span>
                <span className="text-foreground font-extrabold">
                  {completedTrips} / {next.minTrips}
                </span>
              </div>
              <div className="h-2.5 rounded-full bg-muted overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-[#1E6BFF] to-[#00B8D4] rounded-full transition-all duration-500"
                  style={{ width: `${Math.max(4, servicesBarPct)}%` }}
                />
              </div>
              <p className="text-[11px] text-muted-foreground">
                {servicesMissing === 0 ? (
                  <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                    ✓ Meta de servicios alcanzada ({completedTrips} / {next.minTrips})
                  </span>
                ) : (
                  `Te faltan ${servicesMissing} ${
                    servicesMissing === 1 ? 'servicio completado' : 'servicios completados'
                  } para llegar a ${next.minTrips}.`
                )}
              </p>
            </div>

            {/* Barra 2 independiente: Días conectados */}
            <div className="bg-muted/40 border border-border rounded-2xl p-3.5 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-foreground">Días conectados</span>
                <span className="text-foreground font-extrabold">
                  {connectedDays} / {next.minDays}
                </span>
              </div>
              <div className="h-2.5 rounded-full bg-muted overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-[#0284C7] to-[#38BDF8] rounded-full transition-all duration-500"
                  style={{ width: `${Math.max(4, daysBarPct)}%` }}
                />
              </div>
              <p className="text-[11px] text-muted-foreground">
                {daysMissing === 0 ? (
                  <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                    ✓ Meta de días conectados alcanzada ({connectedDays} / {next.minDays})
                  </span>
                ) : (
                  `Te faltan ${daysMissing} ${
                    daysMissing === 1 ? 'día conectado' : 'días conectados'
                  } para llegar a ${next.minDays}.`
                )}
              </p>
            </div>

            {/* Rendimiento requerido para subir al siguiente nivel */}
            <div className="bg-muted/40 border border-border rounded-2xl p-3.5 space-y-2.5">
              <div className="flex items-center justify-between">
                <p className="text-xs font-extrabold text-foreground uppercase tracking-wider">
                  Rendimiento requerido para {next.name} (últimos 30 días)
                </p>
                {!hasMinSample && (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-600 dark:text-amber-300">
                    Muestra: {sampleCount30d}/{MIN_VALID_SAMPLE}
                  </span>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div className="rounded-xl bg-card border border-border p-2.5">
                  <p className="text-[11px] text-muted-foreground">Aceptación mínima</p>
                  <p className="text-sm font-black text-foreground mt-0.5">
                    {next.minAcceptance}%
                  </p>
                  <p
                    className={`text-[11px] font-bold mt-1 ${
                      nextAccMet
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : 'text-amber-600 dark:text-amber-400'
                    }`}
                  >
                    Actual: {acceptance30d}%{' '}
                    {hasMinSample ? (nextAccMet ? '✓' : `(Falta +${(next.minAcceptance - acceptance30d).toFixed(1)}%)`) : ''}
                  </p>
                </div>

                <div className="rounded-xl bg-card border border-border p-2.5">
                  <p className="text-[11px] text-muted-foreground">Cancelaciones máximas</p>
                  <p className="text-sm font-black text-foreground mt-0.5">
                    {next.maxCancellation}%
                  </p>
                  <p
                    className={`text-[11px] font-bold mt-1 ${
                      nextCancelMet
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : 'text-amber-600 dark:text-amber-400'
                    }`}
                  >
                    Actual: {cancellation30d}%{' '}
                    {hasMinSample ? (nextCancelMet ? '✓' : `(Reducir -${(cancellation30d - next.maxCancellation).toFixed(1)}%)`) : ''}
                  </p>
                </div>
              </div>

              {!hasMinSample && (
                <p className="text-[11px] text-muted-foreground leading-relaxed">
                  Necesitamos al menos {MIN_VALID_SAMPLE} registros válidos para evaluar tu rendimiento (llevas {sampleCount30d}).
                </p>
              )}
            </div>
          </div>
        ) : (
          <div className="bg-card rounded-3xl border border-amber-500/40 p-4 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-extrabold text-foreground">
                ¡Estás en el nivel máximo (Nivel Oro)!
              </p>
              <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                Mantén tu aceptación en 90% o más y tus cancelaciones en máximo 3% en los últimos 30 días para conservar tu máxima prioridad.
              </p>
            </div>
          </div>
        )}

        {/* Acceso directo a la sección independiente RENDIMIENTO */}
        {onOpenRendimiento && (
          <button
            type="button"
            onClick={onOpenRendimiento}
            className="w-full rounded-3xl bg-gradient-to-r from-[#051F54] via-[#0B45B4] to-[#00B8FF] p-4 text-white text-left flex items-center justify-between gap-3 shadow-md active:scale-[0.99] transition-transform"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-11 h-11 rounded-2xl bg-white/15 flex items-center justify-center flex-shrink-0">
                <Activity className="w-6 h-6 text-white" />
              </div>
              <div className="min-w-0">
                <p className="text-sm font-extrabold">Ir a mi sección de Rendimiento</p>
                <p className="text-xs text-white/85 truncate">
                  Consulta tu aceptación, cancelaciones y evolución (7, 30 y 90 días)
                </p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-white flex-shrink-0" />
          </button>
        )}

        {/* Beneficios de tu nivel actual */}
        <div className="bg-card rounded-3xl border border-border shadow-xs p-5">
          <h3 className="text-foreground font-extrabold text-base mb-1">
            Beneficios de tu Nivel {current.name}
          </h3>
          <p className="text-xs text-muted-foreground mb-3">
            Tu trayectoria reconoce todo tu trabajo acumulado; tu rendimiento reciente mantiene activos tus beneficios
          </p>
          <div className="space-y-2">
            {(current.benefitsList || [current.benefit]).map((b, i) => (
              <div key={i} className="flex items-start gap-2.5 text-xs text-foreground">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5" />
                <span className="leading-relaxed">{b}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Escala completa de los 3 niveles: Bronce, Plata, Oro */}
        <div className="bg-card rounded-3xl border border-border shadow-xs p-5">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-foreground font-extrabold text-base">
                Categorías del Sistema de Niveles
              </h3>
              <p className="text-muted-foreground text-xs">
                Requisitos acumulados y condiciones de cada categoría
              </p>
            </div>
            <TrendingUp className="w-5 h-5 text-primary flex-shrink-0" />
          </div>

          <div className="space-y-3">
            {DRIVER_TIERS.map((tier) => {
              const isCurrent = tier.id === current.id;
              const isUnlocked = tier.order <= current.order;
              return (
                <div
                  key={tier.id}
                  className={`rounded-2xl p-4 border transition-all ${
                    isCurrent
                      ? 'border-primary bg-primary/5 shadow-xs'
                      : 'border-border bg-muted/30'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2.5">
                      <span
                        className="w-8 h-8 rounded-xl flex items-center justify-center text-white font-bold text-xs shadow-xs flex-shrink-0"
                        style={{ backgroundColor: tier.accentColor }}
                      >
                        {isUnlocked ? (
                          <Award className="w-4 h-4" />
                        ) : (
                          <Lock className="w-3.5 h-3.5" />
                        )}
                      </span>
                      <div>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-extrabold text-sm text-foreground">
                            Nivel {tier.name}
                          </span>
                          {isCurrent && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-primary text-primary-foreground">
                              Tu nivel actual
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-muted-foreground">
                          {tier.id === 'bronce'
                            ? 'Nivel inicial de todos los conductores'
                            : `Mín. ${tier.minTrips} servicios · ${tier.minDays} días conectados · ≥${tier.minAcceptance}% aceptación · ≤${tier.maxCancellation}% cancelación`}
                        </p>
                      </div>
                    </div>

                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-extrabold bg-card border border-border text-foreground flex-shrink-0">
                      <Zap className="w-3 h-3 text-primary" /> {tier.priorityLabel}
                    </span>
                  </div>

                  <p className="text-xs text-muted-foreground leading-relaxed pl-10">
                    {tier.benefit}
                  </p>
                </div>
              );
            })}
          </div>

          <div className="mt-4 pt-3 border-t border-border flex items-start gap-2.5 text-xs text-muted-foreground">
            <ShieldCheck className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              <strong className="text-foreground">Garantía de trayectoria:</strong> Tus{' '}
              {completedTrips} servicios completados y {connectedDays} días conectados son
              históricos acumulados. Nunca se borran ni disminuyen por una mala racha de
              rendimiento.
            </p>
          </div>
        </div>

        {/* Historial de cambios de nivel del conductor */}
        {levelHistory.length > 0 && (
          <div className="bg-card rounded-3xl border border-border shadow-xs p-5 space-y-3">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-primary" />
              <h3 className="text-foreground font-extrabold text-sm">
                Historial de nivel y evaluaciones
              </h3>
            </div>
            <div className="space-y-2.5">
              {levelHistory.slice(0, 6).map((h) => (
                <div
                  key={h.id}
                  className="rounded-2xl bg-muted/40 border border-border p-3 text-xs space-y-1"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-extrabold text-foreground uppercase">
                      {h.change_type === 'ascenso'
                        ? `🏆 Ascenso: ${h.previous_level} → ${h.new_level}`
                        : h.change_type === 'descenso'
                          ? `Cambio de nivel: ${h.previous_level} → ${h.new_level}`
                          : h.change_type === 'inicio_recuperacion'
                            ? `⏳ Inicio de recuperación (${h.new_level})`
                            : h.change_type === 'recuperacion_exitosa'
                              ? `✅ Recuperación exitosa (${h.new_level})`
                              : `📋 Revisión administrativa`}
                    </span>
                    <span className="text-[11px] text-muted-foreground">
                      {fmtDateShort(h.created_date)}
                    </span>
                  </div>
                  <p className="text-muted-foreground leading-relaxed">{h.reason}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
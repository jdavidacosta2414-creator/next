import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, Clock, Check, BadgeCheck, AlertCircle, Gift, Loader2, Wallet, Timer } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from '@/components/ui/use-toast';
import {
  getMinRecharge,
  PASS_DURATION_HOURS,
  isPassActive,
  passExpiry,
  getPassRemainingInfo,
  getEffectiveBalance,
  getPointsWalletBalance,
} from '@/lib/recharge';
import DriverRechargeModal from '@/components/driver/DriverRechargeModal';
import { useBackButton } from '@/hooks/useBackButton';

const fmtCOP = (n) => 'COP ' + Number(n || 0).toLocaleString('es-CO');
const fmtFecha = (d) =>
  d
    ? new Date(d).toLocaleString('es-CO', {
        timeZone: 'America/Bogota',
        dateStyle: 'short',
        timeStyle: 'short',
      })
    : '—';

export default function DriverCartera({ mobile, onBack, onMobileUpdate }) {
  const minAmount = getMinRecharge(mobile?.vehicle_type);
  const [rechargeOpen, setRechargeOpen] = useState(false);
  useBackButton(() => {
    if (rechargeOpen) {
      setRechargeOpen(false);
      return true;
    }
    return false;
  }, true);
  const [pendingRequest, setPendingRequest] = useState(null);
  const [recargas, setRecargas] = useState([]);
  const [activatingFromWallet, setActivatingFromWallet] = useState(false);
  const [nowMs, setNowMs] = useState(() => Date.now());
  const notifiedExpiryRef = useRef(false);

  // Reloj en vivo cada segundo para que el conteo regresivo de las 14 horas sea exacto y visible
  useEffect(() => {
    const t = setInterval(() => setNowMs(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  const paseActivo = isPassActive(mobile);
  const vence = passExpiry(mobile);
  const passCountdown = getPassRemainingInfo(mobile, nowMs);
  const effectiveBalance = getEffectiveBalance(mobile);
  const pointsWalletBalance = getPointsWalletBalance(mobile);
  const canActivateWithPointsWallet = pointsWalletBalance >= minAmount;
  const tuvoPaseVencido = Boolean((mobile?.pass_vence_en || mobile?.pass_activado_en) && !paseActivo);

  const loadRecargas = () => {
    if (!mobile?.id) return;
    base44.entities.WalletTransaction.filter({ mobile_id: mobile.id, type: 'recarga' }, '-created_date', 10)
      .then(setRecargas)
      .catch(() => {});
  };

  const loadPendingRequest = () => {
    if (!mobile?.id) return;
    base44.entities.RechargeRequest.filter({ mobile_id: mobile.id, status: 'pendiente' }, '-created_date', 1)
      .then((list) => setPendingRequest(list[0] || null))
      .catch(() => {});
  };

  // Suscripción en tiempo real al perfil Mobile y a las solicitudes de recarga
  // para que apenas se apruebe la recarga empiece a correr el reloj de 14 horas sin refrescar.
  useEffect(() => {
    if (!mobile?.id) return;
    loadRecargas();
    loadPendingRequest();

    const unsubMobile = base44.entities.Mobile.subscribe((ev) => {
      if (ev?.id === mobile.id && ev?.data) {
        onMobileUpdate?.(ev.data);
        loadRecargas();
      }
    });

    const unsubReq = base44.entities.RechargeRequest.subscribe((ev) => {
      if (!ev?.data || ev.data.mobile_id === mobile.id) {
        loadPendingRequest();
        loadRecargas();
        base44.entities.Mobile.get(mobile.id)
          .then((fresh) => {
            if (fresh) onMobileUpdate?.(fresh);
          })
          .catch(() => {});
      }
    });

    return () => {
      unsubMobile();
      unsubReq();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mobile?.id]);

  // Solo cuando se cumplan las 14 horas completas desde la recarga, renovar el saldo del pase a $0
  useEffect(() => {
    if (!mobile?.id) return;
    if (!paseActivo && Number(mobile.balance || 0) > 0) {
      base44.entities.Mobile.update(mobile.id, { balance: 0, pass_mode: 'pase' })
        .then((updated) => {
          onMobileUpdate?.(updated);
          if (!notifiedExpiryRef.current) {
            notifiedExpiryRef.current = true;
            toast({
              title: `Tus ${PASS_DURATION_HOURS} horas laborales se cumplieron`,
              description:
                pointsWalletBalance >= minAmount
                  ? `Se cumplieron tus ${PASS_DURATION_HOURS} horas y tu saldo pasó a $0, pero tienes ${fmtCOP(pointsWalletBalance)} en tu Cartera por carreras con puntos. ¡Úsalos para activar otras ${PASS_DURATION_HOURS} horas!`
                  : `Se cumplieron tus ${PASS_DURATION_HOURS} horas laborales y tu saldo pasó a $0. Recarga (${fmtCOP(minAmount)}) para activar otras ${PASS_DURATION_HOURS} horas a partir de ahora.`,
            });
          }
        })
        .catch(() => {});
    }
  }, [mobile?.id, mobile?.balance, paseActivo, minAmount, pointsWalletBalance, onMobileUpdate]);

  const handleActivateWithPointsWallet = async () => {
    if (!mobile?.id || activatingFromWallet || pointsWalletBalance < minAmount) return;
    setActivatingFromWallet(true);
    try {
      const res = await base44.functions.invoke('addDriverBalance', {
        mobile_id: mobile.id,
        use_points_wallet: true,
      });
      const data = res?.data || res;
      if (data?.mobile) {
        onMobileUpdate?.(data.mobile);
      } else {
        const refreshed = await base44.entities.Mobile.get(mobile.id);
        onMobileUpdate?.(refreshed);
      }
      loadRecargas();
      toast({
        title: `¡Pase de ${PASS_DURATION_HOURS}h activado desde ahora!`,
        description: `Tienes ${PASS_DURATION_HOURS} horas continuas a partir de este momento para sacar todos los servicios.`,
      });
    } catch (e) {
      toast({
        title: 'No se pudo activar el pase',
        description: e.message || 'Intenta nuevamente.',
        variant: 'destructive',
      });
    } finally {
      setActivatingFromWallet(false);
    }
  };

  const onSubmitted = (createdReq) => {
    setRechargeOpen(false);
    setPendingRequest(createdReq || { status: 'pendiente' });
  };

  return (
    <div className="min-h-screen bg-background flex flex-col max-w-md mx-auto w-full">
      <div className="flex items-center gap-3 px-4 pt-5 pb-3">
        <button onClick={onBack} className="w-10 h-10 flex items-center justify-center">
          <ChevronLeft className="w-6 h-6 text-foreground" />
        </button>
        <h1 className="text-foreground font-bold text-lg">Cartera</h1>
      </div>

      <div className="flex-1 px-4 pb-6 space-y-4">
        {/* Saldo disponible y contador en vivo de 14 horas */}
        <div className="bg-card rounded-2xl p-5 shadow-sm border border-border">
          <p className="text-muted-foreground text-xs mb-1">Saldo disponible en la aplicación</p>
          <p className="text-foreground font-bold text-3xl">{fmtCOP(effectiveBalance)}</p>
          <p className="text-muted-foreground text-xs mt-2">
            Pase de {PASS_DURATION_HOURS} horas continuas ·{' '}
            <span className="font-semibold text-foreground">{fmtCOP(minAmount)}</span> (
            {mobile?.vehicle_type === 'carro' ? 'Carro' : 'Moto'}) · Sin descuento por porcentaje
          </p>
          <p className="text-emerald-600 dark:text-emerald-400 text-xs font-semibold mt-1">
            Si recargas ahora, tienes {PASS_DURATION_HOURS} horas completas a partir de ese momento para sacar todos los servicios (100% para ti).
          </p>

          {/* Contador regresivo en vivo cuando el pase de 14h está activo */}
          {paseActivo && passCountdown.active && (
            <div
              className="mt-4 rounded-2xl bg-emerald-500/12 border border-emerald-500/35 p-3.5"
              data-testid="driver-16h-countdown-box"
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Timer className="w-5 h-5 text-emerald-600 dark:text-emerald-400 animate-pulse" />
                  <span className="text-xs font-extrabold text-emerald-700 dark:text-emerald-300 uppercase tracking-wide">
                    Tiempo restante de tus {PASS_DURATION_HOURS}h
                  </span>
                </div>
                <span
                  className="font-mono text-lg font-black text-emerald-700 dark:text-emerald-300"
                  data-testid="driver-16h-countdown-timer"
                >
                  {passCountdown.formattedWithSeconds}
                </span>
              </div>
              <div className="w-full h-2 rounded-full bg-emerald-950/15 dark:bg-white/10 overflow-hidden mt-2">
                <div
                  className="h-full rounded-full bg-emerald-500 transition-all duration-500"
                  style={{ width: `${passCountdown.progressPct}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[11px] text-muted-foreground mt-2">
                <span>
                  Activado: <strong className="text-foreground">{fmtFecha(mobile?.pass_activado_en)}</strong>
                </span>
                <span>
                  Vence: <strong className="text-foreground">{fmtFecha(vence)}</strong>
                </span>
              </div>
            </div>
          )}

          {/* Saldo acumulado por carreras redimidas con puntos */}
          <div className="mt-4 pt-3.5 border-t border-border flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-[#00E5FF]/15 text-[#0091D5] dark:text-[#00E5FF] flex items-center justify-center flex-shrink-0">
                <Gift className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-extrabold text-foreground">
                  Saldo por carreras con puntos
                </p>
                <p className="text-[11px] text-muted-foreground leading-snug">
                  No vence a las 14h · Úsalo para activar tus próximas 14 horas
                </p>
              </div>
            </div>
            <span className="text-base font-extrabold text-[#0091D5] dark:text-[#00E5FF] flex-shrink-0">
              {fmtCOP(pointsWalletBalance)}
            </span>
          </div>

          {canActivateWithPointsWallet && !paseActivo && (
            <button
              type="button"
              disabled={activatingFromWallet}
              onClick={handleActivateWithPointsWallet}
              className="keep-dark-ink mt-3.5 w-full h-12 rounded-2xl bg-[#00E5FF] text-slate-950 font-extrabold text-xs flex items-center justify-center gap-2 shadow-md active:scale-[0.99] transition-all"
            >
              {activatingFromWallet ? (
                <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
              ) : (
                <>
                  <Wallet className="w-4 h-4 text-slate-950" />
                  <span>
                    Activar {PASS_DURATION_HOURS}h desde ahora con mi saldo ({fmtCOP(minAmount)})
                  </span>
                </>
              )}
            </button>
          )}
        </div>

        {/* Aviso destacado cuando se cumplieron las 14 horas */}
        {tuvoPaseVencido && !pendingRequest && (
          <div className="rounded-2xl bg-amber-500/15 border border-amber-500/30 p-4 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="text-foreground font-bold text-sm">
                Tus {PASS_DURATION_HOURS} horas laborales se cumplieron
              </p>
              <p className="text-muted-foreground text-xs mt-1 leading-relaxed">
                {canActivateWithPointsWallet
                  ? `Tienes ${fmtCOP(pointsWalletBalance)} acumulados por servicios redimidos con puntos. Puedes usarlos ahora mismo para activar tus próximas ${PASS_DURATION_HOURS} horas continuas sin necesidad de transferir.`
                  : `Tu saldo del pase se renovó a $0 al cumplirse las ${PASS_DURATION_HOURS} horas desde tu última recarga. Recarga ${fmtCOP(minAmount)} para tener otras ${PASS_DURATION_HOURS} horas a partir de ahora.`}
              </p>
            </div>
          </div>
        )}

        {/* Información de la modalidad única: Pase de 14 horas laborales */}
        <div className="bg-card rounded-2xl p-5 shadow-sm border border-border space-y-3">
          <div className="flex items-center justify-between gap-2">
            <h2 className="text-foreground font-bold text-base">
              Pase de {PASS_DURATION_HOURS} horas laborales
            </h2>
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-primary/15 text-primary">
              0% comisión
            </span>
          </div>

          <div className="w-full text-left rounded-2xl p-4 border-2 border-primary bg-primary/10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full flex items-center justify-center bg-primary text-primary-foreground flex-shrink-0">
                <BadgeCheck className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-foreground font-bold text-sm">
                  Pase {mobile?.vehicle_type === 'carro' ? 'Carro ($10.000)' : 'Moto ($7.000)'} · {PASS_DURATION_HOURS}h continuas
                </p>
                <p className="text-muted-foreground text-xs mt-0.5 leading-relaxed">
                  Tus {PASS_DURATION_HOURS} horas se cuentan completas desde el momento en que recargas (incluso si pasan al día siguiente).
                </p>
              </div>
              <Check className="w-5 h-5 text-primary flex-shrink-0" />
            </div>
          </div>
        </div>

        {/* Estado del pase */}
        <div className="bg-card rounded-2xl p-5 shadow-sm border border-border space-y-3">
          <h2 className="text-foreground font-bold text-base">Estado de tu pase</h2>
          {paseActivo ? (
            <div className="rounded-2xl bg-[#E8F8EE] dark:bg-[#3DDC84]/15 border border-[#3DDC84]/30 p-4">
              <div className="flex items-center justify-between gap-2 text-[#1B8A4A] dark:text-[#3DDC84]">
                <div className="flex items-center gap-2">
                  <Check className="w-5 h-5" />
                  <p className="font-bold text-sm">
                    Pase de {PASS_DURATION_HOURS} horas activo ({passCountdown.formatted} restantes)
                  </p>
                </div>
              </div>
              <p className="text-gray-600 dark:text-muted-foreground text-xs mt-2">
                Tienes servicios ilimitados hasta el <strong>{fmtFecha(vence)}</strong> (14 horas exactas desde tu activación).
              </p>
              <button
                onClick={() => setRechargeOpen(true)}
                className="mt-3 w-full h-11 rounded-2xl bg-primary text-primary-foreground font-bold text-sm"
              >
                Recargar nuevo pase de {PASS_DURATION_HOURS}h ({fmtCOP(minAmount)})
              </button>
            </div>
          ) : pendingRequest ? (
            <div className="bg-[#FFF3CD] dark:bg-amber-500/15 rounded-2xl p-4 text-center space-y-2">
              <p className="text-black dark:text-foreground font-bold text-sm">
                Recarga en verificación
              </p>
              <p className="text-gray-600 dark:text-muted-foreground text-xs leading-relaxed">
                Tu captura de transferencia fue recibida. Apenas la Central la apruebe, empezarán a correr tus {PASS_DURATION_HOURS} horas continuas a partir de ese momento.
              </p>
              <button
                type="button"
                onClick={() => setRechargeOpen(true)}
                className="text-xs font-extrabold text-primary underline pt-1"
              >
                ¿Necesitas subir otra captura? Toca aquí
              </button>
            </div>
          ) : (
            <div className="rounded-2xl bg-muted border border-border p-4 space-y-2.5">
              <div className="flex items-center gap-2 text-foreground">
                <Clock className="w-5 h-5 text-amber-500" />
                <p className="font-bold text-sm">
                  {tuvoPaseVencido ? 'Pase de 14h vencido' : 'Sin pase activo'}
                </p>
              </div>
              <p className="text-muted-foreground text-xs leading-relaxed">
                {canActivateWithPointsWallet
                  ? `Usa tus ${fmtCOP(pointsWalletBalance)} disponibles en Cartera para activar tus ${PASS_DURATION_HOURS} horas continuas inmediatamente, o recarga por transferencia.`
                  : `Activa tu pase recargando ${fmtCOP(minAmount)} ($7.000 moto / $10.000 carro) y tendrás ${PASS_DURATION_HOURS} horas continuas desde ahora para sacar todos los servicios sin comisión.`}
              </p>
              {canActivateWithPointsWallet && (
                <button
                  type="button"
                  disabled={activatingFromWallet}
                  onClick={handleActivateWithPointsWallet}
                  className="keep-dark-ink w-full h-11 rounded-2xl bg-[#00E5FF] text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 shadow"
                >
                  {activatingFromWallet ? (
                    <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
                  ) : (
                    `Activar ${PASS_DURATION_HOURS}h con saldo de Cartera (${fmtCOP(minAmount)})`
                  )}
                </button>
              )}
              <button
                onClick={() => setRechargeOpen(true)}
                data-testid="open-recharge-modal-btn"
                className="w-full h-11 rounded-2xl bg-primary text-primary-foreground font-bold text-sm"
              >
                Recargar pase por transferencia ({fmtCOP(minAmount)})
              </button>
            </div>
          )}
        </div>

        {/* Últimos abonos */}
        <div>
          <h2 className="text-foreground font-bold text-base mb-3">Últimos abonos y recargas</h2>
          {recargas.length === 0 ? (
            <div className="bg-card rounded-2xl p-6 text-center shadow-sm border border-border">
              <p className="text-muted-foreground text-sm">
                Todavía no tienes recargas ni abonos registrados.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {recargas.map((r) => (
                <div
                  key={r.id}
                  className="bg-card rounded-2xl p-4 flex items-center justify-between shadow-sm border border-border"
                >
                  <div className="min-w-0">
                    <p className="text-foreground text-sm font-medium truncate">
                      {r.description || 'Pase 14h laborales'}
                    </p>
                    <p className="text-muted-foreground text-xs">
                      {new Date(r.created_date).toLocaleString('es-CO', {
                        timeZone: 'America/Bogota',
                        dateStyle: 'short',
                        timeStyle: 'short',
                      })}
                    </p>
                  </div>
                  <p className="text-emerald-600 dark:text-emerald-400 font-extrabold text-sm flex-shrink-0 ml-3">
                    +{fmtCOP(r.amount)}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {rechargeOpen && (
        <DriverRechargeModal
          mobile={mobile}
          initialAmount={minAmount}
          onClose={() => setRechargeOpen(false)}
          onSubmitted={onSubmitted}
        />
      )}
    </div>
  );
}
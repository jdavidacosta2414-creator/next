import React from 'react';
import { Bike, Car, Package, Loader2 } from 'lucide-react';
import { DRIVER_CATEGORY_LABELS, isProfileApproved } from '@/lib/driverProfiles';

const ICONS = { moto: Bike, carro: Car, mensajero: Package };

// Una categoría de la cuenta del conductor con el estado de su registro.
export default function DriverCategoryRow({ category, profile, current, switching, disabled, onSwitch }) {
  const Icon = ICONS[category];
  const rejected = profile?.approval_status === 'rechazado';
  const status = !profile
    ? 'Sin registrar'
    : profile.approval_status === 'pendiente'
      ? 'En revisión por la Central'
      : rejected
        ? 'Rechazado por la Central'
        : current
          ? 'En uso'
          : 'Activo';

  return (
    <div className={`flex items-center gap-3 p-3 rounded-2xl border bg-card ${current ? 'border-primary' : 'border-border'}`}>
      <span className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
        <Icon className="w-5 h-5 text-primary" />
      </span>
      <div className="flex-1 min-w-0 text-left">
        <p className="text-sm font-bold text-foreground">{DRIVER_CATEGORY_LABELS[category]}</p>
        <p className={`text-xs truncate ${rejected ? 'text-destructive' : 'text-muted-foreground'}`}>
          {status}
          {profile?.plate ? ` · Placa ${profile.plate}` : ''}
        </p>
      </div>
      {profile && isProfileApproved(profile) && !current && (
        <button
          type="button"
          onClick={onSwitch}
          disabled={disabled}
          className="h-9 px-4 rounded-full bg-primary text-primary-foreground text-xs font-bold flex items-center gap-1.5 disabled:opacity-60"
        >
          {switching && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
          Cambiar
        </button>
      )}
    </div>
  );
}
import React, { useState, useRef } from 'react';
import { X, Copy, Loader2, Upload, Check, Image as ImageIcon, RefreshCw, Clock } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from '@/components/ui/use-toast';
import { PAYMENT_ACCOUNTS, getMinRecharge, PASS_DURATION_HOURS } from '@/lib/recharge';
import { seedStorageUrlCache, resolveStorageUrl } from '@/components/shared/ResolvedAvatar';
import { useBackButton } from '@/hooks/useBackButton';
import { checkDocument } from '@/lib/checkDocument';

const fmtCOP = (n) => 'COP ' + Number(n || 0).toLocaleString('es-CO');

// Normaliza y comprime capturas de pantalla grandes del celular a JPEG ligero
// para que suban rápido y sin errores en cualquier red móvil o WebView APK.
async function normalizeReceiptImage(file, maxSize = 1400, quality = 0.82) {
  if (!file || typeof document === 'undefined') return file;
  return new Promise((resolve) => {
    try {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const img = new window.Image();
        img.onload = () => {
          try {
            let { width, height } = img;
            if (!width || !height) {
              resolve(file);
              return;
            }
            if (width > height) {
              if (width > maxSize) {
                height = Math.round((height * maxSize) / width);
                width = maxSize;
              }
            } else if (height > maxSize) {
              width = Math.round((width * maxSize) / height);
              height = maxSize;
            }
            const canvas = document.createElement('canvas');
            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            ctx.fillStyle = '#FFFFFF';
            ctx.fillRect(0, 0, width, height);
            ctx.drawImage(img, 0, 0, width, height);
            canvas.toBlob(
              (blob) => {
                if (!blob) {
                  resolve(file);
                  return;
                }
                const safeName = (file.name || 'comprobante.jpg').replace(/\.\w+$/, '') + '.jpg';
                try {
                  resolve(new File([blob], safeName, { type: 'image/jpeg' }));
                } catch {
                  blob.name = safeName;
                  resolve(blob);
                }
              },
              'image/jpeg',
              quality
            );
          } catch {
            resolve(file);
          }
        };
        img.onerror = () => resolve(file);
        img.src = ev.target?.result;
      };
      reader.onerror = () => resolve(file);
      reader.readAsDataURL(file);
    } catch {
      resolve(file);
    }
  });
}

// Modal de recarga: muestra cuentas/QR, permite elegir captura de pantalla de la galería y crea la solicitud de 14 horas.
export default function DriverRechargeModal({ mobile, initialAmount, onClose, onSubmitted }) {
  useBackButton(onClose, true);
  const minAmount = getMinRecharge(mobile?.vehicle_type);
  const [amount, setAmount] = useState(String(initialAmount || minAmount));
  const [method, setMethod] = useState('llave_breve');
  const [photoUri, setPhotoUri] = useState('');
  const [photoPreview, setPhotoPreview] = useState('');
  const [uploadError, setUploadError] = useState('');
  const [uploading, setUploading] = useState(false);
  const [sending, setSending] = useState(false);
  const fileInputRef = useRef(null);

  const account = PAYMENT_ACCOUNTS.find((a) => a.id === method);

  const copy = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({ title: 'Copiado al portapapeles' });
    } catch {}
  };

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadError('');
    setUploading(true);
    const localBlobUrl = URL.createObjectURL(file);
    setPhotoPreview(localBlobUrl);

    try {
      const processed = await normalizeReceiptImage(file);
      let uploadedUri = '';
      try {
        const res = await base44.integrations.Core.UploadPrivateFile({ file: processed });
        uploadedUri = res?.file_uri || '';
      } catch {
        // Respaldo con el archivo original si el procesado falló
        const fallbackRes = await base44.integrations.Core.UploadPrivateFile({ file });
        uploadedUri = fallbackRes?.file_uri || '';
      }

      if (!uploadedUri) {
        throw new Error('No se recibió confirmación del archivo subido');
      }

      const check = await checkDocument({ kind: 'transfer', file_uri: uploadedUri, amount: Number(amount || 0) });
      if (!check.ok) {
        throw new Error(check.message || 'La imagen no corresponde a un comprobante de transferencia.');
      }

      seedStorageUrlCache(uploadedUri, localBlobUrl);
      resolveStorageUrl(uploadedUri).catch(() => {});
      setPhotoUri(uploadedUri);
      toast({
        title: 'Captura cargada correctamente',
        description: 'Ya puedes presionar "Enviar comprobante".',
      });
    } catch (err) {
      setPhotoUri('');
      setPhotoPreview('');
      const msg = err?.message || 'No se pudo subir la captura. Intenta seleccionarla de nuevo.';
      setUploadError(msg);
      toast({
        title: 'Error al subir la captura',
        description: msg,
        variant: 'destructive',
      });
    } finally {
      setUploading(false);
      if (e.target) e.target.value = '';
    }
  };

  const submit = async () => {
    const val = Number(amount || 0);
    if (val < minAmount) {
      toast({ title: `El monto mínimo es ${fmtCOP(minAmount)}`, variant: 'destructive' });
      return;
    }
    if (!photoUri) {
      toast({
        title: 'Sube la captura de la transferencia',
        description: 'Toca el recuadro para elegir la captura desde tu galería.',
        variant: 'destructive',
      });
      return;
    }
    setSending(true);
    try {
      const created = await base44.entities.RechargeRequest.create({
        mobile_id: mobile.id,
        mobile_name: mobile.name,
        amount: val,
        payment_method: method,
        transfer_photo: photoUri,
        status: 'pendiente',
      });
      base44.functions.invoke('verifyRechargeTransfer', { request_id: created.id }).catch(() => {});
      toast({
        title: 'Comprobante enviado con éxito',
        description: `Al aprobarse tu recarga tendrás ${PASS_DURATION_HOURS} horas continuas a partir de ese momento para sacar todos los servicios.`,
      });
      onSubmitted?.(created);
    } catch (e) {
      toast({ title: 'Error al enviar', description: e.message, variant: 'destructive' });
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[1800] bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center">
      <div className="bg-card w-full max-w-md rounded-t-3xl sm:rounded-3xl max-h-[92vh] overflow-y-auto no-scrollbar border border-border shadow-2xl">
        <div className="sticky top-0 bg-card/95 backdrop-blur flex items-center justify-between px-4 py-4 border-b border-border z-20">
          <div>
            <h2 className="text-foreground font-extrabold text-lg leading-tight">
              Recargar pase de {PASS_DURATION_HOURS} horas
            </h2>
            <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1 mt-0.5">
              <Clock className="w-3.5 h-3.5" /> {PASS_DURATION_HOURS} horas continuas desde que se activa tu recarga
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Cerrar"
            className="ml-3 w-9 h-9 rounded-full bg-muted flex items-center justify-center text-foreground flex-shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-4 py-4 space-y-5">
          {/* Monto */}
          <div>
            <p className="text-muted-foreground text-xs mb-1.5">
              Monto mínimo ({mobile?.vehicle_type === 'carro' ? 'Carro' : 'Moto'}):{' '}
              <span className="text-foreground font-bold">{fmtCOP(minAmount)}</span>
            </p>
            <div className="bg-[#c2f0d1] dark:bg-emerald-500/15 rounded-xl px-4 py-3 border border-emerald-500/30">
              <input
                type="number"
                inputMode="numeric"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full bg-transparent outline-none text-foreground font-bold text-2xl"
                placeholder="0"
              />
            </div>
          </div>

          {/* Métodos */}
          <div>
            <p className="text-foreground font-bold text-sm mb-2">Transfiere a una de estas cuentas</p>
            <div className="space-y-2">
              {PAYMENT_ACCOUNTS.map((a) => (
                <button
                  key={a.id}
                  type="button"
                  onClick={() => setMethod(a.id)}
                  className={`w-full text-left rounded-2xl p-3 border-2 transition-colors ${
                    method === a.id ? 'border-primary bg-primary/10' : 'border-border bg-card'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {a.qr ? (
                      <img
                        src={a.qr}
                        alt="QR"
                        className="w-12 h-12 rounded-lg object-contain bg-white border border-border flex-shrink-0"
                      />
                    ) : (
                      <div className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center text-foreground font-bold text-xs flex-shrink-0">
                        {a.label.slice(0, 2).toUpperCase()}
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-foreground font-bold text-sm">{a.label}</p>
                      <p className="text-muted-foreground text-xs truncate">
                        {a.accountType ? `${a.accountType} · ` : ''}
                        {a.number}
                      </p>
                    </div>
                    {method === a.id && <Check className="w-5 h-5 text-primary flex-shrink-0" />}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Detalle del método seleccionado */}
          {account?.qr ? (
            <div className="bg-card rounded-2xl p-4 border border-border text-center">
              <img
                src={account.qr}
                alt="QR llave breve"
                className="w-44 h-44 mx-auto rounded-xl object-contain bg-white p-1"
              />
              <p className="text-foreground font-bold text-lg mt-2">{account.number}</p>
              <button
                type="button"
                onClick={() => copy(account.number)}
                className="text-primary text-sm font-bold mt-1 inline-flex items-center gap-1"
              >
                <Copy className="w-4 h-4" /> Copiar llave
              </button>
            </div>
          ) : (
            account && (
              <div className="bg-card rounded-2xl p-4 border border-border flex items-center justify-between">
                <div className="min-w-0">
                  <p className="text-foreground font-bold text-sm">{account.label}</p>
                  {account.accountType && (
                    <p className="text-muted-foreground text-xs">{account.accountType}</p>
                  )}
                  <p className="text-foreground text-lg font-bold mt-1">{account.number}</p>
                  <p className="text-muted-foreground text-xs">Titular: {account.holder}</p>
                </div>
                <button
                  type="button"
                  onClick={() => copy(account.number)}
                  className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0"
                >
                  <Copy className="w-5 h-5 text-primary" />
                </button>
              </div>
            )
          )}

          {/* Captura de pantalla del comprobante (con input directo superpuesto para abrir Galería/Capturas en celular y APK) */}
          <div data-photo-picker="true">
            <p className="text-foreground font-bold text-sm mb-2">
              Captura de la transferencia
            </p>

            {photoPreview ? (
              <div className="space-y-2">
                <div className="relative rounded-2xl overflow-hidden border-2 border-emerald-500/50 bg-muted">
                  <img
                    src={photoPreview}
                    alt="Comprobante de transferencia"
                    className="w-full h-48 object-contain bg-black/5"
                  />
                  {!uploading && (
                    <button
                      type="button"
                      onClick={() => {
                        setPhotoUri('');
                        setPhotoPreview('');
                        setUploadError('');
                      }}
                      className="absolute top-2.5 right-2.5 bg-red-500 text-white rounded-full p-1.5 shadow-lg z-20"
                      aria-label="Quitar captura"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                  {uploading && (
                    <div className="absolute inset-0 bg-card/80 backdrop-blur-xs flex flex-col items-center justify-center gap-2">
                      <Loader2 className="w-7 h-7 animate-spin text-primary" />
                      <span className="text-xs font-bold text-foreground">
                        Subiendo captura...
                      </span>
                    </div>
                  )}
                </div>

                {!uploading && photoUri && (
                  <div className="flex items-center justify-between rounded-xl bg-emerald-500/15 border border-emerald-500/30 px-3 py-2">
                    <span className="text-xs font-extrabold text-emerald-700 dark:text-emerald-300 flex items-center gap-1.5">
                      <Check className="w-4 h-4" /> Captura lista para enviar
                    </span>
                    <div className="relative overflow-hidden text-xs font-bold text-primary inline-flex items-center gap-1 cursor-pointer">
                      <RefreshCw className="w-3.5 h-3.5" /> Cambiar imagen
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFile}
                        onClick={() => {
                          if (typeof window !== 'undefined') {
                            window.__nextFilePickerOpenUntil = Date.now() + 60000;
                          }
                        }}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                      />
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div
                data-testid="recharge-upload-box"
                className="relative overflow-hidden w-full h-36 flex flex-col items-center justify-center gap-2 border-2 border-dashed border-primary/50 bg-primary/5 rounded-2xl text-foreground cursor-pointer hover:bg-primary/10 active:scale-[0.99] transition-all px-4 text-center"
              >
                {uploading ? (
                  <>
                    <Loader2 className="w-7 h-7 animate-spin text-primary" />
                    <span className="text-sm font-bold text-primary">Cargando captura...</span>
                  </>
                ) : (
                  <>
                    <div className="w-11 h-11 rounded-full bg-primary/15 text-primary flex items-center justify-center">
                      <ImageIcon className="w-5 h-5" />
                    </div>
                    <span className="text-sm font-extrabold text-foreground">
                      Toca aquí para montar la captura de transferencia
                    </span>
                    <span className="text-xs text-muted-foreground">
                      Selecciona el pantallazo desde tu galería o archivos
                    </span>
                  </>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFile}
                  onClick={() => {
                    if (typeof window !== 'undefined') {
                      window.__nextFilePickerOpenUntil = Date.now() + 60000;
                    }
                  }}
                  disabled={uploading}
                  data-testid="recharge-receipt-input"
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                />
              </div>
            )}

            {uploadError && (
              <p className="text-xs font-semibold text-destructive mt-2">{uploadError}</p>
            )}
          </div>

          {/* Enviar */}
          <button
            type="button"
            onClick={submit}
            disabled={sending || uploading || !photoUri}
            data-testid="recharge-submit-btn"
            className="w-full h-12 rounded-2xl bg-primary text-primary-foreground font-extrabold text-sm flex items-center justify-center gap-2 disabled:opacity-50 shadow-lg shadow-primary/25"
          >
            {sending ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Enviando comprobante...</span>
              </>
            ) : (
              <>
                <Upload className="w-4 h-4" />
                <span>Enviar comprobante</span>
              </>
            )}
          </button>

          <p className="text-muted-foreground text-xs text-center leading-relaxed -mt-1">
            Al activarse tu recarga tendrás <strong>{PASS_DURATION_HOURS} horas continuas a partir de ese momento</strong> para sacar todos los servicios con el 0% de comisión. Solo cuando se cumplan las {PASS_DURATION_HOURS} horas completas tu saldo volverá a $0.
          </p>
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import { Bike, Car, Package } from 'lucide-react';

const OPTIONS = [
  { key: 'moto', label: 'Moto', Icon: Bike },
  { key: 'carro', label: 'Carro', Icon: Car },
  { key: 'mensajero', label: 'Mensajero', Icon: Package },
];

// "taken" son las categorías en las que la cuenta ya está registrada: no se pueden repetir.
export default function DriverCategoryPicker({ value, onChange, taken = [] }) {
  return (
    <div className="grid grid-cols-3 gap-2.5">
      {OPTIONS.map(({ key, label, Icon }) => {
        const active = value === key;
        const isTaken = taken.includes(key);
        return (
          <button
            key={key}
            type="button"
            disabled={isTaken}
            onClick={() => onChange(key)}
            className={`flex flex-col items-center justify-center gap-1 h-16 rounded-2xl border-2 transition-all disabled:opacity-50 ${
              active
                ? 'border-[#1E6BFF] dark:border-[#00E5FF] bg-[#1E6BFF]/10 dark:bg-[#00E5FF]/10'
                : 'border-slate-200 dark:border-white/10 bg-white dark:bg-white/5'
            }`}
          >
            <Icon className={`w-5 h-5 ${active ? 'text-[#1E6BFF] dark:text-[#00E5FF]' : 'text-slate-500 dark:text-[#5A6478]'}`} />
            <span className={`font-bold text-xs ${active ? 'text-[#1E6BFF] dark:text-white' : 'text-slate-600 dark:text-[#5A6478]'}`}>
              {label}
            </span>
            {isTaken && (
              <span className="text-[9px] font-semibold leading-none text-muted-foreground">Ya registrado</span>
            )}
          </button>
        );
      })}
    </div>
  );
}
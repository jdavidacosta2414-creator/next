import React, { useState, useEffect, useCallback } from 'react';
import { Hash, Copy, Loader2, RefreshCw } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from '@/components/ui/use-toast';

// El ID es permanente: una vez consultado se guarda en el celular para mostrarlo al instante.
const cacheKey = (mobileId) => `next_courier_id_${mobileId}`;
const readCached = (mobileId) => {
  try {
    return window.localStorage.getItem(cacheKey(mobileId)) || '';
  } catch {
    return '';
  }
};

// ID corto y permanente del mensajero: el que le da a los comercios de NEXT Negocios para que le asignen pedidos.
export default function CourierIdCard({ mobileId }) {
  const [code, setCode] = useState(() => readCached(mobileId));
  const [failed, setFailed] = useState(false);

  const load = useCallback(async () => {
    setFailed(false);
    try {
      const res = await base44.functions.invoke('courierId', { mobile_id: mobileId });
      setCode(res.data.courier_id);
      window.localStorage.setItem(cacheKey(mobileId), res.data.courier_id);
    } catch {
      setFailed(true);
    }
  }, [mobileId]);

  useEffect(() => {
    if (!readCached(mobileId)) load();
  }, [mobileId, load]);

  const copy = async () => {
    await navigator.clipboard.writeText(code);
    toast({ title: 'ID copiado' });
  };

  return (
    <div
      data-testid="courier-id-card"
      className="bg-card rounded-2xl p-4 border border-border shadow-sm flex items-center gap-3"
    >
      <div className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center flex-shrink-0">
        <Hash className="w-5 h-5" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-[11px] font-extrabold uppercase tracking-wider text-muted-foreground">
          Tu ID de mensajero
        </p>
        {code ? (
          <p className="text-2xl font-black text-foreground tracking-[0.18em] leading-tight">{code}</p>
        ) : failed ? (
          <button
            type="button"
            onClick={load}
            className="my-0.5 inline-flex items-center gap-1.5 text-sm font-bold text-primary"
          >
            <RefreshCw className="w-4 h-4" /> No se pudo cargar. Reintentar
          </button>
        ) : (
          <Loader2 className="w-5 h-5 my-1 animate-spin text-primary" />
        )}
        <p className="text-xs text-muted-foreground leading-snug mt-0.5">
          Dáselo a los comercios de NEXT Negocios para que te asignen pedidos directamente. Nunca cambia.
        </p>
      </div>
      {code && (
        <button
          type="button"
          onClick={copy}
          className="h-9 px-3 rounded-xl bg-primary text-primary-foreground text-xs font-bold flex items-center gap-1.5 flex-shrink-0 active:scale-95 transition-transform"
        >
          <Copy className="w-3.5 h-3.5" /> Copiar
        </button>
      )}
    </div>
  );
}
import React, { useState, useEffect } from 'react';
import {
  Wallet, Clock, Bell, Share2, ShieldCheck,
  Settings, HelpCircle, Headphones, LogOut, Bike, Star, Loader2, Gift, Shirt, Award, Activity, Moon, Sun, ChevronRight, Layers,
} from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import { useTheme } from '@/lib/ThemeContext';
import { setExplicitUserMode } from '@/lib/roles';
import ResolvedAvatar from '@/components/shared/ResolvedAvatar';

// Menú lateral del conductor con el diseño visual y colores de marca idénticos al del pasajero.
export default function DriverDrawer({ mobile, user, onClose, onNavigate }) {
  const { toast } = useToast();
  const { theme, toggleTheme } = useTheme();
  const [rating, setRating] = useState(null);
  const [count, setCount] = useState(0);
  const [switching, setSwitching] = useState(false);

  useEffect(() => {
    if (!mobile?.id) return;
    base44.entities.Service.filter({ mobile_id: mobile.id, status: 'finalizado' }, '-created_date', 200)
      .then((svcs) => {
        const rated = svcs.filter((s) => typeof s.rating === 'number' && s.rating > 0);
        if (rated.length) {
          setRating((rated.reduce((a, s) => a + s.rating, 0) / rated.length).toFixed(2).replace('.', ','));
          setCount(rated.length);
        } else {
          setCount(svcs.length);
        }
      })
      .catch(() => {});
  }, [mobile?.id]);

  const soon = (label) => toast({ title: 'Próximamente', description: `${label} estará disponible pronto.` });

  const switchToPassenger = () => {
    setSwitching(true);
    try {
      setExplicitUserMode('pasajero');
      window.location.replace('/cliente');
    } finally {
      setSwitching(false);
    }
  };

  const items = [
    { icon: Award, label: 'Mi Nivel y Beneficios', action: () => onNavigate?.('prioridad') },
    { icon: Activity, label: 'Rendimiento', action: () => onNavigate?.('rendimiento') },
    { icon: Wallet, label: 'Cartera', action: () => onNavigate?.('cartera') },
    { icon: Layers, label: 'Mis categorías', action: () => onNavigate?.('categorias') },
    { icon: Shirt, label: 'Chaqueta', action: () => onNavigate?.('chaqueta') },
    { icon: Gift, label: 'Puntos y recompensas', action: () => onNavigate?.('recompensas') },
    { icon: Clock, label: 'Historial de viajes', action: () => onNavigate?.('historial') },
    { icon: Star, label: 'Valoración y comentario', action: () => onNavigate?.('valoraciones') },
    { icon: Bell, label: 'Notificaciones', action: () => onNavigate?.('notificaciones') },
    { icon: Share2, label: 'Compartir app', action: () => onNavigate?.('compartir') },
    { icon: ShieldCheck, label: 'Seguridad', action: () => onNavigate?.('seguridad') },
    { icon: Settings, label: 'Configuración', action: () => onNavigate?.('config') },
    { icon: HelpCircle, label: 'Ayuda', action: () => onNavigate?.('ayuda') },
    { icon: Headphones, label: 'Soporte', action: () => onNavigate?.('soporte') },
  ];

  const displayName = mobile?.name || user?.display_name || user?.full_name || 'Conductor';
  const profilePhoto = mobile?.photo_url || user?.photo_url || '';

  return (
    <div className="fixed inset-0 z-[2100] flex max-w-md mx-auto w-full">
      <div
        className="absolute inset-0 bg-black/45 backdrop-blur-[1px]"
        onClick={onClose}
      />

      <div className="relative w-[82%] max-w-[320px] h-full bg-white dark:bg-card shadow-2xl flex flex-col animate-in slide-in-from-left overflow-hidden">
        {/* Cabecera azul con detalles diagonales y curva inferior */}
        <div className="relative flex-shrink-0">
          <button
            type="button"
            onClick={() => onNavigate?.('perfil')}
            className="relative w-full overflow-hidden bg-gradient-to-r from-[#041738] via-[#072B66] to-[#0B439C] pt-6 pb-7 px-4 text-left"
          >
            {/* Acentos diagonales decorativos estilo banner */}
            <div className="pointer-events-none absolute -top-6 -left-6 w-24 h-16 bg-gradient-to-r from-[#00D4FF]/60 to-[#1E6BFF]/10 -rotate-45 transform" />
            <div className="pointer-events-none absolute -top-3 left-6 w-16 h-2 bg-[#00E5FF]/50 -rotate-45 transform" />
            <div className="pointer-events-none absolute -bottom-6 -right-6 w-28 h-16 bg-gradient-to-l from-[#00D4FF]/55 to-[#1E6BFF]/20 -rotate-45 transform" />
            <div className="pointer-events-none absolute bottom-2 right-12 w-16 h-2 bg-[#00E5FF]/50 -rotate-45 transform" />

            <div className="relative z-10 flex items-center gap-3.5">
              {/* Avatar con aro azul neón */}
              <ResolvedAvatar
                photo={profilePhoto}
                name={displayName}
                className="w-[54px] h-[54px] rounded-full bg-[#09357A] border-2 border-[#00D4FF] shadow-[0_0_12px_rgba(0,212,255,0.75)] text-white font-extrabold text-xl"
              />

              <div className="flex-1 min-w-0">
                <p className="text-white font-bold text-[17px] leading-snug truncate">
                  {displayName}
                </p>
                {rating ? (
                  <div className="inline-flex items-center gap-1 mt-1 bg-white/15 border border-white/20 rounded-full px-2 py-0.5">
                    {[1, 2, 3, 4, 5].map((n) => (
                      <Star key={n} className="w-3 h-3 fill-amber-400 text-amber-400" />
                    ))}
                    <span className="text-[11px] font-semibold text-white ml-0.5">{rating} ({count})</span>
                  </div>
                ) : (
                  <p className="text-white/85 text-[11.5px] truncate mt-0.5">
                    {user?.email || ''}
                  </p>
                )}
              </div>

              <ChevronRight className="w-5 h-5 text-white/90 flex-shrink-0" />
            </div>

            {/* Curva blanca en la base del encabezado */}
            <svg
              viewBox="0 0 320 22"
              preserveAspectRatio="none"
              className="absolute bottom-0 left-0 w-full h-[18px] pointer-events-none"
            >
              <path
                d="M0,4 Q160,24 320,4 L320,22 L0,22 Z"
                className="fill-white dark:fill-card"
              />
            </svg>
          </button>
        </div>

        {/* Lista de opciones */}
        <div className="flex-1 overflow-y-auto no-scrollbar px-4 pt-0.5 pb-1 space-y-0.5">
          {items.map((it) => {
            const Icon = it.icon;
            return (
              <button
                key={it.label}
                type="button"
                onClick={it.action}
                className="w-full flex items-center gap-3 py-1.5 px-1 rounded-xl hover:bg-slate-50 dark:hover:bg-muted/60 active:scale-[0.99] transition-all text-left"
              >
                <span className="w-8 h-8 rounded-full bg-[#EAF3FF] dark:bg-sky-950/60 flex items-center justify-center flex-shrink-0">
                  <Icon
                    className="w-[17px] h-[17px] text-[#062B60] dark:text-sky-300 fill-[#38BDF8]/35"
                    strokeWidth={2}
                  />
                </span>
                <span className="flex-1 text-[13px] font-semibold text-[#0F172A] dark:text-foreground truncate">
                  {it.label}
                </span>
                <ChevronRight className="w-4 h-4 text-slate-400 flex-shrink-0" />
              </button>
            );
          })}
        </div>

        {/* Pie con botón "Modo pasajero" y "Cerrar sesión" */}
        <div className="px-4 pt-2 pb-3 flex-shrink-0 bg-white dark:bg-card">
          <button
            type="button"
            onClick={switchToPassenger}
            disabled={switching}
            className="w-full h-12 rounded-full bg-gradient-to-r from-[#051F54] via-[#0B45B4] to-[#00B8FF] text-white font-bold text-[15px] px-5 flex items-center justify-between shadow-[0_4px_16px_rgba(0,184,255,0.45)] border border-[#38BDF8]/50 disabled:opacity-60 active:scale-[0.99] transition-transform"
          >
            <span className="w-5" />
            <span className="flex items-center gap-2.5">
              {switching ? (
                <Loader2 className="w-5 h-5 animate-spin text-white" />
              ) : (
                <Bike className="w-5 h-5 text-white" />
              )}
              <span>Modo pasajero</span>
            </span>
            <ChevronRight className="w-5 h-5 text-white" />
          </button>

          <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-border flex items-center justify-between gap-2">
            <button
              type="button"
              onClick={toggleTheme}
              className="flex items-center gap-1.5 py-1 px-2.5 rounded-lg bg-muted text-foreground text-xs font-bold hover:opacity-90 transition-opacity"
            >
              {theme === 'dark' ? (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-400" />
                  <span>Modo claro</span>
                </>
              ) : (
                <>
                  <Moon className="w-3.5 h-3.5 text-primary" />
                  <span>Modo oscuro</span>
                </>
              )}
            </button>
            <button
              type="button"
              onClick={() => base44.auth.logout('/')}
              className="flex items-center justify-center gap-1.5 py-1 px-2 text-slate-500 dark:text-muted-foreground text-xs font-semibold hover:text-foreground"
            >
              <LogOut className="w-4 h-4" />
              <span>Cerrar sesión</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
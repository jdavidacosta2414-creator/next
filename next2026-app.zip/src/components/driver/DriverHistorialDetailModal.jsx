import React from 'react';
import { CreditCard, Star, MapPin } from 'lucide-react';
import ClientAvatar from '@/components/shared/ClientAvatar';
import { useBackButton } from '@/hooks/useBackButton';

const fmtCOP = (n) =>
  '$' + Number(n || 0).toLocaleString('es-CO', { maximumFractionDigits: 0 });

export default function DriverHistorialDetailModal({
  trip,
  categoryLabel,
  paymentLabel,
  formattedDateTime,
  onClose,
}) {
  useBackButton(onClose, Boolean(trip));
  if (!trip) return null;

  return (
    <div className="fixed inset-0 z-[2200] bg-black/55 backdrop-blur-[1px] flex items-end justify-center p-0 sm:p-4" onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md bg-white dark:bg-card rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-sky-100 dark:border-border max-h-[88vh] overflow-y-auto space-y-4 animate-in slide-in-from-bottom"
      >
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-[#1E6BFF] dark:text-sky-400">
              {categoryLabel}
            </span>
            <h3 className="text-lg font-extrabold text-foreground">
              Detalle del viaje
            </h3>
          </div>
        </div>

        <div className="rounded-2xl bg-gradient-to-r from-[#041738] via-[#072B66] to-[#0B439C] p-4 text-white flex items-center justify-between">
          <div>
            <p className="text-xs text-sky-200 font-semibold">Valor del servicio</p>
            <p className="text-2xl font-black mt-0.5">
              {fmtCOP(trip.collected_amount || trip.fare)}
            </p>
            <p className="text-[11px] text-sky-100 mt-1 capitalize">
              {formattedDateTime}
            </p>
          </div>
          <div className="text-right">
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-white/15 text-xs font-bold">
              <CreditCard className="w-3.5 h-3.5 text-[#38BDF8]" />
              {paymentLabel}
            </span>
          </div>
        </div>

        {/* Pasajero */}
        <div className="rounded-2xl bg-slate-50 dark:bg-muted/50 p-3.5 border border-slate-200/70 dark:border-border flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <ClientAvatar
              photo={trip.client_photo}
              name={trip.client_name || 'Pasajero'}
              size="md"
            />
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground font-semibold">Pasajero</p>
              <p className="text-sm font-extrabold text-foreground truncate">
                {trip.client_name || 'Pasajero'}
              </p>
            </div>
          </div>
          {typeof trip.rating === 'number' && trip.rating > 0 && (
            <div className="text-right">
              <p className="text-[10px] text-muted-foreground font-semibold">Te calificó</p>
              <div className="inline-flex items-center gap-1 text-amber-500 font-extrabold text-sm">
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                {trip.rating.toFixed(1)}
              </div>
            </div>
          )}
        </div>

        {/* Ruta completa */}
        <div className="rounded-2xl bg-slate-50 dark:bg-muted/50 p-3.5 border border-slate-200/70 dark:border-border space-y-2.5">
          <p className="text-xs font-extrabold uppercase tracking-wider text-muted-foreground">
            Recorrido
          </p>
          <div className="flex items-start gap-2.5">
            <MapPin className="w-4 h-4 text-[#1E6BFF] mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-[11px] font-bold text-muted-foreground">Punto de recogida (A)</p>
              <p className="text-xs font-bold text-foreground">{trip.pickup_address || '—'}</p>
            </div>
          </div>

          {Array.isArray(trip.stops) &&
            trip.stops
              .filter((st) => st?.address)
              .map((st, i) => (
                <div key={i} className="flex items-start gap-2.5">
                  <MapPin className="w-4 h-4 text-sky-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-[11px] font-bold text-muted-foreground">Parada {i + 1}</p>
                    <p className="text-xs font-bold text-foreground">{st.address}</p>
                  </div>
                </div>
              ))}

          <div className="flex items-start gap-2.5">
            <MapPin className="w-4 h-4 text-[#062B60] dark:text-sky-300 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-[11px] font-bold text-muted-foreground">Destino final (B)</p>
              <p className="text-xs font-bold text-foreground">
                {trip.destination_address || '—'}
              </p>
            </div>
          </div>
        </div>

        {trip.rating_comment && (
          <div className="rounded-2xl bg-slate-50 dark:bg-muted/50 p-3.5 border border-slate-200/70 dark:border-border">
            <p className="text-[11px] font-bold text-muted-foreground">
              Comentario del pasajero
            </p>
            <p className="text-xs text-foreground mt-1 italic">
              “{trip.rating_comment}”
            </p>
          </div>
        )}

        <button
          type="button"
          onClick={onClose}
          className="w-full h-11 rounded-full bg-gradient-to-r from-[#051F54] via-[#0B45B4] to-[#00B8FF] text-white font-extrabold text-sm shadow-md"
        >
          Cerrar
        </button>
      </div>
    </div>
  );
}
import React from 'react';
import Radar from '@/components/driver/Radar';

// Estado de búsqueda.
// mode="offline"  → desconectado (invita a conectarse).
// mode="ocupado"  → ocupado (no recibe servicios hasta volver a Libre).
// mode="searching" → conectado/Libre pero sin servicios aún.
export default function SearchingRadar({ mode = 'searching', onConnect }) {
  const isOffline = mode === 'offline';
  const isBusy = mode === 'ocupado';
  const showCta = isOffline || isBusy;

  const title = isOffline
    ? 'Estás desconectado'
    : isBusy
      ? 'Estás ocupado'
      : 'Buscando servicios disponibles';
  const subtitle = showCta
    ? 'Conéctate para recibir servicios'
    : 'Te avisaremos cuando haya una solicitud';

  return (
    <div className="text-center pt-8 pb-10 px-4">
      <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#EAF3FF] dark:bg-sky-950/60 border border-[#38BDF8]/35 mb-5">
        <span className={`w-2 h-2 rounded-full ${showCta ? 'bg-[#062B60] dark:bg-sky-400' : 'bg-[#3DDC84] animate-pulse'}`} />
        <span className="text-[11.5px] font-bold text-[#062B60] dark:text-sky-300">
          {isOffline ? 'Modo conductor · Fuera de línea' : isBusy ? 'Modo conductor · Pausa activa' : 'En línea · Recibiendo solicitudes'}
        </span>
      </div>

      <div className="flex justify-center mb-5">
        <Radar active={!showCta} />
      </div>

      <h2 className="text-[#0F172A] dark:text-foreground font-extrabold text-lg tracking-tight">{title}</h2>
      <p className="text-slate-500 dark:text-muted-foreground text-sm mt-1 mb-6 max-w-xs mx-auto">{subtitle}</p>

      {showCta && onConnect && (
        <button
          onClick={onConnect}
          className="h-12 px-10 rounded-full bg-gradient-to-r from-[#051F54] via-[#0B45B4] to-[#00B8FF] text-white font-extrabold text-[15px] shadow-[0_6px_20px_rgba(0,184,255,0.42)] border border-[#38BDF8]/50 active:scale-[0.98] transition-transform"
        >
          {isBusy ? 'Pasar a Libre' : 'Conectarme'}
        </button>
      )}
    </div>
  );
}
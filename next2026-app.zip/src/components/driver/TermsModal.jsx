import React, { useState } from 'react';
import { ArrowLeft, ChevronRight, FileText } from 'lucide-react';
import PrivacyPolicyContent from '@/components/driver/PrivacyPolicyContent';
import OpenSourceLicensesContent from '@/components/driver/OpenSourceLicensesContent';
import { useBackButton } from '@/hooks/useBackButton';

const LEGAL_ITEMS = [
  { id: 'terminos', title: 'Términos y condiciones' },
  { id: 'privacidad', title: 'Política de privacidad' },
  { id: 'licencias', title: 'Licencias' },
];

// Menú y visor de Documentos legales (Términos y condiciones, Política de privacidad y Licencias).
export default function TermsModal({ onClose, initialDoc = null }) {
  const [activeDoc, setActiveDoc] = useState(initialDoc);

  const currentTitle = activeDoc
    ? LEGAL_ITEMS.find((item) => item.id === activeDoc)?.title || 'Documentos legales'
    : 'Documentos legales';

  const handleBack = () => {
    if (activeDoc) {
      setActiveDoc(null);
    } else {
      onClose?.();
    }
    return true;
  };

  useBackButton(handleBack, true);

  return (
    <div className="fixed inset-0 z-[1900] bg-background flex flex-col max-w-md mx-auto w-full">
      {/* Encabezado estilo nativo con título centrado */}
      <div className="relative flex items-center justify-center px-4 pt-5 pb-3.5 bg-background border-b border-border/60">
        <button
          type="button"
          onClick={handleBack}
          aria-label="Volver"
          className="absolute left-3 w-10 h-10 flex items-center justify-center rounded-full hover:bg-muted/60 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-foreground" />
        </button>
        <h1 className="text-foreground font-bold text-base text-center truncate px-12">
          {currentTitle}
        </h1>
      </div>

      {/* Vista principal: lista de los 3 documentos legales */}
      {!activeDoc && (
        <div className="flex-1 overflow-y-auto px-2 py-3">
          {LEGAL_ITEMS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveDoc(item.id)}
              className="w-full flex items-center gap-4 px-4 py-4 text-left rounded-xl hover:bg-muted/50 active:bg-muted transition-colors"
            >
              <FileText className="w-5 h-5 text-foreground flex-shrink-0" />
              <span className="flex-1 text-foreground text-base font-normal">
                {item.title}
              </span>
              <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />
            </button>
          ))}
        </div>
      )}

      {/* Vista de Términos y condiciones */}
      {activeDoc === 'terminos' && (
        <div className="flex-1 overflow-y-auto no-scrollbar px-4 py-4 space-y-5 text-foreground">
          <section>
            <h2 className="font-bold text-base">1. Términos y Condiciones de Uso para Usuarios (Pasajeros y Remitentes)</h2>
            <p className="text-sm text-muted-foreground mt-1">Última actualización: Octubre de 2026</p>
            <p className="text-sm text-muted-foreground">Entidad Operadora: NEXT TECNOLOGÍA S.A.S. (En constitución)</p>
            <p className="text-sm text-muted-foreground">Domicilio: Valledupar, Cesar, Colombia.</p>
          </section>

          <section>
            <h3 className="font-bold text-sm">1.1. Naturaleza del Servicio</h3>
            <p className="text-sm leading-relaxed text-muted-foreground">
              NEXT es una plataforma tecnológica de intermediación digital desarrollada por NEXT TECNOLOGÍA S.A.S., cuyo único objeto es conectar de manera eficiente a usuarios solicitantes (&quot;Usuarios&quot;) con conductores y repartidores independientes (&quot;Colaboradores&quot;) para la prestación de servicios privados de transporte individual y/o mensajería exprés urbana en la ciudad de Valledupar y sus áreas de influencia. NEXT TECNOLOGÍA S.A.S. no es una empresa de transporte público, no opera flotillas de vehículos ni actúa como transportador directo.
            </p>
          </section>

          <section>
            <h3 className="font-bold text-sm">1.2. Registro y Capacidad Legal</h3>
            <p className="text-sm leading-relaxed text-muted-foreground">
              Para acceder a la plataforma, el Usuario debe ser mayor de edad (18 años) según la legislación colombiana y proporcionar información veraz, exacta y actualizada (Nombre, Cédula, Teléfono y Correo Electrónico). El uso de cuentas por parte de menores de edad sin supervisión de un adulto titular está estrictamente prohibido.
            </p>
          </section>

          <section>
            <h3 className="font-bold text-sm">1.3. Tarifas y Pagos</h3>
            <p className="text-sm leading-relaxed text-muted-foreground">
              <strong>Libre Negociación / Tarifa Sugerida:</strong> La plataforma calcula una tarifa estimada basada en la distancia y tiempo del trayecto. El Usuario y el Colaborador pueden acordar la tarifa final mediante el mecanismo de subasta/oferta integrado en la app.
            </p>
            <p className="text-sm leading-relaxed text-muted-foreground mt-2">
              <strong>Medios de Pago:</strong> El pago de los servicios se realiza directamente entre el Usuario y el Colaborador en efectivo o transferencia electrónica directa (Nequi / Bancolombia), según lo pactado previamente en la solicitud.
            </p>
          </section>

          <section>
            <h3 className="font-bold text-sm">1.4. Mensajería y Encomiendas (Condiciones de Envío)</h3>
            <p className="text-sm leading-relaxed text-muted-foreground">
              <strong>Objetos Prohibidos:</strong> Se prohíbe el envío de sustancias ilícitas, armas de fuego, explosivos, material biológico, animales vivos, dinero en efectivo en montos superiores a 1 SMLMV, joyas de alto valor o artículos de ilícito comercio bajo las leyes de la República de Colombia.
            </p>
            <p className="text-sm leading-relaxed text-muted-foreground mt-2">
              <strong>Declaración de Valor y Envasado:</strong> El Usuario remitente es responsable de empacar y sellar adecuadamente el paquete. Todo paquete debe ser inspeccionado visualmente al momento de la entrega al repartidor.
            </p>
          </section>

          <section>
            <h3 className="font-bold text-sm">1.5. Exención de Responsabilidad</h3>
            <p className="text-sm leading-relaxed text-muted-foreground">
              NEXT no se hace responsable por pérdidas, daños o retrasos derivados de causas de fuerza mayor, caso fortuito, estado de las vías o el incumplimiento individual por parte de los Colaboradores independientes, sin perjuicio de las investigaciones internas y sanciones de bloqueo de cuenta que NEXT aplique.
            </p>
          </section>

          <section>
            <h2 className="font-bold text-base mt-2">2. Términos y Condiciones para Conductores y Repartidores (&quot;Colaboradores&quot;)</h2>
            <h3 className="font-bold text-sm mt-2">2.1. Calidad de Colaborador Independiente</h3>
            <p className="text-sm leading-relaxed text-muted-foreground">
              El Colaborador declara expresamente que su relación con NEXT TECNOLOGÍA S.A.S. es de naturaleza estrictamente mercantil y civil. No existe vínculo de subordinación, laboralidad ni relación de patrono-empleado. El Colaborador mantiene autonomía absoluta sobre sus horarios, zonas de trabajo y la decisión de aceptar o rechazar solicitudes.
            </p>
          </section>

          <section>
            <h3 className="font-bold text-sm">2.2. Requisitos de Vinculación y Documentación</h3>
            <p className="text-sm leading-relaxed text-muted-foreground">
              Para activar la cuenta en NEXT, el Colaborador debe cargar y mantener vigentes los siguientes documentos:
            </p>
            <ul className="text-sm leading-relaxed text-muted-foreground list-disc pl-5 mt-1 space-y-0.5">
              <li>Cédula de Ciudadanía o Cédula de Extranjería válida.</li>
              <li>Licencia de conducción vigente correspondiente a la categoría del vehículo (A2 para motos, B1/C1 para carros/taxis).</li>
              <li>Licencia de tránsito (Tarjeta de propiedad del vehículo).</li>
              <li>SOAT vigente registrado en RUNT.</li>
              <li>Certificado de Revisión Técnico-Mecánica (cuando aplique).</li>
              <li>Planilla de pago a la Seguridad Social en calidad de Independiente (Salud, Pensión y ARL) según la normativa vigente en Colombia para trabajadores de plataformas digitales.</li>
            </ul>
          </section>

          <section>
            <h3 className="font-bold text-sm">2.3. Esquema Financiero: Pase de 14 Horas Laborales (Sin Comisión por Porcentaje)</h3>
            <p className="text-sm leading-relaxed text-muted-foreground">
              <strong>Modalidad Única de Pase:</strong> NEXT opera exclusivamente bajo la modalidad de Pase de <strong>14 horas laborales</strong>, sin descuento de porcentaje por servicio. El Colaborador conserva el 100% del valor pagado por el Usuario en cada servicio.
            </p>
            <p className="text-sm leading-relaxed text-muted-foreground mt-2">
              <strong>Valor de la Recarga:</strong> La tarifa de activación del pase es de <strong>$7.000 COP para motocicleta</strong> y <strong>$10.000 COP para automóvil</strong>.
            </p>
            <p className="text-sm leading-relaxed text-muted-foreground mt-2">
              <strong>Duración de 14 Horas y Renovación a $0:</strong> Cuando el Colaborador realiza la recarga y esta es activada, dispone de <strong>14 horas laborales</strong> continuas para tomar servicios en la plataforma. Apenas se cumplan las 14 horas desde la recarga, el saldo en la aplicación se renueva automáticamente a <strong>$0</strong> y el sistema le informará que debe volver a recargar para poder seguir tomando servicios.
            </p>
            <p className="text-sm leading-relaxed text-muted-foreground mt-2">
              <strong>Naturaleza de la Recarga:</strong> Los pagos realizados corresponden al pago anticipado por el uso temporal del software durante 14 horas laborales y no constituyen depósitos bancarios ni captación masiva de dinero.
            </p>
          </section>

          <section>
            <h3 className="font-bold text-sm">2.4. Causal de Suspensión o Bloqueo Definitivo de Cuenta</h3>
            <p className="text-sm leading-relaxed text-muted-foreground">
              NEXT se reserva el derecho de inactivar temporal o permanentemente la cuenta del Colaborador por:
            </p>
            <ul className="text-sm leading-relaxed text-muted-foreground list-disc pl-5 mt-1 space-y-0.5">
              <li>Presentar documentación falsa o vencida.</li>
              <li>Calificación promedio de usuarios inferior a 4.2 / 5.0 estrellas.</li>
              <li>Cobrar valores superiores a los pactados en la app.</li>
              <li>Permitir el uso de la cuenta por parte de terceros no autorizados.</li>
              <li>Incurrir en conductas verbales o físicas que atenten contra la seguridad e integridad de los Usuarios.</li>
            </ul>
          </section>

          <section className="pb-6">
            <h2 className="font-bold text-base mt-2">3. Acuerdo Comercial B2B para Restaurantes y Comercios Aliados</h2>
            <p className="text-sm leading-relaxed text-muted-foreground mt-1">
              El acuerdo marco de servicios tiene por objeto afiliar al COMERCIO ALIADO al ecosistema de mensajería express de NEXT para el despacho prioritario de sus domicilios y entregas a clientes finales en Valledupar, liquidando el valor de cada envío según la matriz de distancias por zonas.
            </p>
          </section>
        </div>
      )}

      {/* Vista de Política de privacidad */}
      {activeDoc === 'privacidad' && (
        <div className="flex-1 overflow-y-auto no-scrollbar px-4 py-4">
          <PrivacyPolicyContent />
        </div>
      )}

      {/* Vista de Licencias */}
      {activeDoc === 'licencias' && (
        <div className="flex-1 overflow-y-auto no-scrollbar px-4 py-4">
          <OpenSourceLicensesContent />
        </div>
      )}
    </div>
  );
}
import React, { useState, useMemo } from 'react';
import { Bike, Car, CreditCard, Calendar, Palette } from 'lucide-react';
import {
  COLOMBIA_CAR_CATALOG,
  FACTORY_VEHICLE_COLORS,
} from '@/components/shared/VehicleBrandIllustration';
import DriverCategoryPicker from '@/components/driver/DriverCategoryPicker';

const CURRENT_YEAR = new Date().getFullYear();
const CAR_YEARS = Array.from(
  { length: Math.max(1, CURRENT_YEAR + 1 - 2003 + 1) },
  (_, idx) => String(CURRENT_YEAR + 1 - idx)
);

export default function ConductorVehicleSection({
  vehicleType,
  setVehicleType,
  driverCategory = 'moto',
  takenCategories = [],
  setDriverCategory,
  carSubtype,
  setCarSubtype,
  vehicleBrand,
  setVehicleBrand,
  vehicleModel,
  setVehicleModel,
  vehicleColor = '',
  setVehicleColor,
  vehicleYear,
  setVehicleYear,
  plate,
  setPlate,
  plateType,
  setPlateType,
  inputCls,
}) {
  const [plateFocused, setPlateFocused] = useState(false);
  const showPlateTabs =
    vehicleType === 'carro' && (plateFocused || Boolean(plateType) || Boolean(plate));

  const selectedBrandEntry = useMemo(() => {
    const bLower = String(vehicleBrand || '').trim().toLowerCase();
    return COLOMBIA_CAR_CATALOG.find((item) => item.brand.toLowerCase() === bLower) || null;
  }, [vehicleBrand]);

  const handleSelectVehicle = (category) => {
    const type = category === 'carro' ? 'carro' : 'moto';
    setDriverCategory?.(category);
    setVehicleType(type);
    if (type === 'carro') {
      if (!carSubtype) setCarSubtype('particular');
      if (!plateType) setPlateType('amarilla');
      if (!vehicleYear || Number(vehicleYear) < 2003) setVehicleYear(String(CURRENT_YEAR));
      if (!vehicleColor) setVehicleColor?.('Blanco');
    } else if (!vehicleColor) {
      setVehicleColor?.('Azul');
    }
  };

  return (
    <div className="space-y-3.5">
      {/* Selector de tipo de vehículo */}
      <div>
        <p className="text-slate-600 dark:text-[#8B95A8] text-sm font-medium mb-2">
          ¿Cómo te quieres registrar?
        </p>
        <DriverCategoryPicker value={driverCategory} onChange={handleSelectVehicle} taken={takenCategories} />
        <p className="text-[11px] text-slate-500 dark:text-[#5A6478] mt-1.5 px-1 leading-snug">
          {driverCategory === 'carro'
            ? 'Solo recibirás servicios de transporte en carro.'
            : driverCategory === 'mensajero'
            ? 'Solo recibirás servicios de mensajería (envíos en moto).'
            : 'Solo recibirás servicios de transporte de pasajeros en moto.'}
        </p>

        {/* Pestaña desplegable al elegir Carro: Carro particular o Taxi */}
        {vehicleType === 'carro' && (
          <div className="mt-2.5 p-3 rounded-2xl bg-white dark:bg-[#161C28] border border-sky-200 dark:border-[#00E5FF]/30 shadow-xs animate-in fade-in duration-200">
            <p className="text-[11px] font-bold uppercase tracking-wider text-[#0284C7] dark:text-[#00E5FF] mb-2 px-1">
              Modalidad del carro (visible en Central)
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  setCarSubtype('particular');
                  setPlateType('amarilla');
                }}
                className={`h-11 px-2 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                  carSubtype === 'particular'
                    ? 'border-[#1E6BFF] bg-[#1E6BFF] text-white shadow-sm'
                    : 'border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 text-slate-700 dark:text-[#8B95A8]'
                }`}
              >
                <Car className="w-4 h-4 flex-shrink-0" />
                <span className="leading-tight">Carro particular (Placa amarilla)</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setCarSubtype('taxi');
                  setPlateType('blanca');
                }}
                className={`h-11 px-2 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                  carSubtype === 'taxi'
                    ? 'border-amber-500 bg-amber-400/20 text-amber-900 dark:text-amber-300 shadow-sm'
                    : 'border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 text-slate-700 dark:text-[#8B95A8]'
                }`}
              >
                <Car className="w-4 h-4 flex-shrink-0" />
                <span className="leading-tight">Servicio público / Taxi (Placa blanca)</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Catálogo rápido de Marcas y Modelos Populares en Valledupar */}
      {vehicleType === 'carro' && (
        <div className="rounded-2xl bg-white dark:bg-[#161C28] border border-slate-200 dark:border-white/10 p-3.5 space-y-2.5 shadow-xs">
          <p className="text-[11px] font-bold uppercase tracking-wider text-[#0284C7] dark:text-[#00E5FF]">
            1. Selecciona tu marca popular o escríbela abajo
          </p>
          <div className="flex flex-wrap gap-1.5">
            {COLOMBIA_CAR_CATALOG.map((item) => {
              const active =
                String(vehicleBrand || '').trim().toLowerCase() === item.brand.toLowerCase();
              return (
                <button
                  key={item.brand}
                  type="button"
                  onClick={() => {
                    setVehicleBrand(item.brand);
                    if (!vehicleModel) setVehicleModel(item.models[0]);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                    active
                      ? 'bg-[#1E6BFF] text-white border-[#1E6BFF] dark:border-[#00E5FF] shadow-xs'
                      : 'bg-slate-50 dark:bg-white/5 text-slate-700 dark:text-[#8B95A8] border-slate-200 dark:border-white/10 hover:border-[#1E6BFF]'
                  }`}
                >
                  {item.brand}
                </button>
              );
            })}
          </div>

          {selectedBrandEntry && (
            <div className="pt-1">
              <p className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-[#8B95A8] mb-1.5">
                Modelos {selectedBrandEntry.brand} más usados:
              </p>
              <div className="flex flex-wrap gap-1.5">
                {selectedBrandEntry.models.map((mdl) => {
                  const active =
                    String(vehicleModel || '').trim().toLowerCase() === mdl.toLowerCase();
                  return (
                    <button
                      key={mdl}
                      type="button"
                      onClick={() => setVehicleModel(mdl)}
                      className={`px-3 py-1 rounded-xl text-xs font-extrabold border transition-all ${
                        active
                          ? 'bg-[#1E6BFF]/15 dark:bg-[#00E5FF]/20 text-[#1E6BFF] dark:text-[#00E5FF] border-[#1E6BFF] dark:border-[#00E5FF]'
                          : 'bg-slate-50 dark:bg-white/5 text-slate-800 dark:text-white border-slate-200 dark:border-white/10'
                      }`}
                    >
                      {mdl}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Marca, Línea y Modelo (2003 en adelante para carros) */}
      {vehicleType === 'carro' ? (
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="relative">
              <Car className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 dark:text-[#5A6478]" />
              <input
                className={inputCls}
                placeholder="Marca (ej. Chevrolet)"
                value={vehicleBrand}
                onChange={(e) => setVehicleBrand(e.target.value)}
                required
              />
            </div>
            <div className="relative">
              <Car className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 dark:text-[#5A6478]" />
              <input
                className={inputCls}
                placeholder="Línea (ej. Spark)"
                value={vehicleModel}
                onChange={(e) => setVehicleModel(e.target.value)}
                required
              />
            </div>
          </div>
          <div>
            <div className="relative">
              <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#0284C7] dark:text-[#00E5FF] pointer-events-none" />
              <select
                value={vehicleYear}
                onChange={(e) => setVehicleYear(e.target.value)}
                required
                className={`${inputCls} appearance-none cursor-pointer`}
              >
                <option value="" disabled>
                  Selecciona año modelo (2003 en adelante)
                </option>
                {CAR_YEARS.map((yr) => (
                  <option key={yr} value={yr}>
                    Modelo {yr}
                  </option>
                ))}
              </select>
            </div>
            <span className="block text-[11px] text-slate-500 dark:text-[#8B95A8] mt-1 pl-1">
              * Solo se aceptan vehículos carro modelo 2003 en adelante.
            </span>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3">
          <div className="relative">
            <Bike className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 dark:text-[#5A6478]" />
            <input
              className={inputCls}
              placeholder="Marca (ej. Bajaj, Yamaha)"
              value={vehicleBrand}
              onChange={(e) => setVehicleBrand(e.target.value)}
              required
            />
          </div>
          <div className="relative">
            <Bike className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 dark:text-[#5A6478]" />
            <input
              className={inputCls}
              placeholder="Modelo / Línea (ej. Boxer)"
              value={vehicleModel}
              onChange={(e) => setVehicleModel(e.target.value)}
              required
            />
          </div>
        </div>
      )}

      {/* Selector de Paleta de Color de Fábrica */}
      <div className="rounded-2xl bg-white dark:bg-[#161C28] border border-slate-200 dark:border-white/10 p-3.5 space-y-2.5 shadow-xs">
        <div className="flex items-center justify-between">
          <p className="text-[11px] font-bold uppercase tracking-wider text-[#0284C7] dark:text-[#00E5FF] flex items-center gap-1.5">
            <Palette className="w-3.5 h-3.5" /> Color de fábrica de tu vehículo
          </p>
          <span className="text-xs font-extrabold text-slate-900 dark:text-white capitalize">
            {vehicleColor || (carSubtype === 'taxi' ? 'Amarillo' : 'Blanco')}
          </span>
        </div>

        <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
          {FACTORY_VEHICLE_COLORS.map((sw) => {
            const isSelected =
              String(vehicleColor || '').trim().toLowerCase() === sw.id.toLowerCase();
            return (
              <button
                key={sw.id}
                type="button"
                onClick={() => setVehicleColor?.(sw.id)}
                title={sw.label}
                className={`flex flex-col items-center gap-1 py-2 px-1 rounded-xl border transition-all ${
                  isSelected
                    ? 'border-[#1E6BFF] dark:border-[#00E5FF] bg-[#1E6BFF]/10 dark:bg-[#1E6BFF]/25 ring-2 ring-[#1E6BFF]/25 shadow-xs'
                    : 'border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/5 hover:border-slate-300'
                }`}
              >
                <span
                  className="w-7 h-5 rounded-md border shadow-2xs"
                  style={{ backgroundColor: sw.hex, borderColor: sw.border }}
                />
                <span
                  className={`text-[10px] font-bold truncate w-full text-center ${
                    isSelected
                      ? 'text-[#1E6BFF] dark:text-white'
                      : 'text-slate-700 dark:text-white'
                  }`}
                >
                  {sw.id}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Placa del vehículo + pestaña desplegable Placa amarilla / Placa blanca para carro */}
      <div>
        <div className="relative">
          <CreditCard className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 dark:text-[#5A6478]" />
          <input
            className={inputCls}
            placeholder={
              vehicleType === 'carro'
                ? 'Placa del carro (toca para elegir tipo de placa)'
                : 'Placa de la moto (ej. ABC12D)'
            }
            value={plate}
            onFocus={() => setPlateFocused(true)}
            onClick={() => setPlateFocused(true)}
            onChange={(e) => setPlate(e.target.value.toUpperCase())}
            required
          />
        </div>

        {showPlateTabs && (
          <div className="mt-2.5 p-3 rounded-2xl bg-white dark:bg-[#161C28] border border-sky-200 dark:border-[#00E5FF]/30 shadow-xs animate-in fade-in duration-200">
            <p className="text-[11px] font-bold uppercase tracking-wider text-[#0284C7] dark:text-[#00E5FF] mb-2 px-1">
              Selecciona el tipo de placa de tu carro
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  setPlateType('amarilla');
                  setCarSubtype('particular');
                }}
                className={`h-11 px-2 rounded-xl border text-xs font-extrabold flex items-center justify-center gap-2 transition-all ${
                  plateType === 'amarilla'
                    ? 'border-amber-500 bg-amber-400/20 text-amber-900 dark:text-amber-300 shadow-xs'
                    : 'border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 text-slate-700 dark:text-[#8B95A8]'
                }`}
              >
                <span className="w-4 h-3 rounded-xs bg-amber-400 border border-amber-700 inline-block flex-shrink-0" />
                <span className="leading-tight">Placa amarilla (Particular)</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setPlateType('blanca');
                  setCarSubtype('taxi');
                }}
                className={`h-11 px-2 rounded-xl border text-xs font-extrabold flex items-center justify-center gap-2 transition-all ${
                  plateType === 'blanca'
                    ? 'border-[#1E6BFF] bg-[#1E6BFF]/15 text-[#1E6BFF] dark:text-white shadow-xs'
                    : 'border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 text-slate-700 dark:text-[#8B95A8]'
                }`}
              >
                <span className="w-4 h-3 rounded-xs bg-white border border-slate-500 inline-block flex-shrink-0" />
                <span className="leading-tight">Placa blanca (Público)</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
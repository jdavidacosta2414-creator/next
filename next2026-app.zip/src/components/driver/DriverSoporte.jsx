import React from 'react';
import { ChevronLeft, MessageSquare } from 'lucide-react';

// Número de WhatsApp de soporte — actualizar con el número real.
const SUPPORT_WHATSAPP = '573008353849';

// Sección "Soporte" del menú del conductor.
export default function DriverSoporte({ onBack }) {
  const waLink = `whatsapp://send?phone=${SUPPORT_WHATSAPP}&text=${encodeURIComponent('Hola, necesito ayuda con mi cuenta/servicio en NEXT')}`;

  return (
    <div className="fixed inset-0 z-[1800] bg-background flex flex-col max-w-md mx-auto w-full overflow-y-auto pb-[56px]">
      <div className="flex items-center gap-3 px-4 pt-5 pb-3 flex-shrink-0">
        <button onClick={onBack} className="w-10 h-10 flex items-center justify-center">
          <ChevronLeft className="w-6 h-6 text-foreground" />
        </button>
        <h1 className="text-foreground font-bold text-lg">Soporte</h1>
      </div>

      <div className="flex-1 px-6 pb-8">
        <div className="flex items-center gap-3 mb-5 mt-4">
          <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center">
            <MessageSquare className="w-6 h-6 text-muted-foreground" />
          </div>
          <div>
            <h2 className="text-foreground font-bold text-xl">Soporte</h2>
            <p className="text-muted-foreground text-sm">Contacta al equipo de soporte.</p>
          </div>
        </div>

        <div className="bg-card rounded-2xl p-4 shadow-sm mb-6">
          <p className="text-muted-foreground text-sm">Describe tu inconveniente para recibir ayuda con tu cuenta o con un servicio.</p>
        </div>

        <a href={waLink} className="w-full h-12 rounded-2xl bg-primary text-primary-foreground font-bold text-sm flex items-center justify-center gap-2">
          <MessageSquare className="w-5 h-5" /> Escribir por WhatsApp
        </a>
      </div>
    </div>
  );
}
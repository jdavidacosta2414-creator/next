import React, { useRef } from 'react';
import { ChevronLeft, ChevronRight, Calendar, Search, X } from 'lucide-react';

const PERIOD_TABS = [
  { id: 'todo', label: 'Todo' },
  { id: 'hoy', label: 'Hoy' },
  { id: 'semana', label: 'Esta semana' },
  { id: 'mes', label: 'Por mes' },
];

const STATUS_FILTERS = [
  { id: 'finalizado', label: 'Finalizados' },
  { id: 'cancelado', label: 'Cancelados' },
  { id: 'todos', label: 'Todos los estados' },
];

export default function DriverHistorialFilters({
  period,
  onChangePeriod,
  selectedMonth,
  formattedSelectedMonth,
  onChangeMonth,
  onShiftMonth,
  search,
  onChangeSearch,
  statusFilter,
  onChangeStatusFilter,
}) {
  const monthInputRef = useRef(null);

  const openMonthPicker = () => {
    const el = monthInputRef.current;
    if (!el) return;
    if (typeof el.showPicker === 'function') {
      try {
        el.showPicker();
        return;
      } catch {}
    }
    el.focus();
    el.click();
  };

  return (
    <div className="bg-white dark:bg-card rounded-2xl p-3.5 border border-sky-100 dark:border-border shadow-xs space-y-2.5">
      {/* Pestañas de período */}
      <div className="grid grid-cols-4 gap-1.5">
        {PERIOD_TABS.map((t) => {
          const active = period === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => onChangePeriod(t.id)}
              className={`py-2 px-1.5 rounded-xl text-[11px] leading-tight font-extrabold transition-all ${
                active
                  ? 'bg-gradient-to-r from-[#062356] to-[#1E6BFF] text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-muted text-slate-600 dark:text-muted-foreground'
              }`}
            >
              {t.label}
            </button>
          );
        })}
      </div>

      {/* Selector de mes en español */}
      <div className="flex items-center justify-between gap-2 bg-[#EAF3FF]/75 dark:bg-sky-950/40 border border-sky-200/70 dark:border-sky-800/50 rounded-xl px-2.5 py-1.5">
        <button
          type="button"
          onClick={() => onShiftMonth(-1)}
          aria-label="Mes anterior"
          className="w-8 h-8 rounded-lg bg-white dark:bg-card flex items-center justify-center text-[#062B60] dark:text-sky-300 shadow-2xs active:scale-95"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={openMonthPicker}
          className="relative flex items-center justify-center gap-2 py-1 px-3 rounded-lg hover:bg-white/60 dark:hover:bg-card/50 transition-colors"
        >
          <Calendar className="w-4 h-4 text-[#1E6BFF] dark:text-sky-400 flex-shrink-0" />
          <span className="text-xs font-extrabold text-[#062B60] dark:text-sky-200 capitalize">
            {formattedSelectedMonth}
          </span>
          <input
            ref={monthInputRef}
            type="month"
            value={selectedMonth}
            onChange={(e) => {
              if (e.target.value) {
                onChangeMonth(e.target.value);
              }
            }}
            aria-label="Seleccionar mes"
            className="sr-only"
          />
        </button>

        <button
          type="button"
          onClick={() => onShiftMonth(1)}
          aria-label="Mes siguiente"
          className="w-8 h-8 rounded-lg bg-white dark:bg-card flex items-center justify-center text-[#062B60] dark:text-sky-300 shadow-2xs active:scale-95"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Buscador por dirección, pasajero o fecha */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <input
          type="text"
          value={search}
          onChange={(e) => onChangeSearch(e.target.value)}
          placeholder="Buscar por dirección, pasajero o fecha..."
          className="w-full h-9 rounded-xl bg-slate-50 dark:bg-muted/60 pl-9 pr-8 text-xs font-medium text-foreground placeholder:text-muted-foreground border border-slate-200 dark:border-border focus:border-[#1E6BFF] outline-none"
        />
        {search && (
          <button
            type="button"
            onClick={() => onChangeSearch('')}
            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-foreground"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Filtro por estado del viaje */}
      <div className="grid grid-cols-3 gap-1.5">
        {STATUS_FILTERS.map((sf) => {
          const active = statusFilter === sf.id;
          return (
            <button
              key={sf.id}
              type="button"
              onClick={() => onChangeStatusFilter(sf.id)}
              className={`py-1.5 px-2 rounded-lg text-[11px] font-bold text-center transition-colors ${
                active
                  ? 'bg-[#EAF3FF] text-[#062B60] border border-[#1E6BFF]/40 dark:bg-sky-950/70 dark:text-sky-300'
                  : 'bg-slate-50 dark:bg-muted/50 text-slate-500 dark:text-muted-foreground border border-transparent'
              }`}
            >
              {sf.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}
import React from 'react';
import { Home, Wallet, User } from 'lucide-react';

const TABS = [
  { id: 'inicio', label: 'Inicio', icon: Home },
  { id: 'ingresos', label: 'Ingresos', icon: Wallet },
  { id: 'perfil', label: 'Perfil', icon: User },
];

export default function DriverBottomNav({ active, onChange }) {
  return (
    <nav className="fixed bottom-0 inset-x-0 z-30 bg-card border-t border-border/70 w-full max-w-md mx-auto">
      <div className="grid grid-cols-3 pt-1.5 pb-1 px-2">
        {TABS.map((t) => {
          const isActive = active === t.id;
          const Icon = t.icon;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => onChange(t.id)}
              className="relative flex flex-col items-center justify-center gap-0.5 py-0.5"
            >
              <span className="w-8 h-8 rounded-full flex items-center justify-center transition-colors">
                <Icon
                  className={`w-5 h-5 ${
                    isActive
                      ? 'text-[#0284C7] fill-[#0284C7]/20'
                      : 'text-[#062B60]/70 dark:text-muted-foreground'
                  }`}
                />
              </span>
              <span
                className={`text-[11px] leading-tight ${
                  isActive
                    ? 'font-bold text-[#0284C7]'
                    : 'font-semibold text-[#0F172A]/80 dark:text-muted-foreground'
                }`}
              >
                {t.label}
              </span>
              {isActive && (
                <span className="w-10 h-[3px] rounded-full bg-[#0284C7] mt-0.5" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
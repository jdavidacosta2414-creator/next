import React from 'react';
import { ChevronLeft } from 'lucide-react';
import DriverCategoryList from '@/components/driver/DriverCategoryList';

// Sección "Mis categorías": la misma cuenta puede trabajar en moto, carro y mensajería.
export default function DriverCategorias({ mobile, onBack }) {
  return (
    <div className="fixed inset-0 z-[1800] bg-background flex flex-col max-w-md mx-auto w-full overflow-y-auto overflow-x-hidden pb-24">
      <div className="flex items-center gap-3 px-4 pt-5 pb-3 flex-shrink-0">
        <button onClick={onBack} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-muted">
          <ChevronLeft className="w-6 h-6 text-foreground" />
        </button>
        <h1 className="text-foreground font-bold text-lg">Mis categorías</h1>
      </div>

      <div className="flex-1 px-4 pb-6 space-y-4">
        <p className="text-sm text-muted-foreground leading-relaxed">
          Puedes registrarte en moto, carro y mensajería con tus mismos datos. Cada categoría tiene su propio
          vehículo, su propia cartera y su propio pase, y solo recibe sus propios servicios.
        </p>
        <DriverCategoryList mobile={mobile} />
      </div>
    </div>
  );
}
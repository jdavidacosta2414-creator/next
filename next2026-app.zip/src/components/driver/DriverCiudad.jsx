import React from 'react';
import { ChevronLeft, Car } from 'lucide-react';

// Sección "Ciudad" del menú del conductor.
export default function DriverCiudad({ onBack }) {
  return (
    <div className="min-h-screen bg-background flex flex-col max-w-md mx-auto w-full">
      <div className="flex items-center gap-3 px-4 pt-5 pb-3">
        <button onClick={onBack} className="w-10 h-10 flex items-center justify-center">
          <ChevronLeft className="w-6 h-6 text-foreground" />
        </button>
        <h1 className="text-foreground font-bold text-lg">Ciudad</h1>
      </div>

      <div className="flex-1 px-6 pb-8 flex flex-col items-center text-center">
        <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center mb-5 mt-6">
          <Car className="w-8 h-8 text-muted-foreground" />
        </div>
        <h2 className="text-foreground font-bold text-2xl mb-2">Ciudad</h2>
        <p className="text-muted-foreground text-sm mb-6">Gestiona tus viajes dentro de la ciudad.</p>

        <div className="bg-muted rounded-2xl px-4 py-4 text-left w-full mb-6">
          <p className="text-foreground text-sm leading-relaxed">
            Activa el modo conductor para recibir solicitudes cercanas y revisar los datos antes de aceptar.
          </p>
        </div>

        <button onClick={onBack} className="w-full h-12 rounded-2xl bg-primary text-primary-foreground font-bold text-sm">
          Volver al inicio
        </button>
      </div>
    </div>
  );
}
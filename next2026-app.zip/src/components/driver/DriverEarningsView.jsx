import React, { useState, useEffect, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import {
  ChevronLeft,
  ChevronRight,
  Calendar,
  Clock,
  TrendingUp,
  Wallet,
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import DriverEarningsBreakdown from '@/components/driver/DriverEarningsBreakdown';
import DriverEarningsRecentList from '@/components/driver/DriverEarningsRecentList';
import { parseUtcDate, toBogotaDateStr, getBogotaHour } from '@/lib/dateBogota';

const fmtCOP = (n) =>
  '$' + Number(n || 0).toLocaleString('es-CO', { maximumFractionDigits: 0 });

const DEFAULT_DAILY_GOAL = 80000;

export default function DriverEarningsView({
  mobile,
  onMobileUpdate,
  onOpenPriority,
  onOpenHistorial,
}) {
  const { toast } = useToast();
  const [period, setPeriod] = useState('dia');
  const [offset, setOffset] = useState(0);
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);

  const [dailyGoal, setDailyGoal] = useState(() => {
    if (Number(mobile?.daily_goal) >= 10000) return Number(mobile.daily_goal);
    try {
      const saved = Number(localStorage.getItem(`driver_daily_goal_${mobile?.id}`));
      if (saved >= 10000) return saved;
    } catch {}
    return DEFAULT_DAILY_GOAL;
  });

  useEffect(() => {
    if (Number(mobile?.daily_goal) >= 10000) {
      setDailyGoal(Number(mobile.daily_goal));
    }
  }, [mobile?.daily_goal]);

  const handleSaveDailyGoal = async (newGoal) => {
    setDailyGoal(newGoal);
    try {
      localStorage.setItem(`driver_daily_goal_${mobile?.id}`, String(newGoal));
    } catch {}
    if (mobile?.id) {
      const updated = await base44.entities.Mobile.update(mobile.id, {
        daily_goal: newGoal,
      });
      onMobileUpdate?.(updated);
    }
    toast({
      description: `Tu meta diaria quedó en ${fmtCOP(newGoal)}.`,
    });
  };

  const goalAmount =
    period === 'dia'
      ? dailyGoal
      : period === 'semana'
        ? dailyGoal * 6
        : dailyGoal * 25;

  useEffect(() => {
    const loadServices = async () => {
      try {
        const all = await base44.entities.Service.filter(
          { mobile_id: mobile.id, status: 'finalizado' },
          '-created_date',
          300
        );
        setServices(Array.isArray(all) ? all : all?.items || []);
      } catch (e) {
      } finally {
        setLoading(false);
      }
    };
    loadServices();
    const unsub = base44.entities.Service.subscribe(() => loadServices());
    return unsub;
  }, [mobile.id]);

  // Resumen fijo de Hoy, Esta Semana y Este Mes en hora de Colombia (America/Bogota)
  const quickTotals = useMemo(() => {
    const todayStr = toBogotaDateStr(new Date());
    const [ty, tm, td] = todayStr.split('-').map(Number);
    const todayNoonUtc = new Date(Date.UTC(ty, tm - 1, td, 17, 0, 0));
    const dayOfWeek = (todayNoonUtc.getUTCDay() + 6) % 7; // Lunes = 0
    const mondayUtc = new Date(todayNoonUtc);
    mondayUtc.setUTCDate(todayNoonUtc.getUTCDate() - dayOfWeek);
    const weekStartStr = toBogotaDateStr(mondayUtc);
    const monthPrefix = todayStr.slice(0, 7);

    let dayAmt = 0;
    let dayCnt = 0;
    let weekAmt = 0;
    let weekCnt = 0;
    let monthAmt = 0;
    let monthCnt = 0;

    services.forEach((s) => {
      const refRaw = s.updated_date || s.created_date;
      const sBogotaDay = toBogotaDateStr(refRaw) || toBogotaDateStr(s.created_date);
      if (!sBogotaDay) return;
      const val = Number(s.collected_amount || s.fare || 0);
      if (sBogotaDay === todayStr || toBogotaDateStr(s.created_date) === todayStr) {
        dayAmt += val;
        dayCnt += 1;
      }
      if (sBogotaDay >= weekStartStr && sBogotaDay <= todayStr) {
        weekAmt += val;
        weekCnt += 1;
      }
      if (sBogotaDay.slice(0, 7) === monthPrefix) {
        monthAmt += val;
        monthCnt += 1;
      }
    });

    return {
      dia: { amount: dayAmt, count: dayCnt },
      semana: { amount: weekAmt, count: weekCnt },
      mes: { amount: monthAmt, count: monthCnt },
    };
  }, [services]);

  const range = useMemo(() => {
    const todayStr = toBogotaDateStr(new Date());
    const [ty, tm, td] = todayStr.split('-').map(Number);
    const baseNoon = new Date(Date.UTC(ty, tm - 1, td, 17, 0, 0));

    if (period === 'dia') {
      const target = new Date(baseNoon);
      target.setUTCDate(baseNoon.getUTCDate() + offset);
      const targetStr = toBogotaDateStr(target);
      const isToday = offset === 0;
      const dateText = target.toLocaleDateString('es-CO', {
        weekday: 'short',
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        timeZone: 'America/Bogota',
      });
      return {
        startStr: targetStr,
        endStr: targetStr,
        label: isToday ? `Hoy · ${dateText}` : dateText,
        title: 'Ingresos diarios',
      };
    }
    if (period === 'semana') {
      const ref = new Date(baseNoon);
      ref.setUTCDate(baseNoon.getUTCDate() + offset * 7);
      const day = (ref.getUTCDay() + 6) % 7; // lunes = 0
      const start = new Date(ref);
      start.setUTCDate(ref.getUTCDate() - day);
      const end = new Date(start);
      end.setUTCDate(start.getUTCDate() + 6);
      const startStr = toBogotaDateStr(start);
      const endStr = toBogotaDateStr(end);
      const rangeText = `${start.toLocaleDateString('es-CO', {
        day: 'numeric',
        month: 'short',
        timeZone: 'America/Bogota',
      })} – ${end.toLocaleDateString('es-CO', {
        day: 'numeric',
        month: 'short',
        timeZone: 'America/Bogota',
      })}`;
      return {
        startStr,
        endStr,
        label: offset === 0 ? `Esta semana · ${rangeText}` : rangeText,
        title: 'Ingresos semanales',
      };
    }
    const refMonth = new Date(Date.UTC(ty, tm - 1 + offset, 1, 17, 0, 0));
    const endMonth = new Date(Date.UTC(refMonth.getUTCFullYear(), refMonth.getUTCMonth() + 1, 0, 17, 0, 0));
    const startStr = toBogotaDateStr(refMonth);
    const endStr = toBogotaDateStr(endMonth);
    const monthText = refMonth.toLocaleDateString('es-CO', {
      month: 'long',
      year: 'numeric',
      timeZone: 'America/Bogota',
    });
    return {
      startStr,
      endStr,
      label: offset === 0 ? `Este mes · ${monthText}` : monthText,
      title: 'Ingresos mensuales',
    };
  }, [period, offset]);

  const inRange = useMemo(
    () =>
      services.filter((s) => {
        const sDay = toBogotaDateStr(s.updated_date || s.created_date) || toBogotaDateStr(s.created_date);
        if (!sDay) return false;
        return sDay >= range.startStr && sDay <= range.endStr;
      }),
    [services, range]
  );

  const netEarnings = inRange.reduce(
    (sum, s) => sum + Number(s.collected_amount || s.fare || 0),
    0
  );
  const requests = inRange.length;
  const avgPerTrip = requests > 0 ? Math.round(netEarnings / requests) : 0;

  // Estadísticas por método de pago
  const paymentStats = useMemo(() => {
    let efectivo = 0;
    let efectivoCount = 0;
    let digital = 0;
    let digitalCount = 0;
    let puntos = 0;
    let puntosCount = 0;

    inRange.forEach((s) => {
      const amt = Number(s.collected_amount || s.fare || 0);
      if (s.payment_method === 'redimido_puntos') {
        puntos += amt;
        puntosCount += 1;
      } else if (!s.payment_method || s.payment_method === 'efectivo') {
        efectivo += amt;
        efectivoCount += 1;
      } else {
        digital += amt;
        digitalCount += 1;
      }
    });

    return {
      efectivo,
      efectivoCount,
      digital,
      digitalCount,
      puntos,
      puntosCount,
    };
  }, [inRange]);

  // Estadísticas por tipo de servicio
  const serviceTypeStats = useMemo(() => {
    let transporteAmount = 0;
    let transporteCount = 0;
    let mensajeriaAmount = 0;
    let mensajeriaCount = 0;

    inRange.forEach((s) => {
      const amt = Number(s.collected_amount || s.fare || 0);
      if (s.service_type === 'mensajeria') {
        mensajeriaAmount += amt;
        mensajeriaCount += 1;
      } else {
        transporteAmount += amt;
        transporteCount += 1;
      }
    });

    return {
      transporteAmount,
      transporteCount,
      mensajeriaAmount,
      mensajeriaCount,
    };
  }, [inRange]);

  // Barras según el periodo seleccionado
  const chartBuckets = useMemo(() => {
    if (period === 'dia') {
      const slots = [
        { key: 'madrugada', label: '0-6h', amount: 0, count: 0 },
        { key: 'manana', label: '6-12h', amount: 0, count: 0 },
        { key: 'tarde', label: '12-18h', amount: 0, count: 0 },
        { key: 'noche', label: '18-24h', amount: 0, count: 0 },
      ];
      inRange.forEach((s) => {
        const h = getBogotaHour(s.updated_date || s.created_date);
        const amt = Number(s.collected_amount || s.fare || 0);
        const idx = h < 6 ? 0 : h < 12 ? 1 : h < 18 ? 2 : 3;
        slots[idx].amount += amt;
        slots[idx].count += 1;
      });
      return slots;
    }

    if (period === 'semana') {
      const days = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'].map((label, i) => ({
        key: `d-${i}`,
        label,
        amount: 0,
        count: 0,
      }));
      inRange.forEach((s) => {
        const dStr = toBogotaDateStr(s.updated_date || s.created_date);
        if (!dStr) return;
        const [y, m, dayNum] = dStr.split('-').map(Number);
        const noonUtc = new Date(Date.UTC(y, m - 1, dayNum, 17, 0, 0));
        const idx = (noonUtc.getUTCDay() + 6) % 7;
        const amt = Number(s.collected_amount || s.fare || 0);
        days[idx].amount += amt;
        days[idx].count += 1;
      });
      return days;
    }

    // Mes: 4-5 semanas del mes
    const weeks = [1, 2, 3, 4, 5].map((w) => ({
      key: `w-${w}`,
      label: `Sem ${w}`,
      amount: 0,
      count: 0,
    }));
    inRange.forEach((s) => {
      const dStr = toBogotaDateStr(s.updated_date || s.created_date);
      const dayOfMonth = dStr ? Number(dStr.split('-')[2]) : parseUtcDate(s.created_date).getDate();
      const idx = Math.min(4, Math.floor((dayOfMonth - 1) / 7));
      const amt = Number(s.collected_amount || s.fare || 0);
      weeks[idx].amount += amt;
      weeks[idx].count += 1;
    });
    return weeks;
  }, [inRange, period]);

  const SUMMARY_CARDS = [
    {
      id: 'dia',
      title: 'Diario',
      amount: quickTotals.dia.amount,
      count: quickTotals.dia.count,
      icon: Clock,
    },
    {
      id: 'semana',
      title: 'Semanal',
      amount: quickTotals.semana.amount,
      count: quickTotals.semana.count,
      icon: TrendingUp,
    },
    {
      id: 'mes',
      title: 'Mensual',
      amount: quickTotals.mes.amount,
      count: quickTotals.mes.count,
      icon: Calendar,
    },
  ];

  return (
    <div className="px-4 pt-4 pb-28 space-y-3.5">
      {/* 1. Vista simultánea de ingresos Diarios, Semanales y Mensuales */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-xs font-extrabold uppercase tracking-wider text-[#062B60] dark:text-sky-300">
            Resumen de tus ingresos
          </h2>
          <span className="text-[11px] font-semibold text-muted-foreground">
            Toca un periodo para detallar
          </span>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {SUMMARY_CARDS.map((card) => {
            const isSelected = period === card.id;
            const Icon = card.icon;
            return (
              <button
                key={card.id}
                type="button"
                onClick={() => {
                  setPeriod(card.id);
                  setOffset(0);
                }}
                className={`rounded-2xl p-3 text-left transition-all border ${
                  isSelected
                    ? 'bg-gradient-to-br from-[#041738] via-[#0B3C8C] to-[#0284C7] text-white border-[#38BDF8] shadow-[0_6px_18px_rgba(6,43,110,0.25)]'
                    : 'bg-white dark:bg-card text-foreground border-sky-100 dark:border-border hover:border-sky-300'
                }`}
              >
                <div className="flex items-center justify-between gap-1">
                  <span
                    className={`text-[10px] font-extrabold uppercase tracking-wider truncate ${
                      isSelected ? 'text-sky-200' : 'text-muted-foreground'
                    }`}
                  >
                    {card.title}
                  </span>
                  <Icon
                    className={`w-3.5 h-3.5 flex-shrink-0 ${
                      isSelected ? 'text-[#38BDF8]' : 'text-[#1E6BFF]'
                    }`}
                  />
                </div>
                <p className="text-sm font-black mt-1.5 truncate">
                  {fmtCOP(card.amount)}
                </p>
                <p
                  className={`text-[10px] font-bold mt-0.5 ${
                    isSelected ? 'text-sky-100' : 'text-[#1E6BFF] dark:text-sky-400'
                  }`}
                >
                  {card.count} {card.count === 1 ? 'viaje' : 'viajes'}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Tarjeta principal del periodo seleccionado con navegador de fechas */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#041738] via-[#0B3C8C] to-[#0284C7] p-5 text-white shadow-[0_10px_28px_rgba(6,43,110,0.25)] border border-[#38BDF8]/30">
        <div className="pointer-events-none absolute -top-8 -right-8 w-28 h-16 bg-gradient-to-l from-[#00D4FF]/35 to-transparent -rotate-45 transform" />

        {/* Navegador de fecha (< Hoy / Semana / Mes >) */}
        <div className="flex items-center justify-between bg-white/10 rounded-2xl px-2 py-1.5 mb-4 border border-white/15">
          <button
            type="button"
            onClick={() => setOffset((o) => o - 1)}
            aria-label="Periodo anterior"
            className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center active:scale-95 transition-transform"
          >
            <ChevronLeft className="w-4 h-4 text-white" />
          </button>

          <div className="text-center px-2 min-w-0">
            <p className="text-[10px] font-extrabold uppercase tracking-wider text-sky-200">
              {range.title}
            </p>
            <p className="text-xs font-bold text-white capitalize truncate">
              {range.label}
            </p>
          </div>

          <button
            type="button"
            onClick={() => setOffset((o) => (o < 0 ? o + 1 : o))}
            disabled={offset >= 0}
            aria-label="Periodo siguiente"
            className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 disabled:opacity-30 flex items-center justify-center active:scale-95 transition-transform"
          >
            <ChevronRight className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* Monto total ganado en el periodo */}
        <div className="text-center my-2">
          <p className="text-sky-200 text-xs font-bold uppercase tracking-wider">
            Total ganado en este periodo
          </p>
          <p className="text-4xl font-black tracking-tight mt-1">
            {loading ? '...' : fmtCOP(netEarnings)}
          </p>
          {offset !== 0 && (
            <button
              type="button"
              onClick={() => setOffset(0)}
              className="mt-2 inline-flex items-center gap-1 px-3 py-0.5 rounded-full bg-[#00D4FF]/25 border border-[#00D4FF]/50 text-[11px] font-bold text-white"
            >
              Volver al periodo actual
            </button>
          )}
        </div>

        {/* Métricas clave del periodo */}
        <div className="grid grid-cols-3 gap-2 mt-4 pt-3.5 border-t border-white/15">
          <div className="text-center">
            <p className="text-lg font-black text-white">{requests}</p>
            <p className="text-[11px] text-sky-200 font-semibold">
              Viajes hechos
            </p>
          </div>
          <div className="text-center border-x border-white/15 px-1">
            <p className="text-lg font-black text-white truncate">
              {fmtCOP(avgPerTrip)}
            </p>
            <p className="text-[11px] text-sky-200 font-semibold">
              Promedio / viaje
            </p>
          </div>
          <div className="text-center">
            <p className="text-lg font-black text-[#3DDC84]">100%</p>
            <p className="text-[11px] text-sky-200 font-semibold">
              Libre de comisión
            </p>
          </div>
        </div>

        {/* Billetera de puntos acumulados si tiene */}
        {Number(mobile?.points_wallet_balance || 0) > 0 && (
          <div className="mt-3 pt-2.5 border-t border-white/15 flex items-center justify-between text-xs">
            <span className="flex items-center gap-1.5 text-sky-100 font-semibold">
              <Wallet className="w-3.5 h-3.5 text-[#38BDF8]" />
              Saldo en Billetera de Puntos:
            </span>
            <span className="font-black text-white">
              {fmtCOP(mobile.points_wallet_balance)}
            </span>
          </div>
        )}
      </div>

      {/* 3. Gráfico del periodo + Desglose por método de pago y tipo de servicio + Meta */}
      <DriverEarningsBreakdown
        period={period}
        vehicleType={mobile?.vehicle_type}
        chartBuckets={chartBuckets}
        paymentStats={paymentStats}
        serviceTypeStats={serviceTypeStats}
        dailyGoal={dailyGoal}
        goalAmount={goalAmount}
        netEarnings={netEarnings}
        onSaveDailyGoal={handleSaveDailyGoal}
      />

      {/* 4. Últimos viajes del periodo + Accesos a Historial y Niveles */}
      <DriverEarningsRecentList
        services={inRange}
        onOpenHistorial={onOpenHistorial}
        onOpenPriority={onOpenPriority}
      />
    </div>
  );
}
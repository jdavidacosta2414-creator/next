import React, { useState, useEffect, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import {
  ChevronLeft,
  Loader2,
  Bike,
  Car,
  Package,
  Calendar,
  Clock,
  Star,
  XCircle,
} from 'lucide-react';
import ClientAvatar from '@/components/shared/ClientAvatar';
import DriverHistorialSummary from '@/components/driver/DriverHistorialSummary';
import DriverHistorialFilters from '@/components/driver/DriverHistorialFilters';
import DriverHistorialDetailModal from '@/components/driver/DriverHistorialDetailModal';
import { parseUtcDate, fmtBogotaGroupDate, fmtBogotaFullDateTime } from '@/lib/dateBogota';
import { useBackButton } from '@/hooks/useBackButton';

const fmtCOP = (n) =>
  '$' + Number(n || 0).toLocaleString('es-CO', { maximumFractionDigits: 0 });

const PAYMENT_LABELS = {
  efectivo: 'Efectivo',
  transferencia: 'Transferencia',
  nequi: 'Nequi',
  daviplata: 'DaviPlata',
  bancolombia: 'Bancolombia',
  paga_con_llave: 'Paga con llave',
  redimido_puntos: 'Redimido con puntos',
};

function getBogotaParts(dateInput) {
  const dt = parseUtcDate(dateInput);
  const str = dt.toLocaleDateString('en-CA', { timeZone: 'America/Bogota' });
  const [y, m, d] = str.split('-').map(Number);
  return { str, year: y, month: m, day: d, date: dt };
}

function getStartOfWeekBogota(now = new Date()) {
  const { str } = getBogotaParts(now);
  const [y, m, d] = str.split('-').map(Number);
  const localNoon = new Date(Date.UTC(y, m - 1, d, 17, 0, 0));
  const dow = (localNoon.getUTCDay() + 6) % 7;
  const monday = new Date(localNoon);
  monday.setUTCDate(localNoon.getUTCDate() - dow);
  return monday.toLocaleDateString('en-CA', { timeZone: 'America/Bogota' });
}

const fmtGroupDate = (d) => fmtBogotaGroupDate(d);

const fmtFullDateTime = (d) => fmtBogotaFullDateTime(d);

function getServiceCategory(t, driverVehicleType) {
  if (driverVehicleType === 'carro' || t.vehicle_type === 'carro') {
    return { key: 'carro', Icon: Car, label: 'Transporte en carro' };
  }
  if (t.service_type === 'mensajeria') {
    return { key: 'mensajeria', Icon: Package, label: 'Mensajería' };
  }
  return { key: 'moto', Icon: Bike, label: 'Transporte en moto' };
}

export default function DriverHistorial({ mobile, onBack }) {
  const nowParts = useMemo(() => getBogotaParts(new Date()), []);
  const currentMonthKey = `${nowParts.year}-${String(nowParts.month).padStart(2, '0')}`;
  const isCarDriver = mobile?.vehicle_type === 'carro';

  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState('todo');
  const [selectedMonth, setSelectedMonth] = useState(currentMonthKey);
  const [statusFilter, setStatusFilter] = useState('finalizado');
  const [search, setSearch] = useState('');
  const [detailTrip, setDetailTrip] = useState(null);
  useBackButton(() => {
    if (detailTrip) {
      setDetailTrip(null);
      return true;
    }
    return false;
  }, true);

  useEffect(() => {
    if (!mobile?.id) {
      setLoading(false);
      return;
    }
    let mounted = true;
    const load = async () => {
      try {
        const res = await base44.entities.Service.filter(
          { mobile_id: mobile.id },
          '-created_date',
          500
        );
        const rawList = Array.isArray(res) ? res : res?.items || [];
        const list = rawList.filter((s) => {
          if (mobile?.vehicle_type === 'carro') {
            return s.vehicle_type !== 'moto' && s.service_type !== 'mensajeria';
          }
          if (mobile?.vehicle_type === 'moto') {
            return s.vehicle_type !== 'carro';
          }
          return true;
        });
        if (mounted) setServices(list);
      } catch {
        if (mounted) setServices([]);
      } finally {
        if (mounted) setLoading(false);
      }
    };
    load();
    const unsub = base44.entities.Service.subscribe(() => load());
    return () => {
      mounted = false;
      unsub();
    };
  }, [mobile?.id]);

  const summary = useMemo(() => {
    const todayKey = getBogotaParts(new Date()).str;
    const weekStartKey = getStartOfWeekBogota(new Date());
    const finished = services.filter((s) => s.status === 'finalizado');

    let todayCount = 0;
    let todayAmount = 0;
    let weekCount = 0;
    let weekAmount = 0;
    let monthCount = 0;
    let monthAmount = 0;
    let totalAmount = 0;

    finished.forEach((s) => {
      if (!s.created_date) return;
      const { str } = getBogotaParts(s.created_date);
      const monthKey = str.slice(0, 7);
      const val = Number(s.collected_amount || s.fare || 0);

      totalAmount += val;
      if (str === todayKey) {
        todayCount += 1;
        todayAmount += val;
      }
      if (str >= weekStartKey && str <= todayKey) {
        weekCount += 1;
        weekAmount += val;
      }
      if (monthKey === selectedMonth) {
        monthCount += 1;
        monthAmount += val;
      }
    });

    return {
      todayCount,
      todayAmount,
      weekCount,
      weekAmount,
      monthCount,
      monthAmount,
      totalCount: finished.length,
      totalAmount,
    };
  }, [services, selectedMonth]);

  const shiftMonth = (delta) => {
    const [y, m] = selectedMonth.split('-').map(Number);
    const d = new Date(y, m - 1 + delta, 1);
    const nextKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    setSelectedMonth(nextKey);
    if (period !== 'mes') setPeriod('mes');
  };

  const formattedSelectedMonth = useMemo(() => {
    const [y, m] = selectedMonth.split('-').map(Number);
    const d = new Date(y, m - 1, 1);
    return d.toLocaleDateString('es-CO', { month: 'long', year: 'numeric' });
  }, [selectedMonth]);

  const filteredTrips = useMemo(() => {
    const todayKey = getBogotaParts(new Date()).str;
    const weekStartKey = getStartOfWeekBogota(new Date());
    const q = search.trim().toLowerCase();

    return services.filter((s) => {
      if (statusFilter === 'finalizado' && s.status !== 'finalizado') return false;
      if (statusFilter === 'cancelado' && s.status !== 'cancelado' && s.status !== 'rechazado') return false;
      if (statusFilter === 'todos' && !['finalizado', 'cancelado', 'rechazado'].includes(s.status)) return false;

      const cat = getServiceCategory(s, mobile?.vehicle_type);

      if (s.created_date) {
        const { str } = getBogotaParts(s.created_date);
        if (period === 'hoy' && str !== todayKey) return false;
        if (period === 'semana' && (str < weekStartKey || str > todayKey)) return false;
        if (period === 'mes' && str.slice(0, 7) !== selectedMonth) return false;
      }

      if (!q) return true;
      const dateLabel = fmtFullDateTime(s.created_date).toLowerCase();
      const payLabel = (PAYMENT_LABELS[s.payment_method] || s.payment_method || '').toLowerCase();
      return [
        s.pickup_address,
        s.destination_address,
        s.client_name,
        cat.label,
        dateLabel,
        payLabel,
      ].some((v) => String(v || '').toLowerCase().includes(q));
    });
  }, [services, statusFilter, period, selectedMonth, search, mobile?.vehicle_type]);

  const groupedTrips = useMemo(() => {
    const groups = {};
    filteredTrips.forEach((t) => {
      const key = t.created_date ? fmtGroupDate(t.created_date) : 'Sin fecha';
      if (!groups[key]) groups[key] = [];
      groups[key].push(t);
    });
    return groups;
  }, [filteredTrips]);

  const groupKeys = Object.keys(groupedTrips);

  const filteredTotalAmount = useMemo(
    () =>
      filteredTrips
        .filter((s) => s.status === 'finalizado')
        .reduce((acc, s) => acc + Number(s.collected_amount || s.fare || 0), 0),
    [filteredTrips]
  );

  return (
    <div className="min-h-screen bg-[#F4F8FF] dark:bg-background flex flex-col max-w-md mx-auto w-full pb-10">
      {/* Cabecera con estilo azul de marca */}
      <div className="relative overflow-hidden bg-gradient-to-r from-[#041738] via-[#072B66] to-[#0B439C] pt-4 pb-6 px-4 shadow-md">
        <div className="pointer-events-none absolute -top-6 -right-6 w-28 h-16 bg-gradient-to-l from-[#00D4FF]/45 to-transparent -rotate-45 transform" />
        <div className="pointer-events-none absolute -bottom-6 -left-6 w-28 h-16 bg-gradient-to-r from-[#00D4FF]/35 to-transparent -rotate-45 transform" />

        <div className="relative z-10 flex items-center gap-3">
          <button
            type="button"
            onClick={onBack}
            aria-label="Volver"
            className="w-10 h-10 rounded-full bg-white text-[#041738] flex items-center justify-center shadow-md active:scale-95 transition-transform"
          >
            <ChevronLeft className="w-5 h-5 stroke-[2.5]" />
          </button>
          <div>
            <h1 className="text-white font-extrabold text-lg leading-tight">
              Historial de viajes
            </h1>
            <p className="text-sky-200 text-xs font-medium">
              Consulta tus viajes de hoy, la semana o cualquier mes
            </p>
          </div>
        </div>
      </div>

      <div className="px-4 -mt-3 space-y-3.5 relative z-10">
        <DriverHistorialSummary
          summary={summary}
          period={period}
          onSelectPeriod={setPeriod}
          formattedSelectedMonth={formattedSelectedMonth}
        />

        <DriverHistorialFilters
          period={period}
          onChangePeriod={setPeriod}
          selectedMonth={selectedMonth}
          formattedSelectedMonth={formattedSelectedMonth}
          onChangeMonth={(m) => {
            setSelectedMonth(m);
            setPeriod('mes');
          }}
          onShiftMonth={shiftMonth}
          search={search}
          onChangeSearch={setSearch}
          statusFilter={statusFilter}
          onChangeStatusFilter={setStatusFilter}
        />

        <div className="flex items-center justify-between px-1">
          <p className="text-xs font-extrabold text-[#0F172A] dark:text-foreground">
            {filteredTrips.length} {filteredTrips.length === 1 ? 'viaje encontrado' : 'viajes encontrados'}
          </p>
          <p className="text-xs font-extrabold text-[#1E6BFF] dark:text-sky-400">
            Total: {fmtCOP(filteredTotalAmount)}
          </p>
        </div>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
            <Loader2 className="w-7 h-7 animate-spin text-[#1E6BFF] mb-2" />
            <p className="text-xs font-semibold">Cargando tu historial de viajes...</p>
          </div>
        ) : groupKeys.length === 0 ? (
          <div className="bg-white dark:bg-card rounded-2xl p-8 text-center border border-sky-100 dark:border-border">
            <div className="w-12 h-12 rounded-full bg-[#EAF3FF] dark:bg-sky-950/60 flex items-center justify-center mx-auto mb-3">
              {isCarDriver ? (
                <Car className="w-6 h-6 text-[#1E6BFF]" />
              ) : (
                <Bike className="w-6 h-6 text-[#1E6BFF]" />
              )}
            </div>
            <p className="text-sm font-extrabold text-foreground">
              No se encontraron viajes en este período
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Prueba seleccionando otro mes o cambiando el filtro de búsqueda arriba.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {groupKeys.map((dayLabel) => (
              <div key={dayLabel} className="space-y-2">
                <div className="flex items-center justify-between px-1">
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-[#1E6BFF]" />
                    <span className="text-xs font-extrabold uppercase tracking-wide text-[#062B60] dark:text-sky-300 capitalize">
                      {dayLabel}
                    </span>
                  </div>
                  <span className="text-[11px] font-bold text-slate-500 dark:text-muted-foreground">
                    {groupedTrips[dayLabel].length}{' '}
                    {groupedTrips[dayLabel].length === 1 ? 'viaje' : 'viajes'}
                  </span>
                </div>

                {groupedTrips[dayLabel].map((trip) => {
                  const { Icon, label } = getServiceCategory(trip, mobile?.vehicle_type);
                  const isCancelled =
                    trip.status === 'cancelado' || trip.status === 'rechazado';
                  const amount = Number(trip.collected_amount || trip.fare || 0);
                  const stops = Array.isArray(trip.stops)
                    ? trip.stops.filter((s) => s?.address)
                    : [];

                  return (
                    <button
                      key={trip.id}
                      type="button"
                      onClick={() => setDetailTrip(trip)}
                      className="w-full bg-white dark:bg-card rounded-2xl p-3.5 border border-sky-100 dark:border-border shadow-xs text-left active:scale-[0.99] transition-transform space-y-2.5"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="w-10 h-10 rounded-xl bg-[#EAF3FF] dark:bg-sky-950/60 flex items-center justify-center flex-shrink-0">
                            <Icon className="w-5 h-5 text-[#062B60] dark:text-sky-300" />
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="text-xs font-extrabold text-[#062B60] dark:text-sky-300 uppercase tracking-tight">
                                {label}
                              </span>
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-muted text-slate-600 dark:text-muted-foreground">
                                {PAYMENT_LABELS[trip.payment_method] || trip.payment_method || 'Efectivo'}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-500 dark:text-muted-foreground flex items-center gap-1 mt-0.5 capitalize">
                              <Clock className="w-3 h-3 flex-shrink-0" />
                              {fmtFullDateTime(trip.created_date)}
                            </p>
                          </div>
                        </div>

                        <div className="text-right flex-shrink-0">
                          {isCancelled ? (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-rose-500/15 text-rose-600 dark:text-rose-400">
                              <XCircle className="w-3 h-3" /> Cancelado
                            </span>
                          ) : (
                            <span className="text-base font-black text-[#0F172A] dark:text-foreground">
                              {fmtCOP(amount)}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="space-y-1.5 pl-1">
                        <div className="flex items-start gap-2">
                          <span className="w-2.5 h-2.5 rounded-full border-2 border-[#1E6BFF] mt-1 flex-shrink-0" />
                          <p className="text-xs text-slate-600 dark:text-muted-foreground line-clamp-1">
                            {trip.pickup_address || '—'}
                          </p>
                        </div>

                        {stops.map((st, idx) => (
                          <div key={idx} className="flex items-start gap-2">
                            <span className="w-2.5 h-2.5 rounded-full bg-sky-400 mt-1 flex-shrink-0" />
                            <p className="text-xs text-slate-600 dark:text-muted-foreground line-clamp-1">
                              Parada {idx + 1}: {st.address}
                            </p>
                          </div>
                        ))}

                        <div className="flex items-start gap-2">
                          <span className="w-2.5 h-2.5 rounded-xs bg-[#062B60] dark:bg-sky-400 mt-1 flex-shrink-0" />
                          <p className="text-xs font-bold text-[#0F172A] dark:text-foreground line-clamp-1">
                            {trip.destination_address || '—'}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-border">
                        <div className="flex items-center gap-2 min-w-0">
                          <ClientAvatar
                            photo={trip.client_photo}
                            name={trip.client_name || 'Pasajero'}
                            size="sm"
                          />
                          <div className="min-w-0">
                            <p className="text-xs font-bold text-foreground truncate">
                              {trip.client_name || 'Pasajero'}
                            </p>
                          </div>
                        </div>

                        {typeof trip.rating === 'number' && trip.rating > 0 ? (
                          <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-400/15 text-amber-600 dark:text-amber-300 text-xs font-extrabold">
                            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                            <span>{trip.rating.toFixed(1)}</span>
                          </div>
                        ) : (
                          <span className="text-[11px] font-semibold text-[#1E6BFF] dark:text-sky-400">
                            Ver detalle →
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            ))}
          </div>
        )}
      </div>

      <DriverHistorialDetailModal
        trip={detailTrip}
        categoryLabel={detailTrip ? getServiceCategory(detailTrip, mobile?.vehicle_type).label : ''}
        paymentLabel={
          detailTrip
            ? PAYMENT_LABELS[detailTrip.payment_method] || detailTrip.payment_method || 'Efectivo'
            : ''
        }
        formattedDateTime={detailTrip ? fmtFullDateTime(detailTrip.created_date) : ''}
        onClose={() => setDetailTrip(null)}
      />
    </div>
  );
}
import React from 'react';
import { ChevronLeft, MessageCircle, Users, Bell, Shield, ShieldCheck, Lock, Info, ChevronRight } from 'lucide-react';

const EMERGENCY_PHONE = '123';

// Textos de "Cómo estás protegido" según quién abre la sección.
const PROTECTION = {
  conductor: {
    intro: 'Conoce las herramientas y funciones que cuidan tu seguridad en cada servicio.',
    features: [
      { icon: Shield, title: 'Soporte de seguridad proactivo', desc: 'Monitoreamos tus servicios y te asistimos ante cualquier incidencia en tiempo real.' },
      { icon: ShieldCheck, title: 'Calificación de pasajeros', desc: 'Antes de aceptar ves las estrellas y los viajes del pasajero, y al finalizar tú también lo calificas.' },
      { icon: Lock, title: 'Proteger la privacidad', desc: 'Tus datos personales están encriptados y siempre protegidos.' },
      { icon: ShieldCheck, title: 'Mantener seguridad en todos los servicios', desc: 'Promovemos buenas prácticas ante situaciones de riesgo durante el servicio.' },
    ],
  },
  pasajero: {
    intro: 'Conoce las herramientas y funciones que cuidamos de tu seguridad en cada viaje.',
    features: [
      { icon: Shield, title: 'Soporte de seguridad proactivo', desc: 'Monitoreamos tu viaje y te asistimos ante cualquier incidencia en tiempo real.' },
      { icon: ShieldCheck, title: 'Verificacion de conductores', desc: 'Validamos la identidad y antecedentes de nuestros conductores para tu tranquilidad.' },
      { icon: Lock, title: 'Proteger la privacidad', desc: 'Tus datos personales estan encriptados y siempre protegidos.' },
      { icon: ShieldCheck, title: 'Mantener seguridad en todos los viajes', desc: 'Promovemos buenas practicas ante situaciones de riesgo durante el servicio.' },
    ],
  },
};

// Sección "Seguridad". Le habla al conductor; el panel del pasajero la abre con role="pasajero".
export default function DriverSeguridad({ onBack, onNavigate, role = 'conductor' }) {
  const { intro, features } = PROTECTION[role];

  return (
    <div className="fixed inset-0 z-[1800] bg-background flex flex-col max-w-md mx-auto w-full overflow-y-auto pb-[56px]">
      <div className="flex items-center gap-3 px-4 pt-5 pb-3 flex-shrink-0">
        <button onClick={onBack} className="w-10 h-10 flex items-center justify-center">
          <ChevronLeft className="w-6 h-6 text-foreground" />
        </button>
        <h1 className="text-foreground font-bold text-lg">Seguridad</h1>
      </div>

      <div className="flex-1 px-4 pb-6 space-y-4">
        {/* Soporte + Contactos de emergencia */}
        <div className="grid grid-cols-2 gap-3">
          <button onClick={() => onNavigate?.('soporte')} className="bg-card rounded-2xl p-4 text-left shadow-sm">
            <div className="w-10 h-10 rounded-xl bg-[#fde2e2] dark:bg-red-500/15 flex items-center justify-center mb-2">
              <MessageCircle className="w-5 h-5 text-[#e57373] dark:text-red-400" />
            </div>
            <p className="text-foreground font-bold text-sm">Soporte</p>
            <p className="text-muted-foreground text-xs">Obten ayuda con un asesor</p>
          </button>
          <div className="bg-card rounded-2xl p-4 shadow-sm">
            <div className="w-10 h-10 rounded-xl bg-[#fde2e2] dark:bg-red-500/15 flex items-center justify-center mb-2">
              <Users className="w-5 h-5 text-[#e57373] dark:text-red-400" />
            </div>
            <p className="text-foreground font-bold text-sm">Contactos de emergencia</p>
            <p className="text-muted-foreground text-xs">Contacta a</p>
          </div>
        </div>

        {/* Llamar 123 */}
        <a href={`tel:${EMERGENCY_PHONE}`} className="w-full bg-destructive rounded-2xl p-4 flex items-center gap-3 text-destructive-foreground">
          <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
            <Bell className="w-5 h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-bold text-lg leading-tight">Llamar 123</p>
            <p className="text-white/80 text-xs">Línea de emergencia disponible 24/7</p>
          </div>
          <ChevronRight className="w-5 h-5 flex-shrink-0" />
        </a>

        {/* Cómo estás protegido */}
        <div>
          <h2 className="text-foreground font-bold text-lg">Como estas protegido</h2>
          <p className="text-muted-foreground text-sm">{intro}</p>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {features.map((f) => {
            const Icon = f.icon;
            return (
              <div key={f.title} className="bg-card rounded-2xl p-4 shadow-sm">
                <div className="w-10 h-10 rounded-xl bg-[#E8F5E9] dark:bg-emerald-500/15 flex items-center justify-center mb-2">
                  <Icon className="w-5 h-5 text-[#2E7D32] dark:text-emerald-400" />
                </div>
                <p className="text-foreground font-bold text-sm mb-1">{f.title}</p>
                <p className="text-muted-foreground text-xs leading-relaxed">{f.desc}</p>
              </div>
            );
          })}
        </div>

        {/* Accidentes */}
        <div className="bg-card rounded-2xl p-4 shadow-sm flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#E8F5E9] dark:bg-emerald-500/15 flex items-center justify-center flex-shrink-0">
            <Info className="w-5 h-5 text-[#2E7D32] dark:text-emerald-400" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-foreground font-bold text-sm">Accidentes: pasos a seguir</p>
            <p className="text-muted-foreground text-xs leading-relaxed">Sigue recomendaciones en caso de accidente para tu seguridad y la de los demas.</p>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-card rounded-2xl p-4 shadow-sm flex items-center gap-3">
          <Shield className="w-8 h-8 text-[#2E7D32] dark:text-emerald-400 flex-shrink-0" />
          <div>
            <p className="text-foreground font-bold text-sm">Tu seguridad es nuestra prioridad</p>
            <p className="text-muted-foreground text-xs">Estamos aqui para ayudarte, siempre.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
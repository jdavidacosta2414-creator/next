import React, { useMemo } from 'react';
import { Loader2, Check, X } from 'lucide-react';
import {
  COLOMBIA_CAR_CATALOG,
  FACTORY_VEHICLE_COLORS,
} from '@/components/shared/VehicleBrandIllustration';

const CURRENT_YEAR = new Date().getFullYear();
const CAR_YEARS = Array.from(
  { length: Math.max(1, CURRENT_YEAR + 1 - 2003 + 1) },
  (_, idx) => String(CURRENT_YEAR + 1 - idx)
);

export default function DriverPerfilEditForm({
  name,
  setName,
  phone,
  setPhone,
  cedula,
  setCedula,
  vehicleType,
  setVehicleType,
  carSubtype,
  setCarSubtype,
  plate,
  setPlate,
  plateType,
  setPlateType,
  vehicleBrand,
  setVehicleBrand,
  vehicleModel,
  setVehicleModel,
  vehicleColor,
  setVehicleColor,
  vehicleYear,
  setVehicleYear,
  saving,
  onCancel,
  onSubmit,
}) {
  const selectedBrandEntry = useMemo(() => {
    const bLower = String(vehicleBrand || '').trim().toLowerCase();
    return COLOMBIA_CAR_CATALOG.find((item) => item.brand.toLowerCase() === bLower) || null;
  }, [vehicleBrand]);

  return (
    <form
      onSubmit={onSubmit}
      className="bg-white dark:bg-card rounded-2xl p-4 border border-sky-100 dark:border-border shadow-xs space-y-3"
    >
      <p className="text-xs font-extrabold uppercase tracking-wider text-[#1E6BFF] dark:text-sky-400">
        Editar perfil y vehículo 3D
      </p>

      <div>
        <label className="block text-[11px] font-bold text-muted-foreground mb-1">
          Nombre completo
        </label>
        <input
          type="text"
          required
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="w-full h-10 rounded-xl bg-slate-50 dark:bg-muted px-3 text-sm text-foreground border border-slate-200 dark:border-border outline-none focus:border-[#1E6BFF]"
        />
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        <div>
          <label className="block text-[11px] font-bold text-muted-foreground mb-1">
            Teléfono celular
          </label>
          <input
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="w-full h-10 rounded-xl bg-slate-50 dark:bg-muted px-3 text-sm text-foreground border border-slate-200 dark:border-border outline-none focus:border-[#1E6BFF]"
          />
        </div>
        <div>
          <label className="block text-[11px] font-bold text-muted-foreground mb-1">
            Cédula / Documento
          </label>
          <input
            type="text"
            value={cedula}
            onChange={(e) => setCedula(e.target.value)}
            className="w-full h-10 rounded-xl bg-slate-50 dark:bg-muted px-3 text-sm text-foreground border border-slate-200 dark:border-border outline-none focus:border-[#1E6BFF]"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        <div>
          <label className="block text-[11px] font-bold text-muted-foreground mb-1">
            Tipo de vehículo
          </label>
          <select
            value={vehicleType}
            onChange={(e) => setVehicleType(e.target.value)}
            className="w-full h-10 rounded-xl bg-slate-50 dark:bg-muted px-3 text-sm font-semibold text-foreground border border-slate-200 dark:border-border outline-none focus:border-[#1E6BFF]"
          >
            <option value="moto">Moto</option>
            <option value="carro">Carro</option>
          </select>
        </div>
        <div>
          <label className="block text-[11px] font-bold text-muted-foreground mb-1">
            Placa
          </label>
          <input
            type="text"
            value={plate}
            onChange={(e) => setPlate(e.target.value.toUpperCase())}
            className="w-full h-10 rounded-xl bg-slate-50 dark:bg-muted px-3 text-sm font-extrabold uppercase text-foreground border border-slate-200 dark:border-border outline-none focus:border-[#1E6BFF]"
          />
        </div>
      </div>

      {vehicleType === 'carro' && (
        <>
          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="block text-[11px] font-bold text-muted-foreground mb-1">
                Modalidad
              </label>
              <select
                value={carSubtype || 'particular'}
                onChange={(e) => {
                  const val = e.target.value;
                  setCarSubtype(val);
                  setPlateType(val === 'taxi' ? 'blanca' : 'amarilla');
                }}
                className="w-full h-10 rounded-xl bg-slate-50 dark:bg-muted px-2 text-xs font-semibold text-foreground border border-slate-200 dark:border-border outline-none focus:border-[#1E6BFF]"
              >
                <option value="particular">Carro particular</option>
                <option value="taxi">Servicio público / Taxi</option>
              </select>
            </div>
            <div>
              <label className="block text-[11px] font-bold text-muted-foreground mb-1">
                Tipo de placa
              </label>
              <select
                value={plateType || 'amarilla'}
                onChange={(e) => {
                  const val = e.target.value;
                  setPlateType(val);
                  setCarSubtype(val === 'blanca' ? 'taxi' : 'particular');
                }}
                className="w-full h-10 rounded-xl bg-slate-50 dark:bg-muted px-2 text-xs font-semibold text-foreground border border-slate-200 dark:border-border outline-none focus:border-[#1E6BFF]"
              >
                <option value="amarilla">Placa amarilla (Particular)</option>
                <option value="blanca">Placa blanca (Público)</option>
              </select>
            </div>
            <div>
              <label className="block text-[11px] font-bold text-muted-foreground mb-1">
                Año (2003+)
              </label>
              <select
                value={vehicleYear || String(CURRENT_YEAR)}
                onChange={(e) => setVehicleYear(e.target.value)}
                className="w-full h-10 rounded-xl bg-slate-50 dark:bg-muted px-2 text-xs font-semibold text-foreground border border-slate-200 dark:border-border outline-none focus:border-[#1E6BFF]"
              >
                {CAR_YEARS.map((yr) => (
                  <option key={yr} value={yr}>
                    {yr}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Selección rápida de marca y línea del catálogo */}
          <div className="rounded-xl bg-slate-50 dark:bg-muted/60 p-2.5 border border-slate-200/80 dark:border-border space-y-2">
            <p className="text-[10.5px] font-extrabold uppercase text-muted-foreground">
              Catálogo rápido de marcas y modelos (Valledupar)
            </p>
            <div className="flex flex-wrap gap-1.5">
              {COLOMBIA_CAR_CATALOG.map((item) => {
                const active =
                  String(vehicleBrand || '').trim().toLowerCase() === item.brand.toLowerCase();
                return (
                  <button
                    key={item.brand}
                    type="button"
                    onClick={() => {
                      setVehicleBrand(item.brand);
                      if (!vehicleModel) setVehicleModel(item.models[0]);
                    }}
                    className={`px-2 py-1 rounded-lg text-[11px] font-bold border transition-all ${
                      active
                        ? 'bg-[#1E6BFF] text-white border-[#1E6BFF]'
                        : 'bg-card text-foreground border-border'
                    }`}
                  >
                    {item.brand}
                  </button>
                );
              })}
            </div>
            {selectedBrandEntry && (
              <div className="flex flex-wrap gap-1.5 pt-1 border-t border-border">
                {selectedBrandEntry.models.map((mdl) => {
                  const active =
                    String(vehicleModel || '').trim().toLowerCase() === mdl.toLowerCase();
                  return (
                    <button
                      key={mdl}
                      type="button"
                      onClick={() => setVehicleModel(mdl)}
                      className={`px-2 py-0.5 rounded-lg text-[11px] font-extrabold border transition-all ${
                        active
                          ? 'bg-[#1E6BFF]/15 text-[#1E6BFF] border-[#1E6BFF]'
                          : 'bg-card text-muted-foreground border-border'
                      }`}
                    >
                      {mdl}
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </>
      )}

      <div className="grid grid-cols-3 gap-2.5">
        <div>
          <label className="block text-[11px] font-bold text-muted-foreground mb-1">
            Marca
          </label>
          <input
            type="text"
            value={vehicleBrand}
            onChange={(e) => setVehicleBrand(e.target.value)}
            placeholder="Ej. Chevrolet"
            className="w-full h-10 rounded-xl bg-slate-50 dark:bg-muted px-3 text-sm text-foreground border border-slate-200 dark:border-border outline-none focus:border-[#1E6BFF]"
          />
        </div>
        <div>
          <label className="block text-[11px] font-bold text-muted-foreground mb-1">
            Línea
          </label>
          <input
            type="text"
            value={vehicleModel}
            onChange={(e) => setVehicleModel(e.target.value)}
            placeholder="Ej. Picanto, Spark"
            className="w-full h-10 rounded-xl bg-slate-50 dark:bg-muted px-3 text-sm text-foreground border border-slate-200 dark:border-border outline-none focus:border-[#1E6BFF]"
          />
        </div>
        <div>
          <label className="block text-[11px] font-bold text-muted-foreground mb-1">
            Color
          </label>
          <input
            type="text"
            value={vehicleColor || ''}
            onChange={(e) => setVehicleColor?.(e.target.value)}
            placeholder="Ej. Azul, Rojo..."
            className="w-full h-10 rounded-xl bg-slate-50 dark:bg-muted px-3 text-sm text-foreground border border-slate-200 dark:border-border outline-none focus:border-[#1E6BFF]"
          />
        </div>
      </div>

      {/* Paleta de color de fábrica */}
      <div className="space-y-1.5">
        <label className="block text-[11px] font-bold text-muted-foreground">
          Selecciona el color de fábrica:
        </label>
        <div className="grid grid-cols-6 gap-1.5">
          {FACTORY_VEHICLE_COLORS.map((sw) => {
            const isSelected =
              String(vehicleColor || '').trim().toLowerCase() === sw.id.toLowerCase();
            return (
              <button
                key={sw.id}
                type="button"
                onClick={() => setVehicleColor?.(sw.id)}
                className={`flex flex-col items-center gap-0.5 p-1 rounded-xl border transition-all ${
                  isSelected
                    ? 'border-[#1E6BFF] bg-[#1E6BFF]/10 ring-1 ring-[#1E6BFF]'
                    : 'border-border bg-slate-50 dark:bg-muted/50'
                }`}
              >
                <span
                  className="w-5 h-4 rounded-sm border"
                  style={{ backgroundColor: sw.hex, borderColor: sw.border }}
                />
                <span className="text-[9px] font-bold text-foreground truncate w-full text-center">
                  {sw.id}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="flex items-center gap-2 pt-1">
        <button
          type="button"
          onClick={onCancel}
          disabled={saving}
          className="flex-1 h-10 rounded-xl bg-slate-100 dark:bg-muted text-foreground text-xs font-bold flex items-center justify-center gap-1.5"
        >
          <X className="w-4 h-4" /> Cancelar
        </button>
        <button
          type="submit"
          disabled={saving}
          className="flex-1 h-10 rounded-xl bg-gradient-to-r from-[#051F54] via-[#0B45B4] to-[#00B8FF] text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm"
        >
          {saving ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Check className="w-4 h-4" />
          )}
          Guardar cambios
        </button>
      </div>
    </form>
  );
}
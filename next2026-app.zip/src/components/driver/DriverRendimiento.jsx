import React, { useState, useEffect, useCallback } from 'react';
import {
  ChevronLeft,
  Activity,
  CheckCircle2,
  XCircle,
  Star,
  AlertTriangle,
  Award,
  Clock,
  ShieldCheck,
  RefreshCw,
  TrendingUp,
  Info,
} from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { MIN_VALID_SAMPLE, getTierById } from '@/lib/driverTier';

const PERIOD_TABS = [
  { id: '7d', label: 'Últimos 7 días' },
  { id: '30d', label: 'Últimos 30 días' },
  { id: '90d', label: 'Últimos 90 días' },
  { id: 'all', label: 'Historial completo' },
];

const STATUS_META = {
  excelente: {
    label: 'Excelente',
    badgeCls: 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/35',
    dotCls: 'bg-emerald-500',
    desc: 'Cumples sobradamente los estándares de aceptación y bajas cancelaciones de NEXT.',
  },
  bueno: {
    label: 'Bueno',
    badgeCls: 'bg-sky-500/15 text-sky-700 dark:text-sky-300 border-sky-500/35',
    dotCls: 'bg-sky-500',
    desc: 'Tu rendimiento reciente es sólido y cumple los requisitos para Nivel Plata.',
  },
  en_observacion: {
    label: 'En observación',
    badgeCls: 'bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-500/35',
    dotCls: 'bg-amber-500',
    desc: 'Alguno de tus indicadores recientes requiere atención para proteger los beneficios de tu nivel.',
  },
  necesita_mejorar: {
    label: 'Necesita mejorar',
    badgeCls: 'bg-rose-500/15 text-rose-700 dark:text-rose-300 border-rose-500/35',
    dotCls: 'bg-rose-500',
    desc: 'Te recomendamos aceptar más solicitudes compatibles y evitar cancelar servicios aceptados.',
  },
  sin_datos_suficientes: {
    label: 'En evaluación inicial',
    badgeCls: 'bg-slate-500/15 text-slate-700 dark:text-slate-300 border-slate-500/35',
    dotCls: 'bg-slate-400',
    desc: 'Necesitamos más servicios para evaluar tu rendimiento. Sigue trabajando y pronto tendrás una evaluación más precisa.',
  },
};

function fmtDate(iso) {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleDateString('es-CO', {
      day: '2-digit',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
      timeZone: 'America/Bogota',
    });
  } catch {
    return '—';
  }
}

export default function DriverRendimiento({
  mobile,
  tierInfo,
  avgRating: propAvgRating = 0,
  totalReviews: propTotalReviews = 0,
  onBack,
  onOpenNiveles,
}) {
  const [period, setPeriod] = useState('30d');
  const [loading, setLoading] = useState(false);
  const [evalData, setEvalData] = useState(null);

  const loadPerformance = useCallback(async () => {
    if (!mobile?.id) return;
    setLoading(true);
    try {
      const res = await base44.functions.invoke('driverPerformance', {
        action: 'get_driver_summary',
        mobile_id: mobile.id,
      });
      const data = res?.data || res;
      if (data?.evaluation) {
        setEvalData(data.evaluation);
      }
    } catch {} finally {
      setLoading(false);
    }
  }, [mobile?.id]);

  useEffect(() => {
    loadPerformance();
  }, [loadPerformance]);

  const currentLevelId = evalData?.currentLevel || tierInfo?.current?.id || mobile?.current_level || 'bronce';
  const currentTier = getTierById(currentLevelId);

  const periodsMap = evalData?.periods || tierInfo?.periods || {};
  const activeMetrics = periodsMap[period] || {
    validRequestsReceived: 0,
    validRequestsAccepted: 0,
    validRequestsRejected: 0,
    validRequestsExpired: 0,
    offersNotSelected: 0,
    acceptanceRate: Number(tierInfo?.acceptanceRate ?? 100),
    acceptedServicesCount: 0,
    driverCancellationsTotal: 0,
    driverCancellationsJustified: 0,
    driverCancellationsPenalized: 0,
    passengerCancellations: 0,
    cancellationRate: Number(tierInfo?.cancellationRate ?? 0),
    completedCount: Number(tierInfo?.recentTrips ?? 0),
    ratingsCount: propTotalReviews,
    avgRating: propAvgRating,
    validSampleCount: Number(tierInfo?.validSampleCount ?? 0),
    hasMinimumSample: Boolean(tierInfo?.hasMinimumSample),
  };

  const metrics30d = periodsMap['30d'] || activeMetrics;
  const recovery = evalData?.recovery || tierInfo?.recovery || { active: false };
  const dailyEvolution = evalData?.dailyEvolution || tierInfo?.dailyEvolution || [];
  const driverCancelEvents = evalData?.driverCancellationEvents || tierInfo?.driverCancellationEvents || [];

  // Estado derivado de reglas reales sobre el periodo consultado
  const derivedStatusKey = !activeMetrics.hasMinimumSample
    ? 'sin_datos_suficientes'
    : recovery?.active && period === '30d'
      ? 'en_observacion'
      : activeMetrics.acceptanceRate >= 90 && activeMetrics.cancellationRate <= 3
        ? 'excelente'
        : activeMetrics.acceptanceRate >= 80 && activeMetrics.cancellationRate <= 5
          ? 'bueno'
          : activeMetrics.acceptanceRate >= 70 && activeMetrics.cancellationRate <= 8
            ? 'en_observacion'
            : 'necesita_mejorar';

  const statusMeta = STATUS_META[derivedStatusKey] || STATUS_META.sin_datos_suficientes;

  const accStatusLabel =
    activeMetrics.acceptanceRate >= 90
      ? 'Óptimo (Nivel Oro ≥90%)'
      : activeMetrics.acceptanceRate >= 80
        ? 'Cumple Nivel Plata (≥80%)'
        : 'Por debajo de 80%';

  const cancelStatusLabel =
    activeMetrics.cancellationRate <= 3
      ? 'Óptimo (Nivel Oro ≤3%)'
      : activeMetrics.cancellationRate <= 5
        ? 'Cumple Nivel Plata (≤5%)'
        : 'Supera el 5% permitido';

  const displayRating =
    activeMetrics.avgRating > 0
      ? activeMetrics.avgRating
      : propAvgRating > 0
        ? Number(propAvgRating)
        : 0;
  const displayRatingsCount =
    activeMetrics.ratingsCount > 0 ? activeMetrics.ratingsCount : propTotalReviews;

  return (
    <div className="min-h-screen bg-background">
      {/* Encabezado */}
      <div className="sticky top-0 z-20 flex items-center justify-between gap-3 px-4 h-14 bg-card border-b border-border/60">
        <div className="flex items-center gap-2.5 min-w-0">
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              aria-label="Volver"
              className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-muted transition-colors"
            >
              <ChevronLeft className="w-6 h-6 text-foreground" />
            </button>
          )}
          <div className="min-w-0">
            <h1 className="text-foreground font-extrabold text-base truncate">
              Mi Rendimiento
            </h1>
            <p className="text-[11px] text-muted-foreground truncate">
              Evaluación de comportamiento reciente · Nivel {currentTier.name}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={loadPerformance}
          disabled={loading}
          className="h-9 px-3 rounded-full bg-muted text-foreground font-bold text-xs flex items-center gap-1.5"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Actualizar</span>
        </button>
      </div>

      <div className="px-4 pt-4 pb-28 space-y-4">
        {/* Selector de periodos: 7d, 30d, 90d, Historial completo */}
        <div className="bg-card rounded-2xl p-1.5 border border-border grid grid-cols-2 sm:grid-cols-4 gap-1.5">
          {PERIOD_TABS.map((t) => {
            const active = period === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setPeriod(t.id)}
                className={`py-2 px-2.5 rounded-xl text-xs font-extrabold transition-all ${
                  active
                    ? 'bg-[#1E6BFF] text-white shadow-xs'
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted/60'
                }`}
              >
                {t.label}
              </button>
            );
          })}
        </div>

        <div className="flex items-center justify-between px-1 text-[11px] text-muted-foreground">
          <span>
            {period === '30d'
              ? '✓ Ventana móvil oficial de 30 días usada para decisiones de nivel'
              : 'Consulta informativa del periodo seleccionado'}
          </span>
          {onOpenNiveles && (
            <button
              type="button"
              onClick={onOpenNiveles}
              className="text-primary font-extrabold underline"
            >
              Ver mi Nivel ({currentTier.name})
            </button>
          )}
        </div>

        {/* Regla de muestra mínima (< 20 registros válidos) */}
        {!activeMetrics.hasMinimumSample && (
          <div className="rounded-3xl border border-sky-500/35 bg-sky-500/10 p-4 flex items-start gap-3">
            <Info className="w-5 h-5 text-sky-500 flex-shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="text-xs font-extrabold text-foreground">
                Muestra actual: {activeMetrics.validSampleCount} de {MIN_VALID_SAMPLE} registros válidos
              </p>
              <p className="text-xs text-foreground/90 leading-relaxed font-medium">
                “Necesitamos más servicios para evaluar tu rendimiento. Sigue trabajando y pronto tendrás una evaluación más precisa”.
              </p>
              <p className="text-[11px] text-muted-foreground">
                No recibirás ninguna penalización ni descenso mientras completas tus primeros {MIN_VALID_SAMPLE} registros válidos.
              </p>
            </div>
          </div>
        )}

        {/* Alerta de Periodo de Recuperación de 7 Días si está activo */}
        {recovery?.active && (
          <div className="rounded-3xl border-2 border-amber-500/45 bg-amber-500/10 p-4 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <span className="inline-flex items-center gap-1.5 text-xs font-extrabold text-amber-600 dark:text-amber-300">
                <AlertTriangle className="w-4 h-4" /> Periodo de recuperación de 7 días
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-amber-500 text-slate-950 text-[11px] font-black">
                {recovery.daysRemaining ?? 7} {(recovery.daysRemaining ?? 7) === 1 ? 'día restante' : 'días restantes'}
              </span>
            </div>
            <p className="text-xs text-foreground leading-relaxed font-medium">
              {recovery.reason}
            </p>
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              Durante estos 7 días conservas tu Nivel {currentTier.name}. Si recuperas tus indicadores de 30 días, esta advertencia se cancelará automáticamente.
            </p>
          </div>
        )}

        {/* TARJETA 5 / PRINCIPAL: Estado del rendimiento */}
        <div className="bg-card rounded-3xl border border-border p-5 shadow-xs space-y-3">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
                5. Estado del rendimiento
              </p>
              <div className="flex items-center gap-2 mt-1">
                <span className={`w-3 h-3 rounded-full ${statusMeta.dotCls}`} />
                <h2 className="text-xl font-black text-foreground">{statusMeta.label}</h2>
              </div>
            </div>
            <span
              className={`px-3 py-1 rounded-full text-xs font-extrabold border ${statusMeta.badgeCls}`}
            >
              {statusMeta.label}
            </span>
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed">{statusMeta.desc}</p>

          <div className="pt-2 border-t border-border flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Beneficios de prioridad ({currentTier.name}):</span>
            <span
              className={`font-extrabold ${
                evalData?.priorityBenefitsActive !== false
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : 'text-amber-600 dark:text-amber-400'
              }`}
            >
              {evalData?.priorityBenefitsActive !== false
                ? `✓ Activos (${currentTier.priorityLabel})`
                : 'En revisión'}
            </span>
          </div>
        </div>

        {/* TARJETA 1: Tasa de aceptación */}
        <div className="bg-card rounded-3xl border border-border p-5 shadow-xs space-y-3">
          <div className="flex items-start justify-between gap-2">
            <div>
              <p className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
                1. Tasa de aceptación
              </p>
              <p className="text-3xl font-black text-foreground mt-0.5">
                {activeMetrics.acceptanceRate}%
              </p>
            </div>
            <span
              className={`px-2.5 py-1 rounded-full text-[11px] font-extrabold ${
                activeMetrics.acceptanceRate >= 90
                  ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                  : activeMetrics.acceptanceRate >= 80
                    ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400'
                    : 'bg-amber-500/15 text-amber-600 dark:text-amber-400'
              }`}
            >
              {accStatusLabel}
            </span>
          </div>

          <div className="h-2.5 rounded-full bg-muted overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                activeMetrics.acceptanceRate >= 90
                  ? 'bg-emerald-500'
                  : activeMetrics.acceptanceRate >= 80
                    ? 'bg-[#1E6BFF]'
                    : 'bg-amber-500'
              }`}
              style={{ width: `${Math.max(4, Math.min(100, activeMetrics.acceptanceRate))}%` }}
            />
          </div>

          <div className="grid grid-cols-3 gap-2 pt-1 text-center">
            <div className="rounded-2xl bg-muted/50 p-2.5 border border-border/60">
              <p className="text-base font-black text-foreground">
                {activeMetrics.validRequestsReceived}
              </p>
              <p className="text-[10px] text-muted-foreground">Recibidas válidas</p>
            </div>
            <div className="rounded-2xl bg-muted/50 p-2.5 border border-border/60">
              <p className="text-base font-black text-emerald-600 dark:text-emerald-400">
                {activeMetrics.validRequestsAccepted}
              </p>
              <p className="text-[10px] text-muted-foreground">Aceptadas</p>
            </div>
            <div className="rounded-2xl bg-muted/50 p-2.5 border border-border/60">
              <p className="text-base font-black text-amber-600 dark:text-amber-400">
                {activeMetrics.validRequestsRejected + activeMetrics.validRequestsExpired}
              </p>
              <p className="text-[10px] text-muted-foreground">Rechazadas / Vencidas</p>
            </div>
          </div>

          <p className="text-[11px] text-muted-foreground leading-relaxed">
            ✓ Las ofertas que envías al pasajero y que el pasajero no selecciona ({activeMetrics.offersNotSelected || 0}) y las solicitudes de otros vehículos <strong className="text-foreground">no perjudican tu aceptación</strong>.
          </p>
        </div>

        {/* TARJETA 2: Tasa de cancelación */}
        <div className="bg-card rounded-3xl border border-border p-5 shadow-xs space-y-3">
          <div className="flex items-start justify-between gap-2">
            <div>
              <p className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
                2. Tasa de cancelación
              </p>
              <p className="text-3xl font-black text-foreground mt-0.5">
                {activeMetrics.cancellationRate}%
              </p>
            </div>
            <span
              className={`px-2.5 py-1 rounded-full text-[11px] font-extrabold ${
                activeMetrics.cancellationRate <= 3
                  ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                  : activeMetrics.cancellationRate <= 5
                    ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400'
                    : 'bg-rose-500/15 text-rose-600 dark:text-rose-400'
              }`}
            >
              {cancelStatusLabel}
            </span>
          </div>

          <div className="h-2.5 rounded-full bg-muted overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                activeMetrics.cancellationRate <= 3
                  ? 'bg-emerald-500'
                  : activeMetrics.cancellationRate <= 5
                    ? 'bg-sky-500'
                    : 'bg-rose-500'
              }`}
              style={{
                width: `${Math.max(4, Math.min(100, (activeMetrics.cancellationRate / 10) * 100))}%`,
              }}
            />
          </div>

          <div className="grid grid-cols-3 gap-2 pt-1 text-center">
            <div className="rounded-2xl bg-muted/50 p-2.5 border border-border/60">
              <p className="text-base font-black text-foreground">
                {activeMetrics.driverCancellationsPenalized}
              </p>
              <p className="text-[10px] text-muted-foreground">Por conductor</p>
            </div>
            <div className="rounded-2xl bg-muted/50 p-2.5 border border-border/60">
              <p className="text-base font-black text-emerald-600 dark:text-emerald-400">
                {activeMetrics.driverCancellationsJustified}
              </p>
              <p className="text-[10px] text-muted-foreground">Justificadas (0%)</p>
            </div>
            <div className="rounded-2xl bg-muted/50 p-2.5 border border-border/60">
              <p className="text-base font-black text-sky-600 dark:text-sky-400">
                {activeMetrics.passengerCancellations}
              </p>
              <p className="text-[10px] text-muted-foreground">Por pasajero (0%)</p>
            </div>
          </div>

          <p className="text-[11px] text-muted-foreground leading-relaxed">
            ✓ Si el pasajero cancela o un administrador aprueba que tu cancelación estuvo justificada, <strong className="text-foreground">se excluye del cálculo y no te penaliza</strong>.
          </p>
        </div>

        {/* TARJETA 3: Calificación de pasajeros */}
        <div className="bg-card rounded-3xl border border-border p-5 shadow-xs space-y-3">
          <div className="flex items-start justify-between gap-2">
            <div>
              <p className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
                3. Calificación de pasajeros
              </p>
              <div className="flex items-center gap-2 mt-1">
                <Star className="w-6 h-6 fill-amber-400 text-amber-400" />
                <span className="text-3xl font-black text-foreground">
                  {displayRating > 0 ? displayRating.toFixed(1) : '5.0'}
                </span>
                <span className="text-xs text-muted-foreground font-semibold">
                  ({displayRatingsCount} {displayRatingsCount === 1 ? 'calificación' : 'calificaciones'})
                </span>
              </div>
            </div>
            <span className="px-2.5 py-1 rounded-full text-[11px] font-extrabold bg-amber-500/15 text-amber-600 dark:text-amber-300">
              {displayRating >= 4.7 || displayRating === 0
                ? 'Reputación Sobresaliente'
                : displayRating >= 4.3
                  ? 'Buena Reputación'
                  : 'En observación'}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            {[1, 2, 3, 4, 5].map((n) => (
              <div
                key={n}
                className={`h-2 flex-1 rounded-full ${
                  (displayRating || 5) >= n - 0.25 ? 'bg-amber-400' : 'bg-muted'
                }`}
              />
            ))}
          </div>
          <p className="text-[11px] text-muted-foreground">
            Promedio real calculado a partir de las calificaciones verificadas de tus pasajeros al finalizar cada servicio.
          </p>
        </div>

        {/* TARJETA 4: Servicios recientes y evolución de los últimos días */}
        <div className="bg-card rounded-3xl border border-border p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
                4. Servicios recientes
              </p>
              <h3 className="text-base font-extrabold text-foreground mt-0.5">
                Actividad del periodo y últimos 7 días
              </h3>
            </div>
            <TrendingUp className="w-5 h-5 text-primary" />
          </div>

          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="rounded-2xl bg-muted/50 p-3 border border-border/60">
              <p className="text-xl font-black text-foreground">
                {activeMetrics.completedCount}
              </p>
              <p className="text-[10px] text-muted-foreground font-semibold mt-0.5">
                Completados
              </p>
            </div>
            <div className="rounded-2xl bg-muted/50 p-3 border border-border/60">
              <p className="text-xl font-black text-[#1E6BFF]">
                {activeMetrics.validRequestsAccepted}
              </p>
              <p className="text-[10px] text-muted-foreground font-semibold mt-0.5">
                Aceptadas
              </p>
            </div>
            <div className="rounded-2xl bg-muted/50 p-3 border border-border/60">
              <p className="text-xl font-black text-rose-500">
                {activeMetrics.driverCancellationsPenalized}
              </p>
              <p className="text-[10px] text-muted-foreground font-semibold mt-0.5">
                Cancelaciones
              </p>
            </div>
          </div>

          {/* Evolución día por día (últimos 7 días) */}
          {dailyEvolution.length > 0 && (
            <div className="pt-2 border-t border-border">
              <p className="text-xs font-extrabold text-foreground mb-2.5">
                Evolución diaria (últimos 7 días)
              </p>
              <div className="grid grid-cols-7 gap-1.5 items-end h-24 pt-2">
                {dailyEvolution.map((d) => {
                  const maxVal = Math.max(
                    1,
                    ...dailyEvolution.map((x) => Math.max(x.completed || 0, x.accepted || 0))
                  );
                  const barH = Math.max(12, Math.round(((d.completed || 0) / maxVal) * 56));
                  return (
                    <div
                      key={d.date}
                      className="flex flex-col items-center justify-end gap-1"
                    >
                      <span className="text-[10px] font-extrabold text-foreground">
                        {d.completed}
                      </span>
                      <div
                        className="w-full max-w-[24px] rounded-t-lg bg-gradient-to-t from-[#1E6BFF] to-[#00E5FF]"
                        style={{ height: `${barH}px` }}
                      />
                      <span className="text-[9px] text-muted-foreground truncate w-full text-center">
                        {d.label}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Detalle de cancelaciones atribuibles y su estado de revisión administrativa */}
          {driverCancelEvents.length > 0 && (
            <div className="pt-3 border-t border-border space-y-2">
              <p className="text-xs font-extrabold text-foreground">
                Registro de cancelaciones del conductor y revisión administrativa
              </p>
              {driverCancelEvents.slice(0, 5).map((ev) => {
                const isJustified = ev.justified || ev.justification_status === 'justificada';
                return (
                  <div
                    key={ev.id}
                    className="rounded-2xl bg-muted/40 border border-border p-3 text-xs space-y-1"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-bold text-foreground">
                        Motivo: {ev.cancel_reason || 'Liberado por conductor'}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                          isJustified
                            ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                            : 'bg-amber-500/15 text-amber-600 dark:text-amber-400'
                        }`}
                      >
                        {isJustified ? '✓ Justificada (Excluida)' : 'Contabilizada'}
                      </span>
                    </div>
                    {ev.pickup_address && (
                      <p className="text-muted-foreground truncate">
                        Ruta: {ev.pickup_address} → {ev.destination_address || 'Destino'}
                      </p>
                    )}
                    {isJustified && ev.admin_observation && (
                      <p className="text-emerald-600 dark:text-emerald-400 text-[11px]">
                        Revisión Admin ({ev.reviewed_by_admin || 'Admin'}): {ev.admin_observation}
                      </p>
                    )}
                    <p className="text-[10px] text-muted-foreground">
                      {fmtDate(ev.cancelled_at || ev.created_date)}
                    </p>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
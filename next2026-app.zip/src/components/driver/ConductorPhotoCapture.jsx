import React, { useState, useEffect } from 'react';
import { Camera, Image as ImageIcon, Loader2, X, CheckCircle2, ShieldAlert } from 'lucide-react';
import InAppCameraModal from '@/components/shared/InAppCameraModal';
import { getCachedSignedUrl, resolveStorageUrl } from '@/components/shared/ResolvedAvatar';

// Tarjeta de captura de documento o vehículo:
// 1) "Tomar foto": abre la cámara integrada en la app (InAppCameraModal) sin usar capture="..." en <input>
//    para evitar pantallas blancas o bloqueos de WebChromeClient en APK de Android.
// 2) "Buscar en galería": usa <input type="file" accept="image/*"> superpuesto directamente sobre el botón
//    dentro de un contenedor relative overflow-hidden para evitar saltos de scroll o bloqueos en móvil.
export default function ConductorPhotoCapture({
  kind,
  label,
  subtitle,
  badge,
  value,
  previewUrl,
  loading,
  cameraFacing = 'environment',
  onSelectFile,
  onClear,
  errors = {},
}) {
  const error = errors[kind];
  const [cameraOpen, setCameraOpen] = useState(false);
  const [resolvedPreview, setResolvedPreview] = useState(
    () => previewUrl || getCachedSignedUrl(value) || ''
  );

  useEffect(() => {
    let active = true;
    if (previewUrl) {
      setResolvedPreview(previewUrl);
      return;
    }
    if (!value) {
      setResolvedPreview('');
      return;
    }
    const cached = getCachedSignedUrl(value);
    if (cached) {
      setResolvedPreview(cached);
      if (!cached.startsWith('blob:')) return;
    }
    resolveStorageUrl(value)
      .then((url) => {
        if (active && url) setResolvedPreview(url);
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [value, previewUrl]);

  const markPickerOpen = () => {
    if (typeof window !== 'undefined') {
      window.__nextFilePickerOpenUntil = Date.now() + 60000;
    }
  };

  const handleGalleryInput = (e) => {
    const file = e.target.files?.[0];
    if (e.target) e.target.value = '';
    if (file) {
      onSelectFile(file, kind);
    }
  };

  const handleCameraCaptured = (file) => {
    if (file) {
      onSelectFile(file, kind);
    }
  };

  const displayImg = previewUrl || resolvedPreview || value;

  return (
    <div
      className="relative rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#161C28] p-3.5 shadow-xs transition-colors"
      data-photo-picker="true"
    >
      <InAppCameraModal
        open={cameraOpen}
        facing={cameraFacing}
        title={label}
        onClose={() => setCameraOpen(false)}
        onCaptureFile={handleCameraCaptured}
      />

      <div className="flex items-start justify-between gap-2 mb-2">
        <div>
          <p className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-1.5">
            {label}
            {value && <CheckCircle2 className="w-4 h-4 text-[#00C853] flex-shrink-0" />}
          </p>
          {subtitle && (
            <p className="text-[11px] text-slate-500 dark:text-[#8B95A8] mt-0.5 leading-snug">
              {subtitle}
            </p>
          )}
        </div>
        {badge && (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#1E6BFF]/10 dark:bg-[#1E6BFF]/20 text-[#1E6BFF] dark:text-[#00E5FF] border border-[#1E6BFF]/25 dark:border-[#00E5FF]/30 flex-shrink-0">
            <ShieldAlert className="w-3 h-3" />
            {badge}
          </span>
        )}
      </div>

      {value ? (
        <div className="relative mt-2">
          <img
            src={displayImg}
            alt={label}
            className="w-full h-36 object-cover rounded-xl border-2 border-[#1E6BFF]/60 dark:border-[#00E5FF]/60 bg-slate-100 dark:bg-black/20"
          />
          <button
            type="button"
            onClick={() => onClear(kind)}
            className="absolute top-2 right-2 bg-red-500 hover:bg-red-600 text-white rounded-full p-1.5 shadow-md z-20"
            title="Quitar foto"
          >
            <X className="w-4 h-4" />
          </button>
          <div className="grid grid-cols-2 gap-2 mt-2">
            <button
              type="button"
              disabled={loading}
              onClick={() => setCameraOpen(true)}
              className="h-9 rounded-xl bg-slate-100 dark:bg-white/5 hover:bg-slate-200 dark:hover:bg-white/10 border border-slate-200 dark:border-white/10 text-xs font-semibold text-slate-800 dark:text-white flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <Camera className="w-3.5 h-3.5 text-[#1E6BFF] dark:text-[#00E5FF]" />
              <span>Tomar otra</span>
            </button>
            <div
              className={`relative overflow-hidden h-9 rounded-xl bg-slate-100 dark:bg-white/5 hover:bg-slate-200 dark:hover:bg-white/10 border border-slate-200 dark:border-white/10 text-xs font-semibold text-slate-800 dark:text-white flex items-center justify-center gap-1.5 cursor-pointer ${
                loading ? 'opacity-50 pointer-events-none' : ''
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5 text-[#1E6BFF] dark:text-[#00E5FF]" />
              <span>Cambiar de galería</span>
              <input
                type="file"
                accept="image/*"
                onChange={handleGalleryInput}
                onClick={markPickerOpen}
                disabled={loading}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
              />
            </div>
          </div>
        </div>
      ) : (
        <div className="mt-2">
          {loading ? (
            <div className="w-full h-24 rounded-xl border-2 border-dashed border-[#1E6BFF]/40 dark:border-[#00E5FF]/40 flex flex-col items-center justify-center gap-1.5 bg-[#1E6BFF]/5 dark:bg-[#00E5FF]/5">
              <Loader2 className="w-6 h-6 animate-spin text-[#1E6BFF] dark:text-[#00E5FF]" />
              <span className="text-xs text-slate-600 dark:text-[#8B95A8]">
                Verificando documento con IA...
              </span>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => setCameraOpen(true)}
                className="h-24 rounded-xl border-2 border-dashed border-[#0284C7]/45 dark:border-[#00E5FF]/40 hover:border-[#0284C7] bg-sky-50/70 dark:bg-[#00E5FF]/5 hover:bg-sky-100/70 dark:hover:bg-[#00E5FF]/10 transition-all flex flex-col items-center justify-center gap-1.5 px-2 cursor-pointer active:scale-[0.98]"
              >
                <Camera className="w-6 h-6 text-[#0284C7] dark:text-[#00E5FF]" />
                <span className="text-xs font-bold text-slate-900 dark:text-white">Tomar foto</span>
                <span className="text-[10px] text-slate-500 dark:text-[#8B95A8]">Usar cámara</span>
              </button>

              <div className="relative overflow-hidden h-24 rounded-xl border-2 border-dashed border-[#1E6BFF]/40 hover:border-[#1E6BFF] bg-indigo-50/60 dark:bg-[#1E6BFF]/5 hover:bg-indigo-100/60 dark:hover:bg-[#1E6BFF]/10 transition-all flex flex-col items-center justify-center gap-1.5 px-2 cursor-pointer active:scale-[0.98]">
                <ImageIcon className="w-6 h-6 text-[#1E6BFF]" />
                <span className="text-xs font-bold text-slate-900 dark:text-white">
                  Buscar en galería
                </span>
                <span className="text-[10px] text-slate-500 dark:text-[#8B95A8]">
                  Subir archivo
                </span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleGalleryInput}
                  onClick={markPickerOpen}
                  disabled={loading}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                />
              </div>
            </div>
          )}
        </div>
      )}
      {error && (
        <p className="mt-2 p-2.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-500 text-xs font-semibold leading-snug">
          {error}
        </p>
      )}
    </div>
  );
}
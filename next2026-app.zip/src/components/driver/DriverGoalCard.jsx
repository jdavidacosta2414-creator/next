import React, { useState, useEffect } from 'react';
import { Target, Pencil, Check, X, Loader2 } from 'lucide-react';

const fmtCOP = (n) =>
  '$' + Number(n || 0).toLocaleString('es-CO', { maximumFractionDigits: 0 });

const PRESETS = [50000, 80000, 100000, 150000];

export default function DriverGoalCard({
  period,
  dailyGoal,
  goalAmount,
  netEarnings,
  onSaveDailyGoal,
}) {
  const [editing, setEditing] = useState(false);
  const [inputVal, setInputVal] = useState(String(dailyGoal || 80000));
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setInputVal(String(dailyGoal || 80000));
  }, [dailyGoal]);

  const goalPct = Math.min(100, Math.round((netEarnings / Math.max(goalAmount, 1)) * 100));
  const goalRemaining = Math.max(0, goalAmount - netEarnings);

  const goalLabel =
    period === 'dia'
      ? 'Tu meta diaria'
      : period === 'semana'
        ? 'Tu meta semanal (6 días)'
        : 'Tu meta mensual (25 días)';

  const handleSubmit = async (e) => {
    e.preventDefault();
    const clean = Math.max(10000, parseInt(String(inputVal).replace(/\D/g, ''), 10) || 80000);
    setSaving(true);
    try {
      await onSaveDailyGoal?.(clean);
      setEditing(false);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="bg-gradient-to-r from-[#EAF3FF] to-[#F0F7FF] dark:from-sky-950/60 dark:to-slate-900 rounded-2xl p-4 border border-sky-200/80 dark:border-sky-800/40 space-y-2.5">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <Target className="w-4 h-4 text-[#1E6BFF] dark:text-sky-400 flex-shrink-0" />
          <div className="min-w-0">
            <span className="text-xs font-extrabold text-[#062B60] dark:text-sky-200 block truncate">
              {goalLabel}
            </span>
            {period !== 'dia' && (
              <span className="text-[10px] text-muted-foreground block">
                Basada en tu meta diaria de {fmtCOP(dailyGoal)}
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2 flex-shrink-0">
          <span className="text-sm font-black text-[#062B60] dark:text-white">
            {fmtCOP(goalAmount)}
          </span>
          {!editing && (
            <button
              type="button"
              onClick={() => setEditing(true)}
              aria-label="Personalizar meta diaria"
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#1E6BFF]/15 hover:bg-[#1E6BFF]/25 text-[#062B60] dark:text-sky-200 text-[11px] font-bold transition-colors"
            >
              <Pencil className="w-3 h-3 text-[#1E6BFF] dark:text-sky-300" />
              Personalizar
            </button>
          )}
        </div>
      </div>

      {editing && (
        <form
          onSubmit={handleSubmit}
          className="bg-white dark:bg-card rounded-xl p-3 border border-sky-200 dark:border-border space-y-2.5"
        >
          <label className="block text-[11px] font-extrabold text-[#062B60] dark:text-sky-300">
            Define tu meta de ingresos diarios (COP)
          </label>

          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-bold text-muted-foreground">
              $
            </span>
            <input
              type="number"
              min={10000}
              step={5000}
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              placeholder="80000"
              className="w-full h-10 rounded-xl bg-slate-50 dark:bg-muted pl-7 pr-3 text-sm font-extrabold text-foreground border border-slate-200 dark:border-border outline-none focus:border-[#1E6BFF]"
            />
          </div>

          <div className="grid grid-cols-4 gap-1.5">
            {PRESETS.map((preset) => {
              const active = Number(inputVal) === preset;
              return (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setInputVal(String(preset))}
                  className={`h-8 rounded-lg text-[11px] font-extrabold border transition-colors ${
                    active
                      ? 'bg-[#1E6BFF] text-white border-[#1E6BFF]'
                      : 'bg-slate-50 dark:bg-muted text-foreground border-slate-200 dark:border-border hover:border-[#1E6BFF]/50'
                  }`}
                >
                  {fmtCOP(preset)}
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-2 pt-0.5">
            <button
              type="button"
              onClick={() => {
                setInputVal(String(dailyGoal || 80000));
                setEditing(false);
              }}
              disabled={saving}
              className="flex-1 h-9 rounded-xl bg-slate-100 dark:bg-muted text-foreground text-xs font-bold flex items-center justify-center gap-1"
            >
              <X className="w-3.5 h-3.5" /> Cancelar
            </button>
            <button
              type="submit"
              disabled={saving}
              className="flex-1 h-9 rounded-xl bg-gradient-to-r from-[#051F54] via-[#0B45B4] to-[#00B8FF] text-white text-xs font-bold flex items-center justify-center gap-1 shadow-xs"
            >
              {saving ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Check className="w-3.5 h-3.5" />
              )}
              Guardar meta
            </button>
          </div>
        </form>
      )}

      <div className="h-2.5 rounded-full bg-white dark:bg-slate-800 overflow-hidden border border-sky-200/60 dark:border-sky-800/40">
        <div
          className="h-full rounded-full bg-gradient-to-r from-[#062B60] via-[#1E6BFF] to-[#00B8FF] transition-all"
          style={{ width: `${goalPct}%` }}
        />
      </div>

      <div className="flex items-center justify-between text-[11px]">
        <span className="font-bold text-[#1E6BFF] dark:text-sky-300">
          {goalPct}% completado
        </span>
        <span className="text-muted-foreground font-medium">
          {goalRemaining > 0
            ? `Faltan ${fmtCOP(goalRemaining)} para tu meta`
            : '¡Meta alcanzada!'}
        </span>
      </div>
    </div>
  );
}
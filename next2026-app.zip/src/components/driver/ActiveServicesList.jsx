import React, { useState, useEffect } from 'react';
import { Navigation, Bike } from 'lucide-react';
import ClientAvatar from '@/components/shared/ClientAvatar';
import PassengerTrustBadge from '@/components/shared/PassengerTrustBadge';
import ServiceRouteStops from '@/components/shared/ServiceRouteStops';
import { fetchPassengerStatsMap } from '@/lib/passengerStats';
import { shortAddress, addressWithBarrio } from '@/lib/shortAddress';

const fmtCOP = (n) => 'COL$' + Number(n || 0).toLocaleString('es-CO');

const STATUS_BADGE = {
  asignado: { label: 'Asignado', cls: 'bg-[#00E5FF]/15 text-[#00E5FF]' },
  en_camino: { label: 'En camino', cls: 'bg-[#00E5FF]/15 text-[#00E5FF]' },
  recogida: { label: 'En recogida', cls: 'bg-[#F59E0B]/15 text-[#F59E0B]' },
};

function distance(lat1, lng1, lat2, lng2) {
  if (lat1 == null || lat2 == null) return null;
  const R = 6371, dLat = (lat2 - lat1) * Math.PI / 180, dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function shortAddr(addr) {
  if (!addr) return '—';
  return shortAddress(addr) || addr;
}

// Lista de servicios asignados al conductor (pestaña "En curso").
export default function ActiveServicesList({ activeServices, mobile, onOpenActive }) {
  const [passengerStats, setPassengerStats] = useState({});

  useEffect(() => {
    if (!activeServices || activeServices.length === 0) return;
    fetchPassengerStatsMap(activeServices)
      .then(setPassengerStats)
      .catch(() => {});
  }, [activeServices]);

  if (!activeServices || activeServices.length === 0) {
    return (
      <div className="text-center py-16 px-4">
        <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center mx-auto mb-3">
          <Bike className="w-8 h-8 text-muted-foreground/40" />
        </div>
        <p className="text-foreground font-medium mb-1">No tienes servicios en curso</p>
        <p className="text-sm text-muted-foreground">Los servicios que aceptes aparecerán aquí.</p>
      </div>
    );
  }

  const kmToFinish = (s) =>
    s.destination_lat != null
      ? distance(mobile?.current_lat, mobile?.current_lng, s.destination_lat, s.destination_lng)
      : null;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-[11px] font-bold text-muted-foreground tracking-wider">EN CURSO · {activeServices.length}</p>
        <span className="text-[11px] text-muted-foreground">Toca para gestionar</span>
      </div>
      {activeServices.map((s) => {
        const badge = STATUS_BADGE[s.status] || STATUS_BADGE.asignado;
        const km = kmToFinish(s);
        // En un domicilio de NEXT Negocios quien pide el servicio es el comercio, no su cliente:
        // la tarjeta muestra su nombre, su foto y las direcciones con el barrio que él escribió.
        const isNegocio = s.origin === 'negocios';
        const name = isNegocio ? s.business_name || 'Negocio aliado' : s.client_name;
        const photo = isNegocio ? s.business_logo : s.client_photo || passengerStats[s.id]?.photo;
        return (
          <div
            key={s.id}
            role="button"
            tabIndex={0}
            onClick={() => onOpenActive?.(s)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') onOpenActive?.(s);
            }}
            className="w-full bg-card rounded-2xl p-4 border border-border shadow-sm active:scale-[0.99] transition-transform grid grid-cols-[auto_minmax(0,1fr)_auto] gap-x-3 gap-y-2.5 items-start text-left cursor-pointer"
          >
            <ClientAvatar photo={photo} name={name} size="md" className="row-span-2 mt-0.5" />
            <div className="min-w-0">
              <div className="flex items-center gap-2 mb-1 flex-wrap">
                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${badge.cls}`}>
                  {badge.label}
                </span>
                {name && <span className="text-foreground text-xs font-bold truncate">{name}</span>}
              </div>
              {!isNegocio && <PassengerTrustBadge stats={passengerStats[s.id]} />}
            </div>
            <div className="text-right">
              <p className="text-foreground text-base font-extrabold">{fmtCOP(s.fare || 5000)}</p>
              {s.status !== 'recogida' && km != null && (
                <p className="text-[10px] text-muted-foreground flex items-center justify-end gap-0.5 mt-0.5">
                  <Navigation className="w-3 h-3" /> {km.toFixed(1)} km
                </p>
              )}
            </div>
            {/* Cada dirección va en su propia fila, alineada con su punto */}
            <div className="col-span-2 min-w-0">
              <ServiceRouteStops
                pickupAddress={isNegocio ? addressWithBarrio(s.pickup_address) : shortAddr(s.pickup_address)}
                destinationAddress={isNegocio ? addressWithBarrio(s.destination_address) : shortAddr(s.destination_address)}
                pickupBarrio={s.pickup_barrio}
                destinationBarrio={s.destination_barrio}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}
import React, { useState, useEffect } from 'react';
import {
  Mail,
  Phone,
  Star,
  LogOut,
  Loader2,
  CreditCard,
  Calendar,
  User as UserIcon,
  Camera,
  ShieldCheck,
  Award,
  Activity,
  Clock,
  ChevronRight,
} from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import ResolvedAvatar, { resolveStorageUrl, seedStorageUrlCache } from '@/components/shared/ResolvedAvatar';
import { uploadRegistrationPhoto } from '@/lib/image';
import DriverPerfilVehicleCard from '@/components/driver/DriverPerfilVehicleCard';
import CourierIdCard from '@/components/driver/CourierIdCard';
import { getDriverCategory } from '@/lib/serviceMatch';

const fmtRegDate = (d) => {
  if (!d) return '—';
  try {
    return new Date(d).toLocaleDateString('es-CO', {
      day: '2-digit',
      month: 'long',
      year: 'numeric',
      timeZone: 'America/Bogota',
    });
  } catch {
    return '—';
  }
};

export default function DriverPerfilView({
  mobile,
  user,
  tierInfo,
  totalTrips = 0,
  avgRating = 0,
  onMobileUpdate,
  onOpenNiveles,
  onOpenRendimiento,
  onOpenHistorial,
}) {
  const { checkUserAuth } = useAuth();
  const { toast } = useToast();

  const currentName = mobile?.name || user?.display_name || user?.full_name || '';
  const currentPhone = mobile?.phone || user?.phone || '';
  const currentCedula = mobile?.cedula || user?.cedula || '';
  const currentPhoto =
    mobile?.photo_url || user?.photo_url || '';
  const currentVehicleType = mobile?.vehicle_type || 'moto';
  const currentCarSubtype = mobile?.car_subtype || 'particular';
  const currentPlateType = mobile?.plate_type || 'amarilla';
  const currentBrand = mobile?.vehicle_brand || '';
  const currentModel = mobile?.vehicle_model || '';
  const currentColor =
    mobile?.vehicle_color ||
    (mobile?.vehicle_type === 'carro' && mobile?.car_subtype === 'taxi'
      ? 'Amarillo'
      : '');
  const currentPlate = (mobile?.plate || '').toUpperCase();

  const [photoUri, setPhotoUri] = useState(currentPhoto);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);

  useEffect(() => {
    setPhotoUri(mobile?.photo_url || user?.photo_url || '');
  }, [mobile, user]);

  const handlePhotoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (e.target) e.target.value = '';
    if (!file) return;
    const localBlobUrl = URL.createObjectURL(file);
    setPhotoUri(localBlobUrl);
    setUploadingPhoto(true);
    try {
      const { file_uri, previewUrl } = await uploadRegistrationPhoto(file, 1024, 0.78);
      seedStorageUrlCache(file_uri, previewUrl || localBlobUrl);
      resolveStorageUrl(file_uri).catch(() => {});
      setPhotoUri(file_uri);
      await base44.auth.updateMe({ photo_url: file_uri }).catch(() => {});
      if (mobile?.id) {
        const updated = await base44.entities.Mobile.update(mobile.id, {
          photo_url: file_uri,
        });
        onMobileUpdate?.(updated);
      }
      await checkUserAuth?.();
      toast({ description: 'Foto de perfil actualizada.' });
    } catch (err) {
      toast({
        title: 'No se pudo subir la foto',
        description: err?.message || 'Intenta nuevamente.',
        variant: 'destructive',
      });
    } finally {
      setUploadingPhoto(false);
    }
  };

  const displayName = currentName || 'Conductor NEXT';
  const emailAddr = mobile?.email || user?.email || '—';
  const regDate = fmtRegDate(mobile?.created_date || user?.created_date);
  const currentTier = tierInfo?.current || { name: 'Bronce', priorityLabel: 'Acceso estándar' };
  const ratingText = avgRating > 0 ? Number(avgRating).toFixed(1) : '5.0';

  return (
    <div className="px-4 pt-4 pb-28 space-y-4">
      {/* Tarjeta principal del conductor con colores de marca */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#041738] via-[#0B3C8C] to-[#0284C7] p-5 text-white shadow-[0_10px_28px_rgba(6,43,110,0.25)] border border-[#38BDF8]/30">
        <div className="pointer-events-none absolute -top-8 -right-8 w-28 h-16 bg-gradient-to-l from-[#00D4FF]/40 to-transparent -rotate-45 transform" />
        <div className="pointer-events-none absolute -bottom-8 -left-8 w-28 h-16 bg-gradient-to-r from-[#00D4FF]/30 to-transparent -rotate-45 transform" />

        <div className="relative z-10 flex items-center gap-4">
          <div className="relative flex-shrink-0">
            <ResolvedAvatar
              photo={photoUri || currentPhoto}
              name={displayName}
              className="w-20 h-20 rounded-full bg-[#09357A] border-2 border-[#00D4FF] shadow-[0_0_14px_rgba(0,212,255,0.65)] text-white font-extrabold text-2xl"
            />
            <div
              aria-label="Cambiar foto de perfil"
              data-photo-picker="true"
              className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-[#00B8FF] text-white flex items-center justify-center shadow-md cursor-pointer border-2 border-[#041738] overflow-hidden"
            >
              {uploadingPhoto ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Camera className="w-4 h-4" />
              )}
              <input
                type="file"
                accept="image/*"
                onChange={handlePhotoUpload}
                onClick={() => {
                  if (typeof window !== 'undefined') {
                    window.__nextFilePickerOpenUntil = Date.now() + 60000;
                  }
                }}
                disabled={uploadingPhoto}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
              />
            </div>
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <h2 className="text-white font-extrabold text-lg leading-tight truncate">
                {displayName}
              </h2>
            </div>

            <p className="text-sky-100 text-xs truncate mt-0.5">{emailAddr}</p>
            {currentPhone && (
              <p className="text-sky-200 text-xs truncate mt-0.5">{currentPhone}</p>
            )}

            <div className="flex items-center gap-2 mt-2.5 flex-wrap">
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-white/15 border border-white/20 text-xs font-extrabold text-white">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                {ratingText}
              </span>
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-[#00D4FF]/20 border border-[#00D4FF]/40 text-xs font-extrabold text-white">
                <Award className="w-3.5 h-3.5 text-[#38BDF8]" />
                Nivel {currentTier.name}
              </span>
              <span className="text-[11px] font-bold text-sky-100">
                {totalTrips} {totalTrips === 1 ? 'viaje' : 'viajes'}
              </span>
            </div>
            <p className="text-[10px] text-sky-200/90 mt-2">
              Toca el ícono de cámara para cambiar tu foto de perfil (debe verse claramente tu rostro).
            </p>
          </div>
        </div>
      </div>

      {mobile?.id && getDriverCategory(mobile) === 'mensajero' && <CourierIdCard mobileId={mobile.id} />}

      <DriverPerfilVehicleCard
        vehicleType={currentVehicleType}
        carSubtype={currentCarSubtype}
        plate={currentPlate}
        plateType={currentPlateType}
        brand={currentBrand}
        model={currentModel}
        color={currentColor}
        vehiclePhoto={mobile?.vehicle_photo}
        tarjetaPhoto={mobile?.tarjeta_photo}
        verificationPhoto={mobile?.verification_photo}
        soatPhoto={mobile?.soat_photo}
        tecnoPhoto={mobile?.tecno_photo}
        soatExpiry={mobile?.soat_expiry}
        tecnoExpiry={mobile?.tecno_expiry}
      />

      {/* Datos personales del conductor */}
      <div className="bg-white dark:bg-card rounded-2xl p-4 border border-sky-100 dark:border-border shadow-xs space-y-2.5">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-extrabold uppercase tracking-wider text-[#062B60] dark:text-sky-300">
            Datos personales en tu perfil
          </h3>
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full">
            <ShieldCheck className="w-3.5 h-3.5" /> Verificado
          </span>
        </div>

        <div className="divide-y divide-slate-100 dark:divide-border text-sm">
          <div className="py-2.5 flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#EAF3FF] dark:bg-sky-950/60 flex items-center justify-center flex-shrink-0">
              <UserIcon className="w-4 h-4 text-[#062B60] dark:text-sky-300" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[11px] text-muted-foreground">Nombre completo</p>
              <p className="font-bold text-foreground truncate">{displayName}</p>
            </div>
          </div>

          <div className="py-2.5 flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#EAF3FF] dark:bg-sky-950/60 flex items-center justify-center flex-shrink-0">
              <CreditCard className="w-4 h-4 text-[#062B60] dark:text-sky-300" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[11px] text-muted-foreground">Cédula / Documento</p>
              <p className="font-bold text-foreground truncate">
                {currentCedula || 'No registrado'}
              </p>
            </div>
          </div>

          <div className="py-2.5 flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#EAF3FF] dark:bg-sky-950/60 flex items-center justify-center flex-shrink-0">
              <Phone className="w-4 h-4 text-[#062B60] dark:text-sky-300" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[11px] text-muted-foreground">Teléfono celular</p>
              <p className="font-bold text-foreground truncate">
                {currentPhone || 'No registrado'}
              </p>
            </div>
          </div>

          <div className="py-2.5 flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#EAF3FF] dark:bg-sky-950/60 flex items-center justify-center flex-shrink-0">
              <Mail className="w-4 h-4 text-[#062B60] dark:text-sky-300" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[11px] text-muted-foreground">Correo electrónico</p>
              <p className="font-bold text-foreground truncate">{emailAddr}</p>
            </div>
          </div>

          <div className="py-2.5 flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#EAF3FF] dark:bg-sky-950/60 flex items-center justify-center flex-shrink-0">
              <Calendar className="w-4 h-4 text-[#062B60] dark:text-sky-300" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[11px] text-muted-foreground">Fecha de vinculación</p>
              <p className="font-bold text-foreground truncate capitalize">{regDate}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Accesos rápidos a Niveles e Historial */}
      <div className="bg-white dark:bg-card rounded-2xl border border-sky-100 dark:border-border shadow-xs divide-y divide-slate-100 dark:divide-border overflow-hidden">
        <button
          type="button"
          onClick={onOpenNiveles}
          className="w-full flex items-center gap-3 px-4 py-3.5 text-left hover:bg-slate-50 dark:hover:bg-muted/50 transition-colors"
        >
          <span className="w-9 h-9 rounded-full bg-[#EAF3FF] dark:bg-sky-950/60 flex items-center justify-center flex-shrink-0">
            <Award className="w-4 h-4 text-[#062B60] dark:text-sky-300" />
          </span>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-extrabold text-foreground">Mi Nivel y Beneficios</p>
            <p className="text-xs text-muted-foreground">
              Nivel {currentTier.name} · {currentTier.priorityLabel}
            </p>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        {onOpenRendimiento && (
          <button
            type="button"
            onClick={onOpenRendimiento}
            className="w-full flex items-center gap-3 px-4 py-3.5 text-left hover:bg-slate-50 dark:hover:bg-muted/50 transition-colors"
          >
            <span className="w-9 h-9 rounded-full bg-[#EAF3FF] dark:bg-sky-950/60 flex items-center justify-center flex-shrink-0">
              <Activity className="w-4 h-4 text-[#062B60] dark:text-sky-300" />
            </span>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-extrabold text-foreground">Rendimiento reciente</p>
              <p className="text-xs text-muted-foreground">
                Aceptación: {tierInfo?.acceptanceRate ?? 100}% · Cancelación: {tierInfo?.cancellationRate ?? 0}%
              </p>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>
        )}

        <button
          type="button"
          onClick={onOpenHistorial}
          className="w-full flex items-center gap-3 px-4 py-3.5 text-left hover:bg-slate-50 dark:hover:bg-muted/50 transition-colors"
        >
          <span className="w-9 h-9 rounded-full bg-[#EAF3FF] dark:bg-sky-950/60 flex items-center justify-center flex-shrink-0">
            <Clock className="w-4 h-4 text-[#062B60] dark:text-sky-300" />
          </span>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-extrabold text-foreground">Historial de viajes</p>
            <p className="text-xs text-muted-foreground">
              {totalTrips} {totalTrips === 1 ? 'viaje completado' : 'viajes completados'}
            </p>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>
      </div>

      {/* Cerrar sesión */}
      <button
        type="button"
        onClick={() => base44.auth.logout('/')}
        className="w-full h-11 rounded-2xl bg-rose-500/10 text-rose-600 dark:text-rose-400 font-bold text-sm flex items-center justify-center gap-2"
      >
        <LogOut className="w-4 h-4" /> Cerrar sesión
      </button>
    </div>
  );
}
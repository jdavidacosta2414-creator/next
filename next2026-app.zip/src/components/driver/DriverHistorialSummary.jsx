import React from 'react';
import { Clock, TrendingUp, Calendar, CheckCircle2 } from 'lucide-react';

const fmtCOP = (n) =>
  '$' + Number(n || 0).toLocaleString('es-CO', { maximumFractionDigits: 0 });

export default function DriverHistorialSummary({
  summary,
  period,
  onSelectPeriod,
  formattedSelectedMonth,
}) {
  const cards = [
    {
      id: 'hoy',
      title: 'Viajes hoy',
      count: summary.todayCount,
      amount: summary.todayAmount,
      Icon: Clock,
    },
    {
      id: 'semana',
      title: 'Esta semana',
      count: summary.weekCount,
      amount: summary.weekAmount,
      Icon: TrendingUp,
    },
    {
      id: 'mes',
      title: `Mes (${formattedSelectedMonth.split(' ')[0]})`,
      count: summary.monthCount,
      amount: summary.monthAmount,
      Icon: Calendar,
    },
    {
      id: 'todo',
      title: 'Total viajes',
      count: summary.totalCount,
      amount: summary.totalAmount,
      Icon: CheckCircle2,
    },
  ];

  return (
    <div className="grid grid-cols-2 gap-2.5">
      {cards.map(({ id, title, count, amount, Icon }) => {
        const active = period === id;
        return (
          <button
            key={id}
            type="button"
            onClick={() => onSelectPeriod(id)}
            className={`rounded-2xl p-3.5 text-left transition-all border shadow-xs ${
              active
                ? 'bg-gradient-to-br from-[#062356] via-[#0B3C8C] to-[#0284C7] text-white border-[#38BDF8]'
                : 'bg-white dark:bg-card text-[#0F172A] dark:text-foreground border-sky-100 dark:border-border'
            }`}
          >
            <div className="flex items-center justify-between gap-1">
              <span
                className={`text-[11px] font-bold uppercase tracking-wider truncate ${
                  active ? 'text-sky-200' : 'text-slate-500 dark:text-muted-foreground'
                }`}
              >
                {title}
              </span>
              <Icon
                className={`w-4 h-4 flex-shrink-0 ${
                  active ? 'text-[#38BDF8]' : 'text-[#1E6BFF]'
                }`}
              />
            </div>
            <p className="text-2xl font-black mt-1 leading-none">{count}</p>
            <p
              className={`text-xs font-bold mt-1 ${
                active ? 'text-sky-100' : 'text-[#1E6BFF] dark:text-sky-400'
              }`}
            >
              {fmtCOP(amount)}
            </p>
          </button>
        );
      })}
    </div>
  );
}
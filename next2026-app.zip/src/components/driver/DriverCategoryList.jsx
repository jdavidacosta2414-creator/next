import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from '@/components/ui/use-toast';
import { getDriverCategory } from '@/lib/serviceMatch';
import { DRIVER_CATEGORIES, openDriverCategory } from '@/lib/driverProfiles';
import DriverCategoryRow from '@/components/driver/DriverCategoryRow';

// Categorías (moto, carro y mensajería) de la cuenta del conductor: estado de cada registro,
// cambio de categoría y acceso para registrarse en otra.
export default function DriverCategoryList({ mobile }) {
  const navigate = useNavigate();
  const [profiles, setProfiles] = useState(null);
  const [switching, setSwitching] = useState('');

  useEffect(() => {
    base44.entities.Mobile.filter({ email: mobile.email }).then(setProfiles);
  }, [mobile.email]);

  if (!profiles) {
    return (
      <div className="flex justify-center py-4">
        <Loader2 className="w-5 h-5 animate-spin text-primary" />
      </div>
    );
  }

  const rows = DRIVER_CATEGORIES.map((category) => {
    const mine = profiles.filter((m) => getDriverCategory(m) === category);
    return { category, profile: mine.find((m) => m.approval_status !== 'rechazado') || mine[0] };
  });

  const switchTo = async (category) => {
    setSwitching(category);
    try {
      const busy = await base44.entities.Service.filter({
        mobile_id: mobile.id,
        status: { $in: ['asignado', 'en_camino', 'recogida'] },
      });
      if (busy.length > 0) {
        toast({ title: 'Tienes un servicio en curso', description: 'Termínalo antes de cambiar de categoría.' });
        return;
      }
      // El registro que se deja queda desconectado para que no le sigan llegando servicios de esa categoría.
      await base44.entities.Mobile.update(mobile.id, { status: 'offline' });
      openDriverCategory(category);
    } finally {
      setSwitching('');
    }
  };

  return (
    <div className="space-y-2">
      {rows.map(({ category, profile }) => (
        <DriverCategoryRow
          key={category}
          category={category}
          profile={profile}
          current={profile?.id === mobile.id}
          switching={switching === category}
          disabled={Boolean(switching)}
          onSwitch={() => switchTo(category)}
        />
      ))}
      {rows.some(({ profile }) => !profile || profile.approval_status === 'rechazado') && (
        <button
          type="button"
          onClick={() => navigate('/vinculate/conductor?categoria=nueva')}
          className="w-full h-11 rounded-full border border-primary text-primary font-bold text-sm flex items-center justify-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Registrarme en otra categoría
        </button>
      )}
    </div>
  );
}
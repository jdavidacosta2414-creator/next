import React from 'react';

// Contenedor del tab Inicio del conductor. La lista de servicios (children)
// siempre se monta para poder reportar cuántos hay; el estado de búsqueda
// (radar) lo maneja AvailableServices cuando no hay solicitudes.
export default function DriverHome({ children }) {
  return <div className="px-3.5 pt-3 pb-28">{children}</div>;
}
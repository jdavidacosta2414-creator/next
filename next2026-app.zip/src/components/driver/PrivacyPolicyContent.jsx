import React from 'react';

export default function PrivacyPolicyContent() {
  return (
    <div className="space-y-5 text-foreground pb-8">
      <section>
        <h2 className="font-bold text-base">Política de Privacidad y Protección de Datos Personales</h2>
        <p className="text-sm text-muted-foreground mt-1">Última actualización: Octubre de 2026</p>
        <p className="text-sm text-muted-foreground">Responsable: NEXT TECNOLOGÍA S.A.S. (En constitución)</p>
        <p className="text-sm text-muted-foreground">Domicilio: Valledupar, Cesar, Colombia</p>
        <p className="text-sm text-muted-foreground">Contacto de privacidad: soportenextapp@gmail.com</p>
      </section>

      <section>
        <h3 className="font-bold text-sm">1. Alcance y Cumplimiento Normativo</h3>
        <p className="text-sm leading-relaxed text-muted-foreground mt-1">
          En cumplimiento de la Ley Estatutaria 1581 de 2012, el Decreto Único Reglamentario 1074 de 2015 y las Políticas de Seguridad de Datos de Google Play, NEXT TECNOLOGÍA S.A.S. informa a sus usuarios (Pasajeros, Remitentes y Conductores/Colaboradores) cómo recopila, almacena, protege y trata sus datos personales dentro de la aplicación NEXT.
        </p>
      </section>

      <section>
        <h3 className="font-bold text-sm">2. Datos Personales que Recopilamos</h3>
        <ul className="text-sm leading-relaxed text-muted-foreground list-disc pl-5 mt-1 space-y-1.5">
          <li>
            <strong>Datos de cuenta e identificación:</strong> Nombre completo, número de teléfono celular, dirección de correo electrónico y foto de perfil.
          </li>
          <li>
            <strong>Documentos de verificación de conductores:</strong> Número de documento de identidad (cédula), fotografía del documento de identidad, tarjeta de propiedad, foto y datos del vehículo (marca, modelo y placa).
          </li>
          <li>
            <strong>Datos de ubicación (GPS):</strong> Ubicación geográfica precisa y aproximada cuando la aplicación está en uso para mostrar puntos de recogida y destino, calcular tarifas sugeridas, asignar el conductor más cercano y permitir el seguimiento del viaje o envío en tiempo real.
          </li>
          <li>
            <strong>Imágenes y archivos subidos por el usuario:</strong> Foto de perfil, fotos de documentos del conductor, comprobantes de transferencia para recarga del pase diario y fotografías de evidencia de recogida o entrega en servicios de mensajería.
          </li>
          <li>
            <strong>Historial operativo y billetera:</strong> Registro de viajes solicitados o realizados, calificaciones entre usuarios, saldo de puntos, recompensas y movimientos de recarga.
          </li>
        </ul>
      </section>

      <section>
        <h3 className="font-bold text-sm">3. Almacenamiento Privado y Seguridad de la Información</h3>
        <p className="text-sm leading-relaxed text-muted-foreground mt-1">
          Todas las fotografías sensibles (documento de identidad/cédula, tarjeta de propiedad, foto de perfil, comprobantes de pago y evidencias de entrega) se almacenan en repositorios privados con cifrado en tránsito (HTTPS/TLS) y control de acceso autenticado mediante enlaces firmados temporales. La foto de la cédula nunca se muestra a otros usuarios ni se utiliza como imagen pública de perfil.
        </p>
      </section>

      <section>
        <h3 className="font-bold text-sm">4. Finalidad del Tratamiento de los Datos</h3>
        <ul className="text-sm leading-relaxed text-muted-foreground list-disc pl-5 mt-1 space-y-1">
          <li>Conectar a pasajeros y remitentes con conductores disponibles en su zona de cobertura.</li>
          <li>Verificar la identidad y titularidad del vehículo de los conductores registrados en la plataforma.</li>
          <li>Consultar los antecedentes judiciales de los conductores que se registran, en las fuentes oficiales de la República de Colombia, con su autorización expresa. Si el conductor presenta antecedentes o anotaciones judiciales, su registro será rechazado, no se le permitirá el acceso a la aplicación y se le notificará que su registro no fue válido, pudiendo intentarlo más adelante.</li>
          <li>Validar recargas del pase operativo de 14 horas laborales y gestionar el programa de puntos y recompensas.</li>
          <li>Brindar soporte al usuario, gestión de objetos perdidos y atención de incidencias de seguridad.</li>
          <li>Cumplir obligaciones legales ante autoridades competentes de la República de Colombia.</li>
        </ul>
      </section>

      <section>
        <h3 className="font-bold text-sm">5. Compartición de Datos entre Usuarios</h3>
        <p className="text-sm leading-relaxed text-muted-foreground mt-1">
          NEXT no vende ni alquila datos personales a terceros. Durante un servicio activo, únicamente se comparte entre el pasajero y el conductor asignado la información estrictamente necesaria para el viaje o entrega: nombre, foto de perfil, calificación, datos del vehículo (marca, modelo y placa), ubicación del trayecto y canal de contacto o chat del servicio.
        </p>
      </section>

      <section>
        <h3 className="font-bold text-sm">6. Permisos del Dispositivo</h3>
        <ul className="text-sm leading-relaxed text-muted-foreground list-disc pl-5 mt-1 space-y-1">
          <li><strong>Ubicación (GPS):</strong> Requerida para ubicar el punto de recogida, mostrar conductores cercanos y seguir el recorrido del servicio.</li>
          <li><strong>Cámara y Galería:</strong> Solicitada únicamente cuando el usuario decide tomar o adjuntar su foto de perfil, documentos de registro, comprobante de recarga o evidencia fotográfica de mensajería.</li>
          <li><strong>Notificaciones:</strong> Utilizadas para informar cambios de estado del viaje, ofertas de conductores, mensajes del servicio y aprobaciones de puntos o recargas.</li>
        </ul>
      </section>

      <section>
        <h3 className="font-bold text-sm">7. Derechos del Titular (Habeas Data) y Eliminación de Cuenta</h3>
        <p className="text-sm leading-relaxed text-muted-foreground mt-1">
          Como titular de sus datos personales, usted tiene derecho a conocer, actualizar, rectificar y solicitar la supresión de su información y la baja definitiva de su cuenta en cualquier momento:
        </p>
        <ul className="text-sm leading-relaxed text-muted-foreground list-disc pl-5 mt-1 space-y-1">
          <li>
            <strong>Desde la aplicación:</strong> Ingresando a <em>Menú → Configuración → Eliminar mi cuenta y datos</em> y confirmando la solicitud de baja.
          </li>
          <li>
            <strong>Por correo electrónico:</strong> Enviando una solicitud a <strong>soportenextapp@gmail.com</strong> indicando su nombre y número de teléfono o correo registrado.
          </li>
        </ul>
        <p className="text-sm leading-relaxed text-muted-foreground mt-2">
          Las fotografías de evidencia de mensajería se eliminan automáticamente tras su período de vigencia operativa, y las solicitudes de eliminación de cuenta se procesan en un plazo máximo de 10 días hábiles conforme a la ley colombiana.
        </p>
      </section>
    </div>
  );
}
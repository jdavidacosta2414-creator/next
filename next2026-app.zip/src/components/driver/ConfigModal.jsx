import React from 'react';
import { useBackButton } from '@/hooks/useBackButton';

// Modal de configuración: lista de opciones (radio) o mensaje de confirmación.
// - options: muestra radios; al seleccionar aplica inmediatamente y muestra CANCELAR.
// - message: muestra un texto con botón ACEPTAR.
// Usa tokens de tema para responder a modo claro/oscuro.
export default function ConfigModal({ title, options, value, onSelect, message, onClose, actionLabel = 'ACEPTAR' }) {
  useBackButton(onClose, true);
  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-6">
      <div className="bg-card rounded-2xl w-full max-w-xs p-5 shadow-xl">
        <h2 className="text-foreground font-bold text-lg mb-4">{title}</h2>
        {message ? (
          <p className="text-foreground text-sm leading-relaxed mb-6">{message}</p>
        ) : (
          <div className="space-y-1 mb-6">
            {options.map((o) => (
              <button
                key={o.value}
                onClick={() => onSelect?.(o.value)}
                className="w-full flex items-center gap-3 py-2 text-left"
              >
                <span className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${value === o.value ? 'border-primary' : 'border-border'}`}>
                  {value === o.value && <span className="w-2.5 h-2.5 rounded-full bg-primary" />}
                </span>
                <span className="text-foreground text-sm font-medium">{o.label}</span>
              </button>
            ))}
          </div>
        )}
        <div className="flex justify-end">
          <button onClick={onClose} className="text-primary font-bold text-sm px-3 py-2">
            {message ? actionLabel : 'CANCELAR'}
          </button>
        </div>
      </div>
    </div>
  );
}
import React, { useState, useEffect } from 'react';
import { ChevronLeft, Shirt, CheckCircle2, Clock, ShieldCheck, Loader2, Sparkles } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import { Image } from '@/components/ui/image';
import { useBackButton } from '@/hooks/useBackButton';

const JACKET_IMAGE_URL = 'https://media.base44.com/images/public/6ab13aed46d61158e305a1ce/4d16428f7_1000060949.jpg';
const SIZES = ['S', 'M', 'L', 'XL', 'XXL'];

export default function DriverChaqueta({ mobile, user, onBack }) {
  const { toast } = useToast();
  const [selectedSize, setSelectedSize] = useState('L');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [requests, setRequests] = useState([]);
  const [zoomOpen, setZoomOpen] = useState(false);
  useBackButton(() => setZoomOpen(false), zoomOpen);

  const driverName = mobile?.name || user?.display_name || user?.full_name || 'Conductor';
  const driverPhone = mobile?.phone || user?.phone || '';
  const driverPlate = mobile?.plate || '';

  const loadRequests = async () => {
    if (!mobile?.id) {
      setLoading(false);
      return;
    }
    try {
      const list = await base44.entities.Incidence.filter(
        { related_mobile_id: mobile.id, category: 'conductor' },
        '-created_date',
        20
      );
      const items = Array.isArray(list) ? list : list?.items || [];
      setRequests(items.filter((i) => (i.title || '').toLowerCase().includes('chaqueta')));
    } catch {
      setRequests([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRequests();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mobile?.id]);

  const handleRequestJacket = async () => {
    if (!mobile?.id || submitting) return;
    setSubmitting(true);
    try {
      const title = `Solicitud de chaqueta (${selectedSize}) - ${driverName}`;
      const description = [
        `El conductor ${driverName}${driverPlate ? ` (Placa ${driverPlate})` : ''} solicita la chaqueta oficial NEXT.`,
        `• Talla seleccionada: ${selectedSize}`,
        `• Tiempo de entrega: 10 a 15 días hábiles`,
        driverPhone ? `• Teléfono: ${driverPhone}` : null,
        notes.trim() ? `• Nota del conductor: ${notes.trim()}` : null,
      ]
        .filter(Boolean)
        .join('\n');

      await base44.entities.Incidence.create({
        title,
        description,
        category: 'conductor',
        priority: 'media',
        status: 'abierta',
        related_mobile_id: mobile.id,
        related_mobile_name: driverName,
      });

      await base44.entities.DriverChat.create({
        mobile_id: mobile.id,
        mobile_name: driverName,
        sender_type: 'movil',
        message: `🧥 Hola Central, solicito la chaqueta oficial NEXT (Talla ${selectedSize}, entrega de 10 a 15 días hábiles).${notes.trim() ? ` Nota: ${notes.trim()}` : ''}`,
        read: false,
      }).catch(() => {});

      toast({
        title: '¡Solicitud enviada a Central!',
        description: 'Tu chaqueta llegará de 10 a 15 días hábiles.',
      });
      setNotes('');
      await loadRequests();
    } catch {
      toast({
        title: 'No se pudo enviar la solicitud',
        description: 'Intenta de nuevo en unos segundos.',
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  };

  const activeRequest = requests.find((r) => r.status === 'abierta' || r.status === 'en_proceso');

  return (
    <div className="fixed inset-0 z-[1800] bg-background flex flex-col max-w-md mx-auto w-full overflow-y-auto">
      {/* Cabecera */}
      <div className="flex items-center gap-3 px-4 pt-5 pb-3 border-b border-border bg-card flex-shrink-0 sticky top-0 z-10">
        <button
          type="button"
          onClick={onBack}
          aria-label="Volver"
          className="w-10 h-10 rounded-full hover:bg-muted flex items-center justify-center"
        >
          <ChevronLeft className="w-6 h-6 text-foreground" />
        </button>
        <div className="flex items-center gap-2">
          <Shirt className="w-5 h-5 text-primary" />
          <h1 className="text-foreground font-bold text-lg">Chaqueta oficial NEXT</h1>
        </div>
      </div>

      <div className="flex-1 px-4 py-4 pb-8 space-y-4">
        {/* Imagen oficial de la chaqueta */}
        <div className="bg-card rounded-2xl border border-border overflow-hidden shadow-sm">
          <button
            type="button"
            onClick={() => setZoomOpen(true)}
            className="w-full block relative bg-[#0B1528]"
          >
            <Image
              src={JACKET_IMAGE_URL}
              alt="Chaqueta oficial NEXT Conductores"
              fittingType="fit"
              loading="eager"
              className="w-full h-60 object-contain"
            />
            <span className="absolute bottom-2.5 right-2.5 px-2.5 py-1 rounded-full bg-black/70 text-white text-[11px] font-semibold">
              Toca para ampliar
            </span>
          </button>

          <div className="p-4 space-y-3">
            <div>
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-primary/10 text-primary text-[11px] font-bold mb-1">
                <Sparkles className="w-3 h-3" /> Indumentaria oficial conductores
              </span>
              <h2 className="text-foreground font-extrabold text-lg leading-tight">
                Chaqueta NEXT Transporte y Mensajería
              </h2>
            </div>

            <div className="flex items-center gap-2.5 bg-amber-500/10 border border-amber-500/25 rounded-xl px-3.5 py-2.5">
              <Clock className="w-5 h-5 text-amber-500 flex-shrink-0" />
              <p className="text-xs text-foreground font-medium leading-snug">
                Tiempo estimado de entrega: <span className="font-extrabold">de 10 a 15 días hábiles</span> una vez realizada tu solicitud.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1 text-xs text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-primary flex-shrink-0" />
                <span>Cuello alto con cremallera</span>
              </div>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-primary flex-shrink-0" />
                <span>Logo bordado HD</span>
              </div>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-primary flex-shrink-0" />
                <span>Bolsillos con cierre seguro</span>
              </div>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-primary flex-shrink-0" />
                <span>Tela premium transpirable</span>
              </div>
            </div>
          </div>
        </div>

        {/* Estado de solicitud activa si existe */}
        {loading ? (
          <div className="flex justify-center py-4">
            <Loader2 className="w-6 h-6 animate-spin text-primary" />
          </div>
        ) : activeRequest ? (
          <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-2xl p-4 space-y-1.5">
            <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-bold text-sm">
              <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
              <span>Solicitud enviada a la Central</span>
            </div>
            <p className="text-xs text-foreground leading-relaxed whitespace-pre-line">
              {activeRequest.description}
            </p>
            <p className="text-[11px] text-muted-foreground pt-1">
              La Central ya recibió tu notificación. En un plazo de 10 a 15 días hábiles te llegará tu chaqueta.
            </p>
          </div>
        ) : null}

        {/* Formulario de solicitud */}
        <div className="bg-card rounded-2xl border border-border p-4 shadow-sm space-y-4">
          <div>
            <label className="text-xs font-bold text-foreground uppercase tracking-wider block mb-2">
              Selecciona tu talla
            </label>
            <div className="grid grid-cols-5 gap-2">
              {SIZES.map((sz) => (
                <button
                  key={sz}
                  type="button"
                  onClick={() => setSelectedSize(sz)}
                  className={`h-11 rounded-xl font-bold text-sm border transition-all ${
                    selectedSize === sz
                      ? 'bg-primary text-primary-foreground border-primary shadow-sm'
                      : 'bg-muted/60 text-foreground border-border hover:bg-muted'
                  }`}
                >
                  {sz}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-muted-foreground block mb-1.5">
              Observaciones adicionales (opcional)
            </label>
            <input
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Ej. Prefiero recogerla en la oficina central"
              className="w-full h-11 rounded-xl bg-muted/60 border border-border px-3.5 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary"
            />
          </div>

          <div className="bg-muted/50 rounded-xl p-3 flex items-center justify-between text-xs">
            <div>
              <p className="font-bold text-foreground">Resumen del pedido</p>
              <p className="text-muted-foreground">Chaqueta NEXT · Talla {selectedSize} · Entrega 10-15 días hábiles</p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleRequestJacket}
            disabled={submitting}
            className="w-full h-12 rounded-2xl bg-primary text-primary-foreground font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-primary/25 disabled:opacity-60"
          >
            {submitting ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Enviando solicitud...
              </>
            ) : (
              <>
                <Shirt className="w-5 h-5" />
                Solicitar chaqueta
              </>
            )}
          </button>
        </div>
      </div>

      {/* Visor a pantalla completa */}
      {zoomOpen && (
        <div
          onClick={() => setZoomOpen(false)}
          className="fixed inset-0 z-[2200] bg-black/90 flex items-center justify-center p-4"
        >
          <Image
            src={JACKET_IMAGE_URL}
            alt="Chaqueta oficial NEXT"
            fittingType="fit"
            className="max-w-full max-h-[88vh] object-contain rounded-xl"
          />
        </div>
      )}
    </div>
  );
}
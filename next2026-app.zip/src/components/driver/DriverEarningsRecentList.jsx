import React from 'react';
import {
  Clock,
  Award,
  ChevronRight,
  MapPin,
  Navigation,
} from 'lucide-react';
import { shortAddress } from '@/lib/shortAddress';
import { fmtBogotaShortDateTime } from '@/lib/dateBogota';

const fmtCOP = (n) =>
  '$' + Number(n || 0).toLocaleString('es-CO', { maximumFractionDigits: 0 });

const PAYMENT_LABEL = {
  efectivo: 'Efectivo',
  transferencia: 'Transferencia',
  nequi: 'Nequi',
  daviplata: 'DaviPlata',
  bancolombia: 'Bancolombia',
  paga_con_llave: 'Llave',
  redimido_puntos: 'Puntos NEXT',
};

export default function DriverEarningsRecentList({
  services,
  onOpenHistorial,
  onOpenPriority,
}) {
  const recent = services.slice(0, 5);

  return (
    <div className="space-y-3.5">
      {/* Últimos viajes del periodo */}
      <div className="bg-white dark:bg-card rounded-2xl p-4 border border-sky-100 dark:border-border shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-extrabold uppercase tracking-wider text-[#062B60] dark:text-sky-300">
            Viajes realizados en este periodo ({services.length})
          </h3>
          {services.length > 0 && (
            <button
              type="button"
              onClick={onOpenHistorial}
              className="text-[11px] font-bold text-[#1E6BFF] dark:text-sky-400 hover:underline"
            >
              Ver todos
            </button>
          )}
        </div>

        {recent.length === 0 ? (
          <div className="text-center py-6 px-3 rounded-xl bg-slate-50 dark:bg-muted/30 border border-dashed border-slate-200 dark:border-border">
            <p className="text-xs font-bold text-foreground">
              Sin viajes finalizados en este periodo
            </p>
            <p className="text-[11px] text-muted-foreground mt-0.5">
              Conéctate para recibir solicitudes y ver aquí tus ganancias al instante.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-border">
            {recent.map((s) => {
              const amount = Number(s.collected_amount || s.fare || 0);
              const dateStr = s.created_date
                ? fmtBogotaShortDateTime(s.updated_date || s.created_date)
                : '';
              return (
                <div key={s.id} className="py-2.5 flex items-center justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-foreground truncate">
                      <MapPin className="w-3.5 h-3.5 text-[#1E6BFF] flex-shrink-0" />
                      <span className="truncate">{shortAddress(s.pickup_address)}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground truncate mt-0.5">
                      <Navigation className="w-3 h-3 text-emerald-500 flex-shrink-0" />
                      <span className="truncate">{shortAddress(s.destination_address)}</span>
                    </div>
                    <p className="text-[10px] text-muted-foreground mt-0.5">
                      {dateStr} · {PAYMENT_LABEL[s.payment_method] || 'Efectivo'}
                    </p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-sm font-black text-[#062B60] dark:text-sky-300">
                      {fmtCOP(amount)}
                    </p>
                    <span className="inline-block text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                      Pagado
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Accesos directos a Historial completo y Niveles */}
      <div className="bg-white dark:bg-card rounded-2xl border border-sky-100 dark:border-border shadow-xs divide-y divide-slate-100 dark:divide-border overflow-hidden">
        <button
          type="button"
          onClick={onOpenHistorial}
          className="w-full flex items-center gap-3 px-4 py-3.5 text-left hover:bg-slate-50 dark:hover:bg-muted/50 transition-colors"
        >
          <span className="w-9 h-9 rounded-full bg-[#EAF3FF] dark:bg-sky-950/60 flex items-center justify-center flex-shrink-0">
            <Clock className="w-4 h-4 text-[#062B60] dark:text-sky-300" />
          </span>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-extrabold text-foreground">
              Historial detallado de viajes
            </p>
            <p className="text-xs text-muted-foreground">
              Filtra todos tus servicios por fecha y revisa cada recibo
            </p>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        <button
          type="button"
          onClick={onOpenPriority}
          className="w-full flex items-center gap-3 px-4 py-3.5 text-left hover:bg-slate-50 dark:hover:bg-muted/50 transition-colors"
        >
          <span className="w-9 h-9 rounded-full bg-[#EAF3FF] dark:bg-sky-950/60 flex items-center justify-center flex-shrink-0">
            <Award className="w-4 h-4 text-[#062B60] dark:text-sky-300" />
          </span>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-extrabold text-foreground">Niveles y logros</p>
            <p className="text-xs text-muted-foreground">
              Consulta tu progreso y prioridad para recibir más viajes
            </p>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>
      </div>
    </div>
  );
}
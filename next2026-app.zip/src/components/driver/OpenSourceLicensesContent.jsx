import React from 'react';

const LIBRARIES = [
  {
    name: 'React & React DOM',
    license: 'MIT License',
    copyright: 'Copyright (c) Meta Platforms, Inc. and affiliates.',
  },
  {
    name: 'React Router',
    license: 'MIT License',
    copyright: 'Copyright (c) Remix Software Inc.',
  },
  {
    name: 'Mapbox GL JS & OpenStreetMap',
    license: 'BSD-3-Clause / ODbL',
    copyright: '© Mapbox · © Colaboradores de OpenStreetMap.',
  },
  {
    name: 'Tailwind CSS',
    license: 'MIT License',
    copyright: 'Copyright (c) Tailwind Labs, Inc.',
  },
  {
    name: 'Radix UI Primitives',
    license: 'MIT License',
    copyright: 'Copyright (c) WorkOS.',
  },
  {
    name: 'Lucide Icons',
    license: 'ISC License',
    copyright: 'Copyright (c) Cole Bemis & Lucide Contributors.',
  },
  {
    name: 'TanStack React Query',
    license: 'MIT License',
    copyright: 'Copyright (c) Tanner Linsley.',
  },
  {
    name: 'Framer Motion',
    license: 'MIT License',
    copyright: 'Copyright (c) Framer B.V.',
  },
  {
    name: 'date-fns & Moment.js',
    license: 'MIT License',
    copyright: 'Copyright (c) Sasha Koss & JS Foundation.',
  },
  {
    name: 'Recharts',
    license: 'MIT License',
    copyright: 'Copyright (c) Recharts Group.',
  },
];

export default function OpenSourceLicensesContent() {
  return (
    <div className="space-y-4 text-foreground pb-8">
      <section className="space-y-1.5">
        <h2 className="font-bold text-base">Licencias de Software y Código Abierto</h2>
        <p className="text-sm leading-relaxed text-muted-foreground">
          Esta sección reúne los créditos y avisos legales de las librerías tecnológicas y cartográficas de código abierto que permiten el funcionamiento de la aplicación NEXT, en cumplimiento de las normas de propiedad intelectual y de Google Play.
        </p>
      </section>

      <div className="space-y-2.5">
        {LIBRARIES.map((lib) => (
          <div
            key={lib.name}
            className="rounded-xl bg-card border border-border p-3.5 space-y-1"
          >
            <div className="flex items-center justify-between gap-2">
              <p className="font-semibold text-sm text-foreground">{lib.name}</p>
              <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
                {lib.license}
              </span>
            </div>
            <p className="text-xs text-muted-foreground">{lib.copyright}</p>
          </div>
        ))}
      </div>

      <section className="rounded-xl bg-card border border-border p-3.5 space-y-2">
        <h3 className="font-bold text-xs uppercase tracking-wide text-muted-foreground">
          Texto estándar de Licencia MIT / ISC
        </h3>
        <p className="text-xs leading-relaxed text-muted-foreground">
          Se concede permiso, de forma gratuita, a cualquier persona que obtenga una copia de este software y de los archivos de documentación asociados, para utilizar el Software sin restricción, incluyendo sin limitación los derechos de usar, copiar, modificar, fusionar, publicar, distribuir, sublicenciar y/o vender copias del Software, sujeto a que el aviso de copyright anterior y este aviso de permiso se incluyan en todas las copias.
        </p>
        <p className="text-xs leading-relaxed text-muted-foreground">
          EL SOFTWARE SE PROPORCIONA &quot;TAL CUAL&quot;, SIN GARANTÍA DE NINGÚN TIPO, EXPRESA O IMPLÍCITA, INCLUYENDO PERO NO LIMITADO A GARANTÍAS DE COMERCIABILIDAD, IDONEIDAD PARA UN PROPÓSITO PARTICULAR E INCUMPLIMIENTO.
        </p>
      </section>
    </div>
  );
}
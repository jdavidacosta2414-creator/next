import React from 'react';

// Barra de pestañas para alternar entre servicios Disponibles y En curso.
export default function DriverServiceTabs({ active, onChange, disponiblesCount, enCursoCount }) {
  const tabs = [
    { id: 'disponibles', label: 'Disponibles', count: disponiblesCount },
    { id: 'en_curso', label: 'En curso', count: enCursoCount },
  ];
  return (
    <div className="sticky top-0 z-10 bg-background -mx-3.5 px-3.5 pt-1 pb-2.5 mb-1">
      <div className="flex bg-muted rounded-2xl p-1">
        {tabs.map((t) => {
          const isActive = active === t.id;
          return (
            <button
              key={t.id}
              onClick={() => onChange(t.id)}
              className={`flex-1 h-11 rounded-xl flex items-center justify-center gap-2 text-sm font-bold transition-all ${
                isActive ? 'bg-card text-primary shadow-sm' : 'text-muted-foreground'
              }`}
            >
              {t.label}
              <span
                className={`inline-flex items-center justify-center min-w-[1.4rem] h-5 px-1.5 rounded-full text-xs font-extrabold tabular-nums ${
                  isActive ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'
                }`}
              >
                {t.count}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
import React, { useState, useEffect, useMemo } from 'react';
import { Loader2, Navigation } from 'lucide-react';
import { useMapboxToken } from '@/hooks/useMapboxToken';
import { fetchRoute } from '@/lib/mapRoute';
import { DEFAULT_CITY } from '@/lib/appCity';
import MapboxMap, { MapboxMarker, MapboxRoute, MapboxFitBounds } from '@/components/shared/MapboxMap';
import { stopPinEl } from '@/lib/mapboxMarkers';
import MapTileError from '@/components/shared/MapTileError';
import { shortAddress } from '@/lib/shortAddress';
import { useBackButton } from '@/hooks/useBackButton';

const pickupEl = () => {
  const el = document.createElement('div');
  el.style.cssText =
    'width:12px;height:12px;border-radius:9999px;background:#ffffff;border:3px solid #121212;box-shadow:0 0 6px rgba(0,0,0,0.6);';
  return el;
};

const destEl = () => {
  const el = document.createElement('div');
  el.style.cssText =
    'width:12px;height:12px;border-radius:2px;background:#ffffff;border:3px solid #121212;box-shadow:0 0 6px rgba(0,0,0,0.6);';
  return el;
};

// Mapa del detalle de un servicio: marca A, paradas y B; al tocar cualquier parte del mapa alterna vista completa.
export default function ServicioMapa({ pickup, destination, stops = [], onRouteInfo }) {
  const token = useMapboxToken();
  const [route, setRoute] = useState(null);
  const [tileError, setTileError] = useState(false);
  const [expanded, setExpanded] = useState(false);

  useBackButton(() => setExpanded(false), expanded);

  const pickupPos = pickup ? [pickup.lat, pickup.lng] : null;
  const destPos = destination ? [destination.lat, destination.lng] : null;
  const stopWaypoints = useMemo(
    () =>
      (stops || [])
        .filter((s) => s?.lat != null && s?.lng != null)
        .map((s) => [Number(s.lat), Number(s.lng)]),
    [stops]
  );
  const waypointsKey = stopWaypoints.map(([lat, lng]) => `${lat.toFixed(4)},${lng.toFixed(4)}`).join('|');

  useEffect(() => {
    if (!token || !pickupPos || !destPos) {
      setRoute(null);
      onRouteInfo?.(null);
      return;
    }
    let alive = true;
    fetchRoute(token, pickupPos, destPos, stopWaypoints).then((r) => {
      if (!alive) return;
      setRoute(r);
      onRouteInfo?.(
        r && r.distanceKm != null
          ? { distanceKm: r.distanceKm, durationMin: r.durationMin, durationSeconds: r.durationSeconds }
          : null
      );
    });
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token, pickupPos?.[0], pickupPos?.[1], destPos?.[0], destPos?.[1], waypointsKey]);

  const positions = useMemo(() => {
    const pts = [];
    if (pickupPos) pts.push(pickupPos);
    stopWaypoints.forEach((wp) => pts.push(wp));
    if (destPos) pts.push(destPos);
    return pts;
  }, [pickupPos, destPos, stopWaypoints]);

  const center = pickupPos || [DEFAULT_CITY.lat, DEFAULT_CITY.lng];

  if (!token) {
    return (
      <div className="h-44 bg-muted flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-[#1E6BFF]" />
      </div>
    );
  }

  return (
    <div
      className={
        expanded
          ? 'fixed inset-0 z-[2500] max-w-md mx-auto w-full h-[100dvh] bg-[#121212]'
          : 'h-44 w-full overflow-hidden relative cursor-pointer'
      }
    >
      <MapboxMap
        center={center}
        zoom={14}
        pitch={0}
        dark={true}
        className="h-full w-full"
        onMapClick={() => setExpanded((v) => !v)}
        onTileError={() => setTileError(true)}
      >
        {pickupPos && <MapboxMarker lat={pickupPos[0]} lng={pickupPos[1]} el={pickupEl} interactive={false} />}
        {(stops || []).map((st, idx) =>
          st?.lat != null && st?.lng != null ? (
            <MapboxMarker
              key={`stop-${idx}`}
              lat={st.lat}
              lng={st.lng}
              el={() => stopPinEl(idx + 1, shortAddress(st.address) || st.address, false)}
              anchor="bottom"
              interactive={false}
            />
          ) : null
        )}
        {destPos && <MapboxMarker lat={destPos[0]} lng={destPos[1]} el={destEl} interactive={false} />}
        {route?.coords && <MapboxRoute coords={route.coords} color="#FFFFFF" width={3.5} opacity={0.95} />}
        <MapboxFitBounds
          positions={positions}
          padding={expanded ? 60 : 36}
          singleZoom={15}
          fitKey={expanded ? 'expanded' : 'compact'}
        />
      </MapboxMap>
      {tileError && <MapTileError />}
      {route?.distanceKm != null && (
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 z-[1000] bg-card shadow-lg rounded-full px-3 py-1.5 flex items-center gap-1.5 pointer-events-none">
          <Navigation className="w-3.5 h-3.5 text-[#1E6BFF]" />
          <span className="text-xs font-bold text-foreground">{route.durationMin != null ? `${route.durationMin} min · ` : ''}{route.distanceKm.toFixed(1)} km</span>
        </div>
      )}
    </div>
  );
}
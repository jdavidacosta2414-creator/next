import React, { useState } from 'react';
import {
  Car,
  Wallet,
  Gift,
  Clock,
  Bell,
  Share2,
  ShieldCheck,
  Settings,
  HelpCircle,
  Headphones,
  ChevronRight,
  Bike,
  Loader2,
  LogOut,
  Moon,
  Sun,
  Star,
} from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import { useTheme } from '@/lib/ThemeContext';
import { setExplicitUserMode } from '@/lib/roles';
import ResolvedAvatar from '@/components/shared/ResolvedAvatar';

// Drawer lateral del pasajero con diseño idéntico a la referencia visual.
export default function PasajeroDrawer({
  user,
  mobileProfile,
  onClose,
  onBilletera,
  onHistorial,
  onValoraciones,
  onPuntos,
  onNotificaciones,
  onPerfil,
  onCompartir,
  onSeguridad,
  onConfiguracion,
  onAyuda,
  onSoporte,
}) {
  const { toast } = useToast();
  const { theme, toggleTheme } = useTheme();
  const [checking, setChecking] = useState(false);

  const shareApp = async () => {
    if (onCompartir) {
      onClose?.();
      onCompartir();
      return;
    }
    try {
      if (navigator.share) {
        await navigator.share({
          title: 'NEXT',
          text: 'Transporte y mensajería',
          url: window.location.href,
        });
      } else {
        await navigator.clipboard.writeText(window.location.href);
        toast({ title: 'Enlace copiado' });
      }
    } catch {}
  };

  const switchToDriver = async () => {
    setChecking(true);
    try {
      let hasProfile = false;
      if (user?.email) {
        try {
          const existing = await base44.entities.Mobile.filter({ email: user.email });
          hasProfile = existing.length > 0;
        } catch {}
      }
      if (hasProfile) {
        setExplicitUserMode('conductor');
      }
      onClose?.();
      window.location.replace(hasProfile ? '/movil' : '/vinculate/conductor');
    } finally {
      setChecking(false);
    }
  };

  const items = [
    { icon: Wallet, label: 'Billetera', action: () => { onClose?.(); onBilletera?.(); } },
    { icon: Gift, label: 'NEXT CLUB', action: () => { onClose?.(); onPuntos?.(); } },
    { icon: Clock, label: 'Historial de viajes', action: () => { onClose?.(); onHistorial?.(); } },
    { icon: Star, label: 'Valoración y comentario', action: () => { onClose?.(); onValoraciones?.(); } },
    { icon: Bell, label: 'Notificaciones', action: () => { onClose?.(); onNotificaciones?.(); } },
    { icon: Share2, label: 'Compartir app', action: shareApp },
    { icon: ShieldCheck, label: 'Seguridad', action: () => { onClose?.(); onSeguridad?.(); } },
    { icon: Settings, label: 'Configuración', action: () => { onClose?.(); onConfiguracion?.(); } },
    { icon: HelpCircle, label: 'Ayuda', action: () => { onClose?.(); onAyuda?.(); } },
    { icon: Headphones, label: 'Soporte', action: () => { onClose?.(); onSoporte?.(); } },
  ];

  const emailPrefix = user?.email ? user.email.split('@')[0] : '';
  const displayName = user?.display_name || mobileProfile?.name || user?.full_name || emailPrefix || 'Invitado';
  const profilePhoto = user?.photo_url || mobileProfile?.photo_url || '';

  return (
    <div className="fixed inset-0 z-[2100] flex max-w-md mx-auto w-full">
      <div
        className="absolute inset-0 bg-black/45 backdrop-blur-[1px]"
        onClick={onClose}
      />

      <div className="relative w-[82%] max-w-[320px] h-full bg-white dark:bg-card shadow-2xl flex flex-col animate-in slide-in-from-left overflow-hidden">
        {/* Cabecera azul con detalles diagonales y curva inferior */}
        <div className="relative flex-shrink-0">
          <button
            type="button"
            onClick={() => {
              onClose?.();
              onPerfil?.();
            }}
            className="relative w-full overflow-hidden bg-gradient-to-r from-[#041738] via-[#072B66] to-[#0B439C] pt-6 pb-7 px-4 text-left"
          >
            {/* Acentos diagonales decorativos estilo banner */}
            <div className="pointer-events-none absolute -top-6 -left-6 w-24 h-16 bg-gradient-to-r from-[#00D4FF]/60 to-[#1E6BFF]/10 -rotate-45 transform" />
            <div className="pointer-events-none absolute -top-3 left-6 w-16 h-2 bg-[#00E5FF]/50 -rotate-45 transform" />
            <div className="pointer-events-none absolute -bottom-6 -right-6 w-28 h-16 bg-gradient-to-l from-[#00D4FF]/55 to-[#1E6BFF]/20 -rotate-45 transform" />
            <div className="pointer-events-none absolute bottom-2 right-12 w-16 h-2 bg-[#00E5FF]/50 -rotate-45 transform" />

            <div className="relative z-10 flex items-center gap-3.5">
              {/* Avatar con aro azul neón */}
              <ResolvedAvatar
                photo={profilePhoto}
                name={displayName}
                className="w-[54px] h-[54px] rounded-full bg-[#09357A] border-2 border-[#00D4FF] shadow-[0_0_12px_rgba(0,212,255,0.75)] text-white font-extrabold text-xl"
              />

              <div className="flex-1 min-w-0">
                <p className="text-white font-bold text-[17px] leading-snug truncate">
                  {displayName}
                </p>
                <p className="text-white/85 text-[11.5px] truncate mt-0.5">
                  {user?.email || ''}
                </p>
              </div>

              <ChevronRight className="w-5 h-5 text-white/90 flex-shrink-0" />
            </div>

            {/* Curva blanca en la base del encabezado */}
            <svg
              viewBox="0 0 320 22"
              preserveAspectRatio="none"
              className="absolute bottom-0 left-0 w-full h-[18px] pointer-events-none"
            >
              <path
                d="M0,4 Q160,24 320,4 L320,22 L0,22 Z"
                className="fill-white dark:fill-card"
              />
            </svg>
          </button>
        </div>

        {/* Lista de opciones */}
        <div className="flex-1 overflow-y-auto no-scrollbar px-4 pt-0.5 pb-1.5 space-y-0.5">
          {items.map((it) => {
            const Icon = it.icon;
            return (
              <button
                key={it.label}
                type="button"
                onClick={it.action}
                className="w-full flex items-center gap-3 py-1.5 px-1 rounded-xl hover:bg-slate-50 dark:hover:bg-muted/60 active:scale-[0.99] transition-all text-left"
              >
                <span className="w-8 h-8 rounded-full bg-[#EAF3FF] dark:bg-sky-950/60 flex items-center justify-center flex-shrink-0">
                  <Icon
                    className="w-[17px] h-[17px] text-[#062B60] dark:text-sky-300 fill-[#38BDF8]/35"
                    strokeWidth={2}
                  />
                </span>
                <span className="flex-1 text-[13px] font-semibold text-[#0F172A] dark:text-foreground truncate">
                  {it.label}
                </span>
                <ChevronRight className="w-4 h-4 text-slate-400 flex-shrink-0" />
              </button>
            );
          })}
        </div>

        {/* Pie con botón "Modo conductor" y "Cerrar sesión" */}
        <div className="px-4 pt-2 pb-3 flex-shrink-0 bg-white dark:bg-card">
          <button
            type="button"
            onClick={switchToDriver}
            disabled={checking}
            className="w-full h-12 rounded-full bg-gradient-to-r from-[#051F54] via-[#0B45B4] to-[#00B8FF] text-white font-bold text-[15px] px-5 flex items-center justify-between shadow-[0_4px_16px_rgba(0,184,255,0.45)] border border-[#38BDF8]/50 disabled:opacity-60 active:scale-[0.99] transition-transform"
          >
            <span className="w-5" />
            <span className="flex items-center gap-2.5">
              {checking ? (
                <Loader2 className="w-5 h-5 animate-spin text-white" />
              ) : (
                <Bike className="w-5 h-5 text-white" />
              )}
              <span>Modo conductor</span>
            </span>
            <ChevronRight className="w-5 h-5 text-white" />
          </button>

          <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-border flex items-center justify-between gap-2">
            <button
              type="button"
              onClick={toggleTheme}
              className="flex items-center gap-1.5 py-1 px-2.5 rounded-lg bg-muted text-foreground text-xs font-bold hover:opacity-90 transition-opacity"
            >
              {theme === 'dark' ? (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-400" />
                  <span>Modo claro</span>
                </>
              ) : (
                <>
                  <Moon className="w-3.5 h-3.5 text-primary" />
                  <span>Modo oscuro</span>
                </>
              )}
            </button>
            <button
              type="button"
              onClick={() => base44.auth.logout('/')}
              className="flex items-center justify-center gap-1.5 py-1 px-2 text-slate-500 dark:text-muted-foreground text-xs font-semibold hover:text-foreground"
            >
              <LogOut className="w-4 h-4" />
              <span>Cerrar sesión</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
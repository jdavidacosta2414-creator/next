import React from 'react';
import {
  Menu,
  Search,
  Crosshair,
  LocateFixed,
  Pencil,
  ChevronLeft,
  Crown,
  ArrowRight,
  AlertTriangle,
} from 'lucide-react';
import ServiceSelector from '@/components/pasajero/ServiceSelector';
import PromoBanners from '@/components/pasajero/PromoBanners';
import { shortAddress } from '@/lib/shortAddress';

export function PasajeroTopHeader({ hidden, onOpenDrawer }) {
  return (
    <div
      className={`relative w-full max-w-full bg-gradient-to-r from-[#062B6E] via-[#0B3C8C] to-[#0E56B8] px-3 pt-2 pb-3.5 flex-shrink-0 z-20 transition-all duration-200 ease-out ${
        hidden ? '-translate-y-full opacity-0 pointer-events-none' : 'translate-y-0 opacity-100'
      }`}
    >
      <div className="flex items-center justify-between gap-2 w-full">
        <div className="flex items-center gap-2 min-w-0 flex-1">
          <button
            onClick={onOpenDrawer}
            aria-label="Menú"
            className="w-9 h-9 rounded-full bg-white dark:bg-slate-800 border border-white/25 shadow-md flex items-center justify-center flex-shrink-0"
          >
            <Menu className="w-4.5 h-4.5 text-slate-900 dark:text-white stroke-[2.5]" />
          </button>
          <div className="min-w-0 flex-1">
            <h1 className="text-white font-extrabold text-[19px] leading-none flex items-center gap-1 truncate">
              <span>¡Hola!</span>
              <span className="text-base">👋</span>
            </h1>
            <p className="text-white/95 text-[11px] font-medium mt-0.5 truncate">
              ¿A dónde quieres ir hoy?
            </p>
          </div>
        </div>

        <div className="bg-[#082E70]/85 border border-sky-400/50 rounded-full px-2.5 py-1 flex items-center gap-1.5 flex-shrink-0 shadow-inner">
          <Crown className="w-3.5 h-3.5 text-[#38BDF8] fill-[#38BDF8] flex-shrink-0" />
          <div className="text-white text-[9px] font-semibold leading-[1.15] text-left whitespace-nowrap">
            <div>Tu ciudad,</div>
            <div className="flex items-center gap-0.5">
              <span>nuestro destino</span>
              <span className="text-[#38BDF8]">💙</span>
            </div>
          </div>
        </div>
      </div>

      <svg
        viewBox="0 0 400 22"
        preserveAspectRatio="none"
        className="absolute -bottom-[14px] left-0 w-full h-[18px] pointer-events-none"
      >
        <path
          d="M0,0 L400,0 L400,6 Q300,22 200,10 Q100,-2 0,14 Z"
          fill="#0A3A86"
        />
      </svg>
    </div>
  );
}

export function PasajeroMapCenterArea({
  pickMode,
  step,
  hidePanels,
  isDragging = false,
  stops = [],
  routeKm,
  routeMin,
  pickupAddress,
  destinationAddress,
  pickupUnverified = false,
  destUnverified = false,
  onBackFromPickMode,
  onConfirmPickMode,
  onLocateMe,
  onOpenDrawer,
  onOpenRoute,
  onPickMode,
}) {
  const validStopsCount = (stops || []).filter((st) => (st?.address || '').trim()).length;

  return (
    <div className="relative flex-1 min-h-[72px] pointer-events-none z-10">
      {pickMode ? (
        <>
          <button
            type="button"
            onClick={onBackFromPickMode}
            aria-label="Volver a Introduce tu ruta"
            className="pointer-events-auto absolute top-3.5 left-3.5 z-[600] w-11 h-11 rounded-2xl bg-white dark:bg-slate-800 border border-border shadow-md flex items-center justify-center"
          >
            <ChevronLeft className="w-5 h-5 text-slate-900 dark:text-white stroke-[2.5]" />
          </button>

          <button
            type="button"
            onClick={onLocateMe}
            aria-label="Mi ubicación"
            className={`pointer-events-auto absolute bottom-20 right-3.5 z-[600] w-11 h-11 rounded-2xl bg-card shadow-lg flex items-center justify-center border border-border transition-opacity duration-150 ${
              isDragging ? 'opacity-0 pointer-events-none' : 'opacity-100'
            }`}
          >
            <LocateFixed className="w-5 h-5 text-[#1E6BFF]" />
          </button>

          <div
            className={`pointer-events-auto absolute bottom-5 inset-x-4 z-[600] transition-all duration-150 ${
              isDragging ? 'translate-y-16 opacity-0 pointer-events-none' : 'translate-y-0 opacity-100'
            }`}
          >
            <button
              type="button"
              onClick={onConfirmPickMode}
              className="w-full h-12 bg-primary text-primary-foreground rounded-full font-bold text-sm shadow-lg flex items-center justify-center gap-2"
            >
              <Crosshair className="w-4 h-4" />
              <span>
                {pickMode === 'pickup'
                  ? 'Confirmar punto de recogida'
                  : pickMode?.startsWith('stop_')
                  ? `Confirmar Parada ${Number(pickMode.replace('stop_', '')) + 1}`
                  : 'Confirmar destino'}
              </span>
            </button>
          </div>
        </>
      ) : step === 'config' ? (
        <>
          <div
            className={`absolute top-2.5 inset-x-3 z-[500] flex items-start justify-between gap-2 pointer-events-none transition-all duration-200 ${
              hidePanels ? '-translate-y-16 opacity-0' : 'translate-y-0 opacity-100'
            }`}
          >
            <button
              type="button"
              onClick={onOpenDrawer}
              aria-label="Menú"
              className="pointer-events-auto w-10 h-10 rounded-2xl bg-card/95 backdrop-blur-sm shadow-md flex items-center justify-center flex-shrink-0"
            >
              <Menu className="w-4 h-4 text-foreground" />
            </button>

            <button
              type="button"
              onClick={onOpenRoute}
              className="pointer-events-auto flex-1 max-w-[235px] mx-auto bg-card/90 backdrop-blur-sm rounded-xl shadow-md px-2.5 py-1 text-left border border-border/50"
            >
              <div className="flex items-center justify-between gap-1.5 mb-0.5">
                <span className="flex items-center gap-1 text-[9.5px] text-primary font-semibold">
                  <Pencil className="w-2.5 h-2.5" /> Editar ruta
                  {validStopsCount > 0 && (
                    <span className="ml-1 px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-500 font-bold text-[9px]">
                      +{validStopsCount} par.
                    </span>
                  )}
                </span>
                {(routeKm != null || routeMin != null) && (
                  <span className="flex items-center gap-1 text-[9.5px] text-muted-foreground font-medium whitespace-nowrap">
                    {routeMin != null ? `${routeMin} min · ` : ''}
                    {routeKm != null ? `${routeKm.toFixed(1)} km` : ''}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-primary flex-shrink-0" />
                <p className="text-[10px] font-semibold text-foreground truncate flex-1 leading-tight">
                  {shortAddress(pickupAddress) || 'Recogida'} → {shortAddress(destinationAddress) || 'Destino'}
                </p>
              </div>
            </button>

            <div className="w-10 flex-shrink-0" />
          </div>

          <button
            type="button"
            onClick={onLocateMe}
            aria-label="Centrar ruta"
            className={`pointer-events-auto absolute bottom-7 right-3.5 z-[500] w-11 h-11 rounded-2xl bg-card shadow-lg flex items-center justify-center border border-border transition-opacity duration-200 ${
              hidePanels ? 'opacity-0 pointer-events-none' : 'opacity-100'
            }`}
          >
            <LocateFixed className="w-5 h-5 text-[#1E6BFF]" />
          </button>
        </>
      ) : step === 'home' ? (
        <button
          type="button"
          onClick={onLocateMe}
          aria-label="Mi ubicación"
          className={`pointer-events-auto absolute bottom-7 right-3.5 z-[500] w-11 h-11 rounded-2xl bg-card shadow-lg flex items-center justify-center border border-border transition-opacity duration-200 ${
            hidePanels ? 'opacity-0 pointer-events-none' : 'opacity-100'
          }`}
        >
          <LocateFixed className="w-5 h-5 text-[#1E6BFF]" />
        </button>
      ) : null}
    </div>
  );
}

export function PasajeroHomeBottomSheet({
  hidden,
  activeService,
  serviceKey,
  onSelectService,
  pickupAddress,
  destinationAddress,
  onOpenRoute,
  onResumeActiveService,
}) {
  return (
    <div
      className={`relative z-20 w-full max-w-full flex-shrink-0 transition-all duration-200 ease-out ${
        hidden ? 'translate-y-full opacity-0 pointer-events-none' : 'translate-y-0 opacity-100'
      }`}
    >
      <div className="-mt-4 w-full max-w-full overflow-hidden rounded-t-[24px] bg-card px-3 pt-2 pb-1 shadow-[0_-6px_20px_rgba(0,0,0,0.06)]">
        {activeService && ['pendiente', 'asignado', 'en_camino', 'recogida'].includes(activeService.status) && (
          <button
            type="button"
            onClick={onResumeActiveService}
            className="w-full mb-2 px-3.5 py-2.5 rounded-2xl bg-primary/15 border border-primary/40 flex items-center justify-between gap-2 text-left active:scale-[0.99] transition-transform"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <span className="relative flex h-2.5 w-2.5 flex-shrink-0">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-primary" />
              </span>
              <div className="min-w-0">
                <p className="text-xs font-extrabold text-primary truncate">
                  {activeService.status === 'pendiente'
                    ? 'Buscando conductor en curso...'
                    : 'Viaje en curso'}
                </p>
                <p className="text-[11px] text-foreground font-medium truncate">
                  {activeService.pickup_address} → {activeService.destination_address}
                </p>
              </div>
            </div>
            <span className="px-2.5 py-1 rounded-xl bg-primary text-primary-foreground text-[11px] font-bold flex-shrink-0">
              Abrir
            </span>
          </button>
        )}
        <ServiceSelector value={serviceKey} onSelect={onSelectService} />

        <button
          type="button"
          onClick={onOpenRoute}
          className="w-full h-11 bg-white dark:bg-muted rounded-full pl-3.5 pr-1.5 flex items-center gap-2.5 mb-1.5 shadow-[0_4px_16px_rgba(2,132,199,0.15)] border-2 border-[#0284C7]/35 dark:border-[#0284C7]/50 active:scale-[0.99] transition-transform"
        >
          <Search className="w-4.5 h-4.5 text-[#0284C7] stroke-[2.5] flex-shrink-0" />
          <span className="text-foreground text-[14px] font-extrabold tracking-tight flex-1 min-w-0 text-left truncate">
            {destinationAddress
              ? `${pickupAddress || 'Origen'} → ${destinationAddress}`
              : '¿A dónde y por cuánto?'}
          </span>
          <span className="w-8 h-8 rounded-full bg-[#0284C7] flex items-center justify-center flex-shrink-0 shadow-md">
            <ArrowRight className="w-4 h-4 text-white stroke-[2.5]" />
          </span>
        </button>

        <PromoBanners />
      </div>
    </div>
  );
}
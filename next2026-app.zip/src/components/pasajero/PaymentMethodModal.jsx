import React from 'react';
import { Key, Banknote, Gift } from 'lucide-react';
import { useBackButton } from '@/hooks/useBackButton';

// Opciones de pago. Las de transferencia usan íconos de marca; efectivo y puntos van aparte.
const TRANSFER_OPTIONS = [
  { v: 'paga_con_llave', label: 'Paga con llave' },
  { v: 'daviplata', label: 'DaviPlata' },
  { v: 'nequi', label: 'Nequi' },
  { v: 'bancolombia', label: 'Bancolombia' },
];
const CASH_OPTIONS = [
  { v: 'efectivo', label: 'Efectivo' },
];

// Ícono de marca por método (approx. visual, sin assets externos).
function BrandIcon({ v }) {
  if (v === 'paga_con_llave')
    return (
      <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
        <Key className="w-5 h-5 text-muted-foreground" />
      </div>
    );
  if (v === 'daviplata')
    return (
      <div className="w-10 h-10 rounded-lg bg-[#E30613] flex items-center justify-center">
        <span className="text-white font-extrabold text-sm">D</span>
      </div>
    );
  if (v === 'nequi')
    return (
      <div className="w-10 h-10 rounded-full bg-[#720068] flex items-center justify-center">
        <span className="text-white font-extrabold text-sm">N</span>
      </div>
    );
  if (v === 'bancolombia')
    return (
      <div className="w-10 h-10 rounded-lg overflow-hidden flex flex-col">
        <div className="flex-1 bg-[#006341]" />
        <div className="flex-1 bg-[#FFD200]" />
        <div className="flex-1 bg-[#0033A0]" />
      </div>
    );
  if (v === 'efectivo')
    return (
      <div className="w-10 h-10 rounded-lg bg-[#E8F5E9] dark:bg-emerald-500/15 flex items-center justify-center">
        <Banknote className="w-5 h-5 text-[#2E7D32] dark:text-emerald-400" />
      </div>
    );
  if (v === 'redimido_puntos')
    return (
      <div className="w-10 h-10 rounded-lg bg-[#1E6BFF]/15 flex items-center justify-center">
        <Gift className="w-5 h-5 text-[#1E6BFF]" />
      </div>
    );
  return null;
}

function Row({ opt, selected, onSelect }) {
  return (
    <button type="button" onClick={() => onSelect(opt.v)}
      className="w-full flex items-center gap-3 py-3">
      <BrandIcon v={opt.v} />
      <span className="flex-1 text-left text-foreground text-sm font-medium">{opt.label}</span>
      <span className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${selected ? 'border-[#8926c9]' : 'border-muted-foreground/40'}`}>
        {selected && <span className="w-2.5 h-2.5 rounded-full bg-[#8926c9]" />}
      </span>
    </button>
  );
}

// Hoja inferior para elegir método de pago (efectivo o app del banco).
export default function PaymentMethodModal({ value, onSelect, onClose }) {
  useBackButton(onClose, true);

  return (
    <div className="fixed inset-0 z-[2000] flex items-end justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full max-w-md bg-card rounded-t-[28px] shadow-2xl px-5 pt-3 pb-8 animate-in slide-in-from-bottom max-h-[85vh] overflow-y-auto no-scrollbar">
        <div className="w-10 h-1.5 rounded-full bg-muted mx-auto mb-4" />
        <div className="flex items-center justify-center mb-5">
          <h2 className="text-foreground font-extrabold text-lg text-center">Seleccionar método de pago</h2>
        </div>

        <p className="text-foreground text-sm font-bold mb-0.5">Transferencia de dinero</p>
        <p className="text-muted-foreground text-xs mb-2">Pagar con la aplicación del banco</p>
        <div className="divide-y divide-border mb-5">
          {TRANSFER_OPTIONS.map((opt) => (
            <Row key={opt.v} opt={opt} selected={value === opt.v} onSelect={onSelect} />
          ))}
        </div>

        <p className="text-foreground text-sm font-bold mb-2">Otra forma</p>
        <div className="divide-y divide-border">
          {CASH_OPTIONS.map((opt) => (
            <Row key={opt.v} opt={opt} selected={value === opt.v} onSelect={onSelect} />
          ))}
        </div>
      </div>
    </div>
  );
}
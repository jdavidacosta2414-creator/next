import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import {
  ChevronLeft, Search, Loader2, PackageSearch, Bike, Car, Package, Calendar, Clock, ChevronRight, Radio, XCircle, Eye,
} from 'lucide-react';
import ServicioDetalle from '@/components/pasajero/ServicioDetalle';
import ClientAvatar from '@/components/shared/ClientAvatar';
import CancelRequestModal from '@/components/pasajero/CancelRequestModal';
import { useToast } from '@/components/ui/use-toast';
import { parseUtcDate, fmtBogotaGroupDate, fmtBogotaFullDateTime } from '@/lib/dateBogota';
import { useBackButton } from '@/hooks/useBackButton';

const ACTIVE_STATUSES = ['pendiente', 'asignado', 'en_camino', 'recogida'];
const TEN_MIN_MS = 10 * 60 * 1000;

const ACTIVE_STATUS_LABELS = {
  pendiente: 'Buscando conductor',
  asignado: 'Conductor asignado',
  en_camino: 'Conductor en camino',
  recogida: 'En viaje al destino',
};

const fmtGroupDate = (d) => fmtBogotaGroupDate(d);

const fmtFullDateTime = (d) => fmtBogotaFullDateTime(d);

const fmtMoney = (n) =>
  'COP ' + Number(n || 0).toLocaleString('es-CO', { minimumFractionDigits: 0 });

// Filtros independientes: Todo primero, luego Transporte en moto, Transporte en carro y Mensajería
const FILTERS = [
  { id: 'todo', label: 'Todo' },
  { id: 'moto', label: 'Transporte en moto' },
  { id: 'carro', label: 'Transporte en carro' },
  { id: 'mensajeria', label: 'Mensajería' },
];

function getServiceCategory(t) {
  if (t.service_type === 'mensajeria') {
    return { key: 'mensajeria', Icon: Package, label: 'Mensajería' };
  }
  if (t.vehicle_type === 'carro') {
    return { key: 'carro', Icon: Car, label: 'Transporte en carro' };
  }
  return { key: 'moto', Icon: Bike, label: 'Transporte en moto' };
}

export default function PasajeroHistorial({
  onBack,
  activeServiceId,
  onOpenActiveService,
  onServiceCancelled,
}) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTrips, setActiveTrips] = useState([]);
  const [trips, setTrips] = useState([]);
  const [mobilesMap, setMobilesMap] = useState({});
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('todo');
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState(null);
  const [cancelTarget, setCancelTarget] = useState(null);
  const [nowTs, setNowTs] = useState(Date.now());

  useEffect(() => {
    const t = setInterval(() => setNowTs(Date.now()), 5000);
    return () => clearInterval(t);
  }, []);

  const load = async () => {
    const storedActiveId = activeServiceId || localStorage.getItem('next_active_service_id');
    if (!user?.id && !storedActiveId) {
      setLoading(false);
      return;
    }
    try {
      const queries = [
        base44.entities.Mobile.list('-created_date', 100).catch(() => []),
      ];
      if (user?.id) {
        queries.push(
          base44.entities.Service.filter(
            { created_by_id: user.id, status: 'finalizado' },
            { sort: '-created_date', limit: 50 }
          ).catch(() => ({ items: [] })),
          base44.entities.Service.filter(
            { created_by_id: user.id, status: { $in: ACTIVE_STATUSES } },
            { sort: '-created_date', limit: 10 }
          ).catch(() => ({ items: [] }))
        );
      }
      const [allMobs, finPage, actPage] = await Promise.all(queries);

      let items = finPage?.items || (Array.isArray(finPage) ? finPage : []);
      if (items.length === 0 && user?.phone) {
        const byPhone = await base44.entities.Service.filter(
          { client_phone: user.phone, status: 'finalizado' },
          { sort: '-created_date', limit: 50 }
        ).catch(() => ({ items: [] }));
        items = byPhone?.items || (Array.isArray(byPhone) ? byPhone : []);
      }

      let actItems = actPage?.items || (Array.isArray(actPage) ? actPage : []);
      if (actItems.length === 0 && user?.phone) {
        const actByPhone = await base44.entities.Service.filter(
          { client_phone: user.phone, status: { $in: ACTIVE_STATUSES } },
          { sort: '-created_date', limit: 10 }
        ).catch(() => ({ items: [] }));
        actItems = actByPhone?.items || (Array.isArray(actByPhone) ? actByPhone : []);
      }

      if (storedActiveId && !actItems.some((s) => s.id === storedActiveId)) {
        const single = await base44.entities.Service.get(storedActiveId).catch(() => null);
        if (single && ACTIVE_STATUSES.includes(single.status)) {
          actItems = [single, ...actItems];
        }
      }

      // Verificar si algún servicio en 'pendiente' ya superó los 10 minutos para eliminarlo automáticamente y notificar
      const validActive = [];
      for (const s of actItems) {
        if (s.status === 'pendiente' && s.created_date) {
          const age = Date.now() - parseUtcDate(s.created_date).getTime();
          if (age >= TEN_MIN_MS) {
            base44.entities.Service.update(s.id, {
              status: 'cancelado',
              cancel_reason: 'sin_conductor',
              client_cancel_detail: 'Eliminado automáticamente después de 10 minutos sin conductor.',
            }).catch(() => {});
            onServiceCancelled?.(s.id);
            continue;
          }
        }
        validActive.push(s);
      }

      const mMap = {};
      (Array.isArray(allMobs) ? allMobs : allMobs?.items || []).forEach((m) => {
        if (m?.id) mMap[m.id] = m;
        if (m?.name) mMap[`name:${m.name.trim().toLowerCase()}`] = m;
      });
      setMobilesMap(mMap);
      setActiveTrips(validActive);
      setTrips(items);
    } catch (e) {}
    setLoading(false);
  };

  useEffect(() => {
    load();
    const unsub = base44.entities.Service.subscribe(() => load());
    return unsub;
  }, [user?.id, activeServiceId]);

  useBackButton(
    () => {
      if (cancelTarget) {
        setCancelTarget(null);
        return true;
      }
      if (selected) {
        setSelected(null);
        load();
        return true;
      }
      return false;
    },
    true
  );

  const resolveDriver = (t) => {
    const mob =
      (t.mobile_id && mobilesMap[t.mobile_id]) ||
      (t.mobile_name && mobilesMap[`name:${t.mobile_name.trim().toLowerCase()}`]) ||
      null;
    const name = t.mobile_name || mob?.name || '';
    const plate = (t.mobile_plate || mob?.plate || '').toUpperCase();
    const photo = t.mobile_photo || mob?.photo_url || '';
    const brandModel = [t.vehicle_brand || mob?.vehicle_brand, t.vehicle_model || mob?.vehicle_model]
      .filter(Boolean)
      .join(' ');
    return { mob, name, plate, photo, brandModel };
  };

  if (selected) {
    const { mob } = resolveDriver(selected);
    return (
      <ServicioDetalle
        service={selected}
        initialDriverMob={mob}
        onBack={() => {
          setSelected(null);
          load();
        }}
      />
    );
  }

  const filtered = trips.filter((t) => {
    const cat = getServiceCategory(t);
    if (filter !== 'todo' && cat.key !== filter) return false;
    if (!query) return true;
    const q = query.toLowerCase();
    const drv = resolveDriver(t);
    return [
      t.pickup_address,
      t.destination_address,
      drv.name,
      drv.plate,
      drv.brandModel,
      cat.label,
    ].some((v) => (v || '').toLowerCase().includes(q));
  });

  const groups = {};
  filtered.forEach((t) => {
    const key = fmtGroupDate(t.created_date);
    (groups[key] = groups[key] || []).push(t);
  });
  const groupKeys = Object.keys(groups);

  return (
    <div className="fixed inset-0 z-[1500] w-full max-w-md mx-auto bg-background flex flex-col pb-[56px]">
      {/* Encabezado */}
      <div className="px-4 pt-5 pb-3 flex-shrink-0 bg-card border-b border-border">
        <div className="flex items-center gap-3 mb-3.5">
          <button
            type="button"
            onClick={onBack}
            aria-label="Volver"
            className="w-9 h-9 rounded-full bg-muted flex items-center justify-center"
          >
            <ChevronLeft className="w-5 h-5 text-foreground" />
          </button>
          <h1 className="text-foreground font-extrabold text-xl">Historial de viajes</h1>
        </div>

        {/* Pestañas de filtro independientes bien cuadradas */}
        <div className="grid grid-cols-4 gap-1.5 pb-1">
          {FILTERS.map((f) => {
            const active = filter === f.id;
            return (
              <button
                key={f.id}
                type="button"
                onClick={() => setFilter(f.id)}
                className={`px-2 py-2 rounded-xl text-[11px] leading-tight font-bold text-center flex items-center justify-center transition-colors ${
                  active
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'bg-muted text-muted-foreground hover:text-foreground'
                }`}
              >
                {f.label}
              </button>
            );
          })}
        </div>

        <div className="relative mt-3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar por conductor, placa o dirección"
            className="w-full h-10 bg-muted/60 rounded-xl pl-9 pr-3 text-sm text-foreground placeholder:text-muted-foreground outline-none border border-border focus:border-primary"
          />
        </div>
      </div>

      {/* Lista agrupada por día + Servicios en curso */}
      <div className="flex-1 overflow-y-auto no-scrollbar px-4 pt-4 pb-6 space-y-5">
        {!loading && activeTrips.length > 0 && (
          <div className="space-y-2.5">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-primary" />
              </span>
              <p className="text-foreground font-extrabold text-xs uppercase tracking-wider">
                Servicio en curso ({activeTrips.length})
              </p>
            </div>

            {activeTrips.map((t) => {
              const { Icon, label } = getServiceCategory(t);
              const drv = resolveDriver(t);
              const isSearching = t.status === 'pendiente';
              const remainingMs =
                isSearching && t.created_date
                  ? Math.max(0, TEN_MIN_MS - (nowTs - parseUtcDate(t.created_date).getTime()))
                  : null;
              const remainingMin = remainingMs != null ? Math.ceil(remainingMs / 60000) : null;

              return (
                <div
                  key={t.id}
                  onClick={() => onOpenActiveService?.(t)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => e.key === 'Enter' && onOpenActiveService?.(t)}
                  className="w-full bg-card rounded-2xl p-4 shadow-md border-2 border-primary/60 flex flex-col gap-3 text-left cursor-pointer active:scale-[0.99] transition-transform"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-10 h-10 rounded-xl bg-primary/15 flex items-center justify-center flex-shrink-0">
                        <Icon className="w-5 h-5 text-primary" />
                      </div>
                      <div className="min-w-0">
                        <span className="text-xs font-extrabold text-primary uppercase tracking-tight block">
                          {label}
                        </span>
                        <span className="inline-flex items-center gap-1.5 text-[11px] font-bold text-amber-600 dark:text-amber-400 mt-0.5">
                          <Radio className="w-3 h-3 animate-pulse" />
                          {ACTIVE_STATUS_LABELS[t.status] || 'En curso'}
                          {isSearching && remainingMin != null && (
                            <span className="text-muted-foreground font-medium">
                              · Expira en {remainingMin} min
                            </span>
                          )}
                        </span>
                      </div>
                    </div>
                    <span className="text-sm font-extrabold text-foreground flex-shrink-0">
                      {fmtMoney(t.fare)}
                    </span>
                  </div>

                  <div className="space-y-1.5 pl-1">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full border-2 border-primary flex-shrink-0" />
                      <p className="text-xs text-muted-foreground truncate">
                        {t.pickup_address || '—'}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 border-2 border-foreground flex-shrink-0" />
                      <p className="text-sm font-bold text-foreground truncate">
                        {t.destination_address || '—'}
                      </p>
                    </div>
                  </div>

                  {drv.name && (
                    <div className="flex items-center justify-between gap-2.5 pt-2 border-t border-border/70">
                      <div className="flex items-center gap-2 min-w-0">
                        <ClientAvatar photo={drv.photo} name={drv.name} size="sm" />
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-foreground truncate">{drv.name}</p>
                          <p className="text-[11px] text-muted-foreground truncate">
                            {drv.brandModel || label}
                          </p>
                        </div>
                      </div>
                      {drv.plate && (
                        <span className="px-2.5 py-1 rounded-lg bg-muted border border-border text-foreground font-extrabold text-xs tracking-wider flex-shrink-0">
                          {drv.plate}
                        </span>
                      )}
                    </div>
                  )}

                  <div className="flex items-center gap-2.5 pt-1">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenActiveService?.(t);
                      }}
                      className="flex-1 h-10 rounded-xl bg-primary text-primary-foreground font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      {isSearching ? 'Ver búsqueda' : 'Ver viaje en curso'}
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setCancelTarget(t);
                      }}
                      className="px-3.5 h-10 rounded-xl bg-destructive/15 hover:bg-destructive/25 text-destructive font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      Cancelar
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {loading ? (
          <div className="flex flex-col items-center justify-center h-40 text-muted-foreground">
            <Loader2 className="w-6 h-6 animate-spin mb-2" />
            <p className="text-sm">Cargando historial...</p>
          </div>
        ) : groupKeys.length === 0 && activeTrips.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-60 text-muted-foreground px-6 text-center">
            <PackageSearch className="w-10 h-10 mb-3 text-muted-foreground/40" />
            <p className="text-sm font-bold text-foreground mb-1">No hay servicios en esta categoría</p>
            <p className="text-xs">
              Tus solicitudes de transporte en moto, transporte en carro y mensajería aparecerán aquí con su fecha y hora.
            </p>
          </div>
        ) : (
          groupKeys.map((key) => (
            <div key={key}>
              <div className="flex items-center gap-1.5 mb-2.5">
                <Calendar className="w-3.5 h-3.5 text-primary" />
                <p className="text-foreground font-bold text-xs uppercase tracking-wide capitalize">
                  {key}
                </p>
              </div>
              <div className="space-y-2.5">
                {groups[key].map((t) => {
                  const { Icon, label } = getServiceCategory(t);
                  const cancelled = t.status === 'cancelado';
                  const drv = resolveDriver(t);
                  return (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setSelected(t)}
                      className="w-full bg-card rounded-2xl p-3.5 shadow-sm border border-border flex flex-col gap-2.5 text-left active:scale-[0.99] transition-transform"
                    >
                      <div className="flex items-start gap-3 w-full">
                        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <Icon className="w-5 h-5 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          {/* Encabezado de tarjeta: Categoría + Precio o Cancelado */}
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs font-extrabold text-primary uppercase tracking-tight">
                              {label}
                            </span>
                            {cancelled ? (
                              <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-destructive/15 text-destructive">
                                Cancelado
                              </span>
                            ) : (
                              <span className="text-sm font-extrabold text-foreground">
                                {fmtMoney(t.collected_amount || t.fare)}
                              </span>
                            )}
                          </div>

                          {/* Día, fecha y hora exacta */}
                          <div className="flex items-center gap-1 text-[11px] text-muted-foreground mt-0.5 mb-1.5">
                            <Clock className="w-3 h-3 flex-shrink-0" />
                            <span className="capitalize">{fmtFullDateTime(t.created_date)}</span>
                          </div>

                          {/* Origen y Destino */}
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="w-2 h-2 rounded-full border-2 border-primary flex-shrink-0" />
                              <p className="text-xs text-muted-foreground truncate">
                                {t.pickup_address || '—'}
                              </p>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="w-2 h-2 border-2 border-foreground flex-shrink-0" />
                              <p className="text-sm font-bold text-foreground truncate">
                                {t.destination_address || '—'}
                              </p>
                            </div>
                          </div>
                        </div>
                        <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0 self-center" />
                      </div>

                      {/* Franja del conductor: Foto + Nombre + Vehículo y Placa */}
                      {drv.name && (
                        <div className="flex items-center justify-between gap-2.5 pt-2.5 border-t border-border/70">
                          <div className="flex items-center gap-2.5 min-w-0">
                            <ClientAvatar photo={drv.photo} name={drv.name} size="sm" />
                            <div className="min-w-0">
                              <p className="text-xs font-bold text-foreground truncate">
                                {drv.name}
                              </p>
                              <p className="text-[11px] text-muted-foreground truncate">
                                {drv.brandModel || label}
                              </p>
                            </div>
                          </div>
                          {drv.plate && (
                            <span className="px-2.5 py-1 rounded-lg bg-muted border border-border text-foreground font-extrabold text-xs tracking-wider flex-shrink-0">
                              {drv.plate}
                            </span>
                          )}
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ))
        )}
      </div>

      {cancelTarget && (
        <CancelRequestModal
          serviceId={cancelTarget.id}
          mobileId={cancelTarget.mobile_id}
          mobileName={cancelTarget.mobile_name}
          onCancelled={() => {
            const cancelledId = cancelTarget.id;
            setCancelTarget(null);
            toast({
              title: 'Servicio cancelado',
              description: 'Tu solicitud en curso fue cancelada correctamente.',
            });
            onServiceCancelled?.(cancelledId);
            load();
          }}
          onClose={() => setCancelTarget(null)}
        />
      )}
    </div>
  );
}
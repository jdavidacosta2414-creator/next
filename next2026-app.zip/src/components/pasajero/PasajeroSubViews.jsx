import React from 'react';

const PasajeroHistorial = React.lazy(() => import('@/components/pasajero/PasajeroHistorial'));
const PasajeroBilletera = React.lazy(() => import('@/components/pasajero/PasajeroBilletera'));
const NextClubView = React.lazy(() => import('@/components/club/NextClubView'));
const ObjetosPerdidos = React.lazy(() => import('@/components/pasajero/ObjetosPerdidos'));
const PasajeroNotificaciones = React.lazy(() => import('@/components/pasajero/PasajeroNotificaciones'));
const DriverCompartir = React.lazy(() => import('@/components/driver/DriverCompartir'));
const DriverSeguridad = React.lazy(() => import('@/components/driver/DriverSeguridad'));
const DriverConfig = React.lazy(() => import('@/components/driver/DriverConfig'));
const AppAyuda = React.lazy(() => import('@/components/shared/AppAyuda'));
const DriverSoporte = React.lazy(() => import('@/components/driver/DriverSoporte'));
const ValoracionesView = React.lazy(() => import('@/components/shared/ValoracionesView'));
const PasajeroPerfil = React.lazy(() => import('@/components/pasajero/PasajeroPerfil'));

export default function PasajeroSubViews({
  user,
  mobileProfile,
  setMobileProfile,
  setForm,
  buscandoId,
  activeService,
  setBuscandoId,
  setActiveService,
  backedOutRef,
  setSearchParams,
  setStep,
  setRouteOpen,
  onResetRoute,
  redeemPresetFareRef,
  fareMin,
  openSubView,
  goBackSubView,
  showHistorial,
  setShowHistorial,
  showBilletera,
  setShowBilletera,
  showPuntos,
  setShowPuntos,
  showObjetos,
  setShowObjetos,
  showNotif,
  setShowNotif,
  setNotifCount,
  showCompartir,
  setShowCompartir,
  showSeguridad,
  setShowSeguridad,
  showConfig,
  setShowConfig,
  showAyuda,
  setShowAyuda,
  showSoporte,
  setShowSoporte,
  showPerfil,
  setShowPerfil,
  showValoraciones,
}) {
  const handleBack = (fallbackSetter) => {
    if (typeof goBackSubView === 'function') {
      goBackSubView();
    } else {
      fallbackSetter?.(false);
    }
  };

  return (
    <React.Suspense fallback={null}>
      {showHistorial && (
        <PasajeroHistorial
          onBack={() => handleBack(setShowHistorial)}
          activeServiceId={buscandoId}
          onOpenActiveService={(svc) => {
            if (typeof openSubView === 'function') openSubView(null);
            else setShowHistorial(false);
            backedOutRef.current = false;
            localStorage.setItem('next_active_service_id', svc.id);
            setBuscandoId(svc.id);
            setActiveService(svc);
            setSearchParams({ service: svc.id });
            setStep(svc.status === 'pendiente' ? 'buscando' : 'seguimiento');
          }}
          onServiceCancelled={(svcId) => {
            if (buscandoId === svcId || activeService?.id === svcId) {
              if (onResetRoute) {
                onResetRoute();
              } else {
                localStorage.removeItem('next_active_service_id');
                setActiveService(null);
                setBuscandoId(null);
                setSearchParams({});
                setStep('home');
              }
            }
          }}
        />
      )}
      {showBilletera && (
        <PasajeroBilletera
          onBack={() => handleBack(setShowBilletera)}
          onOpenPuntos={() => {
            if (typeof openSubView === 'function') openSubView('puntos');
            else {
              setShowBilletera(false);
              setShowPuntos(true);
            }
          }}
        />
      )}
      {showPuntos && (
        <div className="fixed inset-0 z-[2150] bg-background w-full max-w-md mx-auto overflow-y-auto overscroll-contain">
          <NextClubView
            onBack={() => handleBack(setShowPuntos)}
            onRequestFreeRide={() => {
              if (typeof openSubView === 'function') openSubView(null);
              else setShowPuntos(false);
              setForm((f) => ({
                ...f,
                mode: 'movilidad',
                service_type: 'transporte',
                vehicle_type: 'moto',
                payment_method: f.payment_method === 'redimido_puntos' ? 'efectivo' : f.payment_method,
                use_free_ride: true,
              }));
              setStep('home');
              setRouteOpen(true);
            }}
          />
        </div>
      )}
      {showObjetos && <ObjetosPerdidos onBack={() => handleBack(setShowObjetos)} />}
      {showNotif && (
        <PasajeroNotificaciones
          user={user}
          onBack={() => handleBack(setShowNotif)}
          onCountChange={setNotifCount}
        />
      )}
      {showCompartir && <DriverCompartir mobile={{ id: user?.id }} onBack={() => handleBack(setShowCompartir)} />}
      {showSeguridad && (
        <DriverSeguridad
          role="pasajero"
          onBack={() => handleBack(setShowSeguridad)}
          onNavigate={(dest) => {
            if (dest === 'soporte') {
              if (typeof openSubView === 'function') openSubView('soporte');
              else {
                setShowSeguridad(false);
                setShowSoporte(true);
              }
            }
          }}
        />
      )}
      {showConfig && <DriverConfig onBack={() => handleBack(setShowConfig)} />}
      {showAyuda && (
        <AppAyuda
          onBack={() => handleBack(setShowAyuda)}
          onOpenSoporte={() => {
            if (typeof openSubView === 'function') openSubView('soporte');
            else { setShowAyuda(false); setShowSoporte(true); }
          }}
          onOpenObjetos={() => {
            if (typeof openSubView === 'function') openSubView('objetos');
            else { setShowAyuda(false); setShowObjetos(true); }
          }}
          onOpenSeguridad={() => {
            if (typeof openSubView === 'function') openSubView('seguridad');
            else { setShowAyuda(false); setShowSeguridad(true); }
          }}
        />
      )}
      {showSoporte && <DriverSoporte onBack={() => handleBack(setShowSoporte)} />}
      {showValoraciones && <ValoracionesView role="pasajero" user={user} onBack={() => handleBack()} />}
      {showPerfil && (
        <PasajeroPerfil
          user={user}
          mobileProfile={mobileProfile}
          onBack={() => handleBack(setShowPerfil)}
          onHistorial={() => {
            if (typeof openSubView === 'function') openSubView('historial');
            else { setShowPerfil(false); setShowHistorial(true); }
          }}
          onPuntos={() => {
            if (typeof openSubView === 'function') openSubView('puntos');
            else { setShowPerfil(false); setShowPuntos(true); }
          }}
          onObjetos={() => {
            if (typeof openSubView === 'function') openSubView('objetos');
            else { setShowPerfil(false); setShowObjetos(true); }
          }}
          onUpdated={({ name, phone, cedula, photo_url }) => {
            setForm((f) => ({ ...f, client_name: name, client_phone: phone }));
            if (mobileProfile) {
              setMobileProfile((m) =>
                m
                  ? {
                      ...m,
                      name: name || m.name,
                      phone: phone || m.phone,
                      cedula: cedula || m.cedula,
                      photo_url: photo_url || m.photo_url,
                    }
                  : m
              );
            }
          }}
        />
      )}
    </React.Suspense>
  );
}
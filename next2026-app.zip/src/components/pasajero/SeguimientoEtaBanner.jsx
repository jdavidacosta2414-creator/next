import React, { useState } from 'react';
import { Sparkles } from 'lucide-react';
import { resolveVehicleColorPalette } from '@/lib/mapboxMarkers';
import VehicleBrandIllustration, { resolveRegisteredVehicleSpec } from '@/components/shared/VehicleBrandIllustration';
import { useBackButton } from '@/hooks/useBackButton';

export function buildVehicleSummary({ driver, service }) {
  const spec = resolveRegisteredVehicleSpec(driver, service);
  const { vType, isTaxi, palette, brandDisplay, rawModel, rawYear, plate, colorLabel } = spec;
  const colorWord =
    colorLabel || palette.label || (isTaxi ? 'Amarillo' : vType === 'carro' ? 'Blanco' : 'Azul');

  const typeLabel = vType === 'carro' ? `Vehículo ${colorWord}` : `Moto ${colorWord}`;
  const brandModel = [brandDisplay, rawModel, rawYear].filter(Boolean).join(' ').trim();

  const parts = [typeLabel];
  if (brandModel) parts.push(brandModel);
  if (plate) parts.push(plate);

  return {
    vType,
    isTaxi,
    colorWord,
    palette: palette || resolveVehicleColorPalette('', isTaxi),
    typeLabel,
    brandModel,
    plate,
    fullVehicleText: parts.join(' · '),
  };
}

export default function SeguimientoEtaBanner({
  phase,
  etaMin,
  remainingKm = null,
  initialMin = null,
  driver,
  service,
}) {
  const [detailOpen, setDetailOpen] = useState(false);
  useBackButton(() => setDetailOpen(false), detailOpen);
  const isToPickup = phase === 'to_pickup';
  const rawMin = etaMin != null && Number.isFinite(Number(etaMin)) ? Number(etaMin) : 1;
  const minutesVal = Math.max(1, Math.round(rawMin));
  const kmNum =
    remainingKm != null && Number.isFinite(Number(remainingKm))
      ? Number(remainingKm) < 0.05
        ? 0.1
        : Math.max(0.1, Number(remainingKm))
      : 0.4;
  const kmText = `(${kmNum.toFixed(1)} km)`;

  const baseMax = Math.max(minutesVal + 1, Number(initialMin) || 6);
  const progressRatio = Math.min(0.92, Math.max(0.18, 1 - minutesVal / (baseMax + 1)));
  const radius = 19;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference * (1 - progressRatio);

  const spec = resolveRegisteredVehicleSpec(driver, service);

  return (
    <>
      <div
        className="mb-3 rounded-2xl bg-[#EAF2FF] dark:bg-[#1E6BFF]/15 border border-[#1E6BFF]/20 px-3.5 py-2.5 flex items-center justify-between gap-3 shadow-xs"
        data-testid="passenger-eta-banner"
      >
        {/* Vehículo 3D isométrico correspondiente a la marca, línea y color de fábrica registrados por el conductor */}
        <button
          type="button"
          onClick={() => setDetailOpen(true)}
          data-testid="vehicle-3d-model-btn"
          title="Toca para ver ficha 3D del vehículo y color"
          className="flex-shrink-0 flex items-center justify-center rounded-xl bg-white/85 dark:bg-slate-900/60 border border-[#1463FF]/25 px-2.5 py-1 shadow-xs active:scale-95 transition-transform"
        >
          <VehicleBrandIllustration
            driver={driver}
            service={service}
            className="w-30 h-16"
          />
        </button>

        {/* Texto central: Llegada en / 1 min / (0.4 km) */}
        <div className="flex-1 min-w-0 text-left pl-1">
          <p className="text-[11.5px] font-semibold text-slate-600 dark:text-slate-300 leading-tight">
            {isToPickup ? 'Llegada en' : 'Destino en'}
          </p>
          <p
            className="text-2xl font-black text-[#0F172A] dark:text-white leading-tight tracking-tight"
            data-testid="eta-minutes-value"
          >
            {minutesVal} min
          </p>
          <p className="text-xs font-semibold text-slate-500 dark:text-slate-300 leading-tight">
            {kmText}
          </p>
        </div>

        {/* Anillo circular de progreso en azul */}
        <div className="relative w-12 h-12 flex items-center justify-center flex-shrink-0">
          <svg className="w-12 h-12 -rotate-90" viewBox="0 0 48 48">
            <circle
              cx="24"
              cy="24"
              r={radius}
              fill="none"
              stroke="rgba(20, 99, 255, 0.20)"
              strokeWidth="4.5"
            />
            <circle
              cx="24"
              cy="24"
              r={radius}
              fill="none"
              stroke="#1463FF"
              strokeWidth="4.5"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
            />
          </svg>
        </div>
      </div>

      {/* Modal 3D de identificación del vehículo al tocar el carro 3D */}
      {detailOpen && (
        <div
          onClick={() => setDetailOpen(false)}
          className="fixed inset-0 z-[2500] bg-black/75 backdrop-blur-xs flex flex-col items-center justify-center p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-sm rounded-3xl overflow-hidden bg-card border border-border shadow-2xl p-5"
          >
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#1E6BFF]/12 text-[#1E6BFF] text-[11px] font-extrabold mb-2">
              <Sparkles className="w-3.5 h-3.5" /> Identificación 3D del vehículo
            </div>

            <div className="rounded-2xl bg-gradient-to-b from-slate-100 to-slate-200/70 dark:from-slate-800/80 dark:to-slate-900 p-4 flex flex-col items-center justify-center border border-border my-2">
              <VehicleBrandIllustration
                driver={driver}
                service={service}
                className="w-52 h-28"
              />
            </div>

            <div className="mt-3 flex items-center justify-between gap-2 bg-muted/60 rounded-2xl p-3 border border-border">
              <div className="min-w-0">
                <p className="text-xs text-muted-foreground font-semibold">Marca y Línea</p>
                <p className="text-base font-black text-foreground truncate">
                  {spec.modelLine}
                </p>
              </div>
              {spec.plate && (
                <span
                  className={`whitespace-nowrap flex-shrink-0 px-3 py-1 rounded-lg font-black text-sm tracking-wider border ${
                    spec.isTaxi
                      ? 'bg-white text-slate-950 border-slate-400'
                      : 'bg-amber-400 text-slate-950 border-amber-600'
                  }`}
                >
                  {spec.plate}
                </span>
              )}
            </div>

            <div className="mt-2.5 flex items-center justify-between gap-2 bg-muted/60 rounded-2xl p-3 border border-border">
              <span className="text-xs text-muted-foreground font-semibold">
                Color registrado
              </span>
              <span className="inline-flex items-center gap-2 text-sm font-extrabold text-foreground capitalize">
                <span
                  className="w-4 h-4 rounded-md border border-slate-400 shadow-xs"
                  style={{ backgroundColor: spec.palette?.bodyFill || '#F8FAFC' }}
                />
                {spec.colorLabel || 'Blanco'}
              </span>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
import React, { useState } from 'react';
import { Bike, Car, Package, TrendingUp, Loader2, ArrowLeft } from 'lucide-react';
import ResolvedAvatar from '@/components/shared/ResolvedAvatar';

const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');
const FARE_STEP = 1000;
const PURPLE = '#8926c9';
const MAX_AVATARS = 8;

// Pantalla de tiempo agotado: cadena de fotos de los conductores que vieron el
// servicio + botón para aumentar la oferta y reiniciar la búsqueda.
export default function TimeoutIncreaseOffer({ service, mobiles, stats, fare, onIncreaseOffer, onCancel }) {
  const [increasing, setIncreasing] = useState(false);
  const [newFare, setNewFare] = useState(null);

  const viewers = (service?.viewed_by || []).filter(Boolean);
  const count = viewers.length;
  const minFare = service?.vehicle_type === 'carro' ? 8000 : 5000;
  const currentFare = Math.max(minFare, Number(fare ?? service?.fare ?? minFare));
  const suggestFare = newFare ?? Math.round((currentFare + 2000) / 500) * 500;

  const confirmIncrease = () => {
    if (suggestFare < minFare) return;
    setIncreasing(true);
    onIncreaseOffer(suggestFare).finally(() => setIncreasing(false));
  };

  const shown = viewers.slice(0, MAX_AVATARS);
  const extra = count - shown.length;

  return (
    <div className="text-center">
      {/* Cadena de avatares de conductores que vieron el servicio */}
      {count > 0 ? (
        <>
          <div className="flex items-center justify-center -space-x-3 mb-3">
            {shown.map((id, i) => {
               const m = mobiles[id];
               const CVIcon = m?.vehicle_type === 'carro' ? Car : service?.service_type === 'mensajeria' ? Package : Bike;
               return (
                <ResolvedAvatar
                  key={id + i}
                  photo={m?.photo_url || m?.vehicle_photo}
                  name={m?.name}
                  className="w-12 h-12 rounded-full bg-muted border-2 border-card shadow-sm"
                  fallback={<CVIcon className="w-6 h-6 text-muted-foreground" />}
                />
              );
            })}
            {extra > 0 && (
              <div className="w-12 h-12 rounded-full bg-muted border-2 border-card flex items-center justify-center shadow-sm">
                <span className="text-foreground text-xs font-bold">+{extra}</span>
              </div>
            )}
          </div>
          <p className="text-foreground font-bold text-base mb-1">
            {count} conductor{count > 1 ? 'es' : ''} {count > 1 ? 'vieron' : 'vio'} tu servicio
          </p>
          <p className="text-muted-foreground text-xs mb-5">Nadie lo tomó. Aumenta la oferta para llamar su atención.</p>
        </>
      ) : (
        <>
          <p className="text-foreground font-bold text-base mb-1">Ningún conductor aceptó tu servicio</p>
          <p className="text-muted-foreground text-xs mb-5">Aumenta la oferta para atraer conductores cercanos.</p>
        </>
      )}

      {/* Aumentar la oferta */}
      {!increasing && newFare == null && (
        <button
          onClick={() => setNewFare(suggestFare)}
          className="w-full h-13 py-3.5 rounded-full text-white font-bold flex items-center justify-center gap-2 shadow-lg"
          style={{ backgroundColor: PURPLE }}
        >
          <TrendingUp className="w-5 h-5" /> Aumentar la oferta del servicio
        </button>
      )}

      {newFare != null && !increasing && (
        <div className="rounded-2xl border border-border p-4 text-left">
          <p className="text-xs text-muted-foreground mb-3 text-center">Ingresa el nuevo valor de la oferta</p>
          <div className="flex items-center justify-between mb-3">
            <button
              type="button"
              onClick={() => setNewFare((f) => Math.max(minFare, (f ?? suggestFare) - FARE_STEP))}
              disabled={(newFare ?? suggestFare) <= minFare}
              className="w-11 h-11 rounded-xl bg-muted text-foreground font-bold text-lg flex items-center justify-center disabled:opacity-40"
            >
              −
            </button>
            <div className="text-center">
              <p className="text-2xl font-extrabold text-foreground">{fmtCOP(newFare)}</p>
              <p className="text-[10px] text-muted-foreground">Nueva oferta</p>
            </div>
            <button
              onClick={() => setNewFare((f) => (f ?? suggestFare) + FARE_STEP)}
              className="w-11 h-11 rounded-xl bg-muted text-foreground font-bold text-lg flex items-center justify-center"
            >
              +
            </button>
          </div>
          <div className="flex gap-2.5">
            <button
              onClick={() => setNewFare(null)}
              className="flex-1 h-11 rounded-xl border border-border text-muted-foreground font-bold text-sm flex items-center justify-center gap-1"
            >
              <ArrowLeft className="w-4 h-4" /> Cancelar
            </button>
            <button
              type="button"
              onClick={confirmIncrease}
              disabled={newFare < minFare}
              className="flex-1 h-11 rounded-xl text-white font-bold text-sm disabled:opacity-50"
              style={{ backgroundColor: PURPLE }}
            >
              Buscar de nuevo
            </button>
          </div>
        </div>
      )}

      {increasing && (
        <div className="h-13 rounded-full flex items-center justify-center gap-2 text-white font-bold" style={{ backgroundColor: PURPLE }}>
          <Loader2 className="w-5 h-5 animate-spin" /> Reiniciando búsqueda...
        </div>
      )}

      {newFare == null && !increasing && (
        <button onClick={onCancel} className="w-full h-11 mt-2 rounded-full bg-muted text-muted-foreground font-bold text-sm">Cancelar solicitud</button>
      )}
    </div>
  );
}
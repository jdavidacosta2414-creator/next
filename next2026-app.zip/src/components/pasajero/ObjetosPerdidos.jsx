import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { ChevronLeft, MessageCircle, Phone, PackageSearch, Loader2, ChevronRight, Info } from 'lucide-react';
import LostItemForm from '@/components/pasajero/LostItemForm';
import { useBackButton } from '@/hooks/useBackButton';

const SUPPORT_PHONE = '573008353849';
const fmtDate = (d) => new Date(d).toLocaleDateString('es-CO', { day: '2-digit', month: 'short', timeZone: 'America/Bogota' });
const fmtTime = (d) => new Date(d).toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'America/Bogota' });

// Flujo de objetos perdidos accesible desde el menú lateral del pasajero.
// Permite contactar a soporte por WhatsApp o llamada, o enviar un reporte que
// llega al panel administrativo de Central.
export default function ObjetosPerdidos({ onBack }) {
  const { user } = useAuth();
  const [trips, setTrips] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);

  useBackButton(() => {
    if (selected) {
      setSelected(null);
      return true;
    }
    return false;
  }, true);

  useEffect(() => {
    if (!user?.id) { setLoading(false); return; }
    base44.entities.Service.filter(
      { created_by_id: user.id, status: { $in: ['finalizado', 'cancelado'] } },
      { sort: '-created_date', limit: 50 }
    )
      .then((page) => setTrips(page.items || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [user?.id]);

  if (selected) return <LostItemForm trip={selected} user={user} onClose={() => setSelected(null)} onSent={() => setSelected(null)} />;

  const waLink = `whatsapp://send?phone=${SUPPORT_PHONE}&text=${encodeURIComponent('Hola, olvidé un objeto en un viaje de NEXT y necesito ayuda.')}`;

  return (
    <div className="fixed inset-0 z-[1800] w-full max-w-md mx-auto bg-background flex flex-col pb-[56px]">
      <div className="flex items-center gap-3 px-4 h-14 flex-shrink-0">
        <button onClick={onBack} aria-label="Volver" className="w-9 h-9 rounded-full bg-card shadow-sm flex items-center justify-center">
          <ChevronLeft className="w-5 h-5 text-foreground" />
        </button>
        <p className="text-foreground font-bold text-lg flex-1">Objetos perdidos</p>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar px-4 pb-6 space-y-4">
        <div className="flex items-start gap-2 bg-card rounded-2xl p-3 shadow-sm">
          <Info className="w-4 h-4 text-[#8926c9] flex-shrink-0 mt-0.5" />
          <p className="text-xs text-muted-foreground">¿Olvidaste algo en un viaje? Escríbenos por WhatsApp, llámanos o envía un reporte que llegará directamente a Central.</p>
        </div>

        <a href={waLink} className="w-full h-13 py-3.5 rounded-2xl bg-[#25D366] text-white font-bold flex items-center justify-center gap-2 shadow-sm">
          <MessageCircle className="w-5 h-5" /> Escribir por WhatsApp
        </a>
        <a href={`tel:${SUPPORT_PHONE}`} className="w-full h-13 py-3.5 rounded-2xl bg-[#1E6BFF] text-white font-bold flex items-center justify-center gap-2 shadow-sm">
          <Phone className="w-5 h-5" /> Llamar a soporte
        </a>

        <div>
          <p className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider mb-2">O envía un reporte a Central</p>
          {loading ? (
            <div className="flex items-center justify-center py-8"><Loader2 className="w-6 h-6 text-muted-foreground/40 animate-spin" /></div>
          ) : trips.length === 0 ? (
            <div className="bg-card rounded-2xl p-6 text-center shadow-sm">
              <PackageSearch className="w-8 h-8 text-muted-foreground/40 mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">No tienes viajes recientes para reportar.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {trips.map((t) => (
                <button key={t.id} onClick={() => setSelected(t)} className="w-full bg-card rounded-2xl p-3 shadow-sm flex items-center gap-3 text-left active:scale-[0.99]">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-foreground truncate">{t.mobile_name || 'Conductor'} · {t.mobile_plate || 'Sin placa'}</p>
                    <p className="text-[11px] text-muted-foreground truncate">{t.pickup_address || '—'} → {t.destination_address || '—'}</p>
                    <p className="text-[11px] text-muted-foreground">{fmtDate(t.created_date)} · {fmtTime(t.created_date)}</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground/50 flex-shrink-0" />
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
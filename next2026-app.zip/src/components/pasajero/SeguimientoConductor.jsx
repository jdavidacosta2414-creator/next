import React, { useState, useEffect, useMemo, useRef } from 'react';
import MapboxMap, { MapboxMarker, MapboxDrivingRoute, MapboxFollowCenter, MapboxFitBounds } from '@/components/shared/MapboxMap';
import { useBackButton } from '@/hooks/useBackButton';
import {
  stopPinEl,
  topDownCarMarkerEl,
  topDownMotoMarkerEl,
  etaFloatingBubbleEl,
  bluePulsePointEl,
  redDestinationPinEl,
} from '@/lib/mapboxMarkers';
import { base44 } from '@/api/base44Client';
import {
  Loader2,
  Phone,
  MessageCircle,
  Send,
  Bike,
  Car,
  Package,
  Star,
  MapPin,
  LocateFixed,
  Menu,
  Share2,
  Check,
  Banknote,
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import CancelRequestModal from '@/components/pasajero/CancelRequestModal';
import ServiceRatingModal from '@/components/shared/ServiceRatingModal';
import ResolvedAvatar, { preloadStorageUrls } from '@/components/shared/ResolvedAvatar';
import { DRIVER_TIERS, fetchDriverRecentActivity } from '@/lib/driverTier';
import { shortAddress, isIncompleteStreetAddress } from '@/lib/shortAddress';
import { reverseGeocodeValledupar } from '@/lib/geocode';
import { calculateCalibratedRouteEta } from '@/lib/routeEstimate';
import SeguimientoEtaBanner, { buildVehicleSummary } from '@/components/pasajero/SeguimientoEtaBanner';
import { resolveRegisteredVehicleSpec } from '@/components/shared/VehicleBrandIllustration';
import ServiceMessageAlertBanner, { playMessageChime } from '@/components/shared/ServiceMessageAlertBanner';
import { getAllRoadHazards, roadHazardMarkerEl } from '@/lib/roadHazardsValledupar';
import {
  PhoneCallOriginalIcon,
  ChatMessageOriginalIcon,
  ShareTripOriginalIcon,
  buildWhatsAppDirectUrl,
  openWhatsAppDirect,
} from '@/components/shared/OriginalActionIcons';
import InAppVoiceCallModal, { useInAppVoiceCall, isCallSignalMessage } from '@/components/shared/InAppVoiceCall';

const ROUTE_BLUE = '#1463FF';
const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');
const PAYMENT_LABELS = {
  efectivo: 'Efectivo',
  transferencia: 'Transferencia',
  nequi: 'Nequi',
  daviplata: 'DaviPlata',
  bancolombia: 'Bancolombia',
  paga_con_llave: 'Paga con llave',
  redimido_puntos: '🎁 Redimido con puntos',
};

function playArrivalAlertSound() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const notes = [587.33, 783.99, 1046.5];
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.001, ctx.currentTime + i * 0.14);
      gain.gain.exponentialRampToValueAtTime(0.22, ctx.currentTime + i * 0.14 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.14 + 0.22);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(ctx.currentTime + i * 0.14);
      osc.stop(ctx.currentTime + i * 0.14 + 0.24);
    });
  } catch {}
  try {
    navigator.vibrate?.([250, 120, 300]);
  } catch {}
}

function recordArrivalNotification(service) {
  if (!service?.id) return;
  try {
    const raw = localStorage.getItem('next_arrival_notifs_v1');
    const list = raw ? JSON.parse(raw) || [] : [];
    const notifId = `driver-arrived-${service.id}`;
    if (!list.some((n) => n.id === notifId)) {
      list.unshift({
        id: notifId,
        service_id: service.id,
        title: '¡Tu conductor llegó al punto de recogida!',
        body: 'Tu conductor llegó al punto de recogida. Sal, por favor.',
        date: new Date().toISOString(),
      });
      localStorage.setItem('next_arrival_notifs_v1', JSON.stringify(list.slice(0, 25)));
      window.dispatchEvent(new CustomEvent('next-notifs-updated'));
    }
  } catch {}
  try {
    if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
      new Notification('¡Ya llegó tu conductor!', {
        body: 'Tu conductor llegó al punto de recogida. Sal, por favor.',
      });
    }
  } catch {}
}

function bearingBetween(lat1, lng1, lat2, lng2) {
  const toRad = (d) => (d * Math.PI) / 180;
  const toDeg = (r) => (r * 180) / Math.PI;
  const φ1 = toRad(lat1), φ2 = toRad(lat2), Δλ = toRad(lng2 - lng1);
  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
  return (toDeg(Math.atan2(y, x)) + 360) % 360;
}

function routeBearingAt(coords, lat, lng) {
  if (!coords || coords.length < 2) return null;
  let minDist = Infinity, idx = 0;
  for (let i = 0; i < coords.length; i++) {
    const d = (coords[i][0] - lat) ** 2 + (coords[i][1] - lng) ** 2;
    if (d < minDist) { minDist = d; idx = i; }
  }
  const next = coords[Math.min(idx + 1, coords.length - 1)];
  return bearingBetween(coords[idx][0], coords[idx][1], next[0], next[1]);
}

export default function SeguimientoConductor({ serviceId, onFinish, onReassigned }) {
  const { toast } = useToast();
  const [service, setService] = useState(null);
  const [driver, setDriver] = useState(null);
  const [driverTier, setDriverTier] = useState(DRIVER_TIERS[0]);
  const [driverStats, setDriverStats] = useState({ rating: '4.9', trips: 128 });
  const [pickupRouteInfo, setPickupRouteInfo] = useState(null);
  const [tripRouteInfo, setTripRouteInfo] = useState(null);
  const [routeCoords, setRouteCoords] = useState(null);
  const [showChat, setShowChat] = useState(false);
  const [messages, setMessages] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [msgAlert, setMsgAlert] = useState(null);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [cancelOpen, setCancelOpen] = useState(false);
  const [showRating, setShowRating] = useState(false);
  const [following, setFollowing] = useState(false);
  const [showFullRoute, setShowFullRoute] = useState(true);
  const [mapExpanded, setMapExpanded] = useState(false);
  const [fitKeyTick, setFitKeyTick] = useState(0);
  const [reroutingNotice, setReroutingNotice] = useState(false);
  const hidePanels = mapExpanded;
  const scrollRef = useRef(null);
  const chatSectionRef = useRef(null);
  const seenMsgIdsRef = useRef(null);
  const showChatRef = useRef(false);
  const internalBackRef = useRef({});

  useEffect(() => {
    internalBackRef.current = { cancelOpen, showRating, showChat, mapExpanded };
  }, [cancelOpen, showRating, showChat, mapExpanded]);

  // Botón "atrás" nativo del celular dentro de seguimiento:
  // cierra primero modales, chat o el mapa expandido antes de salir de seguimiento.
  useBackButton(
    () => {
      const st = internalBackRef.current;
      if (st.cancelOpen) {
        setCancelOpen(false);
        return true;
      }
      if (st.showRating) {
        setShowRating(false);
        return true;
      }
      if (st.showChat) {
        setShowChat(false);
        return true;
      }
      if (st.mapExpanded) {
        setMapExpanded(false);
        return true;
      }
      return false;
    },
    true
  );

  const roadHazards = useMemo(() => getAllRoadHazards(), []);

  useEffect(() => {
    showChatRef.current = showChat;
    if (showChat) {
      setUnreadCount(0);
    }
  }, [showChat]);

  // Cargar servicio y suscribirse a cambios en 0ms + respaldo al volver a la pestaña.
  useEffect(() => {
    const load = () => base44.entities.Service.get(serviceId).then(setService).catch(() => {});
    load();
    const unsub = base44.entities.Service.subscribe((event) => {
      if ((event.id || event?.data?.id) === serviceId) {
        if (event?.data) {
          setService((prev) => (prev ? { ...prev, ...event.data } : event.data));
        } else {
          load();
        }
      }
    });
    const onVisible = () => {
      if (typeof document !== 'undefined' && document.visibilityState === 'visible') {
        load();
      }
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      unsub();
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, [serviceId]);

  useEffect(() => {
    if (!service) return;
    if (service.status === 'finalizado') {
      toast({ title: 'Servicio finalizado', description: '¡Llegaste a tu destino! Califica a tu conductor.' });
      if (service.rating == null) {
        setShowRating(true);
      }
    }
    if (service.status === 'cancelado') toast({ title: 'Servicio cancelado', variant: 'destructive' });
    if (service.status === 'pendiente') {
      if (onReassigned) onReassigned();
    }
  }, [service?.status, service?.rating]);

  // Si alguna dirección guardada es genérica ("Valledupar") o una vía sin '#', resolver la dirección exacta con sus coordenadas
  useEffect(() => {
    if (!service?.id) return;
    let cancelled = false;
    (async () => {
      const patch = {};
      if (
        service.pickup_lat != null &&
        service.pickup_lng != null &&
        (!service.pickup_address || /^(valledupar|cesar|colombia)$/i.test(service.pickup_address.trim()))
      ) {
        const revPick = await reverseGeocodeValledupar(
          parseFloat(service.pickup_lat),
          parseFloat(service.pickup_lng)
        );
        if (revPick && revPick !== service.pickup_address) {
          patch.pickup_address = revPick;
        }
      }
      if (
        service.destination_lat != null &&
        service.destination_lng != null &&
        (!service.destination_address || /^(valledupar|cesar|colombia)$/i.test(service.destination_address.trim()))
      ) {
        const revDest = await reverseGeocodeValledupar(
          parseFloat(service.destination_lat),
          parseFloat(service.destination_lng)
        );
        if (revDest && revDest !== service.destination_address) {
          patch.destination_address = revDest;
        }
      }
      if (Array.isArray(service.stops) && service.stops.length > 0) {
        let stopsChanged = false;
        const resolvedStops = await Promise.all(
          service.stops.map(async (st) => {
            if (st?.lat != null && st?.lng != null && isIncompleteStreetAddress(st.address)) {
              const revSt = await reverseGeocodeValledupar(st.lat, st.lng);
              if (revSt && revSt !== st.address) {
                stopsChanged = true;
                return { ...st, address: revSt };
              }
            }
            return st;
          })
        );
        if (stopsChanged) patch.stops = resolvedStops;
      }
      if (!cancelled && Object.keys(patch).length > 0) {
        setService((prev) => (prev ? { ...prev, ...patch } : prev));
        base44.entities.Service.update(service.id, patch).catch(() => {});
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [
    service?.id,
    service?.pickup_address,
    service?.destination_address,
    service?.pickup_lat,
    service?.pickup_lng,
    service?.destination_lat,
    service?.destination_lng,
  ]);

  // Cargar conductor, calificación real y suscribirse a su ubicación en vivo.
  useEffect(() => {
    if (!service?.mobile_id) return;
    let alive = true;
    const loadDriver = () =>
      base44.entities.Mobile.get(service.mobile_id)
        .then((m) => {
          if (!alive || !m) return;
          if (m.vehicle_photo || m.photo_url) {
            preloadStorageUrls([m.vehicle_photo, m.photo_url].filter(Boolean));
          }
          setDriver(m);
        })
        .catch(() => {});
    loadDriver();

    fetchDriverRecentActivity(service.mobile_id)
      .then((info) => {
        if (!alive) return;
        if (info?.current) setDriverTier(info.current);
        if (info?.recentTrips != null) {
          setDriverStats((prev) => ({
            ...prev,
            trips: Math.max(1, info.recentTrips),
          }));
        }
      })
      .catch(() => {});

    base44.entities.Service.aggregate({
      query: { mobile_id: service.mobile_id, status: 'finalizado', rating: { $gt: 0 } },
      groupBy: 'mobile_id',
      avg: 'rating',
    })
      .then((res) => {
        if (!alive) return;
        const row = res?.rows?.[0];
        if (row?.avg_rating) {
          setDriverStats((prev) => ({
            rating: Number(row.avg_rating).toFixed(1),
            trips: Math.max(prev.trips, row.count || 1),
          }));
        }
      })
      .catch(() => {});

    const unsub = base44.entities.Mobile.subscribe((event) => {
      if (event.id === service.mobile_id && event.data) {
        setDriver((prev) => (prev ? { ...prev, ...event.data } : event.data));
      }
    });
    return () => {
      alive = false;
      unsub();
    };
  }, [service?.mobile_id]);

  const phase = service?.status === 'recogida' ? 'to_dest' : 'to_pickup';
  const driverPos =
    driver?.current_lat != null && driver?.current_lng != null
      ? [Number(driver.current_lat), Number(driver.current_lng)]
      : null;
  const pickupPos =
    service?.pickup_lat != null && service?.pickup_lng != null
      ? [parseFloat(service.pickup_lat), parseFloat(service.pickup_lng)]
      : null;
  const destPos =
    service?.destination_lat != null && service?.destination_lng != null
      ? [parseFloat(service.destination_lat), parseFloat(service.destination_lng)]
      : null;

  const bearing = useMemo(() => {
    if (!driverPos) return 0;
    if (routeCoords) {
      const b = routeBearingAt(routeCoords, driverPos[0], driverPos[1]);
      if (b != null) return b;
    }
    const target = phase === 'to_dest' ? destPos : pickupPos;
    return target ? bearingBetween(driverPos[0], driverPos[1], target[0], target[1]) : 0;
  }, [driverPos, routeCoords, phase, pickupPos, destPos]);

  const [phaseStartTs, setPhaseStartTs] = useState(() => Date.now());
  const [elapsedSec, setElapsedSec] = useState(0);
  const [initialToPickupMin, setInitialToPickupMin] = useState(null);
  const [initialToDestMin, setInitialToDestMin] = useState(null);
  const [manualArrivedSignal, setManualArrivedSignal] = useState(false);
  const notifiedArrivalRef = useRef(false);

  useEffect(() => {
    setPhaseStartTs(Date.now());
    setElapsedSec(0);
  }, [phase, service?.id]);

  useEffect(() => {
    if (!service || service.status === 'finalizado' || service.status === 'cancelado') return;
    const t = setInterval(() => {
      setElapsedSec(Math.floor((Date.now() - phaseStartTs) / 1000));
    }, 5000);
    return () => clearInterval(t);
  }, [service?.status, phaseStartTs]);

  const pickupEtaData = useMemo(
    () =>
      calculateCalibratedRouteEta({
        routeInfo: pickupRouteInfo,
        driverPos,
        originPos: driverPos,
        targetPos: pickupPos,
        stops: [],
        vehicleType: driver?.vehicle_type || service?.vehicle_type || 'moto',
        serviceType: service?.service_type || 'transporte',
        elapsedSec: phase === 'to_pickup' ? elapsedSec : 0,
      }),
    [pickupRouteInfo, driverPos, pickupPos, driver?.vehicle_type, service?.vehicle_type, service?.service_type, phase, elapsedSec]
  );

  const destEtaData = useMemo(
    () =>
      calculateCalibratedRouteEta({
        routeInfo: tripRouteInfo,
        driverPos: phase === 'to_dest' ? driverPos : pickupPos,
        originPos: pickupPos,
        targetPos: destPos,
        stops: service?.stops || [],
        vehicleType: driver?.vehicle_type || service?.vehicle_type || 'moto',
        serviceType: service?.service_type || 'transporte',
        elapsedSec: phase === 'to_dest' ? elapsedSec : 0,
      }),
    [tripRouteInfo, phase, driverPos, pickupPos, destPos, service?.stops, driver?.vehicle_type, service?.vehicle_type, service?.service_type, elapsedSec]
  );

  const activeEtaData = phase === 'to_dest' ? destEtaData : pickupEtaData;
  const eta = activeEtaData.etaMin;
  const distKm = activeEtaData.remainingKm;
  const arrivedAtPickup =
    manualArrivedSignal ||
    (phase === 'to_pickup' && Boolean(driverPos && pickupPos && pickupEtaData.arrived));

  useEffect(() => {
    if (phase === 'to_pickup' && pickupEtaData.etaMin != null && pickupEtaData.etaMin > 0) {
      setInitialToPickupMin((prev) => (prev == null ? pickupEtaData.etaMin : Math.max(prev, pickupEtaData.etaMin)));
    }
  }, [phase, pickupEtaData.etaMin]);

  useEffect(() => {
    if (destEtaData.etaMin != null && destEtaData.etaMin > 0) {
      setInitialToDestMin((prev) => (prev == null ? destEtaData.etaMin : Math.max(prev, destEtaData.etaMin)));
    }
  }, [destEtaData.etaMin]);

  // Escuchar todos los mensajes del servicio en tiempo real (0ms directo del evento + respaldo cada 1s)
  useEffect(() => {
    if (!serviceId) return;
    seenMsgIdsRef.current = null;
    let alive = true;

    const notifyDriverMessageInstant = (msg) => {
      if (!msg?.id || isCallSignalMessage(msg)) return;
      if (!seenMsgIdsRef.current) {
        seenMsgIdsRef.current = new Set();
      }
      if (msg.sender_type === 'movil' && (msg.message || '').toLowerCase().includes('punto de recogida')) {
        setManualArrivedSignal(true);
      }
      if (seenMsgIdsRef.current.has(msg.id)) return;
      seenMsgIdsRef.current.add(msg.id);

      setMessages((prev) => (prev.some((x) => x.id === msg.id) ? prev : [...prev, msg]));

      if (msg.sender_type === 'movil') {
        const senderTitle = `Nuevo mensaje de ${msg.sender_name || 'tu conductor'}`;
        playMessageChime(senderTitle, msg.message);
        setMsgAlert({
          id: msg.id,
          title: senderTitle,
          message: msg.message,
        });
        if (!showChatRef.current) {
          setUnreadCount((c) => c + 1);
        }
      }
    };

    const syncMessages = async () => {
      try {
        const res = await base44.entities.ServiceMessage.filter({ service_id: serviceId }, 'created_date', 100);
        if (!alive) return;
        const items = (Array.isArray(res) ? res : res?.items || []).filter((m) => !isCallSignalMessage(m));
        setMessages(items);

        if (items.some((m) => m.sender_type === 'movil' && (m.message || '').toLowerCase().includes('punto de recogida'))) {
          setManualArrivedSignal(true);
        }

        if (seenMsgIdsRef.current === null) {
          seenMsgIdsRef.current = new Set(items.map((m) => m.id));
          return;
        }

        items.forEach((m) => {
          if (m.id && !seenMsgIdsRef.current.has(m.id)) {
            notifyDriverMessageInstant(m);
          }
        });
      } catch {}
    };

    syncMessages();
    const unsub = base44.entities.ServiceMessage.subscribe((ev) => {
      const msg = ev?.data;
      if (msg && msg.service_id === serviceId) {
        notifyDriverMessageInstant(msg);
        return;
      }
      syncMessages();
    });
    const onVisible = () => {
      if (typeof document !== 'undefined' && document.visibilityState === 'visible') {
        syncMessages();
      }
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      alive = false;
      unsub();
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, [serviceId]);

  useEffect(() => {
    if (!msgAlert) return;
    const t = setTimeout(() => setMsgAlert(null), 9000);
    return () => clearTimeout(t);
  }, [msgAlert]);

  useEffect(() => {
    if (!service?.id) return;
    const storageFlag = `next_notified_pickup_arrival_${service.id}`;
    const shouldNotify = arrivedAtPickup || service.status === 'recogida';
    if (!shouldNotify) return;
    if (notifiedArrivalRef.current || localStorage.getItem(storageFlag)) return;

    notifiedArrivalRef.current = true;
    try {
      localStorage.setItem(storageFlag, '1');
    } catch {}
    playArrivalAlertSound();
    recordArrivalNotification(service);
    toast({
      title: '¡Ya llegó tu conductor!',
      description: 'Tu conductor llegó al punto de recogida. Sal, por favor.',
    });
  }, [arrivedAtPickup, service?.status, service?.id, toast]);

  const stopWaypoints = useMemo(
    () =>
      (service?.stops || [])
        .filter((s) => s?.lat != null && s?.lng != null)
        .map((s) => [Number(s.lat), Number(s.lng)]),
    [service?.stops]
  );

  const allPositions = useMemo(() => {
    const pts = [];
    if (driverPos) pts.push(driverPos);
    if (pickupPos) pts.push(pickupPos);
    stopWaypoints.forEach((wp) => pts.push(wp));
    if (destPos) pts.push(destPos);
    return pts;
  }, [driverPos, pickupPos, destPos, stopWaypoints]);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, showChat]);

  const handleOpenChatFromBanner = () => {
    setMsgAlert(null);
    setMapExpanded(false);
    setShowChat(true);
    setUnreadCount(0);
    setTimeout(() => {
      chatSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 120);
  };

  const sendMessage = async (e) => {
    e.preventDefault();
    const clean = text.trim();
    if (!clean) return;
    setText('');
    setSending(true);
    const passengerName = service?.client_name || 'Cliente';
    try {
      const created = await base44.entities.ServiceMessage.create({
        service_id: serviceId,
        sender_type: 'cliente',
        sender_name: passengerName,
        message: clean,
      });
      if (created?.id) {
        seenMsgIdsRef.current?.add(created.id);
        setMessages((prev) => (prev.some((x) => x.id === created.id) ? prev : [...prev, created]));
      }
      // Enviar notificación push inmediata al celular del conductor asignado
      base44.functions
        .invoke('notifyNearbyDrivers', {
          action: 'service_message',
          service_id: serviceId,
          sender_type: 'cliente',
          sender_name: passengerName,
          message: clean,
        })
        .catch(() => {});
    } catch {
      setText(clean);
      toast({ description: 'No se pudo enviar el mensaje', variant: 'destructive' });
    } finally {
      setSending(false);
    }
  };

  const shareTripText = useMemo(() => {
    if (!service) return '';
    const shareUrl = `${window.location.origin}/cliente?service=${serviceId}`;
    const vehSpec = resolveRegisteredVehicleSpec(driver, service);
    const driverName = service?.mobile_name || driver?.name || 'Por asignar';
    const plateStr = vehSpec.plate || service?.mobile_plate || driver?.plate || 'Sin placa';
    const vehicleStr = [vehSpec.modelLine, vehSpec.colorLabel].filter(Boolean).join(' · ') || 'Vehículo registrado';
    const fareStr = fmtCOP(service?.fare || 5000);
    const payStr = PAYMENT_LABELS[service?.payment_method] || service?.payment_method || 'Efectivo';
    const stopsLines = (service?.stops || [])
      .filter((st) => (st?.address || '').trim())
      .map((st, idx) => `📍 *Parada ${idx + 1}:* ${st.address}`)
      .join('\n');

    return [
      '🚖 *Sigue mi viaje en vivo en NEXT*',
      `👤 *Pasajero:* ${service?.client_name || 'Pasajero'}`,
      `🧑‍✈️ *Conductor:* ${driverName}`,
      `🚗 *Vehículo:* ${vehicleStr} (${plateStr})`,
      `🔵 *Recogida:* ${service?.pickup_address || '—'}`,
      stopsLines || null,
      `🟢 *Destino:* ${service?.destination_address || '—'}`,
      `💵 *Valor del servicio:* ${fareStr} (${payStr})`,
      `⏱️ *Tiempo estimado:* ${Math.max(1, Math.round(Number(eta) || 1))} min`,
      pickupPos && destPos
        ? `🗺️ *Ruta GPS exacta:* https://www.google.com/maps/dir/?api=1&origin=${pickupPos[0]},${pickupPos[1]}&destination=${destPos[0]},${destPos[1]}`
        : null,
      '',
      `🔗 *Ver recorrido en tiempo real:* ${shareUrl}`,
    ]
      .filter(Boolean)
      .join('\n');
  }, [service, driver, serviceId, eta, pickupPos, destPos]);

  const shareWhatsAppUrl = useMemo(() => {
    if (!shareTripText) return '#';
    return buildWhatsAppDirectUrl({ text: shareTripText });
  }, [shareTripText]);

  const handleShareTrip = () => {
    if (!shareTripText) return;
    try {
      navigator.clipboard?.writeText(shareTripText).catch(() => {});
    } catch {}
    openWhatsAppDirect({ text: shareTripText });
  };

  const voiceCall = useInAppVoiceCall({
    serviceId,
    selfRole: 'cliente',
    selfName: service?.client_name || 'Pasajero',
    peerName: service?.mobile_name || driver?.name || 'Conductor',
    peerPhoto: service?.mobile_photo || driver?.photo_url || driver?.vehicle_photo || '',
    peerSubtitle: (service?.mobile_plate || driver?.plate || '').toUpperCase()
      ? `Conductor verificado · Placa ${(service?.mobile_plate || driver?.plate || '').toUpperCase()}`
      : 'Conductor verificado NEXT',
    enabled: Boolean(serviceId && service?.status !== 'finalizado' && service?.status !== 'cancelado'),
  });

  if (!service) {
    return (
      <div className="absolute inset-0 z-[1500] flex items-center justify-center bg-background max-w-md mx-auto w-full">
        <Loader2 className="w-8 h-8 animate-spin text-[#1E6BFF]" />
      </div>
    );
  }

  const VIcon = service.vehicle_type === 'carro' ? Car : service.service_type === 'mensajeria' ? Package : Bike;
  const isDone = service.status === 'finalizado' || service.status === 'cancelado';
  const needsRating = service.status === 'finalizado' && service.rating == null;
  const mapCenter = driverPos || pickupPos || [10.4631, -73.2532];
  const driverPhoto = service.mobile_photo || driver?.photo_url || driver?.vehicle_photo || '';

  const vehSpec = resolveRegisteredVehicleSpec(driver, service);
  const { fullVehicleText } = buildVehicleSummary({ driver, service });

  const etaRounded = Math.max(1, Math.round(Number(eta) || 1));
  const distRounded =
    distKm != null && Number.isFinite(Number(distKm))
      ? Math.max(0.1, Number(distKm)).toFixed(1)
      : '0.4';

  const displayPlate = (vehSpec.plate || service.mobile_plate || driver?.plate || '').toUpperCase();

  return (
    <div className="fixed inset-0 z-[1500] flex flex-col max-w-md mx-auto w-full h-full bg-background overflow-hidden">
      <ServiceMessageAlertBanner
        alert={msgAlert}
        onOpen={handleOpenChatFromBanner}
        onDismiss={() => setMsgAlert(null)}
      />

      {/* Mapa interactivo: al tocarlo se abre al 100% de la pantalla completa sin cortes */}
      <div
        className={` isolate w-full overflow-hidden transition-all duration-200 ${
          mapExpanded
            ? 'fixed inset-0 z-[1550] h-full w-full max-w-md mx-auto'
            : 'relative z-0 flex-1 min-h-[50dvh] border-b border-border shadow-sm'
        }`}
        data-testid="passenger-tracking-map"
      >
        <MapboxMap
          center={mapCenter}
          zoom={15.5}
          pitch={showFullRoute || hidePanels ? 0 : 45}
          bearing={showFullRoute || hidePanels ? 0 : bearing}
          className="h-full w-full"
          onMapClick={() => setMapExpanded((v) => !v)}
          onDragStart={() => setFollowing(false)}
        >
          {/* Vehículo en vivo con su color real */}
          {driverPos && (
            <MapboxMarker
              key={`drv-mk-${driver?.vehicle_type || service.vehicle_type}-${driver?.car_subtype || ''}-${driver?.plate_type || ''}-${driver?.vehicle_color || ''}`}
              lat={driverPos[0]}
              lng={driverPos[1]}
              el={() => {
                const isCar = (driver?.vehicle_type || service.vehicle_type) === 'carro';
                const isTaxiOrYellow = isCar && driver?.car_subtype === 'taxi';
                const colorSpec = driver?.vehicle_color ? driver.vehicle_color : isTaxiOrYellow;
                return isCar ? topDownCarMarkerEl(38, colorSpec) : topDownMotoMarkerEl(35, driver?.vehicle_color || '');
              }}
              rotation={bearing}
              smooth
            />
          )}

          {/* Burbuja flotante en el mapa junto al vehículo: "Llegada en / 1 min / (0.4 km)" */}
          {driverPos && !isDone && (
            <MapboxMarker
              key={`drv-eta-bubble-${etaRounded}-${distRounded}-${phase}`}
              lat={driverPos[0]}
              lng={driverPos[1]}
              el={() =>
                etaFloatingBubbleEl(
                  etaRounded,
                  Number(distRounded),
                  phase === 'to_pickup' ? 'Llegada en' : 'Destino en'
                )
              }
              interactive={false}
            />
          )}

          {/* Punto azul con halo en el punto de recogida */}
          {pickupPos && (
            <MapboxMarker
              lat={pickupPos[0]}
              lng={pickupPos[1]}
              el={() => bluePulsePointEl()}
              anchor="center"
              interactive={false}
            />
          )}

          {/* Paradas intermedias */}
          {(service.stops || []).map((st, idx) =>
            st?.lat != null && st?.lng != null ? (
              <MapboxMarker
                key={`stop-${idx}`}
                lat={st.lat}
                lng={st.lng}
                el={() => stopPinEl(idx + 1, shortAddress(st.address) || st.address, false)}
                labelTitle={`Parada ${idx + 1}`}
                labelAddress={shortAddress(st.address) || st.address}
                showBubble={false}
                anchor="bottom"
                interactive={false}
              />
            ) : null
          )}

          {/* Pin rojo en el punto de destino */}
          {destPos && (
            <MapboxMarker
              lat={destPos[0]}
              lng={destPos[1]}
              el={() => redDestinationPinEl()}
              anchor="bottom"
              interactive={false}
            />
          )}

          {/* Fotomultas y obras viales activas en el mapa */}
          {roadHazards.map((hz) => (
            <MapboxMarker
              key={hz.id}
              lat={hz.lat}
              lng={hz.lng}
              el={() => roadHazardMarkerEl(hz)}
              anchor="bottom"
              interactive={false}
            />
          ))}

          {/* Tramo 1: Conductor -> Punto A con recálculo automático si cambia de ruta */}
          {phase === 'to_pickup' && driverPos && pickupPos && (
            <MapboxDrivingRoute
              from={driverPos}
              to={pickupPos}
              color={ROUTE_BLUE}
              width={6}
              opacity={0.95}
              trimFromPos={driverPos}
              onReroute={() => {
                setReroutingNotice(true);
                setTimeout(() => setReroutingNotice(false), 2600);
              }}
              onRouteInfo={(info) => {
                setPickupRouteInfo(info);
                setRouteCoords(info?.coords || null);
              }}
            />
          )}

          {/* Tramo 2: Punto A -> Paradas -> Destino final con recálculo automático */}
          {pickupPos && destPos && (
            <MapboxDrivingRoute
              from={phase === 'to_dest' && driverPos ? driverPos : pickupPos}
              to={destPos}
              waypoints={stopWaypoints}
              color={ROUTE_BLUE}
              width={phase === 'to_dest' ? 6 : 5}
              opacity={phase === 'to_dest' ? 0.95 : 0.85}
              trimFromPos={phase === 'to_dest' ? driverPos : null}
              onReroute={() => {
                setReroutingNotice(true);
                setTimeout(() => setReroutingNotice(false), 2600);
              }}
              onRouteInfo={(info) => {
                setTripRouteInfo(info);
                if (phase === 'to_dest') {
                  setRouteCoords(info?.coords || null);
                }
              }}
            />
          )}

          {following && driverPos && (
            <MapboxFollowCenter center={driverPos} bearing={bearing} pitch={45} zoom={16.5} />
          )}
          {!following && allPositions.length > 0 && (
            <MapboxFitBounds
              positions={allPositions}
              padding={mapExpanded ? 55 : { top: 75, bottom: 55, left: 45, right: 45 }}
              singleZoom={15.2}
              fitKey={`${mapExpanded ? 'expanded' : 'normal'}-${fitKeyTick}`}
            />
          )}
        </MapboxMap>

        {/* Controles flotantes superiores sobre el mapa */}
        <div className="absolute top-3 inset-x-4 z-20 flex items-center justify-between pointer-events-none">
          <button
            type="button"
            onClick={() => {
              if (mapExpanded) {
                setMapExpanded(false);
              } else {
                onFinish?.({ clearActive: isDone });
              }
            }}
            aria-label="Menú o volver"
            className="pointer-events-auto w-11 h-11 rounded-full bg-white dark:bg-card shadow-lg border border-slate-200/70 dark:border-border flex items-center justify-center text-slate-900 dark:text-foreground active:scale-95 transition-transform"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Indicador oculto para pruebas automatizadas que leen el resumen del vehículo */}
          <span className="sr-only" data-testid="tracking-top-status">
            {fullVehicleText}
          </span>

          <button
            type="button"
            onClick={() => {
              setFollowing(false);
              setShowFullRoute(true);
              setFitKeyTick((t) => t + 1);
            }}
            aria-label="Centrar ruta"
            className="pointer-events-auto w-11 h-11 rounded-full bg-white dark:bg-card shadow-lg border border-slate-200/70 dark:border-border flex items-center justify-center text-slate-900 dark:text-foreground active:scale-95 transition-transform"
          >
            <LocateFixed className="w-5 h-5" />
          </button>
        </div>

        {/* Botón flotante de recentrar sobre la esquina inferior derecha del mapa */}
        {!hidePanels && (
          <div className="absolute bottom-8 right-4 z-20 pointer-events-none">
            <button
              type="button"
              onClick={() => {
                setFollowing(false);
                setFitKeyTick((t) => t + 1);
              }}
              aria-label="Ajustar vista del mapa"
              className="pointer-events-auto w-10 h-10 rounded-full bg-white dark:bg-card shadow-lg border border-slate-200/80 dark:border-border flex items-center justify-center text-slate-800 dark:text-foreground active:scale-95 transition-transform"
            >
              <LocateFixed className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Botón flotante compacto cuando el mapa está abierto a pantalla completa (100%) */}
        {mapExpanded && !isDone && (
          <div className="absolute bottom-5 inset-x-4 z-20 flex justify-center pointer-events-none">
            <button
              type="button"
              onClick={() => setMapExpanded(false)}
              data-testid="restore-tracking-sheet-btn"
              className="pointer-events-auto px-5 h-11 rounded-full bg-[#0B439C] text-white text-xs font-extrabold shadow-2xl border border-white/25 flex items-center justify-center gap-2 active:scale-95 transition-transform"
            >
              <span>Ver detalles del viaje</span>
              {displayPlate && (
                <span className="px-2 py-0.5 rounded bg-amber-400 text-slate-950 font-black tracking-wider">
                  {displayPlate}
                </span>
              )}
            </button>
          </div>
        )}
      </div>

      {/* Tarjeta inferior principal */}
      <div
        className={`${
          mapExpanded && !isDone ? 'hidden' : ''
        } relative z-30 -mt-5 w-full max-h-[50dvh] overflow-y-auto no-scrollbar bg-white dark:bg-card border-t border-slate-200/70 dark:border-border/70 rounded-t-[28px] shadow-[0_-10px_35px_rgba(15,23,42,0.18)] px-4 pt-3 pb-4 transition-all duration-200 ease-out`}
      >
        <div
          onClick={() => setMapExpanded(true)}
          title="Toca para ver el mapa completo"
          className="w-10 h-1 rounded-full bg-slate-300 dark:bg-border mx-auto mb-2.5 cursor-pointer"
        />

        {/* Fila 1: Foto del conductor con check azul + Nombre + Estrellas + Vehículo + Placa bien visible (sin botones repetidos al costado) */}
        <div className="flex items-center justify-between gap-2.5 mb-2.5">
          <div className="flex items-center gap-3 min-w-0 flex-1">
            <div className="relative flex-shrink-0">
              <ResolvedAvatar
                photo={driverPhoto}
                name={service.mobile_name || driver?.name || 'Conductor'}
                className="w-13 h-13 w-12 h-12 rounded-full bg-slate-100 dark:bg-muted border-2 border-[#1463FF] text-foreground font-bold shadow-sm"
                fallback={<VIcon className="w-6 h-6 text-muted-foreground" />}
              />
              <span
                className="absolute -bottom-0.5 -right-0.5 w-4.5 h-4.5 w-5 h-5 rounded-full bg-[#1463FF] text-white flex items-center justify-center shadow border-2 border-white dark:border-card"
                title={`Conductor verificado · Nivel ${driverTier.name}`}
              >
                <Check className="w-3 h-3 stroke-[3]" />
              </span>
            </div>

            <div className="flex-1 min-w-0">
              <p className="text-[#0F172A] dark:text-white font-extrabold text-base leading-tight truncate">
                {service.mobile_name || driver?.name || 'Conductor'}
              </p>
              <div className="flex items-center gap-1 text-xs mt-0.5">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400 flex-shrink-0" />
                <span className="font-extrabold text-[#0F172A] dark:text-white">
                  {driverStats.rating}
                </span>
                <span className="text-slate-500 dark:text-slate-400 font-medium">
                  ({driverStats.trips} viajes)
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-slate-700 dark:text-slate-200 font-bold mt-0.5">
                <VIcon className="w-3.5 h-3.5 text-slate-800 dark:text-slate-200 flex-shrink-0" />
                <span
                  className="w-3 h-3 rounded-sm border border-slate-400 flex-shrink-0 shadow-2xs"
                  style={{ backgroundColor: vehSpec.palette?.bodyFill || '#F8FAFC' }}
                  title={`Color ${vehSpec.colorLabel}`}
                />
                <span className="truncate" data-testid="vehicle-identity-label">
                  {[vehSpec.modelLine, vehSpec.colorLabel]
                    .filter(Boolean)
                    .join(' • ') || fullVehicleText}
                </span>
              </div>
            </div>
          </div>

          {/* Placa del vehículo destacada claramente al costado */}
          {displayPlate && (
            <div
              data-testid="driver-plate-badge"
              className={`flex-shrink-0 px-2.5 py-1 rounded-xl border-2 shadow-sm text-center ${
                vehSpec.isTaxi || driver?.plate_type === 'blanca'
                  ? 'bg-white text-slate-950 border-slate-400'
                  : 'bg-amber-400 text-slate-950 border-amber-600'
              }`}
            >
              <span className="block text-[8px] font-black uppercase tracking-widest leading-none opacity-75">
                PLACA
              </span>
              <span className="block font-mono font-black text-sm tracking-wider leading-tight mt-0.5">
                {displayPlate}
              </span>
            </div>
          )}
        </div>

        {/* Fila 2: Tarjeta celeste con la imagen del vehículo registrado (Renault, Chevrolet, Moto, etc.), "Llegada en 1 min (0.4 km)" y círculo de progreso */}
        {!isDone && (
          <SeguimientoEtaBanner
            phase={phase}
            etaMin={eta}
            remainingKm={distKm}
            initialMin={phase === 'to_pickup' ? initialToPickupMin : initialToDestMin}
            driver={driver}
            service={service}
          />
        )}

        {/* Fila 3: 3 botones de acción seguros tipo inDrive (sin exponer números ni WhatsApp personal): Compartir viaje | Llamada en app | Mensaje */}
        {!isDone && (
          <div className="grid grid-cols-3 gap-2 mb-3">
            <a
              href={shareWhatsAppUrl}
              onClick={(e) => {
                e.preventDefault();
                handleShareTrip();
              }}
              data-testid="share-trip-whatsapp-btn"
              className="h-[68px] rounded-2xl bg-[#EAF2FF] dark:bg-[#1E6BFF]/20 border border-[#1463FF]/25 flex flex-col items-center justify-center gap-1 px-1 text-[#0B439C] dark:text-[#60A5FA] active:scale-95 transition-transform"
            >
              <ShareTripOriginalIcon className="w-7 h-7 flex-shrink-0" />
              <span className="text-[10.5px] font-extrabold leading-tight text-center">
                Compartir viaje
              </span>
            </a>

            <button
              type="button"
              onClick={() => voiceCall.startCall()}
              data-testid="passenger-inapp-call-btn"
              className="h-[68px] rounded-2xl bg-slate-50 dark:bg-muted border border-slate-200/80 dark:border-border flex flex-col items-center justify-center gap-1 px-1 text-[#0F172A] dark:text-white active:scale-95 transition-transform"
            >
              <PhoneCallOriginalIcon className="w-7 h-7 flex-shrink-0" />
              <span className="text-[11px] font-extrabold leading-tight text-center">
                Llamar
              </span>
            </button>

            <button
              type="button"
              onClick={() => {
                setShowChat((v) => !v);
                setUnreadCount(0);
                setMsgAlert(null);
              }}
              data-testid="passenger-open-chat-btn"
              className="relative h-[68px] rounded-2xl bg-slate-50 dark:bg-muted border border-slate-200/80 dark:border-border flex flex-col items-center justify-center gap-1 px-1 text-[#0F172A] dark:text-white active:scale-95 transition-transform"
            >
              <ChatMessageOriginalIcon className="w-7 h-7 flex-shrink-0" />
              <span className="text-[11px] font-extrabold leading-tight">Mensaje</span>
              {unreadCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 min-w-[20px] h-5 px-1.5 rounded-full bg-rose-500 text-white text-[10px] font-black flex items-center justify-center shadow">
                  {unreadCount}
                </span>
              )}
            </button>
          </div>
        )}

        {/* Chat embebido al pulsar Mensaje */}
        {showChat && !isDone && (
          <div ref={chatSectionRef} className="bg-slate-50 dark:bg-muted rounded-2xl p-3 mb-3 border border-border">
            <div ref={scrollRef} className="h-36 overflow-y-auto space-y-2 mb-2 bg-white dark:bg-card rounded-xl p-2 no-scrollbar">
              {messages.length === 0 ? (
                <p className="text-center text-xs text-muted-foreground py-6">
                  Escribe el primer mensaje a tu conductor
                </p>
              ) : (
                messages.map((m) => (
                  <div key={m.id} className={`flex ${m.sender_type === 'cliente' ? 'justify-end' : 'justify-start'}`}>
                    <div
                      className={`max-w-[78%] rounded-2xl px-3 py-2 text-sm ${
                        m.sender_type === 'cliente'
                          ? 'bg-[#1463FF] text-white rounded-br-sm'
                          : 'bg-muted text-foreground rounded-bl-sm'
                      }`}
                    >
                      {m.sender_type !== 'cliente' && (
                        <p className="text-xs font-medium mb-0.5 opacity-70">{m.sender_name}</p>
                      )}
                      <p>{m.message}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
            <form onSubmit={sendMessage} className="flex gap-2 items-center">
              <input
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Escribe un mensaje..."
                className="flex-1 min-w-0 h-10 rounded-xl border border-border bg-white dark:bg-card px-3 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-[#1463FF]"
              />
              <button
                type="submit"
                disabled={sending || !text.trim()}
                className="w-10 h-10 rounded-xl bg-[#1463FF] text-white flex items-center justify-center disabled:opacity-50 flex-shrink-0"
              >
                {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              </button>
            </form>
          </div>
        )}

        {/* Fila 4: Tarjeta de Recogida, Destino y Valor del servicio */}
        <div className="bg-slate-50/90 dark:bg-muted/70 border border-slate-200/70 dark:border-border rounded-2xl px-3.5 py-2.5 mb-3 space-y-2.5">
          {/* Valor del servicio y método de pago visible para el pasajero */}
          <div
            className="flex items-center justify-between gap-2 pb-2 border-b border-slate-200/80 dark:border-border"
            data-testid="passenger-service-fare-row"
          >
            <div className="flex items-center gap-2 min-w-0">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center flex-shrink-0">
                <Banknote className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <p className="text-[10.5px] font-semibold text-slate-500 dark:text-slate-400 leading-tight">
                  Valor del servicio
                </p>
                <p className="text-xs font-bold text-slate-700 dark:text-slate-300 truncate">
                  {PAYMENT_LABELS[service.payment_method] || service.payment_method || 'Efectivo'}
                </p>
              </div>
            </div>
            <p
              className="text-lg font-black text-emerald-600 dark:text-emerald-400 flex-shrink-0"
              data-testid="passenger-service-fare-value"
            >
              {fmtCOP(service.fare || 5000)}
            </p>
          </div>
          <div className="flex items-stretch gap-3">
            <div className="flex flex-col items-center py-1">
              <span className="w-3 h-3 rounded-full bg-[#1463FF] flex-shrink-0 shadow-xs" />
              <span className="w-0.5 flex-1 bg-slate-300 dark:bg-slate-600 my-1" />
              <span className="w-3 h-3 rounded-full bg-[#16A34A] flex-shrink-0 shadow-xs" />
            </div>
            <div className="flex-1 min-w-0 space-y-2">
              <div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium leading-tight">
                  Recogida
                </p>
                <p className="text-[13.5px] font-bold text-[#0F172A] dark:text-white truncate leading-snug">
                  {shortAddress(service.pickup_address) || service.pickup_address}
                </p>
              </div>
              {(service.stops || [])
                .filter((st) => (st?.address || '').trim())
                .map((st, idx) => (
                  <div key={idx}>
                    <p className="text-[10.5px] text-amber-600 dark:text-amber-400 font-bold leading-tight">
                      Parada {idx + 1}
                    </p>
                    <p className="text-xs font-semibold text-[#0F172A] dark:text-white truncate">
                      {shortAddress(st.address) || st.address}
                    </p>
                  </div>
                ))}
              <div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium leading-tight">
                  Destino
                </p>
                <p className="text-[13.5px] font-bold text-[#0F172A] dark:text-white truncate leading-snug">
                  {shortAddress(service.destination_address) || service.destination_address}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Fila 5: Botón azul "Seguir en el mapa" + opción de cancelar */}
        {isDone ? (
          needsRating ? (
            <div className="space-y-2">
              <button
                onClick={() => setShowRating(true)}
                className="w-full h-12 rounded-full bg-[#0B439C] text-white font-extrabold text-sm shadow-lg flex items-center justify-center gap-2"
              >
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" /> Calificar a tu conductor
              </button>
              <button
                onClick={() => onFinish?.({ clearActive: true })}
                className="w-full h-9 rounded-full text-muted-foreground text-xs font-semibold hover:text-foreground"
              >
                Volver al inicio
              </button>
            </div>
          ) : (
            <div className="space-y-2">
              {service.rating > 0 && (
                <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-2.5 text-center">
                  <div className="flex items-center justify-center gap-1 mb-0.5">
                    {[1, 2, 3, 4, 5].map((n) => (
                      <Star
                        key={n}
                        className={`w-4 h-4 ${
                          n <= service.rating ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground/30'
                        }`}
                      />
                    ))}
                  </div>
                  <p className="text-xs font-bold text-foreground">
                    Calificaste este viaje con {service.rating} {service.rating === 1 ? 'estrella' : 'estrellas'}
                  </p>
                </div>
              )}
              <button
                onClick={() => onFinish?.({ clearActive: true })}
                className="w-full h-12 rounded-full bg-[#0B439C] text-white font-extrabold text-sm shadow-lg"
              >
                {service.status === 'finalizado' ? 'Finalizar' : 'Volver al inicio'}
              </button>
            </div>
          )
        ) : (
          <div className="space-y-2">
            <button
              type="button"
              onClick={() => {
                setFollowing(true);
                setShowFullRoute(false);
                setMapExpanded(true);
              }}
              data-testid="follow-mobile-btn"
              className="w-full h-12 rounded-full bg-[#0B439C] hover:bg-[#09357A] text-white font-extrabold text-sm shadow-lg shadow-[#0B439C]/30 flex items-center justify-center gap-2 active:scale-[0.99] transition-transform"
            >
              <MapPin className="w-4 h-4 fill-white/20" />
              <span>Seguir en el mapa</span>
            </button>
            <button
              type="button"
              onClick={() => setCancelOpen(true)}
              className="w-full h-8 text-xs font-bold text-slate-400 hover:text-destructive transition-colors"
            >
              Cancelar servicio
            </button>
          </div>
        )}
      </div>

      {cancelOpen && (
        <CancelRequestModal
          serviceId={serviceId}
          mobileId={service?.mobile_id}
          mobileName={service?.mobile_name}
          onCancelled={() => onFinish?.({ clearActive: true })}
          onClose={() => setCancelOpen(false)}
        />
      )}

      {showRating && (
        <ServiceRatingModal
          serviceId={serviceId}
          role="cliente"
          targetName={service.mobile_name || driver?.name}
          targetPhoto={driverPhoto}
          onDone={() => {
            setShowRating(false);
            onFinish?.({ clearActive: true });
          }}
        />
      )}

      <InAppVoiceCallModal call={voiceCall} />
    </div>
  );
}
import React, { useState } from 'react';
import {
  ChevronLeft,
  Car,
  Bike,
  Sparkles,
  MapPin,
  Navigation,
  Wallet,
  Info,
  ArrowRight,
  Gift,
} from 'lucide-react';
import Vehicle3DIcon from '@/components/shared/Vehicle3DIcon';

const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');
const fmtNum = (n) => Number(n || 0).toLocaleString('es-CO');

const VEHICLE_OPTIONS = [
  {
    key: 'moto',
    label: 'Carrera en Moto',
    minPoints: 5000,
    subtitle: 'Desde 5.000 puntos ($5.000 COP)',
    img: 'https://media.base44.com/images/public/6ab13aed46d61158e305a1ce/dc499356e_generated_image.png',
    flip: true,
  },
  {
    key: 'carro',
    label: 'Carrera en Carro',
    minPoints: 8000,
    subtitle: 'Desde 8.000 puntos ($8.000 COP)',
    img: 'https://media.base44.com/images/public/6ab13aed46d61158e305a1ce/ac3f196ed_generated_image.png',
  },
];

const PRESET_AMOUNTS = [
  { points: 5000, vehicle: 'moto', label: '5.000 pts', cop: '$5.000 (Moto)' },
  { points: 8000, vehicle: 'carro', label: '8.000 pts', cop: '$8.000 (Carro)' },
  { points: 10000, vehicle: 'carro', label: '10.000 pts', cop: '$10.000' },
  { points: 15000, vehicle: 'carro', label: '15.000 pts', cop: '$15.000' },
];

export default function RedimirCarreraView({
  pointsBalance = 0,
  onBack,
  onStartRedeemRide,
}) {
  const [vehicleType, setVehicleType] = useState('moto');
  const [selectedPoints, setSelectedPoints] = useState(5000);

  const handleSelectVehicle = (vKey) => {
    setVehicleType(vKey);
    const minPts = vKey === 'carro' ? 8000 : 5000;
    if (selectedPoints < minPts) {
      setSelectedPoints(minPts);
    }
  };

  return (
    <div className="fixed inset-0 z-[1900] bg-background w-full max-w-md mx-auto flex flex-col pb-[56px]">
      {/* Cabecera */}
      <div className="px-4 pt-5 pb-5 bg-gradient-to-br from-[#062B6E] via-[#1E6BFF] to-[#00B8D4] text-white">
        <div className="flex items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              aria-label="Volver"
              className="w-9 h-9 rounded-full bg-white/15 flex items-center justify-center active:scale-95"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <Car className="w-5 h-5 text-[#00E5FF]" />
              <h1 className="text-lg font-extrabold">Redimir en Carrera</h1>
            </div>
          </div>

          <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/15 text-xs font-extrabold">
            <Sparkles className="w-3.5 h-3.5 text-[#00E5FF]" />
            {fmtNum(pointsBalance)} pts
          </span>
        </div>

        <div className="bg-white/10 backdrop-blur-md border border-white/15 rounded-2xl p-4">
          <p className="text-white/80 text-xs font-bold uppercase tracking-wider">
            Viaja pagando con tus puntos (1 punto = $1 COP)
          </p>
          <p className="text-xl font-extrabold mt-1 leading-snug">
            Equivalencia: {fmtNum(selectedPoints)} puntos = {fmtCOP(selectedPoints)}
          </p>
          <p className="text-[11.5px] text-white/85 mt-1 leading-relaxed">
            Coloca la dirección del <span className="font-bold">Punto A</span> y del <span className="font-bold">Punto B</span>. Tu solicitud saldrá marcada como <span className="font-bold text-[#00E5FF]">Redimido por puntos</span> y ese dinero se sumará directo a la billetera del conductor.
          </p>
        </div>
      </div>

      {/* Contenido */}
      <div className="flex-1 overflow-y-auto no-scrollbar px-4 py-4 space-y-5">
        {/* Selección de vehículo */}
        <section>
          <p className="text-xs font-extrabold text-muted-foreground uppercase tracking-wider mb-2.5">
            1. Elige el vehículo para tu carrera
          </p>
          <div className="grid grid-cols-2 gap-3">
            {VEHICLE_OPTIONS.map((v) => {
              const active = vehicleType === v.key;
              return (
                <button
                  key={v.key}
                  type="button"
                  onClick={() => handleSelectVehicle(v.key)}
                  className={`rounded-2xl border-2 p-3 text-left transition-all flex flex-col items-center text-center ${
                    active
                      ? 'border-[#1E6BFF] bg-[#1E6BFF]/10 shadow-sm'
                      : 'border-border bg-card'
                  }`}
                >
                  <Vehicle3DIcon
                    src={v.img}
                    alt={v.label}
                    flip={v.flip}
                    scale={0.92}
                    className="w-20 h-12 mb-1.5"
                  />
                  <p className="text-sm font-extrabold text-foreground">{v.label}</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5">{v.subtitle}</p>
                </button>
              );
            })}
          </div>
        </section>

        {/* Monto rápido de puntos a redimir */}
        <section>
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs font-extrabold text-muted-foreground uppercase tracking-wider">
              2. Monto de puntos a redimir (1 pto = $1)
            </p>
            <span className="text-xs font-bold text-[#1E6BFF]">
              {fmtCOP(selectedPoints)}
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2.5">
            {PRESET_AMOUNTS.map((item) => {
              const active = selectedPoints === item.points;
              return (
                <button
                  key={item.points}
                  type="button"
                  onClick={() => {
                    setSelectedPoints(item.points);
                    if (item.points >= 8000 && vehicleType === 'moto' && item.vehicle === 'carro') {
                      setVehicleType('carro');
                    } else if (item.points < 8000) {
                      setVehicleType('moto');
                    }
                  }}
                  className={`rounded-2xl border p-3 text-left transition-all flex items-center justify-between ${
                    active
                      ? 'border-[#1E6BFF] bg-[#1E6BFF]/10'
                      : 'border-border bg-card'
                  }`}
                >
                  <div>
                    <p className="text-sm font-extrabold text-foreground">{item.label}</p>
                    <p className="text-[11px] text-muted-foreground font-semibold">{item.cop}</p>
                  </div>
                  <Gift className={`w-4 h-4 ${active ? 'text-[#1E6BFF]' : 'text-muted-foreground'}`} />
                </button>
              );
            })}
          </div>
        </section>

        {/* Explicación para pasajero y conductor */}
        <div className="rounded-2xl bg-[#1E6BFF]/5 border border-[#1E6BFF]/20 p-4 space-y-2">
          <div className="flex items-center gap-2 text-[#1E6BFF] font-extrabold text-xs">
            <Wallet className="w-4 h-4" />
            <span>¿Cómo funciona el servicio redimido por puntos?</span>
          </div>
          <p className="text-[11.5px] text-muted-foreground leading-relaxed">
            • Al tocar el botón inferior, se abrirá automáticamente el buscador para que coloques tu dirección de <span className="font-bold text-foreground">Punto A (origen)</span> y <span className="font-bold text-foreground">Punto B (destino)</span>.
          </p>
          <p className="text-[11.5px] text-muted-foreground leading-relaxed">
            • El conductor verá en su pantalla que el viaje es <span className="font-bold text-foreground">«Redimido por puntos»</span> y, al finalizar la carrera, esos <span className="font-bold text-foreground">{fmtCOP(selectedPoints)}</span> se sumarán directamente a su <span className="font-bold text-foreground">Cartera de conductor</span> para activar sus próximos pases de 14 horas.
          </p>
        </div>

        <button
          type="button"
          onClick={() =>
            onStartRedeemRide?.({
              vehicleType,
              fare: selectedPoints,
            })
          }
          className="w-full h-14 rounded-full bg-gradient-to-r from-[#062B6E] via-[#1E6BFF] to-[#00B8D4] text-white font-extrabold text-sm flex items-center justify-center gap-2.5 shadow-lg active:scale-[0.99] transition-transform"
        >
          <MapPin className="w-5 h-5" />
          <span>Colocar dirección Punto A y Punto B</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
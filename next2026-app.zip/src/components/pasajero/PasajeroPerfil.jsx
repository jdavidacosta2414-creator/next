import React, { useState, useEffect } from 'react';
import {
  ChevronLeft,
  Mail,
  Phone,
  Star,
  Clock,
  Gift,
  PackageSearch,
  Bike,
  Car,
  LogOut,
  ChevronRight,
  Loader2,
  CreditCard,
  Calendar,
  User as UserIcon,
  Camera,
  Hash,
} from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import ResolvedAvatar, { resolveStorageUrl, seedStorageUrlCache } from '@/components/shared/ResolvedAvatar';
import { uploadRegistrationPhoto } from '@/lib/image';

const fmtRegDate = (d) => {
  if (!d) return '—';
  try {
    return new Date(d).toLocaleDateString('es-CO', {
      day: '2-digit',
      month: 'long',
      year: 'numeric',
      timeZone: 'America/Bogota',
    });
  } catch {
    return '—';
  }
};

export default function PasajeroPerfil({
  user,
  mobileProfile,
  onBack,
  onHistorial,
  onPuntos,
  onObjetos,
  onUpdated,
}) {
  const { checkUserAuth } = useAuth();
  const { toast } = useToast();
  const [rating, setRating] = useState(null);
  const [tripCount, setTripCount] = useState(0);
  const [checkingDriver, setCheckingDriver] = useState(false);

  const currentName = user?.display_name || mobileProfile?.name || user?.full_name || '';
  const currentPhone = user?.phone || mobileProfile?.phone || '';
  const currentCedula = user?.cedula || mobileProfile?.cedula || '';
  const currentPhoto =
    user?.photo_url || mobileProfile?.photo_url || '';

  const [photoUri, setPhotoUri] = useState(currentPhoto);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);

  useEffect(() => {
    setPhotoUri(
      user?.photo_url || mobileProfile?.photo_url || ''
    );
  }, [user, mobileProfile]);

  useEffect(() => {
    if (!user?.id) return;
    base44.entities.Service.filter({ created_by_id: user.id }, '-created_date', 100)
      .then((list) => {
        const items = list?.items || list || [];
        const finalized = items.filter((s) => s.status === 'finalizado');
        setTripCount(finalized.length);
        const rated = finalized.filter(
          (s) => typeof s.driver_rating === 'number' && s.driver_rating > 0
        );
        if (rated.length) {
          setRating((rated.reduce((a, s) => a + s.driver_rating, 0) / rated.length).toFixed(2));
        }
      })
      .catch(() => {});
  }, [user]);

  const handlePhotoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (e.target) e.target.value = '';
    if (!file) return;
    const localBlobUrl = URL.createObjectURL(file);
    setPhotoUri(localBlobUrl);
    setUploadingPhoto(true);
    try {
      const { file_uri, previewUrl } = await uploadRegistrationPhoto(file, 1024, 0.78);
      seedStorageUrlCache(file_uri, previewUrl || localBlobUrl);
      resolveStorageUrl(file_uri).catch(() => {});
      setPhotoUri(file_uri);
      await base44.auth.updateMe({ photo_url: file_uri });
      if (mobileProfile?.id) {
        await base44.entities.Mobile.update(mobileProfile.id, { photo_url: file_uri }).catch(
          () => {}
        );
      }
      await checkUserAuth?.();
      onUpdated?.({
        name: currentName,
        phone: currentPhone,
        cedula: currentCedula,
        photo_url: file_uri,
      });
      toast({ description: 'Foto de perfil actualizada.' });
    } catch (err) {
      toast({
        title: 'No se pudo subir la foto',
        description: err?.message || 'Intenta nuevamente.',
        variant: 'destructive',
      });
    } finally {
      setUploadingPhoto(false);
    }
  };

  const switchToDriver = async () => {
    setCheckingDriver(true);
    try {
      let hasProfile = Boolean(mobileProfile?.id);
      if (!hasProfile && user?.email) {
        try {
          const existing = await base44.entities.Mobile.filter({ email: user.email });
          const arr = existing?.items || existing || [];
          hasProfile = arr.length > 0;
        } catch {}
      }
      window.location.replace(hasProfile ? '/movil' : '/vinculate/conductor');
    } finally {
      setCheckingDriver(false);
    }
  };

  const displayName = currentName || 'Pasajero NEXT';
  const emailAddr = user?.email || mobileProfile?.email || '—';
  const regDate = fmtRegDate(user?.created_date || mobileProfile?.created_date);

  return (
    <div className="fixed inset-0 z-[1800] bg-background flex flex-col max-w-md mx-auto w-full pb-[56px]">
      <div className="flex items-center gap-3 px-4 h-14 bg-card border-b border-border flex-shrink-0">
        <button
          onClick={onBack}
          aria-label="Volver"
          className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-muted"
        >
          <ChevronLeft className="w-6 h-6 text-foreground" />
        </button>
        <h1 className="text-foreground font-bold text-base flex-1">Mi perfil</h1>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pt-5 pb-8 space-y-4">
        {/* Tarjeta principal con foto de perfil compartida Pasajero / Conductor */}
        <div className="bg-card rounded-2xl p-5 border border-border shadow-sm">
          <div className="flex items-center gap-4">
            <div className="relative flex-shrink-0">
              <ResolvedAvatar
                photo={photoUri || currentPhoto}
                name={displayName}
                className="w-20 h-20 rounded-full bg-[#0284C7]/15 text-[#0284C7] border-2 border-[#0284C7]/40 font-extrabold text-2xl shadow-sm"
              />
              <div
                aria-label="Cambiar foto de perfil"
                data-photo-picker="true"
                className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-[#0284C7] text-white flex items-center justify-center shadow-md cursor-pointer hover:bg-[#0369A1] transition-colors overflow-hidden"
              >
                {uploadingPhoto ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Camera className="w-4 h-4" />
                )}
                <input
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  onClick={() => {
                    if (typeof window !== 'undefined') {
                      window.__nextFilePickerOpenUntil = Date.now() + 60000;
                    }
                  }}
                  disabled={uploadingPhoto}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                />
              </div>
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-foreground font-extrabold text-lg truncate">
                  {currentName || 'Pasajero NEXT'}
                </h2>
              </div>
              <p className="text-muted-foreground text-xs flex items-center gap-1.5 truncate mt-0.5">
                <Mail className="w-3.5 h-3.5 flex-shrink-0 text-[#0284C7]" /> {emailAddr}
              </p>
              <p className="text-muted-foreground text-xs flex items-center gap-1.5 truncate mt-1">
                <Phone className="w-3.5 h-3.5 flex-shrink-0 text-[#0284C7]" />
                {currentPhone || 'Sin teléfono registrado'}
              </p>
              <div className="flex items-center gap-2.5 mt-2.5 flex-wrap">
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-500 bg-amber-500/10 px-2.5 py-0.5 rounded-full">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  {rating || '5.0'}
                </span>
                <span className="text-xs text-muted-foreground font-medium">
                  {tripCount} {tripCount === 1 ? 'viaje finalizado' : 'viajes finalizados'}
                </span>
              </div>
              <p className="text-[10px] text-muted-foreground mt-2">
                Toca el ícono de cámara para cambiar tu foto de perfil (debe verse claramente tu rostro).
              </p>
            </div>
          </div>
        </div>

        {/* Todos los datos con los que se registró el usuario */}
        <div className="bg-card rounded-2xl p-4 border border-border shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-muted-foreground">
              Datos de tu registro
            </h3>
            <span className="text-[11px] font-semibold text-[#0284C7] bg-[#0284C7]/10 px-2.5 py-0.5 rounded-full">
              {mobileProfile?.id ? 'Pasajero y Conductor' : 'Pasajero'}
            </span>
          </div>

          <div className="divide-y divide-border/70 text-sm">
            <div className="py-2.5 flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center flex-shrink-0">
                <UserIcon className="w-4 h-4 text-[#0284C7]" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[11px] text-muted-foreground">Nombre completo</p>
                <p className="font-bold text-foreground truncate">
                  {currentName || 'No registrado'}
                </p>
              </div>
            </div>

            <div className="py-2.5 flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center flex-shrink-0">
                <Mail className="w-4 h-4 text-[#0284C7]" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[11px] text-muted-foreground">Correo electrónico</p>
                <p className="font-bold text-foreground truncate">{emailAddr}</p>
              </div>
            </div>

            <div className="py-2.5 flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center flex-shrink-0">
                <Phone className="w-4 h-4 text-[#0284C7]" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[11px] text-muted-foreground">Teléfono celular</p>
                <p className="font-bold text-foreground truncate">
                  {currentPhone || 'No registrado'}
                </p>
              </div>
            </div>

            <div className="py-2.5 flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center flex-shrink-0">
                <CreditCard className="w-4 h-4 text-[#0284C7]" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[11px] text-muted-foreground">Cédula / Documento</p>
                <p className="font-bold text-foreground truncate">
                  {currentCedula || 'No registrado'}
                </p>
              </div>
            </div>

            <div className="py-2.5 flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center flex-shrink-0">
                <Calendar className="w-4 h-4 text-[#0284C7]" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[11px] text-muted-foreground">Fecha de vinculación</p>
                <p className="font-bold text-foreground truncate capitalize">{regDate}</p>
              </div>
            </div>

            {user?.referral_code && (
              <div className="py-2.5 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center flex-shrink-0">
                  <Hash className="w-4 h-4 text-[#0284C7]" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[11px] text-muted-foreground">Código de referido</p>
                  <p className="font-bold text-foreground truncate">{user.referral_code}</p>
                </div>
              </div>
            )}

            {mobileProfile?.id && (
              <div className="py-2.5 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center flex-shrink-0">
                  {mobileProfile.vehicle_type === 'carro' ? (
                    <Car className="w-4 h-4 text-[#0284C7]" />
                  ) : (
                    <Bike className="w-4 h-4 text-[#0284C7]" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[11px] text-muted-foreground">Vehículo registrado</p>
                  <p className="font-bold text-foreground truncate">
                    {[
                      mobileProfile.vehicle_type === 'carro' ? 'Carro' : 'Moto',
                      mobileProfile.vehicle_brand,
                      mobileProfile.vehicle_model,
                    ]
                      .filter(Boolean)
                      .join(' · ')}
                  </p>
                </div>
                {mobileProfile.plate && (
                  <span className="px-2.5 py-1 rounded-lg bg-muted border border-border text-foreground font-extrabold text-xs tracking-wider uppercase">
                    {mobileProfile.plate}
                  </span>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Acciones inferiores */}
        <div className="pt-2 space-y-2.5">
          <button
            type="button"
            onClick={switchToDriver}
            disabled={checkingDriver}
            className="w-full h-12 rounded-2xl bg-[#0284C7] text-white font-bold flex items-center justify-center gap-2 shadow-sm disabled:opacity-60"
          >
            {checkingDriver ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Bike className="w-5 h-5" />
            )}
            Cambiar a modo conductor
          </button>

          {user && (
            <button
              type="button"
              onClick={() => base44.auth.logout('/')}
              className="w-full h-11 rounded-2xl bg-destructive/10 text-destructive font-bold text-sm flex items-center justify-center gap-2"
            >
              <LogOut className="w-4 h-4" /> Cerrar sesión
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
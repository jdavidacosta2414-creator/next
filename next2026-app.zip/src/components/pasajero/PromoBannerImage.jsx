import React, { useState } from 'react';
import { Image } from '@/components/ui/image';

// Imagen de un anuncio dentro de su recuadro. Con `ratio` el recuadro tiene esa forma fija (el banner del inicio);
// sin `ratio` toma la forma de la imagen. La imagen siempre se ve completa, sin recortes: lo que no alcance a
// cubrir del recuadro se rellena con la misma imagen difuminada.
export default function PromoBannerImage({ src, alt, ratio: fixedRatio, className = '' }) {
  const [ratio, setRatio] = useState(16 / 5);

  const handleLoad = (e) => {
    const { naturalWidth: w, naturalHeight: h } = e.currentTarget;
    if (!w || !h) return;
    const next = w / h;
    setRatio((prev) => (Math.abs(next - prev) / prev > 0.02 ? next : prev));
  };

  return (
    <div
      className={`relative w-full bg-slate-950 overflow-hidden ${className}`}
      style={{ aspectRatio: fixedRatio || ratio }}
    >
      {src && (
        <Image
          src={src}
          alt=""
          aria-hidden="true"
          className="absolute inset-0 w-full h-full object-cover blur-xl scale-110 opacity-50 pointer-events-none"
        />
      )}
      {src && (
        <Image
          src={src}
          alt={alt}
          fittingType="fit"
          onLoad={fixedRatio ? undefined : handleLoad}
          className="absolute inset-0 w-full h-full object-contain pointer-events-none"
        />
      )}
      {/* Destello de luz animado que recorre el banner */}
      <span
        aria-hidden="true"
        className="pointer-events-none absolute inset-y-0 left-0 z-20 w-1/3 bg-gradient-to-r from-transparent via-white/25 to-transparent promo-shine-bar"
      />
    </div>
  );
}
import React, { useState, useEffect, useMemo } from 'react';
import { Bike, Car, Package, Loader2, ThumbsUp, Star, Award } from 'lucide-react';
import { DRIVER_TIERS } from '@/lib/driverTier';
import ResolvedAvatar from '@/components/shared/ResolvedAvatar';
import VehicleBrandIllustration, { resolveRegisteredVehicleSpec } from '@/components/shared/VehicleBrandIllustration';
import { useMapboxToken } from '@/hooks/useMapboxToken';
import { fetchRoute } from '@/lib/mapRoute';
import { calibrateRouteMetrics, estimateKm } from '@/lib/routeEstimate';

const fmtCOP = (n) => '$' + Number(n).toLocaleString('es-CO');
const GREEN_TAG = '#8ea633';
const LIME = '#caff46';

export default function DriverOfferCard({
  candidate,
  mobile,
  stats,
  driverTier,
  service,
  fare,
  isAccepting,
  onAccept,
  onReject,
}) {
  const token = useMapboxToken();
  const [routeToPickup, setRouteToPickup] = useState(null);
  const dTier = driverTier || DRIVER_TIERS[0];
  const trips = stats?.trips || 0;
  const rating = stats?.rating != null ? Number(stats.rating).toFixed(1) : '5.0';

  const drvLat = mobile?.current_lat ?? candidate?._lat ?? candidate?.lat;
  const drvLng = mobile?.current_lng ?? candidate?._lng ?? candidate?.lng;
  const pLat = service?.pickup_lat;
  const pLng = service?.pickup_lng;
  const vType = mobile?.vehicle_type || service?.vehicle_type || 'moto';
  const sType = service?.service_type || 'transporte';

  useEffect(() => {
    if (!token || drvLat == null || drvLng == null || pLat == null || pLng == null) return;
    let alive = true;
    fetchRoute(token, [drvLat, drvLng], [pLat, pLng])
      .then((r) => {
        if (alive) setRouteToPickup(r);
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, [token, drvLat, drvLng, pLat, pLng]);

  const calibrated = useMemo(
    () =>
      calibrateRouteMetrics({
        routeInfo: routeToPickup,
        straightKm: estimateKm(drvLat, drvLng, pLat, pLng),
        stopsCount: 0,
        vehicleType: vType,
        serviceType: sType,
      }),
    [routeToPickup, drvLat, drvLng, pLat, pLng, vType, sType]
  );

  const eta = calibrated.durationMin;
  const kmVal = calibrated.distanceKm;
  const CVIcon =
    mobile?.vehicle_type === 'carro'
      ? Car
      : service?.service_type === 'mensajeria'
        ? Package
        : Bike;
  const vehSpec = resolveRegisteredVehicleSpec(mobile, service);
  const vehicle =
    [vehSpec.modelLine, vehSpec.colorLabel, vehSpec.plate].filter(Boolean).join(' · ') ||
    'Vehículo';
  const offered =
    candidate.offered_fare != null
      ? candidate.offered_fare
      : fare ?? service?.fare ?? 5000;
  const isCounter =
    candidate.offered_fare != null &&
    candidate.offered_fare !== (service?.fare ?? fare);

  return (
    <div className="rounded-3xl p-5 shadow-2xl border border-border bg-card animate-in slide-in-from-bottom">
      <div className="flex items-center justify-between mb-3">
        <div>
          <p className="text-foreground text-2xl font-extrabold leading-none">
            COL${fmtCOP(offered).replace('$', '')}
          </p>
          <p className="text-muted-foreground text-sm font-semibold mt-1" data-testid="offer-eta-km">
            {eta != null
              ? `${eta} min${
                  kmVal != null
                    ? ` · ${(kmVal < 0.05 ? 0 : Math.max(0.1, kmVal)).toFixed(1).replace('.', ',')} km`
                    : ''
                }`
              : '—'}
          </p>
        </div>
        <span
          className="keep-dark-ink flex items-center gap-1 px-3 h-7 rounded-full text-xs font-extrabold text-slate-950"
          style={{ backgroundColor: GREEN_TAG }}
        >
          <ThumbsUp className="w-3.5 h-3.5" /> {isCounter ? 'Contraoferta' : 'Tu tarifa'}
        </span>
      </div>

      <div className="flex items-center gap-3 mb-4">
        <div className="relative flex-shrink-0">
          <ResolvedAvatar
            photo={mobile?.photo_url || mobile?.vehicle_photo}
            name={mobile?.name || 'Conductor'}
            className="w-12 h-12 rounded-full bg-muted border-2 text-foreground font-bold"
            style={{ borderColor: dTier.accentColor }}
            fallback={<CVIcon className="w-6 h-6 text-muted-foreground" />}
          />
          <span
            className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-white shadow-sm border border-card"
            style={{ backgroundColor: dTier.accentColor }}
            title={`Nivel ${dTier.name}`}
          >
            <Award className="w-3 h-3" />
          </span>
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 flex-wrap">
            <p className="text-foreground font-bold truncate">
              {mobile?.name || 'Conductor'}
            </p>
            <span
              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold text-white shadow-xs flex-shrink-0"
              style={{ backgroundColor: dTier.accentColor }}
            >
              <Award className="w-2.5 h-2.5" /> Nivel {dTier.name}
            </span>
          </div>
          <p className="text-muted-foreground text-xs flex items-center gap-1 mt-0.5">
            <Star className="w-3 h-3 text-amber-400 fill-amber-400" /> {rating} · {trips}{' '}
            {trips === 1 ? 'viaje' : 'viajes'}
          </p>
          <p className="text-muted-foreground text-xs flex items-center gap-1.5 truncate mt-0.5">
            <span
              className="w-2.5 h-2.5 rounded-sm border border-slate-400 flex-shrink-0"
              style={{ backgroundColor: vehSpec.palette?.bodyFill || '#F8FAFC' }}
            />
            <span className="truncate font-semibold text-foreground/90">{vehicle}</span>
          </p>
        </div>

        {/* Icono 3D del modelo y color exactos registrados por el conductor */}
        <div className="flex-shrink-0 rounded-xl bg-muted/60 border border-border px-1.5 py-1">
          <VehicleBrandIllustration
            driver={mobile}
            service={service}
            className="w-16 h-10"
          />
        </div>
      </div>

      <div className="flex gap-3">
        <button
          onClick={() => onReject(candidate.mobile_id)}
          className="flex-1 h-11 rounded-xl border border-border bg-muted/60 hover:bg-muted text-foreground font-bold text-sm transition-colors"
        >
          Rechazar
        </button>
        <button
          onClick={() => onAccept(candidate.mobile_id)}
          disabled={isAccepting}
          className="keep-dark-ink flex-1 h-11 rounded-xl font-extrabold text-sm text-slate-950 disabled:opacity-60 flex items-center justify-center gap-1 shadow-sm"
          style={{ backgroundColor: LIME }}
        >
          {isAccepting && <Loader2 className="w-4 h-4 animate-spin" />} Aceptar
        </button>
      </div>
    </div>
  );
}
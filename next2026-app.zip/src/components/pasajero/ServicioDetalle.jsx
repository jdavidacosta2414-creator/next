import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import {
  ArrowLeft, Star, Receipt, HandCoins, EyeOff, ChevronRight, Phone, MessageCircle,
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import ServicioMapa from '@/components/pasajero/ServicioMapa';
import ServiceRatingModal from '@/components/shared/ServiceRatingModal';
import { ServicioReciboModal, ExtraAmountModal } from '@/components/pasajero/ServicioReciboModal';
import ResolvedAvatar from '@/components/shared/ResolvedAvatar';
import { parseUtcDate, fmtBogotaShortDateTime, fmtBogotaTimeAmPm } from '@/lib/dateBogota';

const SUPPORT_PHONE = '573008353849';

const fmtShortDateTime = (d) => fmtBogotaShortDateTime(d);

const fmtTimeAmPm = (d) => fmtBogotaTimeAmPm(d);

const fmtMoney = (n) =>
  'COP ' + Number(n || 0).toLocaleString('es-CO', { minimumFractionDigits: 0 });

function getCategoryTitle(t) {
  if (t.service_type === 'mensajeria') return 'Mensajería';
  if (t.vehicle_type === 'carro') return 'Viaje en carro';
  return 'Viaje en moto';
}

export default function ServicioDetalle({ service, initialDriverMob = null, onBack }) {
  const { toast } = useToast();
  const [svc, setSvc] = useState(service);
  const [route, setRoute] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [driverMob, setDriverMob] = useState(initialDriverMob);
  const rawDriverPhoto =
    svc?.mobile_photo || driverMob?.photo_url || driverMob?.vehicle_photo || '';
  const [showRecibo, setShowRecibo] = useState(false);
  const [showExtra, setShowExtra] = useState(false);
  const [showRating, setShowRating] = useState(false);

  const t = svc;
  const cancelled = t.status === 'cancelado';
  const categoryLabel = getCategoryTitle(t);

  // Cargar datos completos del conductor (foto, placa, marca, modelo) por mobile_id o por nombre
  useEffect(() => {
    if (driverMob) return;
    if (t.mobile_id) {
      base44.entities.Mobile.get(t.mobile_id)
        .then((m) => { if (m) setDriverMob(m); })
        .catch(() => {});
    } else if (t.mobile_name) {
      base44.entities.Mobile.filter({ name: t.mobile_name }, '-created_date', 1)
        .then((list) => {
          const item = Array.isArray(list) ? list[0] : list?.items?.[0];
          if (item) setDriverMob(item);
        })
        .catch(() => {});
    }
  }, [t.mobile_id, t.mobile_name, driverMob]);



  const handleDelete = async () => {
    if (!window.confirm('¿Ocultar y eliminar este viaje de tu actividad anterior?')) return;
    setDeleting(true);
    try {
      await base44.entities.Service.delete(t.id);
      toast({ description: 'Viaje eliminado de tu actividad anterior.' });
      onBack?.();
    } catch {
      toast({ description: 'No se pudo eliminar.', variant: 'destructive' });
    } finally {
      setDeleting(false);
    }
  };

  const pickup = t.pickup_lat && t.pickup_lng ? { lat: t.pickup_lat, lng: t.pickup_lng } : null;
  const dest = t.destination_lat && t.destination_lng ? { lat: t.destination_lat, lng: t.destination_lng } : null;

  const driverName = (t.mobile_name || driverMob?.name || '').toUpperCase();
  const initials = (driverName || '?').trim().charAt(0).toUpperCase();

  const brandModel = [
    t.vehicle_brand || driverMob?.vehicle_brand,
    t.vehicle_model || driverMob?.vehicle_model,
  ]
    .filter(Boolean)
    .join(' ');
  const defaultVehicleName =
    t.service_type === 'mensajeria'
      ? 'Moto Mensajería'
      : t.vehicle_type === 'carro'
        ? 'Automóvil'
        : 'Motocicleta';
  const plate = (t.mobile_plate || driverMob?.plate || '').toUpperCase();
  const vehicleInfoStr = [brandModel || defaultVehicleName, plate].filter(Boolean).join(', ');

  const totalAmount = Number(t.collected_amount || t.fare || 0);
  const baseFare = Number(t.fare || 0);
  const extraAmount = Math.max(0, totalAmount - baseFare);
  const rating = typeof t.rating === 'number' && t.rating > 0 ? Math.round(t.rating) : 0;

  // Hora de inicio y hora de llegada en hora real de Colombia
  const startTimeStr = fmtTimeAmPm(t.created_date);
  const endDateObj = (() => {
    const startMs = parseUtcDate(t.created_date).getTime();
    const updMs = t.updated_date ? parseUtcDate(t.updated_date).getTime() : NaN;
    if (!Number.isNaN(updMs) && updMs > startMs + 60000) {
      return new Date(updMs);
    }
    const mins = route?.durationMin || 15;
    return new Date(startMs + mins * 60000);
  })();
  const endTimeStr = fmtTimeAmPm(endDateObj);

  const waLink = `whatsapp://send?phone=${SUPPORT_PHONE}&text=${encodeURIComponent(
    'Hola, necesito ayuda sobre mi servicio (' + (t.pickup_address || '') + ' → ' + (t.destination_address || '') + ')'
  )}`;

  const refreshService = async () => {
    try {
      const fresh = await base44.entities.Service.get(t.id);
      if (fresh) setSvc(fresh);
    } catch {}
  };

  return (
    <div className="fixed inset-0 z-[1600] max-w-md mx-auto bg-[#121212] text-white flex flex-col">
      {/* Encabezado estilo Detalles del viaje */}
      <div className="flex items-center gap-4 px-4 h-14 flex-shrink-0">
        <button
          type="button"
          onClick={onBack}
          aria-label="Volver"
          className="w-9 h-9 rounded-full flex items-center justify-center hover:bg-white/10 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <h1 className="text-white font-semibold text-base">Detalles del viaje</h1>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar px-4 pb-8">
        {/* Mapa con esquinas redondeadas */}
        <div className="rounded-2xl overflow-hidden border border-white/10 shadow-md mb-5">
          {pickup && dest ? (
            <ServicioMapa pickup={pickup} destination={dest} stops={t.stops} onRouteInfo={setRoute} />
          ) : (
            <div className="h-44 bg-[#1E1E1E] flex items-center justify-center text-white/50 text-sm">
              Sin ruta registrada en el mapa
            </div>
          )}
        </div>

        {/* Título grande con Nombre del Conductor + Foto Circular del Conductor (como en la foto de referencia) */}
        <div className="flex items-start justify-between gap-3 mb-2">
          <div className="flex-1 min-w-0">
            <h2 className="text-white font-extrabold text-[22px] leading-snug tracking-tight">
              {driverName
                ? `${categoryLabel} con ${driverName}`
                : cancelled
                  ? `${categoryLabel} (Cancelado)`
                  : categoryLabel}
            </h2>
          </div>
          <ResolvedAvatar
            photo={rawDriverPhoto}
            name={driverName || 'Conductor'}
            className="w-14 h-14 rounded-full bg-[#242424] border-2 border-white/20 text-white font-bold text-lg shadow-md"
          />
        </div>

        {/* Fecha/hora y Monto + Vehículo + Placa (ej. COP 8.000 - Doge 2015, LYM233) */}
        <div className="space-y-1 mb-4">
          <p className="text-white/80 text-sm">{fmtShortDateTime(t.created_date)}</p>
          <p className="text-white/95 text-sm font-medium">
            {fmtMoney(totalAmount)}
            {vehicleInfoStr ? ` - ${vehicleInfoStr}` : ''}
          </p>
        </div>

        {/* Botón Recibo (+ contacto si hay teléfono) */}
        <div className="flex items-center gap-2.5 mb-6">
          <button
            type="button"
            onClick={() => setShowRecibo(true)}
            className="inline-flex items-center gap-2 px-4 h-10 rounded-full bg-[#242424] hover:bg-[#2E2E2E] text-white text-sm font-semibold transition-colors"
          >
            <Receipt className="w-4 h-4 text-white/90" />
            <span>Recibo</span>
          </button>

          {/* Número del conductor oculto por privacidad */}

          <a
            href={waLink}
            className="inline-flex items-center gap-1.5 px-3.5 h-10 rounded-full bg-[#242424] hover:bg-[#2E2E2E] text-white/90 text-xs font-semibold transition-colors"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>Soporte</span>
          </a>
        </div>

        {/* Direcciones de origen y destino con hora a la derecha */}
        <div className="space-y-5 pb-5 border-b border-white/10">
          <div className="flex items-center gap-4">
            <div className="w-5 flex items-center justify-center flex-shrink-0">
              <span className="w-2.5 h-2.5 rounded-full border-2 border-white inline-block" />
            </div>
            <p className="flex-1 text-white/90 text-sm leading-snug">
              {t.pickup_address || 'Punto de recogida'}
            </p>
            <span className="text-white/60 text-xs font-medium whitespace-nowrap flex-shrink-0">
              {startTimeStr}
            </span>
          </div>

          <div className="flex items-center gap-4">
            <div className="w-5 flex items-center justify-center flex-shrink-0">
              <span className="w-2.5 h-2.5 border-2 border-white inline-block" />
            </div>
            <p className="flex-1 text-white/90 text-sm leading-snug">
              {t.destination_address || 'Destino'}
            </p>
            <span className="text-white/60 text-xs font-medium whitespace-nowrap flex-shrink-0">
              {endTimeStr}
            </span>
          </div>
        </div>

        {/* Fila: Monto extra */}
        <div className="flex items-center justify-between gap-3 py-4 border-b border-white/10">
          <div className="flex items-center gap-4 min-w-0">
            <HandCoins className="w-5 h-5 text-white/80 flex-shrink-0" />
            <span className="text-white font-medium text-sm leading-snug">
              {extraAmount > 0
                ? `Monto extra: ${fmtMoney(extraAmount)}`
                : 'No se agregó un monto extra'}
            </span>
          </div>
          {!cancelled && (
            <button
              type="button"
              onClick={() => setShowExtra(true)}
              className="px-4 h-9 rounded-full bg-[#242424] hover:bg-[#2E2E2E] text-white text-xs font-semibold whitespace-nowrap flex-shrink-0 transition-colors"
            >
              Agregar monto extra
            </button>
          )}
        </div>

        {/* Fila: Calificación */}
        <div className="flex items-center justify-between gap-3 py-4 border-b border-white/10">
          <div className="flex items-center gap-4 min-w-0">
            <Star
              className={`w-5 h-5 flex-shrink-0 ${
                rating > 0 ? 'fill-amber-400 text-amber-400' : 'text-white/80'
              }`}
            />
            {rating > 0 ? (
              <div>
                <p className="text-white font-medium text-sm">
                  Calificaste con {rating} {rating === 1 ? 'estrella' : 'estrellas'}
                </p>
                {t.rating_comment && (
                  <p className="text-white/60 text-xs mt-0.5">"{t.rating_comment}"</p>
                )}
              </div>
            ) : (
              <span className="text-white font-medium text-sm">Sin calificación</span>
            )}
          </div>
          {!cancelled && (
            <button
              type="button"
              onClick={() => setShowRating(true)}
              className="px-4 h-9 rounded-full bg-[#242424] hover:bg-[#2E2E2E] text-white text-xs font-semibold whitespace-nowrap flex-shrink-0 transition-colors"
            >
              {rating > 0 ? 'Cambiar' : 'Calificar'}
            </button>
          )}
        </div>

        {/* Fila: Ocultar este viaje */}
        <button
          type="button"
          onClick={handleDelete}
          disabled={deleting}
          className="w-full flex items-center justify-between gap-3 py-4 text-left hover:bg-white/5 rounded-xl transition-colors disabled:opacity-50"
        >
          <div className="flex items-center gap-4 min-w-0">
            <EyeOff className="w-5 h-5 text-white/80 flex-shrink-0" />
            <div>
              <p className="text-white font-medium text-sm">Ocultar este viaje</p>
              <p className="text-white/60 text-xs mt-0.5">
                Eliminar este viaje de tu actividad anterior
              </p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-white/60 flex-shrink-0" />
        </button>
      </div>

      {showRecibo && (
        <ServicioReciboModal
          service={{
            ...t,
            mobile_name: t.mobile_name || driverMob?.name,
            mobile_plate: plate,
          }}
          vehicleLabel={categoryLabel}
          onClose={() => setShowRecibo(false)}
        />
      )}

      {showExtra && (
        <ExtraAmountModal
          service={t}
          onSaved={(updated) => {
            setSvc(updated);
            setShowExtra(false);
          }}
          onClose={() => setShowExtra(false)}
        />
      )}

      {showRating && (
        <ServiceRatingModal
          serviceId={t.id}
          role="cliente"
          targetName={t.mobile_name || driverMob?.name}
          targetPhoto={rawDriverPhoto}
          onDone={() => {
            setShowRating(false);
            refreshService();
          }}
        />
      )}
    </div>
  );
}
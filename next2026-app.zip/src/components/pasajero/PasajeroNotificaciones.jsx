import React, { useState, useEffect, useMemo } from 'react';
import { ChevronLeft, Bell, Trash2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');

function fmtDate(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  const pad = (n) => String(n).padStart(2, '0');
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function getStoredDismissedNotifs(user) {
  const storageKey = `next_dismissed_notifs_${user?.id || 'anon'}`;
  const globalKey = 'next_dismissed_notifs_global';
  let localList = [];
  let globalList = [];
  try {
    const raw = localStorage.getItem(storageKey);
    if (raw) localList = JSON.parse(raw) || [];
  } catch {}
  try {
    const rawG = localStorage.getItem(globalKey);
    if (rawG) globalList = JSON.parse(rawG) || [];
  } catch {}
  const remoteList = Array.isArray(user?.dismissed_notification_ids)
    ? user.dismissed_notification_ids
    : [];
  return Array.from(new Set([...localList, ...globalList, ...remoteList]));
}

export function saveDismissedNotifs(user, nextIds) {
  const unique = Array.from(new Set(nextIds));
  const storageKey = `next_dismissed_notifs_${user?.id || 'anon'}`;
  const globalKey = 'next_dismissed_notifs_global';
  try {
    localStorage.setItem(storageKey, JSON.stringify(unique));
    localStorage.setItem(globalKey, JSON.stringify(unique));
  } catch {}
  if (user?.id) {
    base44.auth.updateMe({ dismissed_notification_ids: unique }).catch(() => {});
  }
  window.dispatchEvent(new CustomEvent('next-notifs-updated', { detail: { dismissedIds: unique } }));
  return unique;
}

export default function PasajeroNotificaciones({ user, onBack, onCountChange }) {
  const welcomeDate = user?.created_date || new Date().toISOString();
  const firstName = (user?.display_name || user?.full_name || '').trim().split(/\s+/)[0];
  const [dismissedIds, setDismissedIds] = useState(() => getStoredDismissedNotifs(user));
  const [walletNotifs, setWalletNotifs] = useState([]);
  const [expiredServiceNotifs, setExpiredServiceNotifs] = useState([]);
  const [pointsNotifs, setPointsNotifs] = useState([]);
  const [rewardNotifs, setRewardNotifs] = useState([]);
  const [arrivalNotifs, setArrivalNotifs] = useState([]);

  useEffect(() => {
    const syncArrivals = () => {
      try {
        const raw = localStorage.getItem('next_arrival_notifs_v1');
        const list = raw ? JSON.parse(raw) || [] : [];
        setArrivalNotifs(
          list.map((n) => ({
            id: n.id,
            title: n.title || '¡Tu conductor llegó al punto de recogida!',
            body: n.body || 'Tu conductor llegó al punto de recogida. Sal, por favor.',
            date: fmtDate(n.date),
          }))
        );
      } catch {}
    };
    syncArrivals();
    window.addEventListener('next-notifs-updated', syncArrivals);
    return () => window.removeEventListener('next-notifs-updated', syncArrivals);
  }, []);

  useEffect(() => {
    setDismissedIds(getStoredDismissedNotifs(user));
  }, [user?.id, user?.dismissed_notification_ids]);

  useEffect(() => {
    if (!user?.id) return;
    const loadPoints = async () => {
      try {
        const page = await base44.entities.PointsTransaction.filter(
          {
            user_id: user.id,
            status: 'aprobado',
            type: { $in: ['compra_confirmada', 'referido_aprobado'] },
          },
          { sort: '-created_date', limit: 25 }
        );
        const list = page?.items || (Array.isArray(page) ? page : []);
        const mapped = list
          .filter((tx) => Number(tx.amount) > 0)
          .map((tx) => {
            if (tx.type === 'referido_aprobado') {
              return {
                id: `points-tx-${tx.id}-aprobado`,
                title: `¡Ganaste +${tx.amount} puntos por referido! 🤝`,
                body: `Central aprobó el registro de tu referido${tx.referred_user_name ? ` (${tx.referred_user_name})` : ''} y se acreditaron +${tx.amount} puntos a tu cuenta.`,
                date: fmtDate(tx.updated_date || tx.created_date),
              };
            }
            return {
              id: `points-tx-${tx.id}-aprobado`,
              title: `¡Central aprobó tus +${tx.amount} puntos! 🎉`,
              body: `Se acreditaron +${tx.amount} puntos a tu cuenta por tu compra o servicio adquirido en ${tx.business_name || 'nuestro comercio aliado'}. Ya puedes usarlos en Puntos y recompensas.`,
              date: fmtDate(tx.updated_date || tx.created_date),
            };
          });
        setPointsNotifs(mapped);
      } catch (e) {}
    };
    loadPoints();
    const unsub = base44.entities.PointsTransaction.subscribe(() => loadPoints().catch(() => {}));
    return unsub;
  }, [user?.id]);

  useEffect(() => {
    if (!user?.id) return;
    const loadRewards = async () => {
      try {
        const page = await base44.entities.RewardClaim.filter(
          { scope: 'pasajero', user_id: user.id },
          { sort: '-created_date', limit: 15 }
        );
        const list = page?.items || (Array.isArray(page) ? page : []);
        const mapped = list.map((c) => {
          if (c.status === 'entregado') {
            return {
              id: `pax-reward-${c.id}-entregado`,
              title: '¡Tu recompensa fue aprobada por Central! 🏆',
              body: `Central aprobó y acreditó tu recompensa "${c.reward}".`,
              date: fmtDate(c.updated_date || c.created_date),
            };
          }
          return {
            id: `pax-reward-${c.id}-pendiente`,
            title: '¡Recompensa reclamada! 🎁',
            body: `Adquiriste la recompensa "${c.reward}". Central la validará y entregará pronto.`,
            date: fmtDate(c.created_date),
          };
        });
        setRewardNotifs(mapped);
      } catch (e) {}
    };
    loadRewards();
    const unsub = base44.entities.RewardClaim.subscribe(() => loadRewards().catch(() => {}));
    return unsub;
  }, [user?.id]);

  useEffect(() => {
    if (!user?.id) return;
    const loadExpired = async () => {
      try {
        const page = await base44.entities.Service.filter(
          { created_by_id: user.id, status: 'cancelado', cancel_reason: 'sin_conductor' },
          { sort: '-created_date', limit: 10 }
        );
        const list = page?.items || (Array.isArray(page) ? page : []);
        const mapped = list.map((s) => ({
          id: `expired-svc-${s.id}`,
          title: 'Solicitud eliminada automáticamente (10 min)',
          body: `Tu búsqueda de conductor para ${s.pickup_address || 'origen'} → ${s.destination_address || 'destino'} se eliminó después de 10 minutos sin que ningún conductor tomara el servicio.`,
          date: fmtDate(s.updated_date || s.created_date),
        }));
        setExpiredServiceNotifs(mapped);
      } catch (e) {}
    };
    loadExpired();
    const unsub = base44.entities.Service.subscribe(() => loadExpired().catch(() => {}));
    return unsub;
  }, [user?.id]);

  useEffect(() => {
    if (!user?.id) return;
    const loadWallet = async () => {
      try {
        const page = await base44.entities.PassengerWalletTx.filter(
          { user_id: user.id, type: 'retiro' },
          { sort: '-created_date', limit: 20 }
        );
        const mapped = (page.items || []).map((tx) => {
          if (tx.status === 'transferido') {
            return {
              id: `wallet-tx-${tx.id}-transferido`,
              title: '¡Tus puntos han sido redimidos! 💸',
              body: `Realizamos la transferencia por ${fmtCOP(tx.amount)} a tu cuenta ${tx.bank_type || ''} (${tx.account_number || ''}). Por favor verifica la transferencia en tu cuenta; tu billetera quedó en $0.`,
              date: fmtDate(tx.transferred_at || tx.updated_date || tx.created_date),
            };
          }
          return {
            id: `wallet-tx-${tx.id}-pendiente`,
            title: 'Solicitud de retiro en proceso',
            body: `Tu retiro de Billetera por ${fmtCOP(tx.amount)} hacia ${tx.bank_type || ''} (${tx.account_number || ''}) fue enviado a la Central.`,
            date: fmtDate(tx.created_date),
          };
        });
        setWalletNotifs(mapped);
      } catch (e) {}
    };
    loadWallet();
    const unsub = base44.entities.PassengerWalletTx.subscribe(() => loadWallet().catch(() => {}));
    return unsub;
  }, [user?.id]);

  const baseItems = useMemo(
    () => [
      ...arrivalNotifs,
      ...pointsNotifs,
      ...rewardNotifs,
      ...expiredServiceNotifs,
      ...walletNotifs,
      {
        id: 'welcome',
        title: firstName
          ? `¡Bienvenido a la familia NEXT, ${firstName}! 🚀💙`
          : '¡Bienvenido a la familia NEXT! 🚀💙',
        body: 'Qué alegría tenerte con nosotros. Desde hoy cuentas con carros, motos y mensajería al instante para moverte tranquilo, rápido y seguro por toda la ciudad. Además, cada viaje y oferta aliada suma puntos y recompensas en tu Billetera. ¡Tu ciudad es nuestro destino!',
        date: fmtDate(welcomeDate),
      },
    ],
    [arrivalNotifs, pointsNotifs, rewardNotifs, expiredServiceNotifs, walletNotifs, firstName, welcomeDate]
  );

  const items = useMemo(
    () => baseItems.filter((n) => !dismissedIds.includes(n.id)),
    [baseItems, dismissedIds]
  );

  useEffect(() => {
    onCountChange?.(items.length);
  }, [items.length, onCountChange]);

  const remove = (id) => {
    setDismissedIds((prev) => {
      const updated = saveDismissedNotifs(user, [...prev, id]);
      return updated;
    });
  };

  const clearAll = () => {
    setDismissedIds((prev) => {
      const allIds = [...prev, ...baseItems.map((n) => n.id), 'welcome', 'promo'];
      const updated = saveDismissedNotifs(user, allIds);
      return updated;
    });
  };

  const label = items.length === 1 ? '1 notificación' : `${items.length} notificaciones`;

  return (
    <div className="fixed inset-0 z-[1800] bg-background flex flex-col max-w-md mx-auto w-full pb-[56px]">
      <div className="flex items-center gap-3 px-4 h-14 bg-card border-b border-border flex-shrink-0">
        <button onClick={onBack} className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-muted">
          <ChevronLeft className="w-6 h-6 text-foreground" />
        </button>
        <h1 className="text-foreground font-bold text-base">Notificaciones</h1>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pt-5 pb-6">
        <div className="flex flex-col items-center text-center mb-5">
          <div className="w-14 h-14 rounded-2xl bg-[#0284C7]/10 flex items-center justify-center mb-2.5">
            <Bell className="w-7 h-7 text-[#0284C7]" />
          </div>
          <h2 className="text-foreground font-bold text-lg">Centro de notificaciones</h2>
          <p className="text-muted-foreground text-xs">Avisos sobre tus viajes y promociones</p>
        </div>

        <div className="flex items-center justify-between mb-3">
          <p className="text-foreground font-bold text-xs">{label}</p>
          {items.length > 0 && (
            <button onClick={clearAll} className="text-destructive font-bold text-xs">
              Borrar todo
            </button>
          )}
        </div>

        {items.length === 0 ? (
          <div className="bg-card rounded-2xl p-8 text-center border border-border">
            <p className="text-muted-foreground text-sm">No tienes notificaciones nuevas.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {items.map((n) => (
              <div key={n.id} className="bg-card rounded-2xl p-4 border border-border shadow-sm">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <p className="text-foreground font-bold text-sm">{n.title}</p>
                    <p className="text-muted-foreground text-xs mt-1 leading-relaxed">{n.body}</p>
                    <p className="text-muted-foreground/70 text-[11px] mt-2">{n.date}</p>
                  </div>
                  <button
                    type="button"
                    aria-label="Eliminar notificación"
                    onClick={() => remove(n.id)}
                    className="flex-shrink-0 p-1"
                  >
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
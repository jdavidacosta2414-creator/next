import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { Loader2, CheckCircle2, Bike, Car, Package, Phone, Minus, Plus, X, Wallet, UserRound, Flag, ArrowUpRight, ShieldCheck, ThumbsUp, Star, LocateFixed, Menu, Award } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Switch } from '@/components/ui/switch';
import TimeoutIncreaseOffer from '@/components/pasajero/TimeoutIncreaseOffer';
import CancelRequestModal from '@/components/pasajero/CancelRequestModal';
import DriverOfferCard from '@/components/pasajero/DriverOfferCard';
import ResolvedAvatar, { preloadStorageUrls } from '@/components/shared/ResolvedAvatar';
import { DRIVER_TIERS, fetchDriversTierMap } from '@/lib/driverTier';

const SEARCH_SECONDS = 60;
const MAX_ROUNDS = 2;
const fmtCOP = (n) => '$' + Number(n).toLocaleString('es-CO');
const FARE_STEP = 1000;
const BLUE = '#0284C7';
const LIME = '#caff46';
const GREEN_TAG = '#8ea633';

// Animación de radar que se amplía y se reduce alrededor del muñequito central

function haversine(lat1, lng1, lat2, lng2) {
  if (lat1 == null || lat2 == null || lng1 == null || lng2 == null) return null;
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
const etaMin = (km) => (km == null ? null : Math.max(1, Math.round((km / 25) * 60)));

export default function BuscandoConductores({ serviceId, mapExpanded = false, onAssigned, onCancel, onLocateMe, onOpenDrawer }) {
  const { toast } = useToast();
  const [seconds, setSeconds] = useState(SEARCH_SECONDS);
  const [round, setRound] = useState(1);
  const [service, setService] = useState(null);
  const [mobiles, setMobiles] = useState({});
  const [stats, setStats] = useState({});
  const [driverTiers, setDriverTiers] = useState({});
  const [assigned, setAssigned] = useState(false);
  const [fare, setFare] = useState(null);
  const [savingFare, setSavingFare] = useState(false);
  const [autoAccept, setAutoAccept] = useState(false);
  const [accepting, setAccepting] = useState(null);
  const [rejectedAt, setRejectedAt] = useState({});
  const [cancelOpen, setCancelOpen] = useState(false);
  const fetched = useRef(new Set());

  useEffect(() => {
    const t = setInterval(() => setSeconds((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (seconds > 0 || assigned) return;
    if (round < MAX_ROUNDS) {
      setRound((r) => r + 1);
      setSeconds(SEARCH_SECONDS);
      base44.functions.invoke('notifyNearbyDrivers', { service_id: serviceId }).catch(() => {});
    }
  }, [seconds, assigned, round, serviceId]);

  const expiredNotified = useRef(false);
  const applyServiceUpdate = (s) => {
    if (!s) return;
    setService((prev) => (prev ? { ...prev, ...s } : s));
    setFare((prevFare) => (prevFare == null ? s?.fare ?? null : prevFare));
    if (s?.status === 'cancelado' && s?.cancel_reason === 'sin_conductor' && !expiredNotified.current) {
      expiredNotified.current = true;
      toast({ title: 'Servicio cancelado', description: 'Ningún conductor tomó tu servicio. Vuelve a solicitarlo.' });
      onCancel?.();
    }
  };

  const refreshInFlightRef = useRef(false);
  const refresh = () => {
    if (refreshInFlightRef.current) return Promise.resolve();
    refreshInFlightRef.current = true;
    return base44.entities.Service.get(serviceId)
      .then((s) => applyServiceUpdate(s))
      .catch(() => {})
      .finally(() => {
        refreshInFlightRef.current = false;
      });
  };

  useEffect(() => {
    refresh();
    const poll = setInterval(() => {
      if (typeof document === 'undefined' || document.visibilityState === 'visible') {
        refresh();
      }
    }, 4500);
    const unsub = base44.entities.Service.subscribe((event) => {
      const id = event?.id || event?.data?.id;
      if (id === serviceId) {
        if (event?.data) {
          applyServiceUpdate(event.data);
        } else {
          refresh();
        }
      }
    });
    const onVisible = () => {
      if (typeof document !== 'undefined' && document.visibilityState === 'visible') {
        refresh();
      }
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      clearInterval(poll);
      unsub();
      document.removeEventListener('visibilitychange', onVisible);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [serviceId]);

  useEffect(() => {
    if (!service?.created_date || assigned || expiredNotified.current) return;
    const toUtcMs = (val) => {
      if (!val) return 0;
      const raw = String(val).trim();
      const iso = /([zZ]|[+-]\d{2}:?\d{2})$/.test(raw) ? raw : `${raw.replace(' ', 'T')}Z`;
      const ms = new Date(iso).getTime();
      return Number.isFinite(ms) ? ms : 0;
    };
    const baseMs =
      service.cancelled_by === 'conductor' && service.updated_date
        ? Math.max(toUtcMs(service.created_date), toUtcMs(service.updated_date))
        : toUtcMs(service.created_date);
    if (!baseMs) return;
    const expiresAt = baseMs + 10 * 60 * 1000;
    const remaining = expiresAt - Date.now();
    const expire = () => {
      if (expiredNotified.current || assigned) return;
      expiredNotified.current = true;
      base44.entities.Service.update(serviceId, {
        status: 'cancelado',
        cancel_reason: 'sin_conductor',
        client_cancel_detail: 'Ningún conductor tomó tu servicio en 10 minutos.',
      }).catch(() => {});
      toast({ title: 'Servicio cancelado', description: 'Ningún conductor tomó tu servicio. Vuelve a solicitarlo.' });
      onCancel?.();
    };
    if (remaining <= 0) return;
    const t = setTimeout(expire, remaining);
    return () => clearTimeout(t);
  }, [service?.created_date, service?.updated_date, service?.cancelled_by, assigned, serviceId]);

  useEffect(() => {
    if (!service) return;
    const ids = new Set();
    if (service.mobile_photo) {
      preloadStorageUrls([service.mobile_photo]);
    }
    (service.candidates || []).forEach((c) => c.mobile_id && ids.add(c.mobile_id));
    (service.viewed_by || []).forEach((id) => ids.add(id));
    ids.forEach((id) => {
      if (fetched.current.has(id)) return;
      fetched.current.add(id);
      base44.entities.Mobile.get(id)
        .then((m) => {
          if (m?.photo_url || m?.vehicle_photo) {
            preloadStorageUrls([m.photo_url, m.vehicle_photo].filter(Boolean));
          }
          setMobiles((p) => ({ ...p, [id]: m }));
        })
        .catch(() => { fetched.current.delete(id); });
    });
    if (['asignado', 'en_camino', 'recogida'].includes(service.status) && service.mobile_id) {
      setAssigned(true);
      // Pasar de inmediato a la pantalla de seguimiento en vivo
      const timer = setTimeout(() => {
        onAssigned?.();
      }, 350);
      return () => clearTimeout(timer);
    }
  }, [service]);

  // Suscribirse a cambios de GPS en vivo de los conductores postulados
  useEffect(() => {
    const unsub = base44.entities.Mobile.subscribe((ev) => {
      if (!ev?.id || !ev?.data) return;
      setMobiles((prev) => (prev[ev.id] ? { ...prev, [ev.id]: { ...prev[ev.id], ...ev.data } } : prev));
    });
    return unsub;
  }, []);

  const candidates = (service?.candidates || [])
    .filter((c) => {
      if (!c.mobile_id) return false;
      const rj = rejectedAt[c.mobile_id];
      if (!rj) return true;
      return c.timestamp && new Date(c.timestamp) > new Date(rj);
    })
    .map((c) => {
      const m = mobiles[c.mobile_id];
      const dLat = m?.current_lat ?? c.lat;
      const dLng = m?.current_lng ?? c.lng;
      return {
        ...c,
        _lat: dLat,
        _lng: dLng,
        _km: haversine(service?.pickup_lat, service?.pickup_lng, dLat, dLng),
      };
    })
    .sort((a, b) => (a._km ?? Infinity) - (b._km ?? Infinity))
    .slice(0, 15);
  const candidateKey = candidates.map((c) => c.mobile_id).join(',');

  const viewedIds = (service?.viewed_by || []).filter(Boolean);
  const viewedCount = viewedIds.length;

  useEffect(() => {
    const ids = candidates.map((c) => c.mobile_id);
    if (service?.mobile_id && !ids.includes(service.mobile_id)) {
      ids.push(service.mobile_id);
    }
    if (ids.length === 0) return;
    base44.entities.Service.aggregate({
      query: { mobile_id: { $in: ids }, status: 'finalizado' },
      groupBy: 'mobile_id',
      avg: 'rating',
    }).then((res) => {
      const map = {};
      (res?.rows || []).forEach((r) => { map[r.mobile_id] = { trips: r.count, rating: r.avg_rating }; });
      setStats(map);
    }).catch(() => {});

    fetchDriversTierMap(ids)
      .then((tierMap) => setDriverTiers((prev) => ({ ...prev, ...tierMap })))
      .catch(() => {});
  }, [candidateKey, service?.mobile_id]);

  const timedOut = seconds === 0 && round >= MAX_ROUNDS && !assigned;
  const VIcon = service?.vehicle_type === 'carro' ? Car : service?.service_type === 'mensajeria' ? Package : Bike;
  const paymentLabel = service?.payment_method === 'transferencia' ? 'Transferencia' : 'Efectivo';
  const minFare = service?.vehicle_type === 'carro' ? 8000 : 5000;
  const fareDirty = fare != null && service?.fare != null && fare !== service.fare && fare >= minFare;
  const showProposals = candidates.length > 0 && !assigned && !timedOut;

  const adjustFare = (delta) =>
    setFare((f) => {
      const current = Math.max(minFare, Number(f ?? service?.fare ?? minFare));
      return Math.max(minFare, current + delta);
    });
  const raiseFare = async () => {
    if (!service || !fareDirty) return;
    setSavingFare(true);
    try {
      await base44.entities.Service.update(serviceId, { fare });
      toast({ description: 'Tarifa actualizada para atraer conductores.' });
    } catch {
      toast({ description: 'No se pudo actualizar la tarifa.', variant: 'destructive' });
    } finally {
      setSavingFare(false);
    }
  };

  const increaseOffer = async (newFare) => {
    try {
      await base44.entities.Service.update(serviceId, { fare: newFare, candidates: [], viewed_by: [] });
      fetched.current = new Set();
      setFare(newFare);
      setRejectedAt({});
      setRound(1);
      setSeconds(SEARCH_SECONDS);
      base44.functions.invoke('notifyNearbyDrivers', { service_id: serviceId }).catch(() => {});
      toast({ description: 'Oferta actualizada. Buscando conductores de nuevo.' });
    } catch {
      toast({ description: 'No se pudo actualizar la oferta.', variant: 'destructive' });
    }
  };

  const accept = async (mobile_id) => {
    setAccepting(mobile_id);
    try {
      await base44.functions.invoke('acceptCandidate', { service_id: serviceId, mobile_id });
      toast({ description: 'Conductor seleccionado.' });
    } catch {
      toast({ description: 'No se pudo asignar el conductor.', variant: 'destructive' });
      setAccepting(null);
    }
  };
  const reject = (mobile_id) => {
    setRejectedAt((m) => ({ ...m, [mobile_id]: new Date().toISOString() }));
    const remaining = (service?.candidates || []).filter((c) => c.mobile_id !== mobile_id);
    base44.entities.Service.update(serviceId, { candidates: remaining }).catch(() => {});
  };

  const MAX_VISIBLE_AVATARS = 5;
  const watchingAvatars = viewedIds.slice(0, MAX_VISIBLE_AVATARS).map((id) => mobiles[id]);
  const extraViewedCount = Math.max(0, viewedCount - MAX_VISIBLE_AVATARS);
  const currentFareNum = Math.max(minFare, Number(fare ?? service?.fare ?? minFare));

  return (
    <>
      <div className="absolute inset-0 z-[1500] flex flex-col max-w-md mx-auto w-full pointer-events-none">
        {/* Escáner / radar sobre el mapa en tiempo real estilo inDrive (se oculta al tocar el mapa para ver la ruta completa) */}
        {!showProposals && (
          <div
            className={`flex-1 min-h-[140px] flex flex-col items-center justify-center relative overflow-hidden transition-opacity duration-200 ${
              mapExpanded ? 'opacity-0 pointer-events-none' : 'opacity-100'
            }`}
          >
            {/* Botón superior izquierdo (Menú) */}
            {onOpenDrawer && (
              <button
                type="button"
                onClick={onOpenDrawer}
                aria-label="Menú"
                className="pointer-events-auto absolute top-3.5 left-3.5 w-11 h-11 rounded-2xl bg-white dark:bg-slate-800 shadow-lg flex items-center justify-center border border-slate-200 dark:border-white/20"
              >
                <Menu className="w-5 h-5 text-slate-900 dark:text-white stroke-[2.5]" />
              </button>
            )}

            {/* Botón inferior derecho (Mi ubicación) justo encima de la tarjeta blanca */}
            {onLocateMe && (
              <button
                type="button"
                onClick={onLocateMe}
                aria-label="Mi ubicación"
                className="pointer-events-auto absolute bottom-3.5 right-3.5 w-11 h-11 rounded-2xl bg-white dark:bg-slate-800 shadow-lg flex items-center justify-center border border-slate-200 dark:border-white/20"
              >
                <LocateFixed className="w-5 h-5 text-[#1E6BFF]" />
              </button>
            )}

            {!assigned && !timedOut && (
              <div className="relative w-44 h-44 flex items-center justify-center">
                <style>{`
                  @keyframes radarExpandShrink {
                    0%, 100% { transform: scale(0.38); opacity: 0.85; }
                    50% { transform: scale(1.18); opacity: 0.35; }
                  }
                  @keyframes radarInnerExpandShrink {
                    0%, 100% { transform: scale(0.55); opacity: 0.65; }
                    50% { transform: scale(1.0); opacity: 0.9; }
                  }
                `}</style>
                {/* Círculo exterior del radar que se amplía y se reduce continuamente sin tapar el trazado de la ruta */}
                <span
                  className="absolute w-44 h-44 rounded-full border-2 border-[#0284C7]/45 bg-[#0284C7]/8 shadow-[0_0_25px_rgba(2,132,199,0.18)]"
                  style={{ animation: 'radarExpandShrink 2.4s ease-in-out infinite' }}
                />
                {/* Círculo medio del radar que se amplía y reduce en armonía */}
                <span
                  className="absolute w-28 h-28 rounded-full border border-[#0284C7]/50 bg-[#0284C7]/12 shadow-[0_0_18px_rgba(2,132,199,0.22)]"
                  style={{ animation: 'radarInnerExpandShrink 2.4s ease-in-out infinite' }}
                />

                {/* Punto central limpio del radar para dejar ver la ruta y paradas fijas en el mapa */}
                <span className="relative z-10 w-3.5 h-3.5 rounded-full bg-[#0284C7] border-2 border-white shadow-md" />
              </div>
            )}

            {assigned && (
              <div className="flex flex-col items-center bg-card/90 backdrop-blur-sm px-6 py-4 rounded-3xl shadow-xl">
                <CheckCircle2 className="w-14 h-14 text-[#10B981] mb-1.5" />
                <p className="text-foreground font-bold text-base">¡Conductor asignado!</p>
              </div>
            )}
            {timedOut && (
              <div className="flex flex-col items-center">
                <div className="w-20 h-20 rounded-full bg-card shadow-lg flex items-center justify-center mb-3">
                  <X className="w-10 h-10 text-muted-foreground" />
                </div>
                <p className="text-foreground font-bold text-lg">Ningún conductor aceptó</p>
              </div>
            )}
          </div>
        )}

        {/* Vista de propuestas: el pasajero elige conductor */}
        {showProposals && (
          <div className="flex-1 flex flex-col relative">
            <div className="absolute inset-0 bg-white/75 dark:bg-slate-950/80 backdrop-blur-md" />
            <div className="relative flex flex-col h-full">
              <div className="p-4 pointer-events-auto">
                <button onClick={() => setCancelOpen(true)} className="px-4 h-9 rounded-full bg-red-600 text-white text-xs font-bold shadow-md">
                  Cancelar solicitud
                </button>
              </div>
              <div className="flex-1 flex flex-col items-center px-5 pb-6 overflow-y-auto no-scrollbar pointer-events-auto">
                <h2 className="text-foreground text-2xl font-extrabold mb-1">Elige a un conductor</h2>
                <p className="text-muted-foreground text-xs font-medium flex items-center gap-1.5 mb-5">
                  <ShieldCheck className="w-4 h-4 text-[#0284C7] dark:text-[#38BDF8]" /> Todos los conductores están verificados
                </p>
                <div className="w-full space-y-3 max-w-sm">
                  {candidates.map((c, i) => (
                    <DriverOfferCard
                      key={c.mobile_id + i}
                      candidate={c}
                      mobile={mobiles[c.mobile_id]}
                      stats={stats[c.mobile_id]}
                      driverTier={driverTiers[c.mobile_id]}
                      service={service}
                      fare={fare}
                      isAccepting={accepting === c.mobile_id}
                      onAccept={accept}
                      onReject={reject}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Hoja inferior de búsqueda estilo inDrive (se repliega al tocar el mapa y vuelve al tocarlo de nuevo) */}
        {!showProposals && (
          <div
            className={`min-h-[50dvh] flex flex-col justify-between bg-card border-t border-border/70 rounded-t-[26px] shadow-[0_-8px_30px_rgba(0,0,0,0.25)] px-4 pt-2.5 pb-4 flex-shrink-0 transition-all duration-200 ease-out ${
              mapExpanded ? 'translate-y-full opacity-0 pointer-events-none' : 'translate-y-0 opacity-100 pointer-events-auto'
            }`}
          >
            <div className="w-10 h-1 rounded-full bg-muted mx-auto mb-2" />

            {!assigned && !timedOut && (
              <>
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <p className="text-muted-foreground font-medium text-xs truncate">
                    {viewedCount > 0
                      ? `${viewedCount} conductor${viewedCount > 1 ? 'es' : ''} ${viewedCount > 1 ? 'vieron' : 'vio'} tu solicitud`
                      : round > 1
                      ? 'Ampliando búsqueda de conductores...'
                      : 'Buscando conductores cercanos...'}
                  </p>
                  {viewedCount > 0 && (
                    <div
                      data-testid="viewed-drivers-avatar-carousel"
                      className="flex items-center -space-x-2 flex-shrink-0"
                    >
                      {watchingAvatars.map((m, i) => (
                        <ResolvedAvatar
                          key={viewedIds[i] || i}
                          photo={m?.photo_url || m?.vehicle_photo}
                          name={m?.name}
                          className="w-7 h-7 rounded-full bg-muted border-2 border-card shadow-sm transition-transform duration-200 animate-in fade-in zoom-in-75"
                          fallback={<VIcon className="w-3.5 h-3.5 text-muted-foreground" />}
                        />
                      ))}
                      {extraViewedCount > 0 && (
                        <div
                          data-testid="viewed-drivers-extra-count"
                          className="h-7 min-w-[28px] px-1.5 rounded-full bg-[#0284C7] text-white border-2 border-card text-[10px] font-extrabold flex items-center justify-center shadow-sm z-10"
                        >
                          +{extraViewedCount}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <span className="text-foreground font-bold text-[13px] leading-tight">
                    Mejor tarifa. Tu solicitud tiene prioridad
                  </span>
                  <span className="text-foreground font-extrabold text-[13px] tabular-nums flex-shrink-0">
                    00:{String(seconds).padStart(2, '0')}
                  </span>
                </div>
                <div className="h-1.5 bg-muted rounded-full overflow-hidden mb-3">
                  <div
                    className="h-full rounded-full transition-all duration-1000 ease-linear"
                    style={{ width: `${(seconds / SEARCH_SECONDS) * 100}%`, backgroundColor: BLUE }}
                  />
                </div>

                <div className="flex items-center justify-between gap-2.5 mb-2.5">
                  <button
                    type="button"
                    onClick={() => adjustFare(-FARE_STEP)}
                    disabled={currentFareNum <= minFare}
                    className="w-16 h-10 rounded-xl bg-muted/80 hover:bg-muted disabled:opacity-40 flex items-center justify-center text-foreground text-base font-bold"
                  >
                    - 1
                  </button>
                  <div className="text-center flex-1">
                    <p className="text-xl font-extrabold text-foreground tracking-tight">
                      COP {currentFareNum.toLocaleString('es-CO')}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => adjustFare(FARE_STEP)}
                    className="w-16 h-10 rounded-xl bg-muted/80 hover:bg-muted flex items-center justify-center text-foreground text-base font-bold"
                  >
                    + 1
                  </button>
                </div>

                <button
                  type="button"
                  onClick={raiseFare}
                  disabled={savingFare || !fareDirty}
                  className={`w-full h-10 rounded-xl font-bold text-sm mb-2.5 flex items-center justify-center gap-2 transition-colors ${
                    fareDirty
                      ? 'bg-[#0284C7] text-white shadow-md'
                      : 'bg-muted/80 text-muted-foreground disabled:opacity-80'
                  }`}
                >
                  {savingFare && <Loader2 className="w-4 h-4 animate-spin" />} Aumentar tarifa
                </button>

                <div className="flex items-center gap-2.5 py-2 border-y border-border mb-2.5">
                  <ArrowUpRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <p className="flex-1 text-[11px] text-muted-foreground leading-tight">
                    Aceptar automáticamente ofertas entre {fmtCOP(currentFareNum)} y 5 minutos de distancia
                  </p>
                  <Switch checked={autoAccept} onCheckedChange={setAutoAccept} />
                </div>

                <div className="space-y-1 mb-2.5 text-xs">
                  <div className="flex items-center gap-2 text-foreground">
                    <Wallet className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                    <span className="font-semibold">{fmtCOP(currentFareNum)} {paymentLabel}</span>
                  </div>
                  <div className="flex items-center gap-2 text-foreground">
                    <UserRound className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                    <span className="truncate">{service?.pickup_address || 'Punto de recogida'}</span>
                  </div>
                  {(service?.stops || [])
                    .filter((st) => (st?.address || '').trim())
                    .map((st, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-foreground pl-0.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-amber-500 flex-shrink-0" />
                        <span className="truncate">
                          <strong className="text-amber-600 dark:text-amber-400">Parada {idx + 1}:</strong> {st.address}
                        </span>
                      </div>
                    ))}
                  <div className="flex items-center gap-2 text-foreground">
                    <Flag className="w-3.5 h-3.5 flex-shrink-0" style={{ color: BLUE }} />
                    <span className="truncate">{service?.destination_address || 'Destino'}</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setCancelOpen(true)}
                  className="w-full h-10 rounded-xl bg-muted hover:bg-muted/80 text-foreground font-bold text-sm"
                >
                  Cancelar solicitud
                </button>
              </>
            )}

            {timedOut && (
              <TimeoutIncreaseOffer
                service={service}
                mobiles={mobiles}
                stats={stats}
                fare={fare ?? service?.fare}
                onIncreaseOffer={increaseOffer}
                onCancel={() => setCancelOpen(true)}
              />
            )}

            {assigned && service && (
              <div className="w-full">
                <p className="text-muted-foreground text-sm text-center mb-4">
                  {service.mobile_name || 'Conductor'} tomó tu servicio y va en camino.
                </p>
                <div className="bg-muted rounded-2xl p-4 flex items-center gap-3 mb-4">
                  <ResolvedAvatar
                    photo={
                      service.mobile_photo ||
                      mobiles[service.mobile_id]?.photo_url ||
                      mobiles[service.mobile_id]?.vehicle_photo
                    }
                    name={service.mobile_name || 'Conductor'}
                    className="w-14 h-14 rounded-full bg-primary/10 text-primary font-bold"
                    fallback={<VIcon className="w-7 h-7 text-primary" />}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <p className="text-foreground font-bold truncate">{service.mobile_name || 'Conductor'}</p>
                      {service.mobile_id && (
                        <span
                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold text-white"
                          style={{ backgroundColor: (driverTiers[service.mobile_id] || DRIVER_TIERS[0]).accentColor }}
                        >
                          <Award className="w-2.5 h-2.5" /> Nivel {(driverTiers[service.mobile_id] || DRIVER_TIERS[0]).name}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                      {service.mobile_plate && <span className="font-mono bg-card border border-border text-foreground font-bold px-2 py-0.5 rounded">{service.mobile_plate}</span>}
                    </div>
                  </div>
                </div>
                <button onClick={onAssigned} className="w-full h-14 rounded-full bg-primary text-primary-foreground font-bold shadow-lg shadow-primary/30 mb-3">
                  Ver conductor en el mapa
                </button>
                <button onClick={() => setCancelOpen(true)} className="w-full h-12 rounded-xl bg-muted text-muted-foreground font-bold text-sm">
                  Cancelar solicitud
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {cancelOpen && (
        <CancelRequestModal
          serviceId={serviceId}
          mobileId={service?.mobile_id}
          mobileName={service?.mobile_name}
          onCancelled={() => { setCancelOpen(false); onCancel(); }}
          onClose={() => setCancelOpen(false)}
        />
      )}
    </>
  );
}
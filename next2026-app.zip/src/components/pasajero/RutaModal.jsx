import React, { useState, useEffect } from 'react';
import { X, Search, MapPin, ShieldCheck, Plus, Trash2, LocateFixed, AlertTriangle, Loader2 } from 'lucide-react';
import { matchLocalPlaces } from '@/lib/valleduparPlaces';
import {
  searchPlacesValledupar,
  textSearchPlaces,
  resolvePlaceSelection,
  reverseGeocodeValledupar,
  normalizeColombiaCoords,
} from '@/lib/geocode';
import { useMapboxToken } from '@/hooks/useMapboxToken';
import { useBackButton } from '@/hooks/useBackButton';

// Icono de mapa plegado con pin como en la referencia
function FoldedMapPinIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <path
        d="M3 6.5L9 4L15 6.5L21 4V17.5L15 20L9 17.5L3 20V6.5Z"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path d="M9 4V17.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M15 6.5V20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

// Icono del muñequito saludando para el campo "De"
function WavingPersonIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <circle cx="11" cy="5.5" r="2.6" fill="currentColor" />
      <path
        d="M6.5 9.5V19M6.5 11.5H11.5L15.5 15.5"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M10.5 12V19"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinecap="round"
      />
    </svg>
  );
}

export default function RutaModal({
  pickupAddress,
  destinationAddress,
  pickupPlace = null,
  destPlace = null,
  userCoords = null,
  pickupUnverified = false,
  destUnverified = false,
  stops = [],
  onPickupChange,
  onDestinationChange,
  onPickupSelect,
  onDestinationSelect,
  onUseCurrentLocation,
  onAddStop,
  onRemoveStop,
  onStopChange,
  onStopSelect,
  onPickMode,
  onClose,
  onContinue,
  initialActiveField = 'destination',
}) {
  const [activeField, setActiveField] = useState(initialActiveField);
  const [localPickup, setLocalPickup] = useState(pickupAddress || '');
  const [localDest, setLocalDest] = useState(destinationAddress || '');
  const [localStops, setLocalStops] = useState(() => (Array.isArray(stops) ? stops : []));
  const [selectedPickupPlace, setSelectedPickupPlace] = useState(pickupPlace);
  const [selectedDestPlace, setSelectedDestPlace] = useState(destPlace);
  const [typedByUser, setTypedByUser] = useState(false);
  const [suggestions, setSuggestions] = useState([]);
  const [searching, setSearching] = useState(false);
  const [locatingGps, setLocatingGps] = useState(false);
  const token = useMapboxToken();

  useEffect(() => {
    if (initialActiveField) {
      setActiveField(initialActiveField);
    }
  }, [initialActiveField]);

  useEffect(() => {
    if (!typedByUser && pickupAddress && pickupAddress !== localPickup) {
      setLocalPickup(pickupAddress);
    }
  }, [pickupAddress, typedByUser]);

  useEffect(() => {
    if (!typedByUser && destinationAddress && destinationAddress !== localDest) {
      setLocalDest(destinationAddress);
    }
  }, [destinationAddress, typedByUser]);

  useEffect(() => {
    if (!typedByUser && pickupPlace) {
      setSelectedPickupPlace(pickupPlace);
    }
  }, [pickupPlace, typedByUser]);

  useEffect(() => {
    if (!typedByUser && destPlace) {
      setSelectedDestPlace(destPlace);
    }
  }, [destPlace, typedByUser]);

  const stopIndex = activeField?.startsWith('stop_')
    ? Number(activeField.replace('stop_', ''))
    : -1;

  const currentQuery =
    activeField === 'pickup'
      ? localPickup
      : stopIndex >= 0
      ? localStops[stopIndex]?.address || ''
      : localDest;

  useEffect(() => {
    if (!typedByUser) {
      setSuggestions([]);
      setSearching(false);
      return;
    }
    const q = (currentQuery || '').trim();
    if (q.length < 2) {
      setSuggestions([]);
      setSearching(false);
      return;
    }

    let cancelled = false;
    const isStreetGrid = /#|\b(calle|cl|cll|carrera|cra|kr|kra|diagonal|dg|transversal|tv)\s+\d/i.test(q);
    const instantLocal = !isStreetGrid ? matchLocalPlaces(q, 6) : [];
    if (instantLocal.length > 0) {
      setSuggestions(instantLocal);
    }
    setSearching(true);

    const timer = setTimeout(async () => {
      let results = await searchPlacesValledupar(q, token, { userCoords });
      if (cancelled) return;
      if (results.length === 0) {
        const tsFallback = await textSearchPlaces(q, { userCoords });
        if (cancelled) return;
        results = tsFallback;
      }
      setSuggestions(results.length > 0 ? results : instantLocal);
      setSearching(false);
    }, 180);

    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [currentQuery, activeField, typedByUser, token, userCoords]);

  const handleUseMyLocation = () => {
    if (onUseCurrentLocation) {
      setLocatingGps(true);
      Promise.resolve(onUseCurrentLocation())
        .then((res) => {
          if (res?.address) {
            setLocalPickup(res.address);
          }
          if (res?.lat != null && res?.lng != null) {
            setSelectedPickupPlace({
              place_id: res.place_id || `gps_${res.lat}_${res.lng}`,
              name: res.address || localPickup,
              formatted_address: res.formatted_address || res.address || '',
              lat: parseFloat(res.lat),
              lng: parseFloat(res.lng),
              location_type: 'ROOFTOP',
              isPrecise: true,
              needsConfirmation: false,
              verified: true,
            });
          }
        })
        .finally(() => setLocatingGps(false));
      return;
    }

    if (!navigator.geolocation) return;
    setLocatingGps(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const c = normalizeColombiaCoords(pos.coords.latitude, pos.coords.longitude);
          if (!c) return;
          const addr = (await reverseGeocodeValledupar(c.lat, c.lng, token)) || 'Mi ubicación actual';
          const resolved = {
            place_id: `gps_${c.lat}_${c.lng}`,
            name: addr,
            formatted_address: `${addr}, Colombia`,
            lat: c.lat,
            lng: c.lng,
            location_type: 'ROOFTOP',
            isPrecise: true,
            needsConfirmation: false,
            verified: true,
          };
          setLocalPickup(addr);
          setSelectedPickupPlace(resolved);
          onPickupChange?.(addr);
          onPickupSelect?.(resolved);
        } finally {
          setLocatingGps(false);
        }
      },
      () => setLocatingGps(false),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  const handleContinueClick = (overrideData = null) => {
    const finalPickup = overrideData?.pickupAddress !== undefined ? overrideData.pickupAddress : localPickup;
    const finalDest = overrideData?.destinationAddress !== undefined ? overrideData.destinationAddress : localDest;
    const finalStops = overrideData?.stops !== undefined ? overrideData.stops : localStops;
    const finalPickupPlace = overrideData?.pickupPlace !== undefined ? overrideData.pickupPlace : selectedPickupPlace;
    const finalDestPlace = overrideData?.destPlace !== undefined ? overrideData.destPlace : selectedDestPlace;

    onPickupChange?.(finalPickup);
    onDestinationChange?.(finalDest);
    onContinue?.({
      pickupAddress: finalPickup,
      destinationAddress: finalDest,
      pickupPlace: finalPickupPlace,
      destPlace: finalDestPlace,
      stops: finalStops,
    });
  };

  const handleSelectPlace = async (rawPlace) => {
    setSearching(true);
    const resolved = await resolvePlaceSelection(rawPlace);
    setSearching(false);
    if (!resolved || resolved.lat == null || resolved.lng == null) return;

    setTypedByUser(false);
    setSuggestions([]);

    const formatted = {
      place_id: resolved.place_id,
      name: resolved.name,
      formatted_address: resolved.formatted_address || resolved.name,
      lat: parseFloat(resolved.lat),
      lng: parseFloat(resolved.lng),
      location_type: resolved.location_type || 'ROOFTOP',
      isPrecise: resolved.isPrecise !== false,
      needsConfirmation: Boolean(resolved.needsConfirmation),
      verified: resolved.isPrecise !== false,
    };

    if (activeField === 'pickup') {
      setLocalPickup(formatted.name);
      setSelectedPickupPlace(formatted);
      onPickupSelect?.(formatted);
      if (!localDest.trim() || !selectedDestPlace?.lat) {
        setActiveField('destination');
      }
    } else if (stopIndex >= 0) {
      const nextStops = localStops.map((s, i) =>
        i === stopIndex
          ? {
              address: formatted.name,
              place_id: formatted.place_id,
              formatted_address: formatted.formatted_address,
              lat: formatted.lat,
              lng: formatted.lng,
              location_type: formatted.location_type,
              unverified: Boolean(formatted.needsConfirmation),
            }
          : s
      );
      setLocalStops(nextStops);
      onStopSelect?.(stopIndex, formatted);
      if (!localDest.trim() || !selectedDestPlace?.lat) {
        setActiveField('destination');
      }
    } else {
      setLocalDest(formatted.name);
      setSelectedDestPlace(formatted);
      onDestinationSelect?.(formatted);
      const allStopsFilled = localStops.every((s) => (s?.address || '').trim());
      if (localPickup.trim() && allStopsFilled) {
        handleContinueClick({
          pickupAddress: localPickup,
          destinationAddress: formatted.name,
          pickupPlace: selectedPickupPlace,
          destPlace: formatted,
          stops: localStops,
        });
      }
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleContinueClick();
    }
  };

  useBackButton(onClose, true);

  const showConfirmWarning =
    pickupUnverified ||
    destUnverified ||
    Boolean(selectedPickupPlace?.needsConfirmation) ||
    Boolean(selectedDestPlace?.needsConfirmation);

  return (
    <div className="fixed inset-0 z-[2000] flex items-end max-w-md mx-auto w-full">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div
        style={{
          minHeight: 'calc(var(--apk-shell-height, 100vh) * 0.80)',
          maxHeight: 'calc(var(--apk-shell-height, 100vh) * 0.92)',
        }}
        className="relative w-full bg-card rounded-t-[28px] px-5 pt-4 pb-7 shadow-2xl animate-in slide-in-from-bottom flex flex-col overflow-y-auto no-scrollbar"
      >
        <div className="w-10 h-1.5 rounded-full bg-muted mx-auto mb-3" />
        <div className="relative flex items-center justify-center mb-4">
          <h2 className="text-foreground font-extrabold text-xl text-center">
            Introduce tu ruta
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Cerrar"
            className="absolute right-0 w-9 h-9 rounded-full bg-muted text-foreground flex items-center justify-center active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-2.5">
          {/* Campo De (Punto de recogida) */}
          <div className="bg-muted/70 rounded-2xl px-4 py-3 flex items-center gap-3">
            <div className="w-7 h-7 flex items-center justify-center text-foreground flex-shrink-0">
              <WavingPersonIcon />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-muted-foreground text-xs leading-tight">
                De (Punto de recogida · Dirección o Conjunto Cerrado)
              </p>
              <input
                autoFocus={activeField === 'pickup'}
                value={localPickup}
                onFocus={() => setActiveField('pickup')}
                onChange={(e) => {
                  const val = e.target.value;
                  setActiveField('pickup');
                  setTypedByUser(true);
                  setSelectedPickupPlace(null);
                  setLocalPickup(val);
                }}
                onKeyDown={handleKeyDown}
                placeholder="Escribe tu dirección o nombre del conjunto cerrado"
                className="w-full bg-transparent text-foreground font-medium outline-none text-[15px] mt-0.5"
              />
            </div>
            {localPickup && activeField === 'pickup' && (
              <button
                type="button"
                onClick={() => {
                  setActiveField('pickup');
                  setTypedByUser(false);
                  setSuggestions([]);
                  setSelectedPickupPlace(null);
                  setLocalPickup('');
                }}
                className="w-7 h-7 rounded-full bg-card/80 flex items-center justify-center flex-shrink-0"
              >
                <X className="w-3.5 h-3.5 text-muted-foreground" />
              </button>
            )}
            <button
              type="button"
              onClick={() => {
                onPickMode('pickup');
                onClose();
              }}
              title="Marcar recogida en el mapa"
              className="w-9 h-9 rounded-xl flex items-center justify-center text-foreground flex-shrink-0"
            >
              <FoldedMapPinIcon />
            </button>
          </div>

          {localStops.length < 3 && (
            <div className="flex items-center justify-start px-0.5">
              <button
                type="button"
                onClick={() => {
                  const nextIdx = localStops.length;
                  setLocalStops((prev) => [
                    ...prev,
                    { address: '', lat: null, lng: null, unverified: true },
                  ]);
                  onAddStop?.();
                  setActiveField(`stop_${nextIdx}`);
                  setTypedByUser(false);
                  setSuggestions([]);
                }}
                className="inline-flex items-center gap-1.5 pl-2 pr-3 py-1.5 rounded-full bg-[#1E6BFF]/10 hover:bg-[#1E6BFF]/15 dark:bg-[#1E6BFF]/20 text-[#1E6BFF] dark:text-[#60A5FA] text-xs font-bold border border-[#1E6BFF]/25 shadow-2xs active:scale-[0.98] transition-all"
              >
                <span className="w-4 h-4 rounded-full bg-gradient-to-br from-[#1E6BFF] to-[#00B8D4] text-white flex items-center justify-center">
                  <Plus className="w-3 h-3 stroke-[2.5]" />
                </span>
                <span>Agregar parada</span>
              </button>
            </div>
          )}

          {/* Paradas intermedias (1, 2, 3) */}
          {localStops.map((stop, idx) => {
            const fieldKey = `stop_${idx}`;
            return (
              <div
                key={idx}
                className="bg-[#1E6BFF]/[0.07] dark:bg-[#1E6BFF]/15 border border-[#1E6BFF]/25 rounded-2xl px-4 py-2.5 flex items-center gap-3"
              >
                <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#1E6BFF] to-[#00B8D4] text-white font-extrabold text-xs flex items-center justify-center flex-shrink-0 shadow-xs">
                  {idx + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[#1E6BFF] dark:text-[#60A5FA] text-[11px] font-bold leading-tight">
                    Parada {idx + 1}
                  </p>
                  <input
                    autoFocus={activeField === fieldKey}
                    value={stop.address || ''}
                    onFocus={() => setActiveField(fieldKey)}
                    onChange={(e) => {
                      const val = e.target.value;
                      setActiveField(fieldKey);
                      setTypedByUser(true);
                      setLocalStops((prev) =>
                        prev.map((s, i) =>
                          i === idx ? { ...s, address: val, lat: null, lng: null, unverified: true } : s
                        )
                      );
                      onStopChange?.(idx, val);
                    }}
                    onKeyDown={handleKeyDown}
                    placeholder={`Dirección o lugar de la parada ${idx + 1}`}
                    className="w-full bg-transparent text-foreground font-medium outline-none text-[14px] mt-0.5"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onPickMode(`stop_${idx}`);
                    onClose();
                  }}
                  title={`Marcar parada ${idx + 1} en el mapa`}
                  className="w-8 h-8 rounded-xl flex items-center justify-center text-[#1E6BFF] dark:text-[#60A5FA] flex-shrink-0"
                >
                  <FoldedMapPinIcon />
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setLocalStops((prev) => prev.filter((_, i) => i !== idx));
                    onRemoveStop?.(idx);
                    if (activeField === fieldKey) setActiveField('destination');
                  }}
                  aria-label={`Eliminar parada ${idx + 1}`}
                  className="w-7 h-7 rounded-full bg-card/80 flex items-center justify-center text-muted-foreground hover:text-destructive flex-shrink-0"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}

          {/* Campo A (Punto B: Destino final) */}
          <div className="bg-muted/70 rounded-2xl px-4 py-3 flex items-center gap-3">
            <div className="w-7 h-7 flex items-center justify-center text-foreground flex-shrink-0">
              <Search className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-muted-foreground text-xs leading-tight">
                A (Punto B · Destino final)
              </p>
              <input
                autoFocus={!localDest && activeField === 'destination'}
                value={localDest}
                onFocus={() => setActiveField('destination')}
                onChange={(e) => {
                  const val = e.target.value;
                  setActiveField('destination');
                  setTypedByUser(true);
                  setSelectedDestPlace(null);
                  setLocalDest(val);
                }}
                onKeyDown={handleKeyDown}
                placeholder="¿A dónde vas? (Destino final)"
                className="w-full bg-transparent text-foreground font-medium outline-none text-[15px] mt-0.5"
              />
            </div>
            {localDest && activeField === 'destination' && (
              <button
                type="button"
                onClick={() => {
                  setActiveField('destination');
                  setTypedByUser(false);
                  setSuggestions([]);
                  setSelectedDestPlace(null);
                  setLocalDest('');
                }}
                className="w-7 h-7 rounded-full bg-card/80 flex items-center justify-center flex-shrink-0"
              >
                <X className="w-3.5 h-3.5 text-muted-foreground" />
              </button>
            )}
            <button
              type="button"
              onClick={() => {
                onPickMode('destination');
                onClose();
              }}
              title="Marcar destino en el mapa"
              className="w-9 h-9 rounded-xl flex items-center justify-center text-foreground flex-shrink-0"
            >
              <FoldedMapPinIcon />
            </button>
          </div>

          {showConfirmWarning && (
            <div
              data-testid="confirm-location-warning"
              className="rounded-2xl bg-amber-500/15 border border-amber-500/40 px-3.5 py-2.5 flex items-center justify-between gap-2 text-xs text-amber-700 dark:text-amber-300 font-semibold"
            >
              <div className="flex items-center gap-2 min-w-0">
                <AlertTriangle className="w-4 h-4 flex-shrink-0 text-amber-500" />
                <span>Confirma la ubicación en el mapa</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  if (localPickup !== pickupAddress) onPickupChange?.(localPickup);
                  if (localDest !== destinationAddress) onDestinationChange?.(localDest);
                  onPickMode(
                    destUnverified || selectedDestPlace?.needsConfirmation ? 'destination' : 'pickup'
                  );
                  onClose();
                }}
                className="px-2.5 py-1 rounded-lg bg-amber-500 text-slate-950 font-extrabold text-[11px] flex-shrink-0"
              >
                Ajustar pin
              </button>
            </div>
          )}
        </div>

        {/* Sugerencias cuando la persona escribe manualmente la dirección */}
        {typedByUser && (suggestions.length > 0 || searching) && (
          <div className="mt-4 flex-1 pb-64">
            <div className="mb-2 flex items-center justify-between">
              <span className="inline-block px-4 py-1.5 rounded-full bg-[#111318] text-white text-xs font-bold">
                Resultados
              </span>
              {searching && <Loader2 className="w-4 h-4 animate-spin text-primary" />}
            </div>

            <div className="divide-y divide-border/40">
              {suggestions.map((item, idx) => (
                <button
                  key={`${item.place_id || item.name}-${idx}`}
                  type="button"
                  onClick={() => handleSelectPlace(item)}
                  className="w-full flex items-center gap-3.5 py-3 px-1 text-left hover:bg-muted/50 rounded-xl transition-colors"
                >
                  <MapPin className="w-5 h-5 text-muted-foreground fill-muted-foreground/20 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-[15px] font-bold text-foreground truncate">
                      {item.name}
                    </p>
                    <p className="text-xs text-muted-foreground truncate mt-0.5">
                      {item.subtitle || item.formatted_address || 'Colombia'}
                    </p>
                  </div>
                  {item.needsConfirmation ? (
                    <AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0" title="Confirma la ubicación en el mapa" />
                  ) : (
                    <ShieldCheck className="w-5 h-5 text-muted-foreground/60 flex-shrink-0" />
                  )}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="mt-auto pt-5">
          <button
            type="button"
            onClick={() => handleContinueClick()}
            className="w-full h-13 py-3.5 rounded-full bg-primary text-primary-foreground font-bold text-[15px] shadow-md"
          >
            Continuar
          </button>
        </div>
      </div>
    </div>
  );
}
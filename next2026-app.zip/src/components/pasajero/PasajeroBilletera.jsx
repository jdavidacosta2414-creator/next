import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import {
  ChevronLeft,
  Wallet,
  Sparkles,
  ArrowDownCircle,
  CheckCircle2,
  Clock,
  Building2,
  CreditCard,
  FileText,
  User,
  Loader2,
  Info,
  TrendingUp,
  Gift,
  Send,
} from 'lucide-react';
import { useBackButton } from '@/hooks/useBackButton';

const MIN_WITHDRAWAL = 50000;
const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');
const fmtNum = (n) => Number(n || 0).toLocaleString('es-CO');
const fmtDate = (d) =>
  d ? new Date(d).toLocaleDateString('es-CO', { day: '2-digit', month: 'short', timeZone: 'America/Bogota' }) : '';
const fmtTime = (d) =>
  d ? new Date(d).toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit', hour12: true, timeZone: 'America/Bogota' }) : '';

// Paquetes de redención de puntos a dinero en la Billetera (1 punto = $1 peso COP, hasta 50.000 puntos = $50.000)
const REDEEM_PACKS = [
  { amount: 2000, points: 2000, label: '+$2.000', sub: '2.000 pts' },
  { amount: 3000, points: 3000, label: '+$3.000', sub: '3.000 pts' },
  { amount: 5000, points: 5000, label: '+$5.000', sub: '5.000 pts' },
  { amount: 10000, points: 10000, label: '+$10.000', sub: '10.000 pts' },
  { amount: 20000, points: 20000, label: '+$20.000', sub: '20.000 pts' },
  { amount: 50000, points: 50000, label: '+$50.000', sub: '50.000 pts' },
];

const BANK_OPTIONS = [
  'Nequi',
  'DaviPlata',
  'Bancolombia',
  'Llave / Bre-B',
  'Cuenta Bancaria',
];

export function computePassengerWalletBalance(txs = []) {
  let credits = 0;
  let transferredWithdrawals = 0;
  txs.forEach((tx) => {
    if (tx.status === 'rechazado') return;
    if (tx.type === 'abono_puntos' || tx.type === 'bono') {
      credits += Number(tx.amount || 0);
    } else if (tx.type === 'retiro' && tx.status === 'transferido') {
      transferredWithdrawals += Number(tx.amount || 0);
    }
  });
  return Math.max(0, credits - transferredWithdrawals);
}

export default function PasajeroBilletera({ onBack, onOpenPuntos }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [pointsBalance, setPointsBalance] = useState(0);
  const [txs, setTxs] = useState([]);
  const [redeemingAmt, setRedeemingAmt] = useState(null);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  useBackButton(() => {
    if (showWithdrawModal) {
      setShowWithdrawModal(false);
      return true;
    }
    return false;
  }, true);
  const [submittingWithdraw, setSubmittingWithdraw] = useState(false);
  const [form, setForm] = useState({
    bank_type: 'Nequi',
    account_number: '',
    holder_nit: user?.cedula || '',
    holder_name: user?.display_name || user?.full_name || '',
  });

  useEffect(() => {
    if (!user) return;
    setForm((f) => ({
      ...f,
      holder_nit: f.holder_nit || user.cedula || '',
      holder_name: f.holder_name || user.display_name || user.full_name || '',
    }));
  }, [user]);

  const load = useCallback(async () => {
    if (!user?.id) {
      setLoading(false);
      return;
    }
    try {
      const [ptsAgg, walletPage] = await Promise.all([
        base44.entities.PointsTransaction.aggregate({ query: { user_id: user.id }, sum: 'amount' }),
        base44.entities.PassengerWalletTx.filter({ user_id: user.id }, { sort: '-created_date', limit: 60 }),
      ]);
      setPointsBalance(ptsAgg.rows?.[0]?.sum_amount || 0);
      setTxs(walletPage.items || []);
    } catch (e) {}
    setLoading(false);
  }, [user?.id]);

  useEffect(() => {
    load();
    if (!user?.id) return;
    const unsubWallet = base44.entities.PassengerWalletTx.subscribe(() => load().catch(() => {}));
    const unsubPts = base44.entities.PointsTransaction.subscribe(() => load().catch(() => {}));
    return () => {
      unsubWallet();
      unsubPts();
    };
  }, [load, user?.id]);

  const walletBalance = computePassengerWalletBalance(txs);
  const pendingWithdrawal = txs.find((t) => t.type === 'retiro' && t.status === 'pendiente_transferencia');
  const latestTransferred = txs.find((t) => t.type === 'retiro' && t.status === 'transferido');
  const progressPct = Math.min(100, Math.round((walletBalance / MIN_WITHDRAWAL) * 100));
  const canWithdraw = walletBalance >= MIN_WITHDRAWAL && !pendingWithdrawal;
  const missingForMin = Math.max(0, MIN_WITHDRAWAL - walletBalance);

  const handleRedeemPack = async (pack) => {
    if (!user?.id || redeemingAmt) return;
    if (pointsBalance < pack.points) {
      toast({
        title: 'Puntos insuficientes',
        description: `Necesitas ${fmtNum(pack.points)} puntos para sumar ${fmtCOP(pack.amount)} a tu billetera. Tienes ${fmtNum(pointsBalance)} pts.`,
      });
      return;
    }
    setRedeemingAmt(pack.amount);
    try {
      const clientName = user.display_name || user.full_name || user.email || 'Pasajero';
      await base44.entities.PointsTransaction.create({
        user_id: user.id,
        user_name: clientName,
        amount: -pack.points,
        type: 'canje',
        description: `Redención de ${fmtNum(pack.points)} pts a Billetera (+${fmtCOP(pack.amount)})`,
      });
      await base44.entities.PassengerWalletTx.create({
        user_id: user.id,
        user_name: clientName,
        user_phone: user.phone || '',
        type: 'abono_puntos',
        amount: pack.amount,
        points_redeemed: pack.points,
        status: 'completado',
        description: `Abono por redimir ${fmtNum(pack.points)} puntos`,
      });
      toast({
        title: `¡${fmtCOP(pack.amount)} sumados a tu Billetera!`,
        description: `Canjeaste ${fmtNum(pack.points)} puntos por dinero en tu billetera.`,
      });
      await load();
    } catch (e) {
      toast({ title: 'No se pudo redimir', description: 'Intenta nuevamente.' });
    } finally {
      setRedeemingAmt(null);
    }
  };

  const handleWithdrawSubmit = async (e) => {
    e.preventDefault();
    if (!user?.id || !canWithdraw || submittingWithdraw) return;
    const cleanAccount = form.account_number.trim();
    const cleanNit = form.holder_nit.trim();
    const cleanHolder = form.holder_name.trim();
    if (!cleanAccount || !cleanNit || !cleanHolder) {
      toast({
        title: 'Completa los datos bancarios',
        description: 'Ingresa el número de cuenta, NIT o cédula y nombre del titular.',
      });
      return;
    }

    setSubmittingWithdraw(true);
    try {
      const clientName = user.display_name || user.full_name || cleanHolder || 'Pasajero';
      const withdrawAmount = walletBalance;
      const equivPoints = Math.round(withdrawAmount);

      const inc = await base44.entities.Incidence.create({
        title: `Retiro de Billetera · ${clientName} (${fmtCOP(withdrawAmount)})`,
        category: 'pago',
        priority: 'alta',
        status: 'abierta',
        description: [
          `Cliente: ${clientName}`,
          `Valor a transferir: ${fmtCOP(withdrawAmount)} (${fmtNum(equivPoints)} puntos redimidos)`,
          `Entidad: ${form.bank_type}`,
          `Cuenta / Celular: ${cleanAccount}`,
          `NIT / Cédula: ${cleanNit}`,
          `Titular: ${cleanHolder}`,
        ].join('\n'),
      });

      await base44.entities.PassengerWalletTx.create({
        user_id: user.id,
        user_name: clientName,
        user_phone: user.phone || '',
        type: 'retiro',
        amount: withdrawAmount,
        points_redeemed: equivPoints,
        status: 'pendiente_transferencia',
        bank_type: form.bank_type,
        account_number: cleanAccount,
        holder_nit: cleanNit,
        holder_name: cleanHolder,
        incidence_id: inc?.id || '',
        description: `Solicitud de retiro a ${form.bank_type} · Cta ${cleanAccount} · NIT/CC ${cleanNit}`,
      });

      setShowWithdrawModal(false);
      toast({
        title: 'Solicitud de retiro enviada a Central',
        description: `Notificamos a Central tu retiro por ${fmtCOP(withdrawAmount)}. Te avisaremos apenas se realice la transferencia.`,
      });
      await load();
    } catch (err) {
      toast({ title: 'Error al enviar solicitud', description: 'Intenta de nuevo en unos segundos.' });
    } finally {
      setSubmittingWithdraw(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[1800] bg-background w-full max-w-md mx-auto flex flex-col pb-[56px]">
      {/* Cabecera */}
      <div className="px-4 pt-5 pb-5 bg-gradient-to-br from-[#062B6E] via-[#0B3C8C] to-[#1E6BFF] text-white">
        <div className="flex items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              aria-label="Volver"
              className="w-9 h-9 rounded-full bg-white/15 flex items-center justify-center active:scale-95"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <Wallet className="w-5 h-5 text-[#00E5FF]" />
              <h1 className="text-lg font-bold">Mi Billetera</h1>
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenPuntos}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/15 hover:bg-white/20 text-xs font-bold"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#00E5FF]" />
            <span>{fmtNum(pointsBalance)} pts</span>
          </button>
        </div>

        {/* Saldo principal */}
        <div className="bg-white/10 backdrop-blur-md border border-white/15 rounded-2xl p-4">
          <div className="flex items-start justify-between gap-2">
            <div>
              <p className="text-white/75 text-xs font-medium uppercase tracking-wider">
                Saldo acumulado en billetera
              </p>
              <p className="text-3xl font-extrabold mt-0.5 leading-none">
                {fmtCOP(walletBalance)}
              </p>
            </div>
            <span className="px-2.5 py-1 rounded-full bg-[#00E5FF]/20 text-[#00E5FF] text-[11px] font-extrabold">
              Mín. retiro {fmtCOP(MIN_WITHDRAWAL)}
            </span>
          </div>

          {/* Barra de progreso hacia los $50.000 */}
          <div className="mt-3.5">
            <div className="flex items-center justify-between text-[11px] text-white/85 mb-1">
              <span>Progreso para retiro en efectivo</span>
              <span className="font-bold">{progressPct}%</span>
            </div>
            <div className="h-2.5 rounded-full bg-black/25 overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[#00E5FF] to-[#00E676] transition-all duration-300"
                style={{ width: `${progressPct}%` }}
              />
            </div>
            <p className="text-[11px] text-white/80 mt-1.5">
              {pendingWithdrawal
                ? `Tienes un retiro en proceso por ${fmtCOP(pendingWithdrawal.amount)}.`
                : canWithdraw
                ? '¡Meta de $50.000 cumplida! Ya puedes retirar tu dinero a tu cuenta.'
                : `Te faltan ${fmtCOP(missingForMin)} para habilitar el retiro mínimo de ${fmtCOP(MIN_WITHDRAWAL)}.`}
            </p>
          </div>

          <button
            type="button"
            disabled={!canWithdraw}
            onClick={() => setShowWithdrawModal(true)}
            className="keep-dark-ink mt-3.5 w-full h-11 rounded-xl bg-[#00E5FF] text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 shadow-md disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.99] transition-all"
          >
            <ArrowDownCircle className="w-4 h-4 text-slate-950" />
            <span>
              {pendingWithdrawal
                ? 'Retiro en proceso de transferencia...'
                : canWithdraw
                ? `Retirar ${fmtCOP(walletBalance)} a mi cuenta`
                : `Retirar dinero (mínimo ${fmtCOP(MIN_WITHDRAWAL)})`}
            </span>
          </button>
        </div>
      </div>

      {/* Contenido scrollable */}
      <div className="flex-1 overflow-y-auto no-scrollbar px-4 py-4 space-y-5">
        {/* Aviso cuando una transferencia fue completada recientemente y la billetera quedó en $0 */}
        {latestTransferred && walletBalance === 0 && !pendingWithdrawal && (
          <div className="rounded-2xl bg-emerald-50 dark:bg-emerald-500/15 border border-emerald-200 dark:border-emerald-500/30 p-3.5 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 flex-shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <p className="text-xs font-extrabold text-emerald-800 dark:text-emerald-300">
                ¡Tus puntos han sido redimidos!
              </p>
              <p className="text-[11.5px] text-emerald-700 dark:text-emerald-300/90 mt-0.5 leading-relaxed">
                Central realizó la transferencia de <span className="font-bold">{fmtCOP(latestTransferred.amount)}</span> a tu cuenta {latestTransferred.bank_type} ({latestTransferred.account_number}). Verifica la transferencia en tu cuenta; tu billetera quedó en $0 automáticamente.
              </p>
            </div>
          </div>
        )}

        {/* Estado de solicitud pendiente */}
        {pendingWithdrawal && (
          <div className="rounded-2xl bg-amber-50 dark:bg-amber-500/15 border border-amber-200 dark:border-amber-500/30 p-3.5 flex items-start gap-3">
            <Clock className="w-5 h-5 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <p className="text-xs font-extrabold text-amber-800 dark:text-amber-300">
                Solicitud de retiro enviada a la Central ({fmtCOP(pendingWithdrawal.amount)})
              </p>
              <p className="text-[11.5px] text-amber-700 dark:text-amber-300/90 mt-0.5 leading-relaxed">
                Cuenta destino: <span className="font-bold">{pendingWithdrawal.bank_type} · {pendingWithdrawal.account_number}</span> (NIT/CC {pendingWithdrawal.holder_nit}). Cuando Central realice la transferencia te notificaremos y tu billetera pasará a $0.
              </p>
            </div>
          </div>
        )}

        {/* Redimir puntos a dinero real en la Billetera */}
        <section>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5">
              <Gift className="w-4 h-4 text-[#1E6BFF]" />
              <p className="text-xs font-extrabold text-foreground uppercase tracking-wide">
                Sumar puntos a mi Billetera
              </p>
            </div>
            <span className="text-xs font-bold text-[#1E6BFF]">
              Disponibles: {fmtNum(pointsBalance)} pts
            </span>
          </div>

          <p className="text-xs text-muted-foreground mb-3">
            2.000 puntos equivalen a $2.000 pesos, y así sucesivamente hasta llegar a 50.000 puntos ($50.000 COP) para retirarlo a tu cuenta.
          </p>

          <div className="grid grid-cols-2 gap-2.5">
            {REDEEM_PACKS.map((pack) => {
              const enough = pointsBalance >= pack.points;
              const isBusy = redeemingAmt === pack.amount;
              return (
                <button
                  key={pack.amount}
                  type="button"
                  disabled={Boolean(redeemingAmt) || Boolean(pendingWithdrawal)}
                  onClick={() => handleRedeemPack(pack)}
                  className={`rounded-2xl border p-3 text-left transition-all flex items-center justify-between gap-2 ${
                    enough
                      ? 'bg-card border-[#1E6BFF]/40 hover:border-[#1E6BFF] shadow-sm active:scale-[0.99]'
                      : 'bg-muted/50 border-border opacity-75'
                  }`}
                >
                  <div>
                    <p className="text-base font-extrabold text-foreground leading-tight">
                      {pack.label}
                    </p>
                    <p className="text-[11px] text-muted-foreground font-semibold mt-0.5 flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-[#1E6BFF]" />
                      Canjear {pack.sub}
                    </p>
                  </div>
                  <div className="w-8 h-8 rounded-xl bg-[#1E6BFF]/10 text-[#1E6BFF] flex items-center justify-center flex-shrink-0 font-bold text-xs">
                    {isBusy ? <Loader2 className="w-4 h-4 animate-spin" /> : '+'}
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        {/* Información de cómo funciona */}
        <div className="flex items-start gap-2.5 bg-[#1E6BFF]/5 border border-[#1E6BFF]/15 rounded-2xl p-3.5">
          <Info className="w-4 h-4 text-[#1E6BFF] flex-shrink-0 mt-0.5" />
          <p className="text-[11.5px] text-muted-foreground leading-relaxed">
            Suma <span className="font-bold text-foreground">$2.000, $3.000 o $5.000</span> en tu billetera redimiendo tus puntos. Cuando alcances el monto mínimo de <span className="font-bold text-foreground">$50.000 COP</span>, solicita el retiro ingresando tu número de cuenta y NIT o cédula para que la Central realice la transferencia.
          </p>
        </div>

        {/* Historial de movimientos de la billetera */}
        <section>
          <p className="text-xs font-extrabold text-muted-foreground uppercase tracking-wider mb-2.5">
            Movimientos de Billetera
          </p>
          {loading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="w-6 h-6 text-muted-foreground/40 animate-spin" />
            </div>
          ) : txs.length === 0 ? (
            <div className="bg-card border border-border rounded-2xl p-7 text-center">
              <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center mx-auto mb-2.5">
                <Wallet className="w-5 h-5 text-muted-foreground/50" />
              </div>
              <p className="text-sm font-bold text-foreground">Tu billetera está en $0</p>
              <p className="text-xs text-muted-foreground mt-1">
                Redime tus puntos en bonos de $2.000, $3.000 o $5.000 para empezar a acumular saldo.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {txs.map((m) => {
                const isWithdraw = m.type === 'retiro';
                const isPending = m.status === 'pendiente_transferencia';
                const isTransferred = m.status === 'transferido';
                return (
                  <div
                    key={m.id}
                    className="flex items-center gap-3 bg-card border border-border rounded-2xl p-3"
                  >
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
                        isWithdraw
                          ? isTransferred
                            ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                            : 'bg-amber-500/15 text-amber-600 dark:text-amber-400'
                          : 'bg-[#1E6BFF]/10 text-[#1E6BFF]'
                      }`}
                    >
                      {isWithdraw ? (
                        <ArrowDownCircle className="w-5 h-5" />
                      ) : (
                        <TrendingUp className="w-5 h-5" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <p className="text-sm font-bold text-foreground truncate">
                          {isWithdraw
                            ? isTransferred
                              ? 'Retiro transferido a tu cuenta'
                              : 'Solicitud de retiro en proceso'
                            : m.type === 'bono'
                            ? 'Bono acreditado en Billetera'
                            : 'Abono por redención de puntos'}
                        </p>
                      </div>
                      <p className="text-[11px] text-muted-foreground truncate">
                        {fmtDate(m.created_date)} · {fmtTime(m.created_date)}
                        {m.bank_type ? ` · ${m.bank_type} ${m.account_number || ''}` : ''}
                      </p>
                      {m.description && (
                        <p className="text-[11px] text-muted-foreground/80 truncate mt-0.5">
                          {m.description}
                        </p>
                      )}
                    </div>
                    <div className="text-right flex-shrink-0">
                      <span
                        className={`text-sm font-extrabold block ${
                          isWithdraw
                            ? isPending
                              ? 'text-amber-600 dark:text-amber-400'
                              : 'text-foreground'
                            : 'text-emerald-600 dark:text-emerald-400'
                        }`}
                      >
                        {isWithdraw ? `-${fmtCOP(m.amount)}` : `+${fmtCOP(m.amount)}`}
                      </span>
                      {isWithdraw && (
                        <span
                          className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full inline-block mt-0.5 ${
                            isTransferred
                              ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                              : 'bg-amber-500/15 text-amber-600 dark:text-amber-400'
                          }`}
                        >
                          {isTransferred ? 'Transferido' : 'Pendiente'}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </div>

      {/* Modal para solicitar el retiro indicando NIT/Cédula y Número de cuenta */}
      {showWithdrawModal && (
        <div className="fixed inset-0 z-[2200] bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
          <form
            onSubmit={handleWithdrawSubmit}
            className="w-full max-w-md bg-card rounded-t-3xl sm:rounded-3xl border border-border px-5 pt-5 pb-20 sm:pb-5 space-y-4 animate-in slide-in-from-bottom"
          >
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-foreground font-extrabold text-base">
                  Retirar saldo de Billetera
                </h3>
                <p className="text-xs text-muted-foreground">
                  Monto a transferir: <span className="font-extrabold text-[#1E6BFF]">{fmtCOP(walletBalance)}</span>
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-foreground block mb-1">
                  Entidad o billetera destino
                </label>
                <div className="relative">
                  <Building2 className="w-4 h-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
                  <select
                    value={form.bank_type}
                    onChange={(e) => setForm((f) => ({ ...f, bank_type: e.target.value }))}
                    className="w-full h-11 rounded-xl bg-muted/70 border border-border pl-9 pr-3 text-sm text-foreground font-semibold outline-none focus:border-primary"
                  >
                    {BANK_OPTIONS.map((b) => (
                      <option key={b} value={b}>
                        {b}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-foreground block mb-1">
                  Número de cuenta, celular o llave
                </label>
                <div className="relative">
                  <CreditCard className="w-4 h-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    required
                    value={form.account_number}
                    onChange={(e) => setForm((f) => ({ ...f, account_number: e.target.value }))}
                    placeholder="Ej. 3001234567 o N° de cuenta"
                    className="w-full h-11 rounded-xl bg-muted/70 border border-border pl-9 pr-3 text-sm text-foreground outline-none focus:border-primary"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-foreground block mb-1">
                  NIT o Cédula del titular
                </label>
                <div className="relative">
                  <FileText className="w-4 h-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    required
                    value={form.holder_nit}
                    onChange={(e) => setForm((f) => ({ ...f, holder_nit: e.target.value }))}
                    placeholder="Ingresa tu NIT o número de cédula"
                    className="w-full h-11 rounded-xl bg-muted/70 border border-border pl-9 pr-3 text-sm text-foreground outline-none focus:border-primary"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-foreground block mb-1">
                  Nombre completo del titular
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    required
                    value={form.holder_name}
                    onChange={(e) => setForm((f) => ({ ...f, holder_name: e.target.value }))}
                    placeholder="Nombre de quien recibe la transferencia"
                    className="w-full h-11 rounded-xl bg-muted/70 border border-border pl-9 pr-3 text-sm text-foreground outline-none focus:border-primary"
                  />
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={submittingWithdraw}
              className="w-full h-12 rounded-full bg-gradient-to-r from-[#062B6E] via-[#0B45B4] to-[#00B8FF] text-white font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg disabled:opacity-60"
            >
              {submittingWithdraw ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Confirmar solicitud de retiro ({fmtCOP(walletBalance)})</span>
                </>
              )}
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
import React from 'react';
import { Home, Clock, Bell, User } from 'lucide-react';

// Navegación inferior fija del pasajero (estilo app de logística).
const ITEMS = [
  { key: 'inicio', label: 'Inicio', icon: Home, action: 'onHome' },
  { key: 'viajes', label: 'Mis viajes', icon: Clock, action: 'onViajes' },
  { key: 'notif', label: 'Notificaciones', icon: Bell, action: 'onNotificaciones', dot: true },
  { key: 'perfil', label: 'Perfil', icon: User, action: 'onPerfil' },
];

export default function PasajeroBottomNav({ active, hasNotifs = false, onHome, onViajes, onNotificaciones, onPerfil }) {
  const handlers = { onHome, onViajes, onNotificaciones, onPerfil };
  return (
    <div className="w-full max-w-full flex-shrink-0 bg-card border-t border-border/70 grid grid-cols-4 pt-1.5 pb-1 px-1">
      {ITEMS.map((item) => {
        const isActive = active === item.key;
        const Icon = item.icon;
        return (
          <button
            key={item.key}
            type="button"
            onClick={() => handlers[item.action]?.()}
            className="relative min-w-0 flex flex-col items-center justify-center gap-0.5 py-0.5 px-0.5"
          >
            <div className="relative">
              <Icon
                className={`w-5 h-5 ${
                  isActive ? 'text-[#0284C7] fill-[#0284C7]/20' : 'text-muted-foreground'
                }`}
              />
              {item.dot && hasNotifs && (
                <span className="absolute -top-0.5 -right-1 w-2 h-2 rounded-full bg-[#0284C7]" />
              )}
            </div>
            <span
              className={`text-[10px] leading-tight truncate max-w-full ${
                isActive ? 'font-bold text-[#0284C7]' : 'font-medium text-muted-foreground'
              }`}
            >
              {item.label}
            </span>
            {isActive && (
              <span className="w-8 h-[3px] rounded-full bg-[#0284C7] mt-0.5" />
            )}
          </button>
        );
      })}
    </div>
  );
}
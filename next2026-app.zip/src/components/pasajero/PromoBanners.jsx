import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { ChevronRight, MessageCircle, MapPin, Sparkles, Tag, Clock, Gift, X } from 'lucide-react';
import { useBackButton } from '@/hooks/useBackButton';
import PromoBannerImage from '@/components/pasajero/PromoBannerImage';

const PURCHASE_POINTS = 50;

function getBogotaDayBounds(now = new Date()) {
  const dateKey = now.toLocaleDateString('en-CA', { timeZone: 'America/Bogota' });
  const start = new Date(`${dateKey}T00:00:00.000-05:00`);
  const end = new Date(start.getTime() + 24 * 60 * 60 * 1000);
  return { dateKey, startIso: start.toISOString(), endIso: end.toISOString() };
}

const FALLBACK_ADS = [
  {
    id: 'fallback-1',
    business_name: 'Comidas Rápidas El Punto del Sabor',
    offer_badge: '2x1 HOY',
    offer_title: '2x1 en Hamburguesas Artesanales + Papas',
    category: 'Comidas rápidas',
    business_address: 'Av. Simón Bolívar, Valledupar',
    cta_text: 'Reclamar oferta',
    whatsapp_number: '573177387749',
    image_url: 'https://images.unsplash.com/photo-1561758033-d89a9ad46330?auto=format&fit=crop&w=800&q=80',
    isFallback: true,
  },
  {
    id: 'fallback-2',
    business_name: 'Restaurante Gourmet & Café',
    offer_badge: '15% DTO',
    offer_title: '15% de descuento + Domicilio gratis con NEXT',
    category: 'Restaurante & Café',
    business_address: 'Barrio Novalito, Valledupar',
    cta_text: 'Ver oferta por WhatsApp',
    whatsapp_number: '573177387749',
    image_url: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=800&q=80',
    isFallback: true,
  },
];

function formatShortDate(dateStr) {
  if (!dateStr) return null;
  const parts = String(dateStr).split('-');
  if (parts.length !== 3) return dateStr;
  const months = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
  const m = parseInt(parts[1], 10) - 1;
  return `${parseInt(parts[2], 10)} ${months[m] || parts[1]}`;
}

export default function PromoBanners() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [ads, setAds] = useState([]);
  const [activeIndex, setActiveIndex] = useState(0);
  const [showAll, setShowAll] = useState(false);
  useBackButton(() => setShowAll(false), showAll);
  const inFlightClicksRef = useRef({});
  const scrollRef = useRef(null);

  // Al dar clic en la publicidad NO se regalan puntos automáticamente:
  // se registra una solicitud pendiente (0 puntos) para que Central la apruebe
  // y acredite los +50 puntos cuando el usuario interactúe y adquiera el producto o servicio.
  const handleAdClick = async (ad) => {
    const adId = String(ad?.id || '');
    try {
      base44.analytics.track({
        eventName: 'promo_banner_click',
        properties: {
          ad_id: adId,
          business_name: String(ad?.business_name || ''),
          offer_badge: String(ad?.offer_badge || 'Promo NEXT'),
        },
      });
    } catch (e) {}

    toast({
      title: `Gana +${PURCHASE_POINTS} puntos al adquirir`,
      description: `Pregunta, interactúa y compra en ${ad?.business_name || 'el comercio'}. Central acreditará tus +${PURCHASE_POINTS} puntos al confirmar tu compra.`,
    });

    if (!user?.id || !adId) return;
    if (inFlightClicksRef.current[adId]) return;
    inFlightClicksRef.current[adId] = true;

    try {
      const { startIso, endIso } = getBogotaDayBounds();
      const existingPending = await base44.entities.PointsTransaction.count({
        user_id: user.id,
        advertisement_id: adId,
        status: 'pendiente',
        created_date: { $gte: startIso, $lt: endIso },
      });

      if (existingPending === 0) {
        const offerLabel = ad.offer_title || ad.offer_badge || 'Promoción';
        await base44.entities.PointsTransaction.create({
          user_id: user.id,
          user_name: user.display_name || user.full_name || user.email || 'Pasajero',
          amount: 0,
          type: 'interaccion_click',
          status: 'pendiente',
          advertisement_id: adId,
          business_name: ad.business_name,
          description: `Interacción por WhatsApp (${offerLabel}) — pendiente confirmar compra para +${PURCHASE_POINTS} pts`,
        });
      }
    } catch (e) {
    } finally {
      inFlightClicksRef.current[adId] = false;
    }
  };

  useEffect(() => {
    const load = async () => {
      try {
        const page = await base44.entities.Advertisement.filter(
          { active: true },
          { sort: '-created_date', limit: 20 }
        );
        const { dateKey: today } = getBogotaDayBounds();
        const visibles = (page.items || []).filter((a) =>
          (!a.start_date || today >= a.start_date) && (!a.end_date || today <= a.end_date)
        );
        setAds(visibles);
      } catch (e) {}
    };
    load();
    const unsub = base44.entities.Advertisement.subscribe(() => load().catch(() => {}));
    return unsub;
  }, []);

  const displayAds = ads.length > 0 ? ads : FALLBACK_ADS;

  const waLink = (ad) => {
    let digits = (ad.whatsapp_number || '').replace(/\D/g, '');
    if (digits.length === 10 && digits.startsWith('3')) {
      digits = `57${digits}`;
    }
    const offerText = ad.offer_title || ad.offer_badge;
    const msg = offerText
      ? `Hola ${ad.business_name || ''}, vi su oferta "${offerText}" en la publicidad de la app NEXT y quiero preguntar para adquirir su producto o servicio (+${PURCHASE_POINTS} pts NEXT).`
      : `Hola ${ad.business_name || ''}, vi su publicidad en la app NEXT y quiero preguntar para adquirir su producto o servicio (+${PURCHASE_POINTS} pts NEXT).`;
    return `whatsapp://send?phone=${digits}&text=${encodeURIComponent(msg)}`;
  };

  const handleScroll = () => {
    if (!scrollRef.current) return;
    const el = scrollRef.current;
    const cardWidth = el.clientWidth * 0.88;
    const idx = Math.round(el.scrollLeft / (cardWidth || 1));
    setActiveIndex(Math.min(displayAds.length - 1, Math.max(0, idx)));
  };

  // Auto-rotación suave del carrusel cada 4.5s para dar movimiento dinámico
  useEffect(() => {
    if (displayAds.length <= 1 || showAll) return;
    const interval = setInterval(() => {
      const el = scrollRef.current;
      if (!el) return;
      const nextIdx = (activeIndex + 1) % displayAds.length;
      const cardWidth = el.clientWidth * 0.88;
      el.scrollTo({ left: nextIdx * (cardWidth + 10), behavior: 'smooth' });
      setActiveIndex(nextIdx);
    }, 4500);
    return () => clearInterval(interval);
  }, [activeIndex, displayAds.length, showAll]);

  return (
    <div className="w-full max-w-full overflow-hidden">
      <style>{`
        @keyframes promoBannerFloat {
          0%, 100% { transform: scale(1) translateY(0px); }
          50% { transform: scale(1.045) translateY(-2px); }
        }
        @keyframes promoBannerShine {
          0% { transform: translateX(-140%) skewX(-20deg); }
          45%, 100% { transform: translateX(220%) skewX(-20deg); }
        }
        @keyframes promoCtaPulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.05); }
        }
        .promo-img-animated {
          animation: promoBannerFloat 4.2s ease-in-out infinite;
          will-change: transform;
        }
        .promo-shine-bar {
          animation: promoBannerShine 4.8s ease-in-out infinite;
        }
        .promo-cta-pulse {
          animation: promoCtaPulse 2.4s ease-in-out infinite;
        }
      `}</style>

      <div className="flex items-center justify-between gap-1.5 mb-1.5">
        <div className="flex items-center gap-1.5 min-w-0 overflow-hidden">
          <p className="text-foreground font-extrabold text-[12px] sm:text-[13px] tracking-tight whitespace-nowrap flex-shrink-0">
            Ofertas y negocios
          </p>
          <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-amber-500/15 text-amber-600 dark:text-amber-400 text-[9px] sm:text-[9.5px] font-bold whitespace-nowrap truncate">
            <Gift className="w-2.5 h-2.5 flex-shrink-0" /> +{PURCHASE_POINTS} pts por compra
          </span>
        </div>
        <button
          type="button"
          onClick={() => setShowAll(true)}
          className="text-[#0284C7] text-[11px] sm:text-[11.5px] font-bold flex items-center gap-0.5 flex-shrink-0 whitespace-nowrap ml-auto"
        >
          Ver todas ({displayAds.length}) <ChevronRight className="w-3.5 h-3.5 flex-shrink-0" />
        </button>
      </div>

      <div
        ref={scrollRef}
        onScroll={handleScroll}
        className="flex gap-2.5 w-full overflow-x-auto no-scrollbar snap-x snap-mandatory"
      >
        {displayAds.map((ad) => {
          const badge = ad.offer_badge || 'PROMO NEXT';
          const headline = ad.offer_title || ad.business_name;
          const cta = ad.cta_text || 'Ver oferta';

          return (
            <a
              key={ad.id}
              href={waLink(ad)}
              onClick={() => handleAdClick(ad)}
              className={`${displayAds.length > 1 ? 'w-[92%]' : 'w-full'} max-w-full rounded-2xl overflow-hidden flex-shrink-0 snap-start relative shadow-md border border-border/70 active:scale-[0.99] transition-all block bg-card`}
            >
              {/* Recuadro alargado de tamaño fijo (16:5): el arte de cada anuncio viene en ese mismo formato y lo llena completo */}
              <PromoBannerImage src={ad.image_url} alt={ad.business_name} ratio={16 / 5} />

              {/* Franja inferior compacta fuera de la imagen: ninguna etiqueta tapa el arte */}
              <div className="px-2.5 py-1.5 bg-card flex items-center justify-between gap-2 border-t border-border/50">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-md bg-amber-400 text-slate-950 text-[9px] font-extrabold uppercase tracking-wide flex-shrink-0">
                      <Tag className="w-2.5 h-2.5 fill-slate-950" />
                      {badge}
                    </span>
                    <p className="text-foreground font-extrabold text-xs truncate">
                      {headline}
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground mt-0.5 truncate">
                    <span className="text-amber-600 dark:text-amber-400 font-bold flex items-center gap-0.5 flex-shrink-0">
                      <Sparkles className="w-2.5 h-2.5" />
                      { `+${PURCHASE_POINTS} pts por adquirir` }
                    </span>
                    {ad.business_address && (
                      <>
                        <span>·</span>
                        <span className="truncate flex items-center gap-0.5">
                          <MapPin className="w-2.5 h-2.5 flex-shrink-0" />
                          {ad.business_address}
                        </span>
                      </>
                    )}
                  </div>
                </div>

                <span className="promo-cta-pulse inline-flex items-center gap-1 bg-[#25D366] hover:bg-[#20bd5a] text-white text-[10.5px] font-extrabold px-2.5 py-1.5 rounded-full shadow-sm flex-shrink-0">
                  <MessageCircle className="w-3 h-3 fill-white" />
                  {cta}
                </span>
              </div>
            </a>
          );
        })}
      </div>

      {/* Indicadores de carrusel */}
      <div className="flex items-center justify-center gap-1.5 mt-1.5">
        {Array.from({ length: Math.max(2, displayAds.length) }).slice(0, 5).map((_, i) => {
          const isCurrent = i === activeIndex;
          return (
            <span
              key={i}
              className={`h-1.5 rounded-full transition-all ${
                isCurrent ? 'w-4 bg-[#0284C7]' : 'w-1.5 bg-muted-foreground/30'
              }`}
            />
          );
        })}
      </div>

      {/* Modal Ver todas las promociones */}
      {showAll && typeof document !== 'undefined' && createPortal(
        <div className="pasajero-theme fixed inset-0 z-[1900] bg-background flex flex-col max-w-md mx-auto w-full h-[100dvh]">
          <div className="flex items-center justify-between px-4 py-3.5 bg-card border-b border-border flex-shrink-0">
            <div className="min-w-0">
              <h2 className="text-foreground font-extrabold text-base leading-tight">Promociones y Ofertas</h2>
              <p className="text-muted-foreground text-xs leading-snug mt-0.5">
                Gana +{PURCHASE_POINTS} puntos al preguntar, interactuar y adquirir el alimento o servicio con nuestros anunciantes
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowAll(false)}
              aria-label="Cerrar"
              className="ml-3 w-9 h-9 rounded-full bg-muted flex items-center justify-center flex-shrink-0 active:scale-95"
            >
              <X className="w-5 h-5 text-foreground" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {displayAds.map((ad) => {
              const badge = ad.offer_badge || 'PROMO NEXT';
              const headline = ad.offer_title || ad.business_name;
              const subtitle = ad.offer_title ? ad.business_name : (ad.category || 'Beneficio exclusivo para usuarios NEXT');
              const cta = ad.cta_text || 'Reclamar por WhatsApp';
              const untilDate = formatShortDate(ad.end_date);

              return (
                <a
                  key={ad.id}
                  href={waLink(ad)}
                  onClick={() => handleAdClick(ad)}
                  className="block bg-card rounded-2xl border border-border overflow-hidden shadow-sm active:scale-[0.99] transition-transform"
                >
                  <PromoBannerImage src={ad.image_url} alt={ad.business_name} className="max-h-[70dvh]" />
                  <div className="p-4">
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[11px] font-extrabold uppercase shadow-sm">
                          <Tag className="w-3 h-3 fill-slate-950" />
                          {badge}
                        </span>
                        {ad.category && (
                          <span className="px-2 py-0.5 rounded-full bg-muted text-muted-foreground text-[11px] font-semibold">
                            {ad.category}
                          </span>
                        )}
                      </div>
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-500/15 text-amber-600 dark:text-amber-400 text-xs font-bold flex-shrink-0">
                        <Sparkles className="w-3 h-3" />
                        +{PURCHASE_POINTS} pts al adquirir
                      </span>
                    </div>
                    <p className="text-foreground font-extrabold text-base leading-snug">
                      {headline}
                    </p>
                    <p className="text-primary font-bold text-xs mt-0.5">
                      {subtitle}
                    </p>
                    <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-muted-foreground">
                      {ad.business_address && (
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                          {ad.business_address}
                        </span>
                      )}
                      {untilDate && (
                        <span className="flex items-center gap-1 text-amber-600 dark:text-amber-400 font-medium">
                          <Clock className="w-3.5 h-3.5 flex-shrink-0" />
                          Válido hasta {untilDate}
                        </span>
                      )}
                    </div>
                    <div className="mt-3.5 flex items-center justify-between gap-3 pt-3 border-t border-border">
                      <span className="text-[11px] text-muted-foreground font-medium">
                        Pregunta y adquiere por WhatsApp (+{PURCHASE_POINTS} pts)
                      </span>
                      <span className="promo-cta-pulse inline-flex items-center gap-1.5 bg-[#25D366] text-white text-xs font-extrabold px-4 py-2 rounded-full shadow-sm flex-shrink-0">
                        <MessageCircle className="w-4 h-4 fill-white" />
                        {cta}
                      </span>
                    </div>
                  </div>
                </a>
              );
            })}
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}
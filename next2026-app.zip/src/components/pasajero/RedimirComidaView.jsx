import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import {
  ChevronLeft,
  Utensils,
  Sparkles,
  MapPin,
  Tag,
  MessageCircle,
  CheckCircle2,
  Loader2,
  Info,
} from 'lucide-react';

const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');
const fmtNum = (n) => Number(n || 0).toLocaleString('es-CO');

const FALLBACK_RESTAURANTS = [
  {
    id: 'fallback-1',
    business_name: 'Comidas Rápidas El Punto del Sabor',
    offer_badge: '2x1 HOY',
    offer_title: '2x1 en Hamburguesas Artesanales + Papas',
    category: 'Comidas rápidas',
    business_address: 'Calle 19D #16-30, Valledupar',
    whatsapp_number: '573177387749',
    image_url: 'https://images.unsplash.com/photo-1561758033-d89a9ad46330?auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 'fallback-2',
    business_name: 'Restaurante Gourmet & Café',
    offer_badge: '15% DTO',
    offer_title: '15% de descuento + Domicilio gratis con NEXT',
    category: 'Restaurante & Café',
    business_address: 'Barrio Novalito, Valledupar',
    whatsapp_number: '573177387749',
    image_url: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=800&q=80',
  },
];

// Equivalencia 1 a 1: 1 punto = $1 COP
const FOOD_BONOS = [
  { points: 5000, amount: 5000, label: 'Bono $5.000', sub: '5.000 pts' },
  { points: 10000, amount: 10000, label: 'Bono $10.000', sub: '10.000 pts' },
  { points: 15000, amount: 15000, label: 'Bono $15.000', sub: '15.000 pts' },
  { points: 20000, amount: 20000, label: 'Bono $20.000', sub: '20.000 pts' },
];

export default function RedimirComidaView({ pointsBalance = 0, onBack, onRedeemed }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [restaurants, setRestaurants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedAmounts, setSelectedAmounts] = useState({});
  const [redeemingId, setRedeemingId] = useState(null);
  const [lastClaim, setLastClaim] = useState(null);

  useEffect(() => {
    const loadAds = async () => {
      try {
        const page = await base44.entities.Advertisement.filter(
          { active: true },
          { sort: '-created_date', limit: 20 }
        );
        const list = page?.items || (Array.isArray(page) ? page : []);
        setRestaurants(list.length > 0 ? list : FALLBACK_RESTAURANTS);
      } catch {
        setRestaurants(FALLBACK_RESTAURANTS);
      } finally {
        setLoading(false);
      }
    };
    loadAds();
  }, []);

  const buildWaUrl = (rest, amount, code) => {
    let digits = (rest.whatsapp_number || '573177387749').replace(/\D/g, '');
    if (digits.length === 10 && digits.startsWith('3')) digits = `57${digits}`;
    const clientName = user?.display_name || user?.full_name || 'Cliente NEXT';
    const msg = code
      ? `Hola ${rest.business_name}, soy ${clientName}. Redimí ${fmtNum(amount)} puntos (${fmtCOP(amount)}) en la app NEXT para comida (Código: ${code}). Quiero hacer mi pedido.`
      : `Hola ${rest.business_name}, vi su restaurante en la sección de Redimir Puntos por Comida de la app NEXT y quiero conocer el menú para redimir mis puntos.`;
    return `whatsapp://send?phone=${digits}&text=${encodeURIComponent(msg)}`;
  };

  const handleRedeemFood = async (rest) => {
    const amount = selectedAmounts[rest.id] || 5000;
    if (!user?.id || redeemingId) return;
    if (pointsBalance < amount) {
      toast({
        title: 'Puntos insuficientes',
        description: `Necesitas ${fmtNum(amount)} puntos (${fmtCOP(amount)}) para redimir este bono en ${rest.business_name}. Tienes ${fmtNum(pointsBalance)} puntos.`,
      });
      return;
    }

    setRedeemingId(rest.id);
    try {
      const clientName = user.display_name || user.full_name || user.email || 'Pasajero';
      const code = `COMIDA-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;

      await base44.entities.PointsTransaction.create({
        user_id: user.id,
        user_name: clientName,
        amount: -amount,
        type: 'canje',
        advertisement_id: String(rest.id),
        business_name: rest.business_name,
        description: `Canje de comida (${fmtCOP(amount)}) en ${rest.business_name} · Código ${code}`,
      });

      await base44.entities.RewardClaim.create({
        scope: 'pasajero',
        user_id: user.id,
        goal_type: 'viajes_semana',
        period_key: `puntos-comida-${Date.now()}`,
        goal: amount,
        reward: `Bono comida ${fmtCOP(amount)} en ${rest.business_name} (${code})`,
        status: 'pendiente',
        notes: `Cliente: ${clientName} · Tel: ${user.phone || 'S/N'} · Restaurante: ${rest.business_name}`,
      });

      await base44.entities.Incidence.create({
        title: `Canje de Comida con Puntos · ${rest.business_name} (${fmtCOP(amount)})`,
        category: 'cliente',
        priority: 'media',
        status: 'abierta',
        description: [
          `Cliente: ${clientName} (${user.phone || 'sin teléfono'})`,
          `Restaurante elegido: ${rest.business_name}`,
          `Puntos redimidos: ${fmtNum(amount)} pts = ${fmtCOP(amount)}`,
          `Código de canje: ${code}`,
        ].join('\n'),
      }).catch(() => {});

      setLastClaim({ rest, amount, code });
      onRedeemed?.();
      toast({
        title: `¡Bono de ${fmtCOP(amount)} generado! 🍔`,
        description: `Redimiste ${fmtNum(amount)} puntos en ${rest.business_name}. Código: ${code}`,
      });
    } catch {
      toast({ title: 'No se pudo completar el canje', description: 'Intenta nuevamente.' });
    } finally {
      setRedeemingId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-[1900] bg-background w-full max-w-md mx-auto flex flex-col pb-[56px]">
      {/* Cabecera */}
      <div className="px-4 pt-5 pb-5 bg-gradient-to-br from-orange-500 via-rose-500 to-amber-500 text-white">
        <div className="flex items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              aria-label="Volver"
              className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center active:scale-95"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <Utensils className="w-5 h-5" />
              <h1 className="text-lg font-extrabold">Redimir en Comida</h1>
            </div>
          </div>

          <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/20 text-xs font-extrabold">
            <Sparkles className="w-3.5 h-3.5" />
            {fmtNum(pointsBalance)} pts
          </span>
        </div>

        <div className="bg-black/15 backdrop-blur-md border border-white/20 rounded-2xl p-3.5">
          <p className="text-xs font-bold uppercase tracking-wider text-white/85">
            Restaurantes aliados en publicidad
          </p>
          <p className="text-sm font-extrabold mt-0.5">
            1 punto = $1 COP · Elige tu restaurante y canjea tus puntos por comida
          </p>
          <p className="text-[11px] text-white/85 mt-1">
            Por ejemplo: <span className="font-bold">5.000 puntos = $5.000 pesos</span>, <span className="font-bold">10.000 puntos = $10.000 pesos</span> en cualquiera de nuestros restaurantes aliados.
          </p>
        </div>
      </div>

      {/* Lista de restaurantes */}
      <div className="flex-1 overflow-y-auto no-scrollbar px-4 py-4 space-y-4">
        {lastClaim && (
          <div className="rounded-2xl bg-emerald-50 dark:bg-emerald-500/15 border border-emerald-200 dark:border-emerald-500/30 p-4 space-y-2.5">
            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-xs font-extrabold text-emerald-800 dark:text-emerald-300">
                  ¡Bono listo por {fmtCOP(lastClaim.amount)} en {lastClaim.rest.business_name}!
                </p>
                <p className="text-[11.5px] text-emerald-700 dark:text-emerald-300/90 mt-0.5">
                  Código de canje: <span className="font-extrabold">{lastClaim.code}</span>. Envía tu código por WhatsApp al restaurante para reclamar tu pedido.
                </p>
              </div>
            </div>
            <a
              href={buildWaUrl(lastClaim.rest, lastClaim.amount, lastClaim.code)}
              className="w-full h-10 rounded-xl bg-[#25D366] text-white font-extrabold text-xs flex items-center justify-center gap-2 shadow-sm"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              Reclamar mi pedido por WhatsApp
            </a>
          </div>
        )}

        <div className="flex items-center justify-between">
          <p className="text-xs font-extrabold text-muted-foreground uppercase tracking-wider">
            Restaurantes disponibles ({restaurants.length})
          </p>
          <span className="text-[11px] font-bold text-orange-600 dark:text-orange-400">
            Elige dónde redimir
          </span>
        </div>

        {loading ? (
          <div className="flex justify-center py-10">
            <Loader2 className="w-6 h-6 animate-spin text-orange-500" />
          </div>
        ) : (
          <div className="space-y-4">
            {restaurants.map((rest) => {
              const chosenAmt = selectedAmounts[rest.id] || 5000;
              const enough = pointsBalance >= chosenAmt;
              const isBusy = redeemingId === rest.id;

              return (
                <div
                  key={rest.id}
                  className="bg-card rounded-2xl border border-border overflow-hidden shadow-sm"
                >
                  {/* Imagen del restaurante */}
                  <div className="relative w-full h-40 bg-slate-950 flex items-center justify-center overflow-hidden">
                    {rest.image_url && (
                      <>
                        <img
                          src={rest.image_url}
                          alt=""
                          aria-hidden="true"
                          className="absolute inset-0 w-full h-full object-cover blur-lg scale-110 opacity-50"
                        />
                        <img
                          src={rest.image_url}
                          alt={rest.business_name}
                          className="relative z-10 w-full h-full object-contain"
                        />
                      </>
                    )}
                    <span className="absolute top-2.5 left-2.5 z-20 inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-400 text-slate-950 text-[10px] font-extrabold uppercase shadow">
                      <Tag className="w-3 h-3 fill-slate-950" />
                      {rest.offer_badge || 'RESTAURANTE ALIADO'}
                    </span>
                  </div>

                  <div className="p-4 space-y-3">
                    <div>
                      <h3 className="text-foreground font-extrabold text-base leading-tight">
                        {rest.business_name}
                      </h3>
                      <p className="text-primary font-bold text-xs mt-0.5">
                        {rest.offer_title || 'Canjea tus puntos por productos del menú'}
                      </p>
                      {rest.business_address && (
                        <p className="text-muted-foreground text-xs flex items-center gap-1 mt-1">
                          <MapPin className="w-3.5 h-3.5 flex-shrink-0" />
                          {rest.business_address}
                        </p>
                      )}
                    </div>

                    {/* Selector de monto de puntos a redimir en este restaurante */}
                    <div>
                      <p className="text-[11px] font-bold text-muted-foreground mb-1.5">
                        Selecciona cuántos puntos quieres redimir:
                      </p>
                      <div className="grid grid-cols-2 gap-2">
                        {FOOD_BONOS.map((b) => {
                          const active = chosenAmt === b.amount;
                          return (
                            <button
                              key={b.amount}
                              type="button"
                              onClick={() =>
                                setSelectedAmounts((prev) => ({ ...prev, [rest.id]: b.amount }))
                              }
                              className={`rounded-xl border px-3 py-2 text-left transition-all ${
                                active
                                  ? 'border-orange-500 bg-orange-500/10 text-foreground'
                                  : 'border-border bg-muted/40 text-muted-foreground'
                              }`}
                            >
                              <p className="text-xs font-extrabold text-foreground">{b.label}</p>
                              <p className="text-[10px] font-semibold text-orange-600 dark:text-orange-400">
                                {b.sub}
                              </p>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-1">
                      <button
                        type="button"
                        disabled={Boolean(redeemingId)}
                        onClick={() => handleRedeemFood(rest)}
                        className={`flex-1 h-11 rounded-xl font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all ${
                          enough
                            ? 'bg-gradient-to-r from-orange-500 to-rose-500 text-white active:scale-[0.99]'
                            : 'bg-muted text-muted-foreground'
                        }`}
                      >
                        {isBusy ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <>
                            <Sparkles className="w-4 h-4" />
                            <span>
                              Redimir {fmtNum(chosenAmt)} pts ({fmtCOP(chosenAmt)})
                            </span>
                          </>
                        )}
                      </button>

                      <a
                        href={buildWaUrl(rest, chosenAmt, null)}
                        className="h-11 px-3.5 rounded-xl bg-[#25D366]/15 text-[#1da851] dark:text-[#25D366] font-extrabold text-xs flex items-center justify-center gap-1 flex-shrink-0"
                      >
                        <MessageCircle className="w-4 h-4" />
                        <span>Ver menú</span>
                      </a>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <div className="flex items-start gap-2.5 bg-orange-500/10 border border-orange-500/20 rounded-2xl p-3.5">
          <Info className="w-4 h-4 text-orange-500 flex-shrink-0 mt-0.5" />
          <p className="text-[11.5px] text-muted-foreground leading-relaxed">
            Cada punto equivale a <span className="font-bold text-foreground">$1 peso COP</span>. Al redimir tus puntos en uno de los restaurantes en publicidad, se genera tu código de canje y se notifica a Central para respaldar tu pedido.
          </p>
        </div>
      </div>
    </div>
  );
}
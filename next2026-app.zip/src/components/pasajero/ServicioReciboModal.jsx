import React, { useState } from 'react';
import { Receipt, HandCoins, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import { parseUtcDate } from '@/lib/dateBogota';
import { useBackButton } from '@/hooks/useBackButton';

const fmtMoney = (n) => 'COP ' + Number(n || 0).toLocaleString('es-CO');
const PAYMENT_NAMES = {
  efectivo: 'Efectivo',
  nequi: 'Nequi',
  daviplata: 'DaviPlata',
  bancolombia: 'Bancolombia',
  paga_con_llave: 'Paga con llave',
  transferencia: 'Transferencia',
};

export function ServicioReciboModal({ service, vehicleLabel, onClose }) {
  useBackButton(onClose, true);
  const baseFare = Number(service.fare || 0);
  const totalPaid = Number(service.collected_amount || service.fare || 0);
  const extraAmount = Math.max(0, totalPaid - baseFare);
  const dateStr = service.created_date
    ? parseUtcDate(service.created_date).toLocaleString('es-CO', {
        weekday: 'long',
        day: '2-digit',
        month: 'long',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
        timeZone: 'America/Bogota',
      })
    : '—';

  return (
    <div className="fixed inset-0 z-[2100] flex items-end sm:items-center justify-center bg-black/65 backdrop-blur-sm px-3">
      <div className="w-full max-w-md bg-card rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-border animate-in slide-in-from-bottom">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-primary/15 flex items-center justify-center">
              <Receipt className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="text-foreground font-bold text-base">Recibo del servicio</h3>
              <p className="text-muted-foreground text-[11px] capitalize">{dateStr}</p>
            </div>
          </div>
        </div>

        <div className="bg-muted/60 rounded-2xl p-4 space-y-2.5 text-sm mb-4">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Tipo de servicio</span>
            <span className="text-foreground font-semibold">{vehicleLabel}</span>
          </div>
          {service.mobile_name && (
            <div className="flex justify-between">
              <span className="text-muted-foreground">Conductor</span>
              <span className="text-foreground font-semibold">{service.mobile_name}</span>
            </div>
          )}
          {service.mobile_plate && (
            <div className="flex justify-between">
              <span className="text-muted-foreground">Placa</span>
              <span className="text-foreground font-semibold">{service.mobile_plate}</span>
            </div>
          )}
          <div className="flex justify-between">
            <span className="text-muted-foreground">Método de pago</span>
            <span className="text-foreground font-semibold">
              {PAYMENT_NAMES[service.payment_method] || service.payment_method || 'Efectivo'}
            </span>
          </div>
          <div className="border-t border-border pt-2.5 flex justify-between">
            <span className="text-muted-foreground">Tarifa del viaje</span>
            <span className="text-foreground font-medium">{fmtMoney(baseFare)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Monto extra</span>
            <span className="text-foreground font-medium">{fmtMoney(extraAmount)}</span>
          </div>
          <div className="border-t border-border pt-2.5 flex justify-between text-base font-extrabold text-foreground">
            <span>Total</span>
            <span className="text-primary">{fmtMoney(totalPaid)}</span>
          </div>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full h-11 rounded-full bg-primary text-primary-foreground font-bold text-sm"
        >
          Cerrar recibo
        </button>
      </div>
    </div>
  );
}

export function ExtraAmountModal({ service, onSaved, onClose }) {
  useBackButton(onClose, true);
  const { toast } = useToast();
  const baseFare = Number(service.fare || 0);
  const currentExtra = Math.max(0, Number(service.collected_amount || service.fare || 0) - baseFare);
  const [extra, setExtra] = useState(currentExtra || 2000);
  const [saving, setSaving] = useState(false);

  const presets = [1000, 2000, 3000, 5000];

  const save = async () => {
    setSaving(true);
    try {
      const newTotal = baseFare + Math.max(0, Number(extra || 0));
      const updated = await base44.entities.Service.update(service.id, {
        collected_amount: newTotal,
      });
      toast({ title: 'Monto extra guardado', description: `Total actualizado a ${fmtMoney(newTotal)}` });
      onSaved?.(updated);
    } catch {
      toast({ title: 'No se pudo guardar el monto extra', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[2100] flex items-end sm:items-center justify-center bg-black/65 backdrop-blur-sm px-3">
      <div className="w-full max-w-md bg-card rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-border animate-in slide-in-from-bottom">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-primary/15 flex items-center justify-center">
              <HandCoins className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="text-foreground font-bold text-base">Agregar monto extra</h3>
              <p className="text-muted-foreground text-xs">Reconoce el buen servicio de tu conductor</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-4 gap-2 mb-4">
          {presets.map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => setExtra(p)}
              className={`h-10 rounded-xl font-bold text-xs border transition-colors ${
                Number(extra) === p
                  ? 'border-primary bg-primary text-primary-foreground'
                  : 'border-border bg-muted text-foreground'
              }`}
            >
              +{fmtMoney(p)}
            </button>
          ))}
        </div>

        <div className="mb-4">
          <label className="text-xs text-muted-foreground block mb-1">Otro valor (COP)</label>
          <input
            type="number"
            min="0"
            step="500"
            value={extra}
            onChange={(e) => setExtra(e.target.value)}
            className="w-full h-11 rounded-xl bg-muted border border-border px-3 text-sm font-bold text-foreground outline-none focus:border-primary"
          />
        </div>

        <button
          type="button"
          disabled={saving}
          onClick={save}
          className="w-full h-11 rounded-full bg-primary text-primary-foreground font-bold text-sm flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Guardar monto extra'}
        </button>
      </div>
    </div>
  );
}
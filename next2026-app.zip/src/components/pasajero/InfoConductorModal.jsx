import React, { useState } from 'react';
import { Info, Briefcase, Plug, PawPrint, Minus, Plus } from 'lucide-react';
import { useBackButton } from '@/hooks/useBackButton';

const NEEDS = [
  { key: 'extra_space', icon: Briefcase, title: 'Llevar cosas', desc: 'Necesito espacio extra' },
  { key: 'charger', icon: Plug, title: 'Cargador', desc: 'Para mi dispositivo' },
  { key: 'pet', icon: PawPrint, title: 'Mascota', desc: 'Viaja conmigo' },
];

// Modal "Información para tu conductor": personas, necesidades y comentario.
export default function InfoConductorModal({ initial, onSubmit, onClose }) {
  useBackButton(onClose, true);
  const [people, setPeople] = useState(initial?.passenger_count ?? 1);
  const [needs, setNeeds] = useState({
    extra_space: initial?.need_extra_space ?? false,
    charger: initial?.need_charger ?? false,
    pet: initial?.with_pet ?? false,
  });
  const [comment, setComment] = useState(initial?.driver_comment ?? '');

  const toggle = (k) => setNeeds((n) => ({ ...n, [k]: !n[k] }));

  const save = () => onSubmit({
    passenger_count: people,
    need_extra_space: needs.extra_space,
    need_charger: needs.charger,
    with_pet: needs.pet,
    driver_comment: comment.slice(0, 150),
  });

  return (
    <div className="fixed inset-0 z-[2000] flex items-end max-w-md mx-auto w-full">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full bg-card rounded-t-[28px] p-5 pb-8 shadow-2xl animate-in slide-in-from-bottom max-h-[92vh] overflow-y-auto no-scrollbar">
        <div className="w-10 h-1.5 rounded-full bg-muted mx-auto mb-4" />

        <div className="flex items-center justify-center mb-1">
          <h2 className="text-foreground font-extrabold text-lg text-center">Información para tu conductor</h2>
        </div>
        <p className="text-muted-foreground text-xs text-center mb-5">Cuéntale lo que necesita saber antes de llegar.</p>

        {/* Personas */}
        <h3 className="text-foreground font-bold text-sm mb-3">¿Cuántas personas viajan?</h3>
        <div className="flex items-center justify-center gap-6 mb-5">
          <button type="button" onClick={() => setPeople((p) => Math.max(1, p - 1))} className="w-11 h-11 rounded-full bg-muted flex items-center justify-center">
            <Minus className="w-5 h-5 text-foreground" />
          </button>
          <span className="text-2xl font-bold text-foreground w-8 text-center">{people}</span>
          <button type="button" onClick={() => setPeople((p) => Math.min(6, p + 1))} className="w-11 h-11 rounded-full bg-muted flex items-center justify-center">
            <Plus className="w-5 h-5 text-foreground" />
          </button>
        </div>

        {/* Necesidades */}
        <h3 className="text-foreground font-bold text-sm mb-3">¿Necesitas algo adicional?</h3>
        <div className="grid grid-cols-3 gap-2 mb-5">
          {NEEDS.map((n) => {
            const Icon = n.icon;
            const active = needs[n.key];
            return (
              <button key={n.key} type="button" onClick={() => toggle(n.key)}
                className={`rounded-2xl p-3 flex flex-col items-center text-center gap-1 border-2 ${active ? 'border-[#8926c9] bg-[#f3eafa] dark:bg-[#8926c9]/15' : 'border-border bg-muted'}`}>
                <Icon className={`w-6 h-6 ${active ? 'text-[#8926c9]' : 'text-muted-foreground'}`} />
                <span className={`text-xs font-bold ${active ? 'text-foreground' : 'text-muted-foreground'}`}>{n.title}</span>
                <span className="text-[10px] text-muted-foreground leading-tight">{n.desc}</span>
                <span className={`w-4 h-4 rounded-full border-2 mt-1 flex items-center justify-center ${active ? 'border-[#8926c9] bg-[#8926c9]' : 'border-muted-foreground/40'}`}>
                  {active && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                </span>
              </button>
            );
          })}
        </div>

        {/* Comentario */}
        <h3 className="text-foreground font-bold text-sm mb-2">Comentario adicional</h3>
        <textarea value={comment} onChange={(e) => setComment(e.target.value.slice(0, 150))} rows={3}
          placeholder="Ejemplo: Estoy en la entrada principal, llevo equipaje, etc."
          className="w-full bg-muted rounded-2xl p-3 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-[#8926c9] border border-transparent resize-none" />
        <p className="text-right text-[10px] text-muted-foreground mb-4">{comment.length}/150</p>

        {/* Info banner */}
        <div className="rounded-2xl bg-[#f3eafa] dark:bg-[#8926c9]/10 p-3 flex items-start gap-2 mb-5">
          <Info className="w-4 h-4 text-[#8926c9] flex-shrink-0 mt-0.5" />
          <p className="text-xs text-[#6b2a8d] dark:text-[#c084fc]">Esta información se enviará al conductor después de confirmar tu solicitud.</p>
        </div>

        <button onClick={save} className="w-full h-13 py-3.5 rounded-full bg-[#8926c9] text-white font-bold">Guardar y continuar</button>
      </div>
    </div>
  );
}
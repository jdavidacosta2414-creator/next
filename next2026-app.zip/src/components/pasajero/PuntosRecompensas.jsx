import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { ChevronLeft, Gift, Sparkles, Car, Utensils, Wallet, TrendingUp, Loader2, Info, Target, Check } from 'lucide-react';
import { PASSENGER_WEEKLY_GOAL, PASSENGER_REWARDS, weekBounds } from '@/lib/rewards';
import RedimirComidaView from '@/components/pasajero/RedimirComidaView';
import RedimirCarreraView from '@/components/pasajero/RedimirCarreraView';
import { useBackButton } from '@/hooks/useBackButton';

const fmtDate = (d) => new Date(d).toLocaleDateString('es-CO', { day: '2-digit', month: 'short', timeZone: 'America/Bogota' });
const fmtTime = (d) => new Date(d).toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit', hour12: true, timeZone: 'America/Bogota' });
const fmtNum = (n) => Number(n || 0).toLocaleString('es-CO');

const REWARDS_ICON = { carrera_gratis: Car, salchipapa: Utensils, efectivo: Wallet };

const TYPE_META = {
  interaccion_click: { label: 'Servicio / producto adquirido', tone: 'text-[#1E6BFF] bg-[#1E6BFF]/10' },
  compra_confirmada: { label: 'Compra / servicio adquirido (+50 pts)', tone: 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-500/15' },
  referido_pendiente: { label: 'Referido registrado (por aprobar)', tone: 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-500/15' },
  referido_aprobado: { label: 'Bono por referido aprobado (+100 pts)', tone: 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-500/15' },
  canje: { label: 'Canje de recompensa', tone: 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-500/15' },
  ajuste: { label: 'Ajuste / devolución', tone: 'text-muted-foreground bg-muted' },
};

const REWARDS = [
  {
    key: 'carrera',
    icon: Car,
    title: 'Carrera gratis',
    desc: 'Coloca Punto A y B y viaja con tus puntos',
    color: 'from-[#1E6BFF] to-[#00E5FF]',
  },
  {
    key: 'comida',
    icon: Utensils,
    title: 'Comida gratis',
    desc: 'Elige entre los restaurantes en publicidad',
    color: 'from-orange-400 to-rose-400',
  },
  {
    key: 'billetera',
    icon: Wallet,
    title: 'Saldo en billetera',
    desc: '2.000 pts = $2.000 hasta 50.000 pts',
    color: 'from-violet-500 to-fuchsia-500',
  },
];

export default function PuntosRecompensas({
  onBack,
  onOpenBilletera,
  onStartRedeemRide,
}) {
  const { user } = useAuth();
  const [balance, setBalance] = useState(0);
  const [moves, setMoves] = useState([]);
  const [loading, setLoading] = useState(true);
  const [weekTrips, setWeekTrips] = useState(0);
  const [weekClaim, setWeekClaim] = useState(null);
  const [claiming, setClaiming] = useState(false);
  const [subView, setSubView] = useState(null); // 'carrera' | 'comida' | null

  useBackButton(() => {
    if (subView) {
      setSubView(null);
      return true;
    }
    return false;
  }, true);

  const load = useCallback(async () => {
    if (!user?.id) {
      setLoading(false);
      return;
    }
    try {
      const wr = weekBounds();
      const [agg, page, weekCount, claimPage] = await Promise.all([
        base44.entities.PointsTransaction.aggregate({ query: { user_id: user.id }, sum: 'amount' }),
        base44.entities.PointsTransaction.filter({ user_id: user.id }, { sort: '-created_date', limit: 50 }),
        base44.entities.Service.count({
          created_by_id: user.id,
          status: 'finalizado',
          created_date: { $gte: wr.start.toISOString(), $lt: wr.end.toISOString() },
        }),
        base44.entities.RewardClaim.filter({
          scope: 'pasajero',
          user_id: user.id,
          goal_type: 'viajes_semana',
          period_key: wr.key,
        }),
      ]);
      setBalance(agg.rows?.[0]?.sum_amount || 0);
      setMoves(page.items || []);
      setWeekTrips(weekCount || 0);
      setWeekClaim((claimPage.items || claimPage || [])[0] || null);
    } catch (e) {}
    setLoading(false);
  }, [user?.id]);

  useEffect(() => {
    load();
    const unsub = base44.entities.PointsTransaction.subscribe(() => load().catch(() => {}));
    return unsub;
  }, [load]);

  const claimReward = async (rewardTitle) => {
    if (!user?.id || claiming) return;
    setClaiming(true);
    try {
      const wr = weekBounds();
      await base44.entities.RewardClaim.create({
        scope: 'pasajero',
        user_id: user.id,
        user_name: user.display_name || user.full_name || user.email || 'Pasajero',
        goal_type: 'viajes_semana',
        period_key: wr.key,
        goal: PASSENGER_WEEKLY_GOAL,
        reward: rewardTitle,
        status: 'pendiente',
      });
      await load();
    } catch (e) {}
    setClaiming(false);
  };

  if (subView === 'comida') {
    return (
      <RedimirComidaView
        pointsBalance={balance}
        onBack={() => setSubView(null)}
        onRedeemed={load}
      />
    );
  }

  if (subView === 'carrera') {
    return (
      <RedimirCarreraView
        pointsBalance={balance}
        onBack={() => setSubView(null)}
        onStartRedeemRide={(opts) => {
          setSubView(null);
          onStartRedeemRide?.(opts);
        }}
      />
    );
  }

  const weekPct = Math.min(100, Math.round((weekTrips / PASSENGER_WEEKLY_GOAL) * 100));
  const reached = weekTrips >= PASSENGER_WEEKLY_GOAL;

  return (
    <div className="fixed inset-0 z-[1800] bg-background w-full max-w-md mx-auto flex flex-col pb-[56px]">
      <div className="px-4 pt-5 pb-4 bg-gradient-to-br from-[#1E6BFF] to-[#0a3aa8] text-white">
        <div className="flex items-center gap-3 mb-5">
          <button
            onClick={onBack}
            className="w-9 h-9 rounded-full bg-white/15 flex items-center justify-center active:scale-95"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <Gift className="w-5 h-5" />
            <h1 className="text-lg font-bold">Puntos y recompensas</h1>
          </div>
        </div>
        <div className="flex items-end justify-between">
          <div>
            <p className="text-white/70 text-xs font-medium uppercase tracking-wider">Tus puntos</p>
            <div className="flex items-end gap-1.5 mt-0.5">
              <span className="text-4xl font-extrabold leading-none">{fmtNum(balance)}</span>
              <Sparkles className="w-5 h-5 mb-1 text-[#00E5FF]" />
            </div>
          </div>
          <div className="text-right">
            <p className="text-white/70 text-[11px]">Movimientos</p>
            <p className="text-xl font-bold">{moves.length}</p>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar px-4 py-4 space-y-6">
        <section>
          <div className="flex items-center gap-2 mb-2">
            <Target className="w-4 h-4 text-[#1E6BFF]" />
            <p className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider">
              Meta semanal de viajes
            </p>
          </div>
          <div className="rounded-2xl border border-border bg-card p-4">
            <div className="flex items-end justify-between mb-2">
              <p className="text-sm font-bold text-foreground">
                {weekTrips} de {PASSENGER_WEEKLY_GOAL} viajes
              </p>
              <p className="text-[11px] text-muted-foreground">esta semana</p>
            </div>
            <div className="h-2.5 rounded-full bg-muted overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] transition-all"
                style={{ width: `${weekPct}%` }}
              />
            </div>
            {reached ? (
              weekClaim ? (
                <div className="mt-3 flex items-start gap-2 bg-emerald-50 dark:bg-emerald-500/15 border border-emerald-100 dark:border-emerald-500/20 rounded-xl p-3">
                  <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-emerald-700 dark:text-emerald-300 font-medium">
                    Recompensa reclamada: {weekClaim.reward}. Central la entregará pronto.
                  </p>
                </div>
              ) : (
                <div className="mt-3">
                  <p className="text-xs text-foreground font-semibold mb-2">
                    ¡Meta alcanzada! Elige tu recompensa:
                  </p>
                  <div className="space-y-2">
                    {PASSENGER_REWARDS.map((r) => {
                      const Icon = REWARDS_ICON[r.id] || Gift;
                      return (
                        <button
                          key={r.id}
                          disabled={claiming}
                          onClick={() => claimReward(r.title)}
                          className="w-full flex items-center gap-3 bg-card border border-border rounded-xl p-3 active:scale-[0.99] disabled:opacity-60"
                        >
                          <div className="w-9 h-9 rounded-xl bg-[#1E6BFF]/10 flex items-center justify-center">
                            <Icon className="w-4 h-4 text-[#1E6BFF]" />
                          </div>
                          <div className="flex-1 text-left">
                            <p className="text-sm font-bold text-foreground">{r.title}</p>
                            <p className="text-[11px] text-muted-foreground">{r.desc}</p>
                          </div>
                          <span className="text-[11px] font-bold text-[#1E6BFF]">Reclamar</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )
            ) : (
              <p className="mt-3 text-[11px] text-muted-foreground">
                Te faltan <span className="font-bold text-foreground">{PASSENGER_WEEKLY_GOAL - weekTrips}</span> viajes para desbloquear una recompensa esta semana.
              </p>
            )}
          </div>
        </section>

        <section>
          <p className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider mb-2">
            Redimir puntos (1 punto = $1 COP)
          </p>
          <div className="grid grid-cols-3 gap-3">
            {REWARDS.map((r) => {
              const Icon = r.icon;
              return (
                <button
                  key={r.key}
                  type="button"
                  onClick={() => {
                    if (r.key === 'billetera') onOpenBilletera?.();
                    else if (r.key === 'comida') setSubView('comida');
                    else if (r.key === 'carrera') setSubView('carrera');
                  }}
                  className="rounded-2xl border border-[#1E6BFF]/35 hover:border-[#1E6BFF] bg-card p-3 flex flex-col items-center text-center transition-all active:scale-[0.98] shadow-sm"
                >
                  <div
                    className={`w-11 h-11 rounded-2xl bg-gradient-to-br ${r.color} flex items-center justify-center mb-2 shadow-sm`}
                  >
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  <p className="text-[12px] font-bold text-foreground leading-tight">{r.title}</p>
                  <p className="text-[10px] text-muted-foreground leading-tight mt-0.5">{r.desc}</p>
                </button>
              );
            })}
          </div>
          <div className="mt-3 flex items-start gap-2 bg-[#1E6BFF]/5 border border-[#1E6BFF]/10 rounded-xl p-3">
            <Info className="w-4 h-4 text-[#1E6BFF] flex-shrink-0 mt-0.5" />
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              Suma <span className="font-bold text-foreground">+{fmtNum(50)} puntos por adquirir el alimento, producto o servicio</span> de los negocios en publicidad (dale clic al anuncio, pregunta, interactúa y compra con nuestros anunciantes; no se dan puntos solo por dar clic). <span className="font-bold text-foreground">2.000 puntos equivalen a $2.000 pesos</span> hasta llegar a 50.000 puntos ($50.000 COP).
            </p>
          </div>
        </section>

        <section>
          <p className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider mb-2">
            Historial de puntos
          </p>
          {loading ? (
            <div className="flex items-center justify-center py-10">
              <Loader2 className="w-6 h-6 text-muted-foreground/40 animate-spin" />
            </div>
          ) : moves.length === 0 ? (
            <div className="text-center py-10">
              <div className="w-14 h-14 rounded-full bg-muted flex items-center justify-center mx-auto mb-3">
                <TrendingUp className="w-6 h-6 text-muted-foreground/40" />
              </div>
              <p className="text-sm font-semibold text-muted-foreground">Aún no tienes puntos</p>
              <p className="text-xs text-muted-foreground/70 mt-1">
                Abre las promociones de la pantalla principal para empezar a sumar.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {moves.filter((m) => m.status !== 'rechazado').map((m) => {
                const isPending = m.status === 'pendiente' || (m.type === 'interaccion_click' && Number(m.amount) === 0);
                const meta = isPending
                  ? { label: 'Compra por confirmar en Central', tone: 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-500/15' }
                  : (TYPE_META[m.type] || TYPE_META.ajuste);
                const positive = m.amount >= 0;
                return (
                  <div
                    key={m.id}
                    className="flex items-center gap-3 bg-card border border-border rounded-2xl p-3"
                  >
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${meta.tone}`}
                    >
                      <TrendingUp className={`w-5 h-5 ${positive ? '' : 'rotate-180'}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-foreground truncate">{meta.label}</p>
                      <p className="text-[11px] text-muted-foreground truncate">
                        {m.business_name ? m.business_name + ' · ' : ''}
                        {fmtDate(m.created_date)} · {fmtTime(m.created_date)}
                      </p>
                      {m.description && (
                        <p className="text-[11px] text-muted-foreground/70 truncate mt-0.5">
                          {m.description}
                        </p>
                      )}
                    </div>
                    {isPending ? (
                      <span className="text-[11px] font-bold px-2 py-1 rounded-lg bg-amber-500/15 text-amber-600 dark:text-amber-400 flex-shrink-0">
                        Pendiente +50
                      </span>
                    ) : (
                      <span
                        className={`text-sm font-extrabold flex-shrink-0 ${
                          positive
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : 'text-amber-600 dark:text-amber-400'
                        }`}
                      >
                        {positive ? '+' : ''}
                        {fmtNum(m.amount)}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
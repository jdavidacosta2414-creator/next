import React from 'react';
import { Minus, Plus, Send, Loader2, Wallet, MessageCircle, Gift, X } from 'lucide-react';
import Vehicle3DIcon from '@/components/shared/Vehicle3DIcon';
import FreeRideToggle from '@/components/club/FreeRideToggle';

const fmtCOP = (n) => '$' + Number(n).toLocaleString('es-CO');

export default function PasajeroConfigSheet({
  onClose,
  mapInteracting,
  submit,
  selectedVehicle,
  suggestedFare,
  form,
  set,
  contentTypes,
  adjustFare,
  fareMin,
  error,
  setShowPay,
  payments,
  loading,
  setInfoOpen,
  freeRidesAvailable = 0,
}) {
  return (
    <div
      data-testid="pasajero-config-sheet"
      className={`relative z-20 -mt-4 min-h-[50dvh] flex flex-col rounded-t-[26px] border-t border-border/70 bg-card px-4 pt-2.5 pb-4 shadow-[0_-8px_30px_rgba(0,0,0,0.22)] flex-shrink-0 transition-all duration-200 ease-out ${
        mapInteracting ? 'translate-y-full opacity-0 pointer-events-none' : 'translate-y-0 opacity-100'
      }`}
    >
      <div className="relative h-8 mb-1.5 flex items-center justify-center">
        <div className="w-10 h-1 rounded-full bg-muted" />
        <button
          type="button"
          onClick={onClose}
          aria-label="Cerrar"
          className="absolute right-0 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-muted text-foreground flex items-center justify-center active:scale-95"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <form onSubmit={submit} className="flex-1 flex flex-col justify-between gap-3.5">
        {/* Vehículo y precio sugerido */}
        <div className="w-full flex items-center gap-3.5 bg-muted/70 border border-border/50 rounded-2xl px-4 py-3 text-left">
          <Vehicle3DIcon
            src={selectedVehicle.img}
            alt={selectedVehicle.label}
            flip={selectedVehicle.flip}
            scale={1.05}
            className="w-16 h-12 flex-shrink-0"
          />
          <div className="flex-1 min-w-0">
            <p className="text-base font-extrabold text-foreground leading-tight">{selectedVehicle.label}</p>
            <p className="text-xs font-medium text-muted-foreground leading-tight mt-0.5">{selectedVehicle.subtitle}</p>
          </div>
          <div className="text-right">
            <span className="text-lg font-extrabold text-primary block leading-tight">{fmtCOP(suggestedFare)}</span>
            <span className="text-xs text-muted-foreground font-semibold block leading-tight mt-0.5">Precio sugerido</span>
          </div>
        </div>

        {form.service_type === 'mensajeria' && (
          <div>
            <label className="text-xs font-bold text-muted-foreground tracking-wider block mb-1.5">
              ¿QUÉ VAS A ENVIAR?
            </label>
            <div className="flex flex-wrap gap-2">
              {contentTypes.map((opt) => (
                <button
                  key={opt.v}
                  type="button"
                  onClick={() => set('content_type', opt.v)}
                  className={`px-3 h-8 rounded-full text-xs font-bold border ${
                    form.content_type === opt.v
                      ? 'border-primary bg-primary/10 text-foreground'
                      : 'border-border text-muted-foreground'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {form.payment_method === 'redimido_puntos' && (
          <div className="rounded-2xl bg-[#1E6BFF]/10 border border-[#1E6BFF]/30 px-3.5 py-2 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <Gift className="w-4 h-4 text-[#1E6BFF] flex-shrink-0" />
              <p className="text-xs font-extrabold text-[#1E6BFF] truncate">
                Canje: {Number(form.fare || 0).toLocaleString('es-CO')} pts ({fmtCOP(form.fare)})
              </p>
            </div>
            <button
              type="button"
              onClick={() => set('payment_method', 'efectivo')}
              className="text-xs font-bold text-muted-foreground underline flex-shrink-0"
            >
              Cambiar
            </button>
          </div>
        )}

        {form.service_type === 'transporte' && form.vehicle_type === 'moto' && (
          <FreeRideToggle
            available={freeRidesAvailable}
            checked={Boolean(form.use_free_ride)}
            onChange={(v) => set('use_free_ride', v)}
            fare={form.fare}
          />
        )}

        {/* Tarifa recomendada */}
        <div>
          <div className="flex items-center justify-between px-1 mb-2">
            <span className="text-xs font-extrabold text-muted-foreground tracking-wider uppercase">
              {form.payment_method === 'redimido_puntos' ? 'MONTO EN PUNTOS' : 'TARIFA RECOMENDADA'}
            </span>
            <span className="text-xs text-muted-foreground font-bold">
              Tarifa mínima {fmtCOP(fareMin[form.vehicle_type])}
            </span>
          </div>
          <div className="flex items-center justify-between bg-muted/70 border border-border/50 rounded-2xl px-3.5 py-2.5">
            <button
              type="button"
              onClick={() => adjustFare(-500)}
              className="w-12 h-12 rounded-2xl bg-card border border-border flex items-center justify-center shadow-sm active:scale-95 transition-transform"
            >
              <Minus className="w-5 h-5 text-foreground stroke-[2.5]" />
            </button>
            <span className="text-3xl font-black text-primary tracking-tight">{fmtCOP(form.fare)}</span>
            <button
              type="button"
              onClick={() => adjustFare(500)}
              className="w-12 h-12 rounded-2xl bg-card border border-border flex items-center justify-center shadow-sm active:scale-95 transition-transform"
            >
              <Plus className="w-5 h-5 text-foreground stroke-[2.5]" />
            </button>
          </div>
        </div>

        {/* Nombre y teléfono */}
        <div className="grid grid-cols-2 gap-3">
          <input
            required
            value={form.client_name}
            onChange={(e) => set('client_name', e.target.value)}
            placeholder="Tu nombre"
            className="h-12 bg-muted/70 rounded-2xl px-3.5 text-sm font-bold text-foreground placeholder:text-muted-foreground outline-none focus:border-primary border border-border/50"
          />
          <input
            value={form.client_phone}
            onChange={(e) => set('client_phone', e.target.value)}
            placeholder="Teléfono"
            className="h-12 bg-muted/70 rounded-2xl px-3.5 text-sm font-bold text-foreground placeholder:text-muted-foreground outline-none focus:border-primary border border-border/50"
          />
        </div>

        {error && (
          <p className="text-xs font-semibold text-red-500 bg-red-50 dark:bg-red-950/30 rounded-xl p-2.5 text-center">
            {error}
          </p>
        )}

        {/* Botones de pago, Buscar conductor y comentarios */}
        <div className="flex items-center gap-2.5 pt-1">
          <button
            type="button"
            onClick={() => setShowPay(true)}
            className="w-14 h-14 rounded-2xl bg-muted/80 border border-border/70 flex flex-col items-center justify-center gap-1 flex-shrink-0 active:scale-95 transition-transform"
          >
            <Wallet className="w-5 h-5 text-foreground flex-shrink-0" />
            <span className="text-[10.5px] font-extrabold text-foreground leading-none truncate max-w-[50px]">
              {(payments.find((p) => p.v === form.payment_method)?.label || 'Efectivo').split(' ')[0]}
            </span>
          </button>
          <button
            type="submit"
            disabled={loading}
            data-testid="submit-search-driver-btn"
            className="flex-1 min-w-0 h-14 px-4 bg-gradient-to-r from-[#0B439C] via-[#1463FF] to-[#1E6BFF] text-white font-extrabold text-[15px] leading-none whitespace-nowrap rounded-2xl flex items-center justify-center gap-2 disabled:opacity-50 shadow-lg shadow-[#1E6BFF]/30 active:scale-[0.99] transition-transform"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin flex-shrink-0" />
                <span className="leading-none">Enviando...</span>
              </>
            ) : (
              <>
                <Send className="w-4 h-4 flex-shrink-0" />
                <span className="leading-none">Buscar conductor</span>
              </>
            )}
          </button>
          <button
            type="button"
            onClick={() => setInfoOpen(true)}
            className="w-14 h-14 rounded-2xl bg-muted/80 border border-border/70 flex items-center justify-center flex-shrink-0 active:scale-95 transition-transform"
          >
            <MessageCircle className="w-5 h-5 text-foreground flex-shrink-0" />
          </button>
        </div>
      </form>
    </div>
  );
}
import React, { useState } from 'react';
import { AlertTriangle, Loader2, HelpCircle, MapPin } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { withRetry } from '@/lib/api-helpers';
import { useBackButton } from '@/hooks/useBackButton';

const REASONS = [
  { value: 'ya_no_necesito', label: 'Ya no necesito el viaje' },
  { value: 'direccion_equivocada', label: 'Dirección equivocada', icon: 'pin' },
  { value: 'pedi_por_error', label: 'Me equivoqué al solicitar' },
  { value: 'conductor_demora', label: 'El tiempo de espera es muy alto' },
  { value: 'cambie_direccion', label: 'Cambié mi destino' },
  { value: 'otro', label: 'Otro motivo' },
];

// Modal de cancelación de solicitud (pasajero): motivo + detalle.
// Si un conductor ya tomó el servicio, lo libera y le notifica por chat.
export default function CancelRequestModal({ serviceId, mobileId, mobileName, onCancelled, onClose }) {
  useBackButton(onClose, true);
  const [reason, setReason] = useState('');
  const [detail, setDetail] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    if (!reason) return;
    setLoading(true);
    try {
      const reasonLabel = REASONS.find((r) => r.value === reason)?.label || reason;
      await withRetry(() =>
        base44.entities.Service.update(serviceId, {
          status: 'cancelado',
          cancelled_by: 'pasajero',
          cancel_reason: reason,
          client_cancel_detail: detail.trim() || null,
        })
      );
      if (mobileId) {
        try { await withRetry(() => base44.entities.Mobile.update(mobileId, { status: 'disponible' })); } catch {}
        base44.functions.invoke('driverPerformance', {
          action: 'record_event',
          mobile_id: mobileId,
          service_id: serviceId,
          event_type: 'cancelled_by_passenger',
          cancelled_by: 'pasajero',
          cancel_reason: reason,
        }).catch(() => {});
        try {
          await base44.entities.ServiceMessage.create({
            service_id: serviceId,
            sender_type: 'cliente',
            sender_name: 'Cliente',
            message: `El cliente canceló el servicio. Motivo: ${reasonLabel}${detail.trim() ? ` — ${detail.trim()}` : ''}`,
          });
        } catch {}
      }
      onCancelled?.();
    } catch (e) {
      setLoading(false);
      alert('No se pudo cancelar: ' + (e.message || 'intenta de nuevo'));
    }
  };

  return (
    <div className="fixed inset-0 z-[3000] bg-black/40 flex items-center justify-center p-4 max-w-md mx-auto">
      <div className="bg-card rounded-3xl w-full max-w-sm p-5 shadow-2xl max-h-[92vh] overflow-y-auto no-scrollbar">
        <div className="flex flex-col items-center text-center mb-4">
          <div className="w-14 h-14 rounded-full bg-red-100 dark:bg-red-500/15 flex items-center justify-center mb-3">
            <AlertTriangle className="w-7 h-7 text-[#C84B4B] dark:text-red-400" />
          </div>
          <h2 className="text-foreground font-bold text-lg">Cancelar solicitud</h2>
          <p className="text-muted-foreground text-xs mt-1">Se cancelará la búsqueda y los conductores dejarán de ver este pedido.</p>
        </div>

        <div className="space-y-2 mb-4">
          {REASONS.map((r) => {
            const selected = reason === r.value;
            return (
              <button
                key={r.value}
                onClick={() => setReason(r.value)}
                className={`w-full flex items-center gap-3 rounded-xl border px-3 py-3 text-left ${selected ? 'border-red-500 bg-red-50 dark:bg-red-500/15' : 'border-border bg-card'}`}
              >
                <span className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${selected ? 'border-red-500' : 'border-muted-foreground/40'}`}>
                  {selected && <span className="w-2.5 h-2.5 rounded-full bg-red-500" />}
                </span>
                <span className={`flex-1 text-sm font-medium ${selected ? 'text-red-600 dark:text-red-400' : 'text-foreground'}`}>{r.label}</span>
                <span className="w-6 h-6 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                  {r.icon === 'pin' ? <MapPin className="w-3.5 h-3.5 text-muted-foreground" /> : <HelpCircle className="w-3.5 h-3.5 text-muted-foreground" />}
                </span>
              </button>
            );
          })}
        </div>

        <p className="text-xs text-muted-foreground mb-1.5">Agrega más detalles (opcional)</p>
        <textarea
          value={detail}
          onChange={(e) => setDetail(e.target.value.slice(0, 120))}
          rows={3}
          placeholder="Cuéntanos brevemente qué ocurrió..."
          className="w-full rounded-xl border border-border bg-card p-3 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-red-400 resize-none"
        />
        <p className="text-right text-[10px] text-muted-foreground mt-0.5 mb-4">{detail.length}/120</p>

        <div className="flex gap-3">
          <button onClick={onClose} disabled={loading} className="flex-1 h-12 rounded-xl border-2 border-red-500 text-red-600 dark:text-red-400 font-bold text-sm disabled:opacity-50">
            Volver
          </button>
          <button onClick={submit} disabled={!reason || loading} className="flex-1 h-12 rounded-xl bg-red-600 text-white font-bold text-sm disabled:opacity-50 flex items-center justify-center gap-2">
            {loading && <Loader2 className="w-4 h-4 animate-spin" />} Cancelar viaje
          </button>
        </div>
      </div>
    </div>
  );
}
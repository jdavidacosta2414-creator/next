import React from 'react';
import { Check } from 'lucide-react';
import Vehicle3DIcon from '@/components/shared/Vehicle3DIcon';

// Ilustraciones 3D de vehículos sin cuadro blanco de fondo.
const SERVICES = [
  { key: 'carro', label: 'Carro', subtitle: 'Rápido y seguro', img: 'https://media.base44.com/images/public/6ab13aed46d61158e305a1ce/ac3f196ed_generated_image.png', scale: 0.9 },
  { key: 'moto', label: 'Moto', subtitle: 'Ágil y económico', img: 'https://media.base44.com/images/public/6ab13aed46d61158e305a1ce/dc499356e_generated_image.png', flip: true, scale: 0.9 },
  { key: 'mensajeria', label: 'Mensajería', subtitle: 'Tus envíos a tiempo', img: 'https://media.base44.com/images/public/6ab13aed46d61158e305a1ce/dbc636d13_generated_image.png', scale: 0.94 },
];

export default function ServiceSelector({ value, onSelect }) {
  return (
    <div className="grid grid-cols-3 gap-2 mb-1.5 w-full">
      {SERVICES.map((s) => {
        const active = value === s.key;
        return (
          <button
            key={s.key}
            type="button"
            onClick={() => onSelect(s.key)}
            className={`relative min-w-0 overflow-hidden rounded-2xl px-1.5 pt-2 pb-1.5 flex flex-col items-center justify-between text-center transition-all ${
              active
                ? 'bg-[#EEF6FF] dark:bg-primary/15 border-2 border-[#0EA5E9] shadow-sm'
                : 'bg-[#F8FAFC] dark:bg-muted/60 border border-border/60'
            }`}
          >
            {active && (
              <span className="absolute top-1.5 right-1.5 z-20 w-4 h-4 rounded-full bg-[#0EA5E9] text-white flex items-center justify-center shadow-sm">
                <Check className="w-2.5 h-2.5 stroke-[3]" />
              </span>
            )}
            <Vehicle3DIcon
              src={s.img}
              alt={s.label}
              flip={s.flip}
              scale={s.scale}
              className="w-[62px] h-9"
            />
            <div className="mt-0.5 w-full min-w-0">
              <p className="font-extrabold text-[12px] text-foreground leading-tight truncate">
                {s.label}
              </p>
              <p className="text-[9px] text-muted-foreground leading-tight mt-0.5 truncate">
                {s.subtitle}
              </p>
            </div>
          </button>
        );
      })}
    </div>
  );
}
import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { ChevronLeft, Loader2, Send, MessageCircle, CheckCircle2, PackageSearch, Phone } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

// Número de soporte por WhatsApp. Actualízalo con el número oficial de la empresa.
const SUPPORT_PHONE = '573008353849';

// Formulario para reportar un objeto perdido u olvidado en un viaje específico.
// El reporte se envía al panel administrativo para que Central contacte al conductor.
export default function LostItemForm({ trip, user, onClose, onSent }) {
  const { toast } = useToast();
  const [description, setDescription] = useState('');
  const [name, setName] = useState(user?.full_name || '');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    if (!description.trim()) { toast({ description: 'Describe el objeto olvidado.' }); return; }
    if (!name.trim() || !phone.trim()) { toast({ description: 'Completa tus datos de contacto.' }); return; }
    setLoading(true);
    try {
      await base44.entities.LostItemReport.create({
        service_id: trip.id,
        pickup_address: trip.pickup_address || null,
        destination_address: trip.destination_address || null,
        service_date: trip.created_date,
        vehicle_type: trip.vehicle_type || null,
        mobile_id: trip.mobile_id || null,
        mobile_name: trip.mobile_name || null,
        mobile_plate: trip.mobile_plate || null,
        mobile_phone: trip.mobile_phone || null,
        reporter_name: name,
        reporter_phone: phone,
        object_description: description,
        status: 'nuevo',
      });
      setSent(true);
      toast({ title: 'Reporte enviado', description: 'Central se comunicará contigo pronto.' });
    } catch (err) {
      toast({ description: 'No se pudo enviar el reporte. Intenta de nuevo.' });
    } finally { setLoading(false); }
  };

  const waLink = `whatsapp://send?phone=${SUPPORT_PHONE}&text=${encodeURIComponent('Hola, olvidé un objeto en un viaje de NEXT. Viaje de ' + (trip.pickup_address || '') + ' a ' + (trip.destination_address || ''))}`;

  if (sent) {
    return (
      <div className="fixed inset-0 z-[2100] max-w-md mx-auto bg-background flex flex-col">
        <div className="flex items-center gap-3 px-4 h-14 border-b border-border">
          <button onClick={onSent} aria-label="Cerrar" className="w-9 h-9 rounded-full bg-muted flex items-center justify-center">
            <ChevronLeft className="w-5 h-5 text-foreground" />
          </button>
          <p className="text-foreground font-bold text-lg">Reporte enviado</p>
        </div>
        <div className="flex-1 flex flex-col items-center justify-center px-6 text-center">
          <CheckCircle2 className="w-16 h-16 text-green-500 mb-4" />
          <p className="text-foreground font-bold text-lg mb-1">¡Reporte recibido!</p>
          <p className="text-sm text-muted-foreground mb-6">Central recibió tu reporte y se comunicará contigo para coordinar la devolución del objeto.</p>
          <a href={waLink} className="w-full h-12 rounded-2xl bg-[#25D366] text-white font-bold flex items-center justify-center gap-2 mb-3">
            <MessageCircle className="w-5 h-5" /> Escribir a soporte por WhatsApp
          </a>
          <button onClick={onSent} className="w-full h-12 rounded-2xl bg-muted text-foreground font-bold">Listo</button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[2100] max-w-md mx-auto bg-background flex flex-col">
      <div className="flex items-center gap-3 px-4 h-14 border-b border-border">
        <button onClick={onClose} aria-label="Volver" className="w-9 h-9 rounded-full bg-muted flex items-center justify-center">
          <ChevronLeft className="w-5 h-5 text-foreground" />
        </button>
        <p className="text-foreground font-bold text-lg flex-1">Objeto olvidado</p>
      </div>

      <form onSubmit={submit} className="flex-1 overflow-y-auto no-scrollbar px-4 py-4">
        {/* Viaje relacionado */}
        <div className="bg-muted rounded-2xl p-3 mb-4">
          <p className="text-[10px] font-bold text-muted-foreground tracking-wider mb-1">VIAJE RELACIONADO</p>
          <p className="text-sm font-medium text-foreground">{trip.mobile_name || 'Conductor'} · {trip.mobile_plate || 'Sin placa'}</p>
          <p className="text-xs text-muted-foreground mt-0.5">{trip.pickup_address || '—'} → {trip.destination_address || '—'}</p>
        </div>

        {/* Descripción */}
        <label className="text-[10px] font-bold text-muted-foreground tracking-wider block mb-1.5">¿QUÉ OLVIDASTE?</label>
        <textarea
          value={description} onChange={(e) => setDescription(e.target.value)} rows={4} required
          placeholder="Describe el objeto (color, tamaño, marca, contenido...)"
          className="w-full bg-muted rounded-xl p-3 text-sm text-foreground placeholder:text-muted-foreground outline-none border border-transparent focus:border-[#8926c9] mb-4 resize-none"
        />

        {/* Contacto */}
        <label className="text-[10px] font-bold text-muted-foreground tracking-wider block mb-1.5">TUS DATOS DE CONTACTO</label>
        <div className="grid grid-cols-1 gap-2 mb-3">
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Tu nombre" required
            className="h-11 bg-muted rounded-xl px-3 text-sm text-foreground placeholder:text-muted-foreground outline-none border border-transparent focus:border-[#8926c9]" />
          <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Tu teléfono" required type="tel"
            className="h-11 bg-muted rounded-xl px-3 text-sm text-foreground placeholder:text-muted-foreground outline-none border border-transparent focus:border-[#8926c9]" />
        </div>

        <button type="submit" disabled={loading}
          className="w-full h-13 py-3.5 bg-[#8926c9] text-white font-bold rounded-2xl flex items-center justify-center gap-2 disabled:opacity-50 shadow-lg shadow-[#8926c9]/30 mb-3">
          {loading ? <><Loader2 className="w-5 h-5 animate-spin" />Enviando...</> : <><Send className="w-5 h-5" />Enviar reporte</>}
        </button>

        <a href={waLink} className="w-full h-12 rounded-2xl bg-[#25D366]/10 border border-[#25D366]/30 text-[#1a8e3a] dark:text-emerald-400 font-bold flex items-center justify-center gap-2 mb-2">
          <MessageCircle className="w-5 h-5" /> Contactar soporte por WhatsApp
        </a>
        <a href={`tel:${SUPPORT_PHONE}`} className="w-full h-12 rounded-2xl bg-[#1E6BFF]/10 border border-[#1E6BFF]/30 text-[#1E6BFF] font-bold flex items-center justify-center gap-2">
          <Phone className="w-5 h-5" /> Llamar a soporte
        </a>
      </form>
    </div>
  );
}
import React from 'react';
import { Bike } from 'lucide-react';
import { cn } from '@/lib/utils';

const SIZES = {
  sm: { box: 'w-8 h-8 rounded-lg', icon: 'w-5 h-5', text: 'text-base' },
  md: { box: 'w-11 h-11 rounded-xl', icon: 'w-6 h-6', text: 'text-lg' },
  lg: { box: 'w-16 h-16 rounded-2xl', icon: 'w-9 h-9', text: 'text-2xl' },
};

export default function MotoLinkLogo({ size = 'md', showText = true, className }) {
  const s = SIZES[size] || SIZES.md;
  return (
    <div className={cn('flex items-center gap-2', className)}>
      <div className={cn(s.box, 'bg-primary flex items-center justify-center flex-shrink-0 shadow-sm')}>
        <Bike className={cn(s.icon, 'text-primary-foreground')} />
      </div>
      {showText && (
        <span className={cn(s.text, 'font-bold tracking-tight text-foreground')}>
          Moto<span className="text-primary">Link</span>
        </span>
      )}
    </div>
  );
}
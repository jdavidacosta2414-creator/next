import React, { useEffect, useState } from 'react';
import { buildBackDiagReport, getBackDiagEvents, getBackDiagSnapshot, subscribeBackDiag } from '@/lib/backDiagnostics';

// Panel TEMPORAL de diagnóstico del botón Atrás. No registra manejadores de retroceso.
export default function BackDiagnosticsPanel() {
  const [open, setOpen] = useState(false);
  const [, setTick] = useState(0);
  const [copied, setCopied] = useState('');

  useEffect(() => {
    if (!open) return;
    const unsub = subscribeBackDiag(() => setTick((n) => n + 1));
    const t = setInterval(() => setTick((n) => n + 1), 1000);
    return () => { unsub(); clearInterval(t); };
  }, [open]);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(buildBackDiagReport());
      setCopied('Copiado');
    } catch {
      setCopied('No se pudo copiar: mantén presionado el texto para seleccionarlo');
    }
  };

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} className="fixed left-1 top-1/2 z-[3000] w-9 h-9 rounded-full bg-amber-500/80 text-[10px] font-bold text-black shadow">
        DX
      </button>
    );
  }

  const snap = getBackDiagSnapshot();
  const events = [...getBackDiagEvents()].reverse();
  return (
    <div className="fixed inset-x-2 top-12 bottom-24 z-[3000] rounded-xl bg-black/90 text-white text-[10px] font-mono flex flex-col select-text">
      <div className="flex gap-2 p-2 border-b border-white/20">
        <span className="font-bold flex-1">Diagnóstico Atrás</span>
        <button onClick={copy} className="px-2 py-1 rounded bg-amber-500 text-black font-bold">Copiar informe</button>
        <button onClick={() => setOpen(false)} className="px-2 py-1 rounded bg-white/20">Cerrar</button>
      </div>
      {copied && <p className="px-2 py-1 text-amber-300">{copied}</p>}
      <div className="overflow-y-auto p-2 space-y-0.5">
        {Object.entries(snap).map(([k, v]) => (
          <p key={k} className="break-all"><span className="text-amber-300">{k}:</span> {typeof v === 'object' ? JSON.stringify(v) : String(v)}</p>
        ))}
        <p className="pt-2 text-amber-300 font-bold">Eventos (más reciente arriba)</p>
        {events.map((e, i) => (
          <p key={i} className="break-all">[{e.t}s] <b>{e.type}</b> {e.detail}</p>
        ))}
      </div>
    </div>
  );
}
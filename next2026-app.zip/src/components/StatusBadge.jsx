import { cn } from '@/lib/utils';

const CONFIG = {
  pendiente: { label: 'Pendiente', cls: 'bg-[#F59E0B]/15 text-[#F59E0B]' },
  asignado: { label: 'Asignado', cls: 'bg-blue-500/15 text-blue-400' },
  en_camino: { label: 'En camino', cls: 'bg-blue-500/15 text-blue-400' },
  recogida: { label: 'En recogida', cls: 'bg-blue-500/15 text-blue-400' },
  finalizado: { label: 'Finalizado', cls: 'bg-[#1E6BFF]/15 text-[#1E6BFF]' },
  rechazado: { label: 'Rechazado', cls: 'bg-red-500/15 text-red-400' },
  cancelado: { label: 'Cancelado', cls: 'bg-red-500/15 text-red-400' },
  disponible: { label: 'Disponible', cls: 'bg-[#1E6BFF]/15 text-[#1E6BFF]' },
  ocupado: { label: 'Ocupado', cls: 'bg-[#F59E0B]/15 text-[#F59E0B]' },
  offline: { label: 'Offline', cls: 'bg-[#262626] text-[#8B8C94]' },
  pagada: { label: 'Pagada', cls: 'bg-[#1E6BFF]/15 text-[#1E6BFF]' },
  bloqueado: { label: 'Bloqueado', cls: 'bg-red-500/15 text-red-400' },
};

export default function StatusBadge({ status }) {
  const c = CONFIG[status] || { label: status, cls: 'bg-[#262626] text-[#8B8C94]' };
  return <span className={cn('inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium', c.cls)}>{c.label}</span>;
}
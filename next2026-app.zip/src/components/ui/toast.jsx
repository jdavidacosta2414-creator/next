import * as React from "react";
import * as ToastPrimitives from "@radix-ui/react-toast";
import { cva } from "class-variance-authority";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

const ToastProvider = ToastPrimitives.Provider;

const ToastViewport = React.forwardRef(({ className, ...props }, ref) => (
  <ToastPrimitives.Viewport
    ref={ref}
    className={cn(
      "pointer-events-none fixed left-1/2 -translate-x-1/2 top-[calc(var(--apk-status-bar-height,0px)+10px)] z-[2600] flex max-h-screen w-[calc(100%-24px)] max-w-[360px] flex-col gap-1.5 p-0",
      className
    )}
    {...props}
  />
));
ToastViewport.displayName = ToastPrimitives.Viewport.displayName;

const toastVariants = cva(
  "group pointer-events-auto relative flex w-full items-center justify-between gap-2.5 overflow-hidden rounded-2xl border px-3.5 py-2.5 pr-8 shadow-xl backdrop-blur-md select-none touch-pan-y transition-all data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-80 data-[state=open]:slide-in-from-top-3",
  {
    variants: {
      variant: {
        default: "border-border/80 bg-card/95 text-foreground shadow-black/20",
        destructive:
          "destructive group border-destructive bg-destructive/95 text-destructive-foreground",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
);

const Toast = React.forwardRef(
  ({ className, variant, onSwipeDismiss, style, ...props }, ref) => {
    const startXRef = React.useRef(null);
    const [dragX, setDragX] = React.useState(0);
    const [swipingOut, setSwipingOut] = React.useState(null);

    const handleStart = (clientX) => {
      if (swipingOut) return;
      startXRef.current = clientX;
    };

    const handleMove = (clientX) => {
      if (startXRef.current == null || swipingOut) return;
      setDragX(clientX - startXRef.current);
    };

    const handleEnd = () => {
      if (startXRef.current == null || swipingOut) return;
      startXRef.current = null;
      if (Math.abs(dragX) > 40) {
        const dir = dragX > 0 ? 1 : -1;
        setSwipingOut(dir);
        setTimeout(() => {
          onSwipeDismiss?.();
        }, 140);
      } else {
        setDragX(0);
      }
    };

    const translateX = swipingOut ? swipingOut * 380 : dragX;
    const opacity = swipingOut
      ? 0
      : Math.max(0.25, 1 - Math.abs(dragX) / 240);

    return (
      <ToastPrimitives.Root
        ref={ref}
        onTouchStart={(e) => {
          if (e.touches?.[0]) handleStart(e.touches[0].clientX);
        }}
        onTouchMove={(e) => {
          if (e.touches?.[0]) handleMove(e.touches[0].clientX);
        }}
        onTouchEnd={handleEnd}
        onTouchCancel={handleEnd}
        onPointerDown={(e) => {
          if (e.pointerType === "mouse") handleStart(e.clientX);
        }}
        onPointerMove={(e) => {
          if (e.pointerType === "mouse") handleMove(e.clientX);
        }}
        onPointerUp={(e) => {
          if (e.pointerType === "mouse") handleEnd();
        }}
        style={{
          ...style,
          transform: `translate3d(${translateX}px, 0, 0)`,
          opacity,
          transition:
            startXRef.current != null
              ? "none"
              : "transform 150ms ease-out, opacity 150ms ease-out",
        }}
        className={cn(toastVariants({ variant }), className)}
        {...props}
      />
    );
  }
);
Toast.displayName = ToastPrimitives.Root.displayName;

const ToastAction = React.forwardRef(({ className, ...props }, ref) => (
  <ToastPrimitives.Action
    ref={ref}
    className={cn(
      "inline-flex h-8 shrink-0 items-center justify-center rounded-md border bg-transparent px-3 text-sm font-medium ring-offset-background transition-colors hover:bg-secondary focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 group-[.destructive]:border-muted/40 group-[.destructive]:hover:border-destructive/30 group-[.destructive]:hover:bg-destructive group-[.destructive]:hover:text-destructive-foreground group-[.destructive]:focus:ring-destructive",
      className
    )}
    {...props}
  />
));
ToastAction.displayName = ToastPrimitives.Action.displayName;

const ToastClose = React.forwardRef(({ className, ...props }, ref) => (
  <ToastPrimitives.Close
    ref={ref}
    className={cn(
      "absolute right-2 top-2 rounded-full p-1 text-foreground/60 opacity-80 transition-opacity hover:text-foreground hover:opacity-100 focus:opacity-100 focus:outline-none group-[.destructive]:text-red-200 group-[.destructive]:hover:text-white",
      className
    )}
    toast-close=""
    {...props}
  >
    <X className="h-3.5 w-3.5" />
  </ToastPrimitives.Close>
));
ToastClose.displayName = ToastPrimitives.Close.displayName;

const ToastTitle = React.forwardRef(({ className, ...props }, ref) => (
  <ToastPrimitives.Title
    ref={ref}
    className={cn("text-xs font-bold leading-snug line-clamp-1", className)}
    {...props}
  />
));
ToastTitle.displayName = ToastPrimitives.Title.displayName;

const ToastDescription = React.forwardRef(({ className, ...props }, ref) => (
  <ToastPrimitives.Description
    ref={ref}
    className={cn("text-[11px] leading-snug opacity-90 line-clamp-2", className)}
    {...props}
  />
));
ToastDescription.displayName = ToastPrimitives.Description.displayName;

export {
  ToastProvider,
  ToastViewport,
  Toast,
  ToastTitle,
  ToastDescription,
  ToastClose,
  ToastAction,
};
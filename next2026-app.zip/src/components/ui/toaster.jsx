import { useToast } from "@/components/ui/use-toast";
import {
  Toast,
  ToastClose,
  ToastDescription,
  ToastProvider,
  ToastTitle,
  ToastViewport,
} from "@/components/ui/toast";

export function Toaster() {
  const { toasts, dismiss } = useToast();

  return (
    <ToastProvider duration={2400} swipeThreshold={35}>
      {toasts.map(function ({ id, title, description, action, onDismiss, ...props }) {
        return (
          <Toast
            key={id}
            onSwipeDismiss={() => {
              onDismiss?.();
              dismiss(id);
            }}
            {...props}
          >
            <div className="grid gap-0.5 min-w-0 flex-1">
              {title && <ToastTitle>{title}</ToastTitle>}
              {description && (
                <ToastDescription>{description}</ToastDescription>
              )}
            </div>
            {action}
            <ToastClose
              onClick={() => {
                onDismiss?.();
                dismiss(id);
              }}
            />
          </Toast>
        );
      })}
      <ToastViewport />
    </ToastProvider>
  );
}
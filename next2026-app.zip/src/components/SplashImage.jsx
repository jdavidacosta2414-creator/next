import { useLayoutEffect } from 'react';
import { holdBootSplash } from '@/lib/bootSplash';

// Mantiene en pantalla la imagen de apertura (la misma que ya se ve desde que abre la app)
// mientras esta vista esté montada.
export default function SplashImage() {
  useLayoutEffect(holdBootSplash, []);
  return null;
}
import React from 'react';
import { Check } from 'lucide-react';

const STEPS = [
  { status: 'pendiente', label: 'Buscando mensajero' },
  { status: 'asignado', label: 'Mensajero asignado' },
  { status: 'en_camino', label: 'En camino al comercio' },
  { status: 'recogida', label: 'Pedido recogido, va hacia ti' },
  { status: 'finalizado', label: 'Entregado' },
];

export default function SeguimientoPasos({ status }) {
  const current = STEPS.findIndex((s) => s.status === status);
  return (
    <ol className="space-y-2">
      {STEPS.map((step, i) => {
        const done = i < current || status === 'finalizado';
        const active = i === current && !done;
        return (
          <li key={step.status} className="flex items-center gap-2.5">
            <span
              className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${
                done ? 'bg-primary text-primary-foreground' : active ? 'border-2 border-primary' : 'border-2 border-border'
              }`}
            >
              {done && <Check className="w-3 h-3" />}
              {active && <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />}
            </span>
            <span className={`text-sm ${done || active ? 'text-foreground font-semibold' : 'text-muted-foreground'}`}>
              {step.label}
            </span>
          </li>
        );
      })}
    </ol>
  );
}
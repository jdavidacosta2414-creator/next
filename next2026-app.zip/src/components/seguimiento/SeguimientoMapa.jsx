import React from 'react';
import MapboxMap, { MapboxMarker, MapboxDrivingRoute, MapboxFitBounds } from '@/components/shared/MapboxMap';
import { bluePulsePointEl, redDestinationPinEl, topDownMotoMarkerEl } from '@/lib/mapboxMarkers';
import { seedSavedRoute } from '@/lib/mapRoute';

const toPos = (p) => (p?.lat != null && p?.lng != null ? [Number(p.lat), Number(p.lng)] : null);

// Mapa del enlace público de seguimiento: comercio, destino y mensajero (solo mientras el pedido está activo).
export default function SeguimientoMapa({ order, onRouteInfo }) {
  const pickup = toPos(order.pickup);
  const dest = toPos(order.destination);
  const courier = toPos(order.courier_location);
  const target = order.status === 'recogida' ? dest : pickup;
  const points = [courier, pickup, dest].filter(Boolean);
  seedSavedRoute({
    ...order,
    pickup_lat: pickup?.[0],
    pickup_lng: pickup?.[1],
    destination_lat: dest?.[0],
    destination_lng: dest?.[1],
  });

  return (
    <MapboxMap center={courier || pickup || dest} zoom={14} className="h-full w-full">
      {pickup && (
        <MapboxMarker lat={pickup[0]} lng={pickup[1]} el={() => bluePulsePointEl()} anchor="center" interactive={false} />
      )}
      {dest && (
        <MapboxMarker lat={dest[0]} lng={dest[1]} el={() => redDestinationPinEl()} anchor="bottom" interactive={false} />
      )}
      {courier && (
        <MapboxMarker lat={courier[0]} lng={courier[1]} el={() => topDownMotoMarkerEl(35)} smooth interactive={false} />
      )}
      {courier && target ? (
        <MapboxDrivingRoute from={courier} to={target} onRouteInfo={onRouteInfo} />
      ) : (
        pickup && dest && <MapboxDrivingRoute from={pickup} to={dest} />
      )}
      <MapboxFitBounds positions={points} padding={60} fitKey={order.status} />
    </MapboxMap>
  );
}
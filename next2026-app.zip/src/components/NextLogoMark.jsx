import React, { useId } from 'react';
import { cn } from '@/lib/utils';

// Marca de logo NEXT: doble chevron en degradado azul/cian (sin texto).
export default function NextLogoMark({ size = 48, className, withGlow = false }) {
  const raw = useId();
  const id = `nextmark-${raw.replace(/:/g, '')}`;
  return (
    <div className={cn('relative', className)} style={{ width: size, height: size }}>
      <svg viewBox="0 0 48 48" className="relative w-full h-full">
        <defs>
          <linearGradient id={id} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#00E5FF" />
            <stop offset="100%" stopColor="#1E6BFF" />
          </linearGradient>
        </defs>
        <path d="M15 7 L29 24 L15 41 L15 34 L22 24 L15 14 Z" fill={`url(#${id})`} />
        <path d="M27 7 L41 24 L27 41 L27 34 L34 24 L27 14 Z" fill={`url(#${id})`} />
      </svg>
    </div>
  );
}
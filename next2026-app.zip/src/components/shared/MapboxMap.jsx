import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { mapboxgl, loadMapbox } from '@/lib/mapboxLoader';
import 'mapbox-gl/dist/mapbox-gl.css';
import { Loader2 } from 'lucide-react';
import { useMapboxToken, DEFAULT_MAPBOX_TOKEN } from '@/hooks/useMapboxToken';
import { fetchRoute, sliceRouteFromPosition, checkDriverRouteDeviation } from '@/lib/mapRoute';
import { useTheme } from '@/lib/ThemeContext';

const MapContext = createContext(null);
export const useMap = () => useContext(MapContext);

// Estilo con cartografía oficial actualizada de Google Maps optimizado para datos móviles y Wi-Fi en Colombia
function createGoogleMapsStyle() {
  const conn = typeof navigator !== 'undefined' ? navigator.connection : null;
  const isCellularOrConstrained =
    Boolean(conn?.saveData) ||
    conn?.type === 'cellular' ||
    conn?.effectiveType === '2g' ||
    conn?.effectiveType === 'slow-2g' ||
    conn?.effectiveType === '3g' ||
    (typeof conn?.downlink === 'number' && conn.downlink < 6) ||
    (typeof conn?.rtt === 'number' && conn.rtt > 120);
  const scaleParam = isCellularOrConstrained ? '1' : '2';

  return {
    version: 8,
    sources: {
      'google-roadmap-hd': {
        type: 'raster',
        tiles: [
          `https://mt0.google.com/vt/lyrs=m&hl=es&gl=co&x={x}&y={y}&z={z}&scale=${scaleParam}`,
          `https://mt1.google.com/vt/lyrs=m&hl=es&gl=co&x={x}&y={y}&z={z}&scale=${scaleParam}`,
          `https://mt2.google.com/vt/lyrs=m&hl=es&gl=co&x={x}&y={y}&z={z}&scale=${scaleParam}`,
          `https://mt3.google.com/vt/lyrs=m&hl=es&gl=co&x={x}&y={y}&z={z}&scale=${scaleParam}`,
        ],
        tileSize: 256,
        maxzoom: 20,
      },
    },
    layers: [
      {
        id: 'google-roadmap-layer',
        type: 'raster',
        source: 'google-roadmap-hd',
        minzoom: 0,
        maxzoom: 22,
        paint: {
          'raster-fade-duration': 0,
        },
      },
    ],
  };
}

let routeIdCounter = 0;

export default function MapboxMap({
  center,
  zoom = 14,
  pitch = 0,
  bearing = 0,
  vector = false,
  stageStyle = null,
  className,
  dark = false,
  cursor,
  onMapClick,
  onDragStart,
  onInteractStart,
  onInteractEnd,
  onTileError,
  children,
}) {
  const hookToken = useMapboxToken();
  const token = hookToken || DEFAULT_MAPBOX_TOKEN;
  const themeCtx = useTheme();
  const [domDark, setDomDark] = useState(() =>
    typeof document !== 'undefined' && document.documentElement.classList.contains('dark')
  );

  useEffect(() => {
    if (typeof document === 'undefined' || typeof MutationObserver === 'undefined') return;
    const sync = () => setDomDark(document.documentElement.classList.contains('dark'));
    sync();
    const obs = new MutationObserver(sync);
    obs.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
    return () => obs.disconnect();
  }, []);

  const isDark = Boolean(dark || themeCtx?.theme === 'dark' || domDark);

  const containerRef = useRef(null);
  const [map, setMap] = useState(null);
  // La librería del mapa llega aparte (ver mapboxLoader): el mapa se crea en cuanto está lista
  const [libReady, setLibReady] = useState(() => Boolean(mapboxgl));

  const clickRef = useRef(onMapClick);
  const errorRef = useRef(onTileError);
  const dragStartRef = useRef(onDragStart);
  const interactStartRef = useRef(onInteractStart);
  const interactEndRef = useRef(onInteractEnd);
  clickRef.current = onMapClick;
  errorRef.current = onTileError;
  dragStartRef.current = onDragStart;
  interactStartRef.current = onInteractStart;
  interactEndRef.current = onInteractEnd;

  useEffect(() => {
    if (libReady) return;
    let alive = true;
    loadMapbox()
      .then(() => {
        if (alive) setLibReady(true);
      })
      .catch(() => {
        if (alive) errorRef.current?.();
      });
    return () => {
      alive = false;
    };
  }, [libReady]);

  useEffect(() => {
    if (!token || !libReady || !containerRef.current) return;
    let alive = true;
    let mapInstance = null;
    let ro = null;

    try {
      mapboxgl.accessToken = DEFAULT_MAPBOX_TOKEN;

      const initCenter = center
        ? [Number(center[1]), Number(center[0])]
        : [-73.2532, 10.4631];

      mapInstance = new mapboxgl.Map({
        container: containerRef.current,
        style: createGoogleMapsStyle(),
        center: initCenter,
        zoom: Number(zoom) || 14,
        pitch: Number(pitch) || 0,
        bearing: Number(bearing) || 0,
        attributionControl: false,
        pitchWithRotate: true,
        dragRotate: true,
        refreshExpiredTiles: false,
        fadeDuration: 0,
        maxParallelImageRequests: 12,
      });

      // Métodos auxiliares de cámara para controladores 3D y de seguimiento
      mapInstance.moveCamera = ({ center: c, zoom: z, tilt, heading }) => {
        try {
          const jumpOpts = {};
          if (c && c.lat != null && c.lng != null) {
            jumpOpts.center = [Number(c.lng), Number(c.lat)];
          } else if (Array.isArray(c) && c.length >= 2) {
            jumpOpts.center = [Number(c[1]), Number(c[0])];
          }
          if (z != null) jumpOpts.zoom = Number(z);
          if (tilt != null) jumpOpts.pitch = Number(tilt);
          if (heading != null) jumpOpts.bearing = Number(heading);
          mapInstance.jumpTo(jumpOpts);
        } catch {}
      };
      mapInstance.getTilt = () => {
        try {
          return mapInstance.getPitch();
        } catch {
          return 0;
        }
      };
      mapInstance.getHeading = () => {
        try {
          return mapInstance.getBearing();
        } catch {
          return 0;
        }
      };
      mapInstance.setHeading = (h) => {
        try {
          mapInstance.setBearing(Number(h) || 0);
        } catch {}
      };
      mapInstance.setTilt = (t) => {
        try {
          mapInstance.setPitch(Number(t) || 0);
        } catch {}
      };

      mapInstance.on('click', (e) => {
        if (e?.lngLat) {
          clickRef.current?.({ lat: e.lngLat.lat, lng: e.lngLat.lng });
        } else {
          clickRef.current?.(null);
        }
      });

      mapInstance.on('dragstart', (e) => {
        if (e?.originalEvent) {
          dragStartRef.current?.();
          interactStartRef.current?.();
        }
      });

      mapInstance.on('dragend', (e) => {
        if (e?.originalEvent) {
          interactEndRef.current?.();
        }
      });

      const safeResize = () => {
        try {
          mapInstance?.resize();
        } catch {}
      };

      mapInstance.on('load', safeResize);
      mapInstance.on('style.load', safeResize);
      setTimeout(safeResize, 120);
      setTimeout(safeResize, 450);

      if (typeof ResizeObserver !== 'undefined') {
        ro = new ResizeObserver(safeResize);
        ro.observe(containerRef.current);
      }

      setMap(mapInstance);
    } catch {
      if (alive) errorRef.current?.();
    }

    return () => {
      alive = false;
      if (ro) ro.disconnect();
      setMap(null);
      if (mapInstance) {
        try {
          mapInstance.remove();
        } catch {}
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [libReady]);

  useEffect(() => {
    if (!map) return;
    try {
      const canvas = map.getCanvasContainer?.();
      if (canvas) {
        canvas.style.cursor = cursor || '';
      }
    } catch {}
  }, [map, cursor]);

  if (!token) {
    return (
      <div
        className={`${className || 'h-40'} ${
          isDark ? 'bg-[#0B0F1A]' : 'bg-[#E8EAED]'
        } flex items-center justify-center`}
      >
        <Loader2
          className={`w-6 h-6 animate-spin ${isDark ? 'text-[#00E5FF]' : 'text-[#1E6BFF]'}`}
        />
      </div>
    );
  }

  return (
    <div
      className={`relative ${className || ''} ${isDark ? 'gmap-dark-canvas' : 'gmap-light-canvas'}`}
      data-testid="interactive-map"
    >
      <div
        ref={containerRef}
        className="h-full w-full"
        style={stageStyle || undefined}
      />
      {map && <MapContext.Provider value={map}>{children}</MapContext.Provider>}
    </div>
  );
}

// Marcador HTML personalizado con interpolación suave al moverse en vivo
export function MapboxMarker({
  lat,
  lng,
  el,
  draggable = false,
  interactive = true,
  rotation = null,
  alignWithMap = false,
  anchor = 'center',
  smooth = false,
  labelTitle,
  labelAddress,
  showBubble,
  onClick,
  onDragStart,
  onDrag,
  onDragEnd,
}) {
  const map = useMap();
  const markerRef = useRef(null);
  const innerRef = useRef(null);
  const rotRef = useRef(rotation);
  const alignRef = useRef(alignWithMap);
  const dragStartCbRef = useRef(onDragStart);
  const dragCbRef = useRef(onDrag);
  const cbRef = useRef(onDragEnd);
  const clickCbRef = useRef(onClick);

  rotRef.current = rotation;
  alignRef.current = alignWithMap;
  dragStartCbRef.current = onDragStart;
  dragCbRef.current = onDrag;
  cbRef.current = onDragEnd;
  clickCbRef.current = onClick;

  const hasCoords =
    lat != null && lng != null && !Number.isNaN(Number(lat)) && !Number.isNaN(Number(lng));

  const applyRotation = () => {
    const inner = innerRef.current;
    if (!inner) return;
    if (rotRef.current != null) {
      const mapBearing = alignRef.current ? Number(map?.getBearing?.() || 0) : 0;
      const relDeg = (((Number(rotRef.current) - mapBearing) % 360) + 360) % 360;
      inner.style.transform = `rotate(${relDeg}deg)`;
    } else {
      inner.style.transform = '';
    }
  };

  useEffect(() => {
    if (!map || !hasCoords) return;

    const wrapper = document.createElement('div');
    wrapper.style.userSelect = 'none';
    wrapper.style.zIndex = draggable ? '30' : '20';
    wrapper.style.cursor = draggable ? 'grab' : interactive ? 'pointer' : 'default';
    if (!interactive && !draggable) {
      wrapper.style.pointerEvents = 'none';
    }

    const inner = typeof el === 'function' ? el() : el || document.createElement('div');
    if (smooth) {
      inner.style.transition = 'transform 0.5s ease-out';
    }
    wrapper.appendChild(inner);
    innerRef.current = inner;

    if (interactive && !draggable) {
      wrapper.addEventListener('click', (ev) => {
        ev.stopPropagation();
        clickCbRef.current?.();
      });
    }

    const marker = new mapboxgl.Marker({
      element: wrapper,
      anchor: anchor === 'bottom' ? 'bottom' : 'center',
      draggable: Boolean(draggable),
    })
      .setLngLat([Number(lng), Number(lat)])
      .addTo(map);

    if (draggable) {
      marker.on('dragstart', () => {
        const ll = marker.getLngLat();
        if (ll) {
          dragStartCbRef.current?.({ lat: ll.lat, lng: ll.lng });
        }
      });
      marker.on('drag', () => {
        const ll = marker.getLngLat();
        if (ll) {
          dragCbRef.current?.({ lat: ll.lat, lng: ll.lng });
        }
      });
      marker.on('dragend', () => {
        const ll = marker.getLngLat();
        if (ll) {
          cbRef.current?.({ lat: ll.lat, lng: ll.lng });
        }
      });
      wrapper.addEventListener('click', (ev) => {
        ev.stopPropagation();
        clickCbRef.current?.();
      });
    }

    markerRef.current = marker;
    applyRotation();

    const onRotate = () => applyRotation();
    if (alignWithMap) {
      map.on('rotate', onRotate);
      map.on('move', onRotate);
    }

    return () => {
      if (alignWithMap) {
        try {
          map.off('rotate', onRotate);
          map.off('move', onRotate);
        } catch {}
      }
      try {
        marker.remove();
      } catch {}
      markerRef.current = null;
      innerRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [map, hasCoords, draggable, interactive, anchor]);

  useEffect(() => {
    if (markerRef.current && hasCoords) {
      try {
        markerRef.current.setLngLat([Number(lng), Number(lat)]);
        applyRotation();
      } catch {}
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lat, lng, rotation, hasCoords]);

  useEffect(() => {
    const inner = innerRef.current;
    if (!inner) return;
    const bubbleEl = inner.querySelector?.('[data-role="pin-bubble"]');
    const titleEl = inner.querySelector?.('[data-role="pin-title"]');
    const addrEl = inner.querySelector?.('[data-role="pin-address"]');
    const arrowSvgEl = inner.querySelector?.('[data-role="pin-arrow-svg"]');
    if (bubbleEl && showBubble !== undefined) {
      bubbleEl.style.display = showBubble ? 'flex' : 'none';
    }
    if (bubbleEl) {
      bubbleEl.style.cursor = interactive ? 'pointer' : 'default';
    }
    if (arrowSvgEl) {
      arrowSvgEl.style.display = interactive ? 'block' : 'none';
    }
    if (titleEl && labelTitle !== undefined) {
      titleEl.textContent = labelTitle;
    }
    if (addrEl && labelAddress !== undefined) {
      addrEl.textContent = labelAddress || 'Ubicando dirección...';
    }
  }, [labelTitle, labelAddress, showBubble, interactive]);

  return null;
}

export function MapboxRoute({
  coords,
  color = '#1E6BFF',
  casingColor = '#0A2E73',
  width = 5,
  opacity = 0.92,
  dashed = false,
}) {
  const map = useMap();
  const idRef = useRef(null);
  if (!idRef.current) {
    routeIdCounter += 1;
    idRef.current = `next-route-${routeIdCounter}`;
  }
  const coordsRef = useRef(coords);
  coordsRef.current = coords;
  const coordsKey = JSON.stringify(coords);
  const appliedSignatureRef = useRef('');

  useEffect(() => {
    if (!map) return;
    const sourceId = `${idRef.current}-src`;
    const casingLayerId = `${idRef.current}-casing`;
    const lineLayerId = `${idRef.current}-line`;
    return () => {
      appliedSignatureRef.current = '';
      try {
        if (map.getLayer(lineLayerId)) map.removeLayer(lineLayerId);
        if (map.getLayer(casingLayerId)) map.removeLayer(casingLayerId);
        if (map.getSource(sourceId)) map.removeSource(sourceId);
      } catch {}
    };
  }, [map]);

  useEffect(() => {
    if (!map) return;
    const sourceId = `${idRef.current}-src`;
    const casingLayerId = `${idRef.current}-casing`;
    const lineLayerId = `${idRef.current}-line`;

    const cleanup = () => {
      appliedSignatureRef.current = '';
      try {
        if (map.getLayer(lineLayerId)) map.removeLayer(lineLayerId);
        if (map.getLayer(casingLayerId)) map.removeLayer(casingLayerId);
        if (map.getSource(sourceId)) map.removeSource(sourceId);
      } catch {}
    };

    const drawRoute = () => {
      const currentCoords = coordsRef.current;
      if (!currentCoords || currentCoords.length < 2) {
        cleanup();
        return;
      }
      try {
        const styleObj = map.getStyle?.();
        if (!styleObj || !Array.isArray(styleObj.layers)) return;

        const sig = `${coordsKey}|${color}|${casingColor}|${width}|${opacity}|${dashed}`;
        const existingSource = map.getSource(sourceId);
        const hasLineLayer = Boolean(map.getLayer(lineLayerId));

        // Evitar llamadas redundantes a setData/setPaintProperty que disparan bucles de repintado
        if (existingSource && hasLineLayer && appliedSignatureRef.current === sig) {
          return;
        }

        const geojson = {
          type: 'Feature',
          properties: {},
          geometry: {
            type: 'LineString',
            coordinates: currentCoords.map(([lat, lng]) => [Number(lng), Number(lat)]),
          },
        };

        if (existingSource) {
          existingSource.setData(geojson);
        } else {
          map.addSource(sourceId, {
            type: 'geojson',
            data: geojson,
          });
        }

        if (casingColor && !dashed) {
          if (!map.getLayer(casingLayerId)) {
            map.addLayer({
              id: casingLayerId,
              type: 'line',
              source: sourceId,
              layout: {
                'line-join': 'round',
                'line-cap': 'round',
              },
              paint: {
                'line-color': casingColor,
                'line-width': width + 3,
                'line-opacity': 0.55,
              },
            });
          } else {
            map.setPaintProperty(casingLayerId, 'line-color', casingColor);
            map.setPaintProperty(casingLayerId, 'line-width', width + 3);
          }
        }

        if (!hasLineLayer) {
          map.addLayer({
            id: lineLayerId,
            type: 'line',
            source: sourceId,
            layout: {
              'line-join': 'round',
              'line-cap': 'round',
            },
            paint: {
              'line-color': color,
              'line-width': width,
              'line-opacity': opacity,
              ...(dashed ? { 'line-dasharray': [2, 2] } : {}),
            },
          });
        } else {
          map.setPaintProperty(lineLayerId, 'line-color', color);
          map.setPaintProperty(lineLayerId, 'line-width', width);
          map.setPaintProperty(lineLayerId, 'line-opacity', opacity);
        }

        appliedSignatureRef.current = sig;
      } catch {}
    };

    drawRoute();
    map.on('load', drawRoute);
    map.on('style.load', drawRoute);

    return () => {
      try {
        map.off('load', drawRoute);
        map.off('style.load', drawRoute);
      } catch {}
    };
  }, [map, coordsKey, color, casingColor, width, opacity, dashed]);

  return null;
}

function normalizeSafePadding(rawPad, canvasW = 360, canvasH = 640) {
  const w = Math.max(240, Number(canvasW) || 360);
  const h = Math.max(280, Number(canvasH) || 640);
  const base =
    typeof rawPad === 'number'
      ? { top: rawPad, bottom: rawPad, left: rawPad, right: rawPad }
      : {
          top: Number(rawPad?.top) || 40,
          bottom: Number(rawPad?.bottom) || 40,
          left: Number(rawPad?.left) || 40,
          right: Number(rawPad?.right) || 40,
        };

  // Evita que top + bottom supere el 48% de la altura del lienzo (p. ej. cuando el teclado móvil
  // se está cerrando), lo cual causaba que Mapbox hiciera zoom out a toda la región.
  const maxVertTotal = Math.max(90, Math.floor(h * 0.48));
  const vertTotal = base.top + base.bottom;
  const vertScale = vertTotal > maxVertTotal ? maxVertTotal / vertTotal : 1;

  const maxHorizTotal = Math.max(60, Math.floor(w * 0.28));
  const horizTotal = base.left + base.right;
  const horizScale = horizTotal > maxHorizTotal ? maxHorizTotal / horizTotal : 1;

  return {
    top: Math.round(base.top * vertScale),
    bottom: Math.round(base.bottom * vertScale),
    left: Math.round(base.left * horizScale),
    right: Math.round(base.right * horizScale),
  };
}

export function MapboxFitBounds({
  positions,
  padding = 50,
  singleZoom = 16,
  singlePadding = null,
  fitKey = null,
}) {
  const map = useMap();

  const positionsSig = React.useMemo(() => {
    if (!Array.isArray(positions) || positions.length === 0) return '';
    const valid = positions.filter(
      (p) =>
        Array.isArray(p) &&
        p[0] != null &&
        p[1] != null &&
        !Number.isNaN(Number(p[0])) &&
        !Number.isNaN(Number(p[1]))
    );
    if (valid.length === 0) return '';
    const first = valid[0];
    const last = valid[valid.length - 1];
    const mid = valid[Math.floor(valid.length / 2)];
    return `${valid.length}:${Number(first[0]).toFixed(4)},${Number(first[1]).toFixed(4)}:${Number(
      mid[0]
    ).toFixed(4)},${Number(mid[1]).toFixed(4)}:${Number(last[0]).toFixed(4)},${Number(
      last[1]
    ).toFixed(4)}`;
  }, [positions]);

  const key = `${fitKey != null ? String(fitKey) : 'auto'}|${positionsSig}`;

  useEffect(() => {
    if (!map || !positions || positions.length === 0) return;
    const valid = positions.filter(
      (p) =>
        Array.isArray(p) &&
        p[0] != null &&
        p[1] != null &&
        !Number.isNaN(Number(p[0])) &&
        !Number.isNaN(Number(p[1]))
    );
    if (valid.length === 0) return;

    const isSameSpot =
      valid.length > 1 &&
      valid.every(
        ([lat, lng]) =>
          Math.abs(Number(lat) - Number(valid[0][0])) < 0.0004 &&
          Math.abs(Number(lng) - Number(valid[0][1])) < 0.0004
      );

    const applyFit = (durationMs = 320) => {
      try {
        map.resize();
        const canvas = map.getCanvas?.();
        const canvasW = canvas?.clientWidth || 360;
        const canvasH = canvas?.clientHeight || 640;

        if (valid.length === 1 || isSameSpot) {
          const safeSinglePad = singlePadding
            ? normalizeSafePadding(singlePadding, canvasW, canvasH)
            : { top: 0, bottom: 0, left: 0, right: 0 };
          map.easeTo({
            center: [Number(valid[0][1]), Number(valid[0][0])],
            zoom: singleZoom,
            padding: safeSinglePad,
            duration: durationMs,
          });
        } else {
          const bounds = new mapboxgl.LngLatBounds();
          let minLat = Infinity;
          let maxLat = -Infinity;
          let minLng = Infinity;
          let maxLng = -Infinity;
          valid.forEach(([lat, lng]) => {
            const nLat = Number(lat);
            const nLng = Number(lng);
            if (nLat < minLat) minLat = nLat;
            if (nLat > maxLat) maxLat = nLat;
            if (nLng < minLng) minLng = nLng;
            if (nLng > maxLng) maxLng = nLng;
            bounds.extend([nLng, nLat]);
          });

          const spanKm = Math.hypot((maxLat - minLat) * 111, (maxLng - minLng) * 109);
          const safePad = normalizeSafePadding(padding, canvasW, canvasH);
          map.fitBounds(bounds, {
            padding: safePad,
            maxZoom: 16,
            ...(spanKm <= 22 ? { minZoom: 12.2 } : {}),
            duration: durationMs,
          });
        }
      } catch {}
    };

    const initialCanvasH = map.getCanvas?.()?.clientHeight || 0;
    const rafId = requestAnimationFrame(() => applyFit(320));
    // Re-ajustar únicamente si la altura del lienzo cambió de forma real (p. ej. al cerrarse el teclado móvil)
    const t1 = setTimeout(() => {
      const curH = map.getCanvas?.()?.clientHeight || 0;
      if (Math.abs(curH - initialCanvasH) > 40) {
        applyFit(220);
      }
    }, 320);

    return () => {
      cancelAnimationFrame(rafId);
      clearTimeout(t1);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [map, key, singleZoom]);

  return null;
}

export function MapDragPinSync({ enabled = false, activePoint, onMove, onMoveEnd }) {
  const map = useMap();
  const pointRef = useRef(activePoint);
  const moveRef = useRef(onMove);
  const endRef = useRef(onMoveEnd);
  pointRef.current = activePoint;
  moveRef.current = onMove;
  endRef.current = onMoveEnd;

  useEffect(() => {
    if (!map || !enabled) return;
    let startCenter = null;
    let startPoint = null;
    let latestPoint = null;
    let rafId = null;
    let isUserGesture = false;

    const onDragStart = (e) => {
      if (!e?.originalEvent) return;
      const c = map.getCenter();
      const pt = latestPoint || pointRef.current;
      if (!c || !pt || pt.lat == null || pt.lng == null) return;
      isUserGesture = true;
      startCenter = { lat: c.lat, lng: c.lng };
      startPoint = { lat: Number(pt.lat), lng: Number(pt.lng) };
      latestPoint = startPoint;
      moveRef.current?.(latestPoint);
    };

    const onMoveHandler = () => {
      if (!isUserGesture || !startCenter || !startPoint) return;
      const c = map.getCenter();
      if (!c) return;
      const dLat = c.lat - startCenter.lat;
      const dLng = c.lng - startCenter.lng;
      latestPoint = {
        lat: startPoint.lat + dLat,
        lng: startPoint.lng + dLng,
      };
      if (!rafId) {
        rafId = requestAnimationFrame(() => {
          rafId = null;
          if (latestPoint) moveRef.current?.(latestPoint);
        });
      }
    };

    const onMoveEndHandler = () => {
      if (!isUserGesture) return;
      if (rafId) {
        cancelAnimationFrame(rafId);
        rafId = null;
      }
      if (startCenter && startPoint) {
        const c = map.getCenter();
        if (c) {
          latestPoint = {
            lat: startPoint.lat + (c.lat - startCenter.lat),
            lng: startPoint.lng + (c.lng - startCenter.lng),
          };
        }
      }
      const finalPt = latestPoint;
      isUserGesture = false;
      startCenter = null;
      startPoint = null;
      latestPoint = null;
      if (finalPt) {
        endRef.current?.(finalPt);
      }
    };

    map.on('dragstart', onDragStart);
    map.on('move', onMoveHandler);
    map.on('moveend', onMoveEndHandler);

    return () => {
      if (rafId) cancelAnimationFrame(rafId);
      try {
        map.off('dragstart', onDragStart);
        map.off('move', onMoveHandler);
        map.off('moveend', onMoveEndHandler);
      } catch {}
    };
  }, [map, enabled]);

  return null;
}

export function MapboxDrivingRoute({
  from,
  to,
  waypoints = [],
  color = '#1E6BFF',
  casingColor = '#0A2E73',
  width = 5,
  opacity = 0.85,
  dashed = false,
  showArrows = false,
  refreshSignal = 0,
  trimFromPos = null,
  onReroute,
  onRouteInfo,
}) {
  const map = useMap();
  const token = useMapboxToken();
  const [coords, setCoords] = useState(null);
  const [rerouteCount, setRerouteCount] = useState(0);
  const lastCalcFromRef = useRef(null);
  const prevDriverPosRef = useRef(null);
  const liveBearingRef = useRef(null);
  const lastRerouteAtRef = useRef(0);
  const offRouteStreakRef = useRef(0);
  const maxReachedSegRef = useRef(0);
  const visitedWpKeysRef = useRef(new Set());
  const cbRef = useRef(onRouteInfo);
  const rerouteCbRef = useRef(onReroute);
  cbRef.current = onRouteInfo;
  rerouteCbRef.current = onReroute;

  const toKey = to ? `${to[0].toFixed(4)},${to[1].toFixed(4)}` : '';
  const rawWpKey = (waypoints || [])
    .filter((w) => Array.isArray(w) && w[0] != null && w[1] != null)
    .map((w) => `${Number(w[0]).toFixed(4)},${Number(w[1]).toFixed(4)}`)
    .join('|');

  useEffect(() => {
    visitedWpKeysRef.current = new Set();
  }, [toKey, rawWpKey]);

  const activeWaypoints = React.useMemo(() => {
    const valid = (waypoints || []).filter(
      (w) => Array.isArray(w) && w[0] != null && w[1] != null
    );
    if (!trimFromPos || !from || from[0] == null || from[1] == null) return valid;
    const curLat = Number(from[0]);
    const curLng = Number(from[1]);
    return valid.filter((w) => {
      const k = `${Number(w[0]).toFixed(4)},${Number(w[1]).toFixed(4)}`;
      if (visitedWpKeysRef.current.has(k)) return false;
      const dMeters = Math.hypot(
        (curLat - Number(w[0])) * 111320,
        (curLng - Number(w[1])) * 109000
      );
      if (dMeters <= 55) {
        visitedWpKeysRef.current.add(k);
        return false;
      }
      return true;
    });
  }, [waypoints, trimFromPos, from?.[0], from?.[1]]);

  const wpKey = activeWaypoints
    .map((w) => `${Number(w[0]).toFixed(4)},${Number(w[1]).toFixed(4)}`)
    .join('|');

  // Recalcular únicamente si el conductor realmente cruza por otra calle y avanza en esa dirección
  useEffect(() => {
    if (!from || from[0] == null || from[1] == null) return;
    const curLat = Number(from[0]);
    const curLng = Number(from[1]);

    const prevPos = prevDriverPosRef.current;
    let movedEnough = false;
    if (prevPos) {
      const dLat = curLat - prevPos[0];
      const dLng = curLng - prevPos[1];
      const movedMeters = Math.hypot(dLat * 111320, dLng * 109000);
      if (movedMeters >= 8) {
        movedEnough = true;
        const toRad = (d) => (d * Math.PI) / 180;
        const toDeg = (r) => (r * 180) / Math.PI;
        const φ1 = toRad(prevPos[0]);
        const φ2 = toRad(curLat);
        const Δλ = toRad(curLng - prevPos[1]);
        const y = Math.sin(Δλ) * Math.cos(φ2);
        const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
        liveBearingRef.current = (toDeg(Math.atan2(y, x)) + 360) % 360;
        prevDriverPosRef.current = [curLat, curLng];
      }
    } else {
      prevDriverPosRef.current = [curLat, curLng];
    }

    if (!coords || coords.length < 2) return;

    const { deviated, offMeters } = checkDriverRouteDeviation(
      coords,
      curLat,
      curLng,
      liveBearingRef.current
    );

    if (deviated) {
      if (movedEnough || offMeters > 50) {
        offRouteStreakRef.current += 1;
      }
      const prevCalc = lastCalcFromRef.current;
      const distFromLastCalc = prevCalc
        ? Math.hypot((curLat - prevCalc[0]) * 111320, (curLng - prevCalc[1]) * 109000)
        : Infinity;
      const now = Date.now();
      if (
        offRouteStreakRef.current >= 2 &&
        distFromLastCalc >= 35 &&
        now - lastRerouteAtRef.current >= 6000
      ) {
        offRouteStreakRef.current = 0;
        lastRerouteAtRef.current = now;
        rerouteCbRef.current?.({ offMeters: Math.round(offMeters) });
        setRerouteCount((c) => c + 1);
      }
    } else {
      offRouteStreakRef.current = 0;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [from?.[0], from?.[1], coords]);

  const initialFromKey =
    !coords && from
      ? `${from[0].toFixed(4)},${from[1].toFixed(4)}`
      : trimFromPos
      ? 'live-tracking'
      : 'locked';

  useEffect(() => {
    if (!map || !from || !to) {
      setCoords(null);
      maxReachedSegRef.current = 0;
      return;
    }
    let alive = true;
    lastCalcFromRef.current = [Number(from[0]), Number(from[1])];
    const forceRefresh = rerouteCount > 0 || refreshSignal > 0;
    fetchRoute(token, from, to, activeWaypoints, {
      forceRefresh,
      bearing: forceRefresh ? liveBearingRef.current : null,
    }).then((r) => {
      if (!alive) return;
      maxReachedSegRef.current = 0;
      setCoords(r?.coords || null);
      cbRef.current?.(
        r && r.distanceKm != null
          ? {
              distanceKm: r.distanceKm,
              durationSeconds: r.durationSeconds,
              durationMin: r.durationMin,
              coords: r.coords,
              steps: r.steps || [],
              avoidedConstruction: Boolean(r.avoidedConstruction),
              constructionHits: r.constructionHits || 0,
            }
          : null
      );
    });
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [map, token, initialFromKey, toKey, wpKey, rerouteCount, refreshSignal]);

  const renderedCoords = React.useMemo(() => {
    if (!trimFromPos || !coords) return coords;
    const res = sliceRouteFromPosition(
      coords,
      trimFromPos[0],
      trimFromPos[1],
      maxReachedSegRef.current
    );
    if (res && Array.isArray(res.sliced)) {
      maxReachedSegRef.current = res.reachedSegIdx || 0;
      return res.sliced;
    }
    return coords;
  }, [coords, trimFromPos?.[0], trimFromPos?.[1]]);

  if (!renderedCoords || renderedCoords.length < 2) return null;
  return (
    <MapboxRoute
      coords={renderedCoords}
      color={color}
      casingColor={casingColor}
      width={width}
      opacity={opacity}
      dashed={dashed}
      showArrows={showArrows}
    />
  );
}

export function MapboxFollowCenter({
  center,
  bearing,
  pitch,
  zoom,
  padding = null,
  recenterKey = 0,
  following = true,
}) {
  const map = useMap();
  const key = center ? `${center[0].toFixed(5)},${center[1].toFixed(5)}` : '';
  const bearingKey = bearing != null ? Math.round(Number(bearing) / 2) * 2 : '';

  useEffect(() => {
    if (!map || !center || !following) return;
    try {
      map.easeTo({
        center: [Number(center[1]), Number(center[0])],
        ...(zoom != null ? { zoom: Number(zoom) } : {}),
        ...(bearing != null ? { bearing: Number(bearing) } : {}),
        ...(pitch != null ? { pitch: Number(pitch) } : {}),
        ...(padding ? { padding } : {}),
        duration: 340,
      });
    } catch {}
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [map, key, following, bearingKey, zoom, pitch, recenterKey]);

  return null;
}
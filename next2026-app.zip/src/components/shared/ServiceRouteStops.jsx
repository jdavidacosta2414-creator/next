import React from 'react';
import { ArrowUp, ArrowDown } from 'lucide-react';
import { shortAddress, joinBarrio } from '@/lib/shortAddress';

function formatEtaKmLine(minVal, kmVal) {
  const hasMin = minVal != null && Number.isFinite(Number(minVal));
  const hasKm = kmVal != null && Number.isFinite(Number(kmVal));
  if (!hasMin && !hasKm) return null;
  const m = hasMin ? `${Math.max(1, Math.round(Number(minVal)))} min` : null;
  const nKm = hasKm ? Math.max(0, Number(kmVal)) : null;
  const k =
    nKm != null
      ? `${(nKm < 0.05 ? 0 : Math.max(0.1, nKm)).toFixed(1).replace('.', ',')} km`
      : null;
  if (m && k) return `${m} (${k})`;
  return m || k;
}

// Muestra la ruta completa: Punto de recogida (A) con minutos y km hacia recogida,
// paradas intermedias (1, 2, 3) y Destino final (Punto B) con minutos y km hacia destino.
export default function ServiceRouteStops({
  pickupAddress,
  destinationAddress,
  stops = [],
  compact = false,
  fullAddress = false,
  pickupBarrio = '',
  destinationBarrio = '',
  showLetterBadges = false,
  pickupEtaMin = null,
  pickupKm = null,
  destEtaMin = null,
  destKm = null,
}) {
  const validStops = (stops || []).filter((s) => s && (s.address || '').trim());
  const pickupMetrics = formatEtaKmLine(pickupEtaMin, pickupKm);
  const destMetrics = formatEtaKmLine(destEtaMin, destKm);
  const showDriverMetrics = Boolean(pickupMetrics || destMetrics);
  // En la tarjeta compacta la dirección va en una sola línea. Si lleva barrio (o con fullAddress, que la
  // muestra tal como llega) ocupa las líneas que necesite, para que el barrio no quede cortado.
  const addressText = (address, barrio) =>
    joinBarrio((compact && !fullAddress ? shortAddress(address) || address : address) || '—', barrio);
  const addressClass = (barrio) =>
    !compact ? 'text-[14px]' : fullAddress || barrio ? 'text-[12px] break-words' : 'text-[12px] truncate';

  return (
    <div className={compact ? 'space-y-1.5' : 'space-y-2.5'}>
      {/* Punto de recogida (A) */}
      <div className="flex items-center gap-2">
        {showDriverMetrics ? (
          <div className={`${compact ? 'w-7 h-7' : 'w-8 h-8'} rounded-full bg-[#1E6BFF] text-white flex items-center justify-center flex-shrink-0 shadow-xs`}>
            <ArrowUp className="w-3.5 h-3.5 stroke-[2.8]" />
          </div>
        ) : showLetterBadges ? (
          <div className="w-6 h-6 rounded-lg bg-[#1E6BFF] text-white flex items-center justify-center font-extrabold text-xs flex-shrink-0">
            A
          </div>
        ) : (
          <div className="w-3 h-3 rounded-full bg-[#1E6BFF] flex-shrink-0" />
        )}
        <div className="min-w-0 flex-1">
          {pickupMetrics && (
            <span
              className={`text-[#1E6BFF] dark:text-[#38BDF8] font-extrabold ${
                compact ? 'text-[12px] tracking-tight whitespace-nowrap' : 'text-sm'
              } leading-tight block`}
              data-testid="pickup-eta-km"
            >
              Recogida · {pickupMetrics}
            </span>
          )}
          <span
            className={`text-foreground font-medium ${addressClass(pickupBarrio)} leading-snug block`}
          >
            {addressText(pickupAddress, pickupBarrio)}
          </span>
        </div>
      </div>

      {/* Paradas intermedias (1, 2, 3) señalizadas con puntico */}
      {validStops.map((stop, idx) => (
        <div key={idx} className="flex items-center gap-2 pl-0.5">
          {showLetterBadges || showDriverMetrics ? (
            <div className="w-6 h-6 rounded-full bg-amber-500 text-white flex items-center justify-center font-extrabold text-[10px] flex-shrink-0 shadow-xs">
              {idx + 1}
            </div>
          ) : (
            <div className="w-3 h-3 rounded-full bg-amber-500 ring-2 ring-amber-500/25 flex-shrink-0" />
          )}
          <div className="min-w-0 flex-1">
            <span className={`text-foreground font-medium ${addressClass(stop.barrio)} leading-snug block`}>
              <span className="font-extrabold text-amber-600 dark:text-amber-400 mr-1">
                Parada {idx + 1}:
              </span>
              {addressText(stop.address, stop.barrio)}
            </span>
          </div>
        </div>
      ))}

      {/* Punto B (Destino final) */}
      <div className="flex items-center gap-2">
        {showDriverMetrics ? (
          <div className={`${compact ? 'w-7 h-7' : 'w-8 h-8'} rounded-full bg-[#093280] dark:bg-[#0284C7] text-white flex items-center justify-center flex-shrink-0 shadow-xs`}>
            <ArrowDown className="w-3.5 h-3.5 stroke-[2.8]" />
          </div>
        ) : showLetterBadges ? (
          <div className="w-6 h-6 rounded-lg bg-[#0B439C] text-white flex items-center justify-center font-extrabold text-xs flex-shrink-0">
            B
          </div>
        ) : (
          <div className="w-3 h-3 rounded-full bg-[#00B8D4] flex-shrink-0" />
        )}
        <div className="min-w-0 flex-1">
          {destMetrics && (
            <span
              className={`text-[#1E6BFF] dark:text-sky-300 font-extrabold ${
                compact ? 'text-[12px] tracking-tight whitespace-nowrap' : 'text-sm'
              } leading-tight block`}
              data-testid="dest-eta-km"
            >
              Destino · {destMetrics}
            </span>
          )}
          <span
            className={`text-foreground font-medium ${addressClass(destinationBarrio)} leading-snug block`}
          >
            {addressText(destinationAddress, destinationBarrio)}
          </span>
        </div>
      </div>
    </div>
  );
}
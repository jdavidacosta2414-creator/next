import React, { useState, useEffect } from 'react';
import { Camera, Image as ImageIcon, Loader2, X } from 'lucide-react';
import { getCachedSignedUrl, resolveStorageUrl, seedStorageUrlCache } from '@/components/shared/ResolvedAvatar';
import { uploadRegistrationPhoto } from '@/lib/image';
import InAppCameraModal from '@/components/shared/InAppCameraModal';

export default function ImageCapture({
  label,
  onChange,
  value,
  facing = 'environment',
  maxSize = 1024,
  height = 'h-40',
  // Solo cámara: la foto no se puede elegir de la galería (constancia de entrega).
  cameraOnly = false,
}) {
  const [loading, setLoading] = useState(false);
  const [cameraOpen, setCameraOpen] = useState(false);
  const [signed, setSigned] = useState(() => getCachedSignedUrl(value) || '');
  const [error, setError] = useState(null);

  useEffect(() => {
    let active = true;
    if (!value) {
      setSigned('');
      return;
    }
    const cached = getCachedSignedUrl(value);
    if (cached) {
      setSigned(cached);
      if (!cached.startsWith('blob:')) return;
    }
    resolveStorageUrl(value)
      .then((url) => {
        if (active && url) setSigned(url);
      })
      .catch(() => {
        if (active) setError('No se pudo cargar la vista previa.');
      });
    return () => {
      active = false;
    };
  }, [value]);

  const markPickerOpen = () => {
    if (typeof window !== 'undefined') {
      window.__nextFilePickerOpenUntil = Date.now() + 60000;
    }
  };

  const processFile = async (file) => {
    if (!file) return;
    const localBlobUrl = URL.createObjectURL(file);
    setSigned(localBlobUrl);
    setLoading(true);
    setError(null);
    try {
      const { file_uri, previewUrl } = await uploadRegistrationPhoto(file, maxSize, 0.76);
      seedStorageUrlCache(file_uri, previewUrl || localBlobUrl);
      resolveStorageUrl(file_uri).catch(() => {});
      onChange(file_uri);
    } catch {
      setError('No se pudo procesar la foto. Intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  const handleGalleryInput = (e) => {
    const file = e.target.files?.[0];
    if (e.target) e.target.value = '';
    if (file) processFile(file);
  };

  return (
    <div className="relative space-y-2" data-photo-picker="true">
      <InAppCameraModal
        open={cameraOpen}
        facing={facing}
        cameraOnly={cameraOnly}
        title={label || 'Tomar foto'}
        onClose={() => setCameraOpen(false)}
        onCaptureFile={processFile}
      />

      {value ? (
        <div className="relative">
          {signed ? (
            <img
              src={signed}
              alt={label}
              className={`w-full ${height} object-cover rounded-xl border border-border`}
            />
          ) : (
            <div
              className={`w-full ${height} rounded-xl border border-border bg-muted flex items-center justify-center`}
            >
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          )}
          <button
            type="button"
            onClick={() => onChange('')}
            className="absolute top-2 right-2 bg-destructive text-destructive-foreground rounded-full p-1.5 shadow-lg z-20"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ) : loading ? (
        <div
          className={`w-full ${height} flex flex-col items-center justify-center gap-2 border-2 border-dashed border-border rounded-xl text-muted-foreground`}
        >
          <Loader2 className="w-6 h-6 animate-spin text-primary" />
          <span className="text-xs font-medium">Procesando foto...</span>
        </div>
      ) : (
        <div className={cameraOnly ? 'grid grid-cols-1' : 'grid grid-cols-2 gap-2.5'}>
          <button
            type="button"
            onClick={() => setCameraOpen(true)}
            className="h-24 flex flex-col items-center justify-center gap-1.5 border-2 border-dashed border-primary/40 bg-primary/5 hover:bg-primary/10 rounded-xl text-foreground transition-colors"
          >
            <Camera className="w-6 h-6 text-primary" />
            <span className="text-xs font-bold">Tomar foto</span>
            <span className="text-[10px] text-muted-foreground truncate max-w-full px-2">
              {label || 'Usar cámara'}
            </span>
          </button>

          {!cameraOnly && (
            <div className="relative overflow-hidden h-24 flex flex-col items-center justify-center gap-1.5 border-2 border-dashed border-border bg-muted/40 hover:bg-muted rounded-xl text-foreground transition-colors cursor-pointer">
              <ImageIcon className="w-6 h-6 text-primary" />
              <span className="text-xs font-bold">Galería</span>
              <span className="text-[10px] text-muted-foreground">Subir imagen</span>
              <input
                type="file"
                accept="image/*"
                onChange={handleGalleryInput}
                onClick={markPickerOpen}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
              />
            </div>
          )}
        </div>
      )}
      {error && <p className="text-sm text-destructive">{error}</p>}
    </div>
  );
}
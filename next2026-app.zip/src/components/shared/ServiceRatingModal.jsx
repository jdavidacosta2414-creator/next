import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, Loader2, Check } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import ResolvedAvatar from '@/components/shared/ResolvedAvatar';
import { useBackButton } from '@/hooks/useBackButton';

// Modal de calificación bilateral al finalizar un servicio.
// role: 'cliente' califica al conductor (rating/rating_comment)
// role: 'movil' califica al pasajero (driver_rating/driver_rating_comment)
export default function ServiceRatingModal({ serviceId, role, targetName, targetPhoto, onDone }) {
  const { toast } = useToast();
  const [stars, setStars] = useState(0);
  const [hover, setHover] = useState(0);
  const [comment, setComment] = useState('');
  const [saving, setSaving] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const isClient = role === 'cliente';
  const ratingField = isClient ? 'rating' : 'driver_rating';
  const commentField = isClient ? 'rating_comment' : 'driver_rating_comment';
  const title = isClient ? '¡Viaje finalizado! Califica a tu conductor' : '¡Servicio finalizado! Califica al pasajero';
  const subtitle = isClient
    ? `Dale estrellas y deja un comentario para ${targetName || 'tu conductor'}`
    : `Dale estrellas y deja un comentario sobre ${targetName || 'el pasajero'}`;

  const submit = async () => {
    if (stars === 0) {
      toast({ description: 'Selecciona al menos una estrella para calificar', variant: 'destructive' });
      return;
    }
    setSaving(true);
    try {
      const updated = await base44.entities.Service.update(serviceId, {
        [ratingField]: stars,
        [commentField]: comment.trim() || null,
      });
      setSubmitted(true);
      toast({
        title: '¡Calificación enviada!',
        description: isClient
          ? 'Tu calificación y comentario para el conductor fueron guardados.'
          : 'Tu calificación y comentario sobre el pasajero fueron guardados.',
      });
      setTimeout(() => onDone?.(updated), 1100);
    } catch (e) {
      toast({ title: 'No se pudo guardar', description: e.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const skip = async () => {
    setSaving(true);
    try {
      await base44.entities.Service.update(serviceId, { [ratingField]: 0 });
      onDone?.();
    } catch {
      onDone?.();
    } finally {
      setSaving(false);
    }
  };

  useBackButton(skip, true);

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[2200] flex items-end sm:items-center justify-center bg-black/65 backdrop-blur-sm px-3"
      >
        <motion.div
          initial={{ y: 60, opacity: 0, scale: 0.98 }}
          animate={{ y: 0, opacity: 1, scale: 1 }}
          exit={{ y: 60, opacity: 0 }}
          transition={{ type: 'spring', damping: 26, stiffness: 280 }}
          className="w-full max-w-md bg-card rounded-t-[28px] sm:rounded-[28px] shadow-2xl overflow-hidden border border-border"
        >
          {submitted ? (
            <div className="flex flex-col items-center justify-center py-14 px-6 text-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', damping: 12, stiffness: 220, delay: 0.05 }}
                className="w-16 h-16 rounded-full bg-[#1E6BFF]/15 flex items-center justify-center mb-4"
              >
                <Check className="w-8 h-8 text-[#1E6BFF]" />
              </motion.div>
              <p className="text-lg font-bold text-foreground">¡Calificación guardada!</p>
              <p className="text-sm text-muted-foreground mt-1">
                {isClient
                  ? 'Gracias por calificar a tu conductor.'
                  : 'Gracias por calificar al pasajero. Esto ayuda a toda la comunidad de conductores.'}
              </p>
            </div>
          ) : (
            <>
              {/* Encabezado */}
              <div className="relative px-5 pt-5 pb-4 bg-gradient-to-r from-[#062B6E] via-[#0B3C8C] to-[#1E6BFF] text-white">
                <div className="flex items-center gap-3">
                  <ResolvedAvatar
                    photo={targetPhoto}
                    name={targetName || (isClient ? 'Conductor' : 'Pasajero')}
                    className="w-13 h-13 w-12 h-12 rounded-full bg-white/20 text-white font-bold text-base border-2 border-white/40 flex-shrink-0"
                  />
                  <div className="min-w-0">
                    <p className="text-base font-extrabold leading-tight">{title}</p>
                    <p className="text-xs text-white/85 mt-0.5 truncate">{subtitle}</p>
                  </div>
                </div>
              </div>

              {/* Cuerpo */}
              <div className="px-5 py-5">
                <p className="text-center text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                  Toca las estrellas para calificar
                </p>

                {/* Estrellas */}
                <div className="flex items-center justify-center gap-2 mb-3">
                  {[1, 2, 3, 4, 5].map((n) => (
                    <button
                      key={n}
                      type="button"
                      disabled={saving}
                      onClick={() => setStars(n)}
                      onMouseEnter={() => setHover(n)}
                      onMouseLeave={() => setHover(0)}
                      className="p-1.5 transition-transform active:scale-90"
                      aria-label={`${n} ${n === 1 ? 'estrella' : 'estrellas'}`}
                    >
                      <motion.div
                        animate={{ scale: (hover || stars) >= n ? 1.1 : 1 }}
                        transition={{ type: 'spring', damping: 14, stiffness: 300 }}
                      >
                        <Star
                          className={`w-11 h-11 transition-colors ${
                            (hover || stars) >= n
                              ? 'fill-amber-400 text-amber-400'
                              : 'text-muted-foreground/35'
                          }`}
                        />
                      </motion.div>
                    </button>
                  ))}
                </div>

                {/* Etiquetas rápidas */}
                <p className="text-center text-sm font-bold text-foreground mb-4 min-h-[20px]">
                  {stars === 5 && '⭐⭐⭐⭐⭐ ¡Excelente! (5 estrellas)'}
                  {stars === 4 && '⭐⭐⭐⭐ Muy bueno (4 estrellas)'}
                  {stars === 3 && '⭐⭐⭐ Aceptable (3 estrellas)'}
                  {stars === 2 && '⭐⭐ Regular (2 estrellas)'}
                  {stars === 1 && '⭐ Malo (1 estrella)'}
                  {stars === 0 && <span className="text-muted-foreground font-normal text-xs">Selecciona de 1 a 5 estrellas</span>}
                </p>

                {/* Comentario */}
                <label className="block text-xs font-semibold text-foreground mb-1.5">
                  {isClient ? 'Comentario sobre el conductor' : 'Comentario respecto al pasajero'}
                </label>
                <textarea
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  disabled={saving}
                  maxLength={200}
                  rows={3}
                  placeholder={
                    isClient
                      ? 'Escribe cómo estuvo el servicio o deja un comentario para el conductor...'
                      : 'Escribe un comentario respecto a este pasajero...'
                  }
                  className="w-full rounded-2xl border border-border bg-muted px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-[#1E6BFF] focus:bg-card resize-none"
                />
                <p className="text-right text-[11px] text-muted-foreground mt-1">{comment.length}/200</p>

                {/* Acciones */}
                <button
                  onClick={submit}
                  disabled={saving || stars === 0}
                  className="w-full h-12 rounded-full bg-gradient-to-r from-[#1E6BFF] to-[#00B8D4] text-white font-bold text-sm flex items-center justify-center gap-2 disabled:opacity-40 shadow-lg shadow-[#1E6BFF]/30 mt-2"
                >
                  {saving ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      <Star className="w-4 h-4 fill-white" /> Enviar calificación
                    </>
                  )}
                </button>
                <button
                  onClick={skip}
                  disabled={saving}
                  className="w-full h-10 mt-2 text-muted-foreground text-xs font-medium hover:text-foreground"
                >
                  Omitir por ahora
                </button>
              </div>
            </>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
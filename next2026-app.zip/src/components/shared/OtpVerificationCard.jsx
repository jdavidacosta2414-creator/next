import React, { useState, useEffect } from 'react';
import { ArrowLeft, ArrowRight, Loader2, RefreshCw, MailCheck, CheckCircle2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';
import { signInExistingAccount } from '@/lib/existingAccount';

const NEXT_LOGO_URL =
  // Versión liviana del logo (se muestra a 64 px): el archivo original pesa 1,5 MB
  'https://media.base44.com/images/public/6ab13aed46d61158e305a1ce/0708957cd_file_0000000006d881f5a60038597f37c314.png/v1/fit/w_192,h_192,q_85,usm_0.66_1.00_0.01,enc_webp,quality_auto/0708957cd_file_0000000006d881f5a60038597f37c314.webp';

// Verifica primero en la base de datos si el correo (o cédula/placa en conductor) ya está registrado.
// Si ya está registrado en la base de datos, bloquea el registro e informa al usuario.
// Solo envía el código OTP si es un correo nuevo o una cuenta aún no verificada (is_verified === false).
export async function checkDatabaseRegistration({ email, cedula, plate, scope = 'pasajero', driverCategory }) {
  const cleanEmail = String(email || '').trim().toLowerCase();
  const res = await base44.functions.invoke('verifyDriverPhotos', {
    action: 'check_registration',
    email: cleanEmail,
    cedula: cedula ? String(cedula).trim() : '',
    plate: plate ? String(plate).trim().toUpperCase() : '',
    scope,
    driver_category: driverCategory,
  });
  return res?.data || res || { exists: false, verified: false };
}

export async function registerOrSendOtp(rawEmail, password, extraCheck = {}) {
  const cleanEmail = String(rawEmail || '').trim().toLowerCase();
  const dbCheck = await checkDatabaseRegistration({
    email: cleanEmail,
    cedula: extraCheck.cedula,
    plate: extraCheck.plate,
    scope: extraCheck.scope || 'pasajero',
    driverCategory: extraCheck.driverCategory,
  });

  if (dbCheck?.exists && dbCheck?.verified) {
    // El correo ya tiene cuenta en NEXT: se entra con ella en lugar de mandar a iniciar sesión.
    if (dbCheck.field === 'email') {
      await signInExistingAccount(cleanEmail, password);
      return { status: 'signed_in', email: cleanEmail };
    }
    const dupErr = new Error(
      dbCheck.error ||
        'Este correo electrónico ya está registrado en la base de datos. No puedes volver a registrarte con él.'
    );
    dupErr.code = 'ALREADY_REGISTERED';
    dupErr.field = dbCheck.field || 'email';
    throw dupErr;
  }

  // Si existe en User pero con is_verified === false (intentó registrarse y le faltó poner el código OTP)
  if (dbCheck?.exists && dbCheck?.verified === false) {
    await base44.auth.resendOtp(cleanEmail);
    return { status: 'resent', email: cleanEmail };
  }

  try {
    await base44.auth.register({ email: cleanEmail, password });
    return { status: 'registered', email: cleanEmail };
  } catch (err) {
    const msg = String(err?.message || err?.response?.data?.detail || '').toLowerCase();
    if (msg.includes('already') || msg.includes('exists') || msg.includes('registrad') || msg.includes('duplicate')) {
      const dupErr = new Error(
        'Este correo electrónico ya está registrado en la base de datos. Por favor inicia sesión.'
      );
      dupErr.code = 'ALREADY_REGISTERED';
      throw dupErr;
    }
    if (msg.includes('undeliverable') || msg.includes("can't receive mail") || msg.includes('invalid email')) {
      throw new Error('Ese correo electrónico no es válido o no puede recibir mensajes. Verifica que esté bien escrito (por ejemplo @gmail.com).');
    }
    throw err;
  }
}

export default function OtpVerificationCard({
  email,
  otpCode,
  setOtpCode,
  loading,
  error,
  onVerify,
  onBack,
  submitLabel = 'Verificar y continuar',
  loadingLabel = 'Verificando...',
}) {
  const [resending, setResending] = useState(false);
  const [cooldown, setCooldown] = useState(25);
  const [resendInfo, setResendInfo] = useState('Código de 6 dígitos enviado a tu correo.');

  useEffect(() => {
    if (cooldown <= 0) return;
    const t = setInterval(() => {
      setCooldown((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(t);
  }, [cooldown]);

  const handleResend = async () => {
    if (resending || cooldown > 0) return;
    const cleanEmail = String(email || '').trim().toLowerCase();
    if (!cleanEmail) return;
    setResending(true);
    setResendInfo('');
    try {
      await base44.auth.resendOtp(cleanEmail);
      setOtpCode('');
      setCooldown(30);
      setResendInfo('¡Listo! Te enviamos un nuevo código de 6 dígitos a tu correo.');
    } catch (err) {
      setResendInfo('Acabamos de enviarte un código. Revisa tu bandeja de entrada o Spam.');
      setCooldown(15);
    } finally {
      setResending(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F4F7FB] dark:bg-[#0B0F1A] flex flex-col px-6 py-8 max-w-md mx-auto w-full">
      <button
        type="button"
        onClick={onBack}
        className="w-10 h-10 rounded-full bg-white dark:bg-[#161C28] shadow-sm flex items-center justify-center text-slate-900 dark:text-white mb-6 self-start border border-slate-200/70 dark:border-white/10"
      >
        <ArrowLeft className="w-5 h-5" />
      </button>

      <div className="flex-1 flex flex-col items-center justify-center">
        <div className="w-full bg-white dark:bg-[#161C28] rounded-3xl border border-slate-200/80 dark:border-white/10 shadow-xl p-6 flex flex-col items-center text-center">
          <div className="relative mb-3">
            <img
              src={NEXT_LOGO_URL}
              alt="Next"
              className="w-16 h-16 rounded-2xl object-cover border-2 border-[#1E6BFF] shadow-md"
            />
            <span className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-[#1E6BFF] text-white flex items-center justify-center shadow">
              <MailCheck className="w-3.5 h-3.5" />
            </span>
          </div>

          <span className="text-[11px] font-extrabold uppercase tracking-widest text-[#1E6BFF] dark:text-[#00E5FF] mb-1">
            Verificación oficial NEXT
          </span>
          <h1 className="text-slate-900 dark:text-white text-2xl font-extrabold mb-1.5">
            Verifica tu correo
          </h1>
          <p className="text-slate-500 dark:text-[#8B95A8] text-sm mb-2">
            Enviamos un código de 6 dígitos a:
          </p>
          <p className="text-slate-900 dark:text-white font-bold text-sm px-3 py-1 rounded-full bg-slate-100 dark:bg-white/5 mb-4 break-all">
            {email}
          </p>

          {resendInfo && !error && (
            <div className="mb-4 px-3 py-2 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-700 dark:text-emerald-300 text-xs font-medium flex items-center justify-center gap-1.5 w-full">
              <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
              <span>{resendInfo}</span>
            </div>
          )}

          {error && (
            <div className="mb-4 p-3 rounded-xl bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/25 text-red-600 dark:text-red-400 text-xs font-semibold w-full text-center">
              {error}
            </div>
          )}

          <div className="flex justify-center my-4">
            <InputOTP
              maxLength={6}
              value={otpCode}
              onChange={setOtpCode}
              autoFocus
              autoComplete="one-time-code"
            >
              <InputOTPGroup>
                {[0, 1, 2, 3, 4, 5].map((i) => (
                  <InputOTPSlot
                    key={i}
                    index={i}
                    className="w-11 h-12 sm:w-12 sm:h-12 text-lg font-extrabold border-2 border-slate-200 dark:border-white/10 rounded-xl bg-slate-50 dark:bg-white/5 text-slate-900 dark:text-white data-[filled=true]:border-[#1E6BFF] dark:data-[filled=true]:border-[#00E5FF]"
                  />
                ))}
              </InputOTPGroup>
            </InputOTP>
          </div>

          <button
            type="button"
            onClick={onVerify}
            disabled={loading || otpCode.length < 6}
            className="w-full h-14 bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white font-bold rounded-full flex items-center justify-center gap-2 disabled:opacity-50 shadow-lg shadow-[#1E6BFF]/25 mt-2"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" /> {loadingLabel}
              </>
            ) : (
              <>
                {submitLabel} <ArrowRight className="w-5 h-5" />
              </>
            )}
          </button>

          <div className="mt-5 pt-4 border-t border-slate-100 dark:border-white/10 w-full flex flex-col items-center gap-2">
            <p className="text-[11px] text-slate-500 dark:text-[#8B95A8]">
              ¿No ves el correo? Revisa tu carpeta de <strong>Spam</strong> o <strong>Promociones</strong>.
            </p>
            <button
              type="button"
              onClick={handleResend}
              disabled={resending || cooldown > 0}
              className="inline-flex items-center gap-1.5 text-xs font-extrabold text-[#1E6BFF] dark:text-[#00E5FF] disabled:opacity-50 py-1.5 px-3 rounded-full hover:bg-[#1E6BFF]/10 transition-colors"
            >
              {resending ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" /> Reenviando código...
                </>
              ) : cooldown > 0 ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5" /> Reenviar código en {cooldown}s
                </>
              ) : (
                <>
                  <RefreshCw className="w-3.5 h-3.5" /> Reenviar código ahora
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
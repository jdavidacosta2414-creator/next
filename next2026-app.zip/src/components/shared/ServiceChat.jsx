import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { Send, Loader2 } from 'lucide-react';
import { isCallSignalMessage } from '@/components/shared/InAppVoiceCall';

export default function ServiceChat({ serviceId, senderType, senderName }) {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const scrollRef = useRef(null);
  const inputRef = useRef(null);

  const load = async () => {
    try {
      const res = await base44.entities.ServiceMessage.filter({ service_id: serviceId }, 'created_date', 100);
      const msgs = (Array.isArray(res) ? res : res?.items || []).filter((m) => !isCallSignalMessage(m));
      setMessages(msgs);
    } catch (e) {
      console.error('Chat load error:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    const unsub = base44.entities.ServiceMessage.subscribe((ev) => {
      const msg = ev?.data;
      if (msg && msg.service_id === serviceId && msg.id) {
        if (isCallSignalMessage(msg)) return;
        setMessages((prev) => (prev.some((x) => x.id === msg.id) ? prev : [...prev, msg]));
        return;
      }
      load().catch(() => {});
    });
    const poll = setInterval(() => load().catch(() => {}), 1000);
    return () => {
      unsub();
      clearInterval(poll);
    };
  }, [serviceId]);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const send = async (e) => {
    e.preventDefault();
    const clean = text.trim();
    if (!clean) return;
    setText('');
    setSending(true);
    const effectiveSenderName = senderName || (senderType === 'movil' ? 'Conductor' : 'Cliente');
    try {
      const created = await base44.entities.ServiceMessage.create({
        service_id: serviceId,
        sender_type: senderType,
        sender_name: effectiveSenderName,
        message: clean,
      });
      if (created?.id) {
        setMessages((prev) => (prev.some((x) => x.id === created.id) ? prev : [...prev, created]));
      }
      // Disparar notificación push inmediata al celular de la contraparte
      base44.functions
        .invoke('notifyNearbyDrivers', {
          action: 'service_message',
          service_id: serviceId,
          sender_type: senderType,
          sender_name: effectiveSenderName,
          message: clean,
        })
        .catch(() => {});
    } catch (e) {
      setText(clean);
      console.error('Chat send error:', e);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="bg-card rounded-2xl p-4 border border-border overflow-hidden">
      <div ref={scrollRef} className="h-48 overflow-y-auto space-y-2 mb-3 bg-muted/60 rounded-xl p-3">
        {loading ? (
          <div className="flex justify-center py-4"><Loader2 className="w-5 h-5 animate-spin text-[#1E6BFF]" /></div>
        ) : messages.length === 0 ? (
          <p className="text-center text-xs text-muted-foreground py-4">Escribe el primer mensaje</p>
        ) : messages.map(m => (
          <div key={m.id} className={`flex ${m.sender_type === senderType ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[75%] rounded-2xl px-3 py-2 text-sm ${
              m.sender_type === senderType
                ? 'bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white rounded-br-sm'
                : 'bg-card border border-border text-foreground rounded-bl-sm'
            }`}>
              {m.sender_type !== senderType && <p className="text-xs font-medium mb-0.5 text-muted-foreground">{m.sender_name}</p>}
              <p>{m.message}</p>
            </div>
          </div>
        ))}
      </div>
      <form onSubmit={send} className="flex gap-2 items-center">
        <input
          ref={inputRef}
          value={text}
          onChange={e => setText(e.target.value)}
          placeholder="Escribe un mensaje..."
          className="flex-1 min-w-0 h-10 rounded-lg border border-border bg-muted/60 px-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
        />
        <button type="submit" disabled={sending || !text.trim()} className="w-10 h-10 rounded-lg bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white flex items-center justify-center disabled:opacity-50 flex-shrink-0">
          {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
        </button>
      </form>
    </div>
  );
}
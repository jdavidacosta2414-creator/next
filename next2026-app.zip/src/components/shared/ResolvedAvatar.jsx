import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useBackButton } from '@/hooks/useBackButton';

const STORAGE_KEY = 'next_signed_url_cache_v2';
const SIGNED_URL_TTL_SECONDS = 3600; // Máximo permitido por servidor: 1 hora (3600s)
const CACHE_TTL_MS = 50 * 60 * 1000; // 50 minutos en caché persistente local

export const signedUrlCache = new Map();
const expMap = new Map();
const inFlightSignedUrls = new Map();
const preloadedImages = new Set();

// Hidratar caché desde localStorage de forma síncrona al cargar el módulo
// para que las fotos de perfil aparezcan en 0ms desde el primer render.
try {
  const raw = typeof window !== 'undefined' ? window.localStorage.getItem(STORAGE_KEY) : null;
  if (raw) {
    const parsed = JSON.parse(raw);
    const now = Date.now();
    if (parsed && typeof parsed === 'object') {
      Object.entries(parsed).forEach(([uri, entry]) => {
        if (entry && typeof entry.url === 'string' && entry.exp > now) {
          signedUrlCache.set(uri, entry.url);
          expMap.set(uri, entry.exp);
        }
      });
    }
  }
} catch {}

function persistCache() {
  try {
    if (typeof window === 'undefined') return;
    const now = Date.now();
    const obj = {};
    let count = 0;
    for (const [uri, url] of signedUrlCache.entries()) {
      if (!url || url.startsWith('blob:')) continue;
      const exp = expMap.get(uri) || now + CACHE_TTL_MS;
      if (exp > now) {
        obj[uri] = { url, exp };
        count += 1;
        if (count >= 150) break;
      }
    }
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(obj));
  } catch {}
}

export function preloadImage(url) {
  if (!url || typeof window === 'undefined' || preloadedImages.has(url)) return;
  preloadedImages.add(url);
  try {
    const img = new window.Image();
    img.decoding = 'sync';
    img.fetchPriority = 'high';
    img.src = url;
  } catch {}
}

export function isDirectImageUrl(v) {
  return (
    typeof v === 'string' &&
    (/^https?:\/\//.test(v) || v.startsWith('blob:') || v.startsWith('data:'))
  );
}

export function getCachedSignedUrl(uri) {
  if (!uri || typeof uri !== 'string') return null;
  const clean = uri.trim();
  if (!clean) return null;
  if (isDirectImageUrl(clean)) return clean;
  if (signedUrlCache.has(clean)) {
    const exp = expMap.get(clean);
    if (!exp || exp > Date.now()) {
      return signedUrlCache.get(clean);
    }
    signedUrlCache.delete(clean);
    expMap.delete(clean);
  }
  return null;
}

export function seedStorageUrlCache(uri, url) {
  if (!uri || !url) return;
  const clean = uri.trim();
  if (!clean) return;
  signedUrlCache.set(clean, url);
  expMap.set(clean, Date.now() + CACHE_TTL_MS);
  preloadImage(url);
  if (!url.startsWith('blob:')) {
    persistCache();
  }
}

export async function resolveStorageUrl(uri) {
  if (!uri || typeof uri !== 'string') return null;
  const clean = uri.trim();
  if (!clean) return null;
  if (isDirectImageUrl(clean)) {
    preloadImage(clean);
    return clean;
  }
  const cached = getCachedSignedUrl(clean);
  if (cached && !cached.startsWith('blob:')) {
    preloadImage(cached);
    return cached;
  }
  if (inFlightSignedUrls.has(clean)) {
    return inFlightSignedUrls.get(clean);
  }
  const promise = (async () => {
    try {
      const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({
        file_uri: clean,
        expires_in: SIGNED_URL_TTL_SECONDS,
      });
      if (signed_url) {
        signedUrlCache.set(clean, signed_url);
        expMap.set(clean, Date.now() + CACHE_TTL_MS);
        preloadImage(signed_url);
        persistCache();
        return signed_url;
      }
    } catch {}
    return cached || null;
  })().finally(() => {
    inFlightSignedUrls.delete(clean);
  });

  inFlightSignedUrls.set(clean, promise);
  return promise;
}

export function preloadStorageUrls(uris = []) {
  if (!Array.isArray(uris)) return;
  uris.forEach((u) => {
    if (u && typeof u === 'string' && u.trim()) {
      resolveStorageUrl(u.trim()).catch(() => {});
    }
  });
}

export default function ResolvedAvatar({
  photo,
  name = '',
  className = 'w-12 h-12 rounded-full',
  imgClassName = 'w-full h-full object-cover',
  fallback = null,
  style,
}) {
  const cleanPhoto = typeof photo === 'string' ? photo.trim() : '';
  const syncUrl = getCachedSignedUrl(cleanPhoto);
  const [resolvedUrl, setResolvedUrl] = useState(() => syncUrl);
  const [imgError, setImgError] = useState(false);
  const [lightboxOpen, setLightboxOpen] = useState(false);

  useBackButton(() => setLightboxOpen(false), lightboxOpen);

  const effectiveUrl = syncUrl || resolvedUrl;

  useEffect(() => {
    let active = true;
    setImgError(false);
    if (!cleanPhoto) {
      setResolvedUrl(null);
      return;
    }
    const immediate = getCachedSignedUrl(cleanPhoto);
    if (immediate) {
      setResolvedUrl(immediate);
      preloadImage(immediate);
      if (!immediate.startsWith('blob:')) return;
    }
    resolveStorageUrl(cleanPhoto).then((url) => {
      if (active && url) setResolvedUrl(url);
    });
    return () => {
      active = false;
    };
  }, [cleanPhoto]);

  const initials = (name || '?').trim().charAt(0).toUpperCase();

  const handleAvatarClick = (e) => {
    if (!effectiveUrl || imgError) return;
    if (e.currentTarget.closest('button, a, [data-photo-picker]')) return;
    e.stopPropagation();
    setLightboxOpen(true);
  };

  return (
    <>
      <div
        onClick={handleAvatarClick}
        className={`overflow-hidden flex items-center justify-center flex-shrink-0 ${
          effectiveUrl && !imgError ? 'cursor-pointer' : ''
        } ${className}`}
        style={style}
      >
        {effectiveUrl && !imgError ? (
          <img
            src={effectiveUrl}
            alt={name || 'Perfil'}
            loading="eager"
            decoding="sync"
            fetchPriority="high"
            className={imgClassName}
            onError={() => {
              if (cleanPhoto && !isDirectImageUrl(cleanPhoto)) {
                signedUrlCache.delete(cleanPhoto);
                expMap.delete(cleanPhoto);
                resolveStorageUrl(cleanPhoto).then((fresh) => {
                  if (fresh && fresh !== effectiveUrl) {
                    setResolvedUrl(fresh);
                    setImgError(false);
                  } else {
                    setImgError(true);
                  }
                });
              } else {
                setImgError(true);
              }
            }}
          />
        ) : (
          fallback ?? <span>{initials}</span>
        )}
      </div>

      {lightboxOpen && effectiveUrl && !imgError && (
        <div
          className="fixed inset-0 z-[2600] bg-black/90 flex items-center justify-center p-4"
          onClick={(e) => {
            e.stopPropagation();
            setLightboxOpen(false);
          }}
        >
          <img
            src={effectiveUrl}
            alt={name || 'Perfil'}
            className="max-w-[90vw] max-h-[85vh] rounded-2xl object-contain"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </>
  );
}
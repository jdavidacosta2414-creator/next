import React, { useState, useEffect } from 'react';
import {
  getCachedSignedUrl,
  isDirectImageUrl,
  resolveStorageUrl,
  preloadImage,
  signedUrlCache,
} from '@/components/shared/ResolvedAvatar';
import { useBackButton } from '@/hooks/useBackButton';

// Avatar del pasajero o conductor: muestra la foto de perfil al instante usando caché persistente,
// o las iniciales. Al tocar la foto se abre un lightbox a pantalla completa.
export default function ClientAvatar({ photo, name, size = 'sm', className = '' }) {
  const [open, setOpen] = useState(false);
  useBackButton(() => setOpen(false), open);
  const cleanPhoto = typeof photo === 'string' ? photo.trim() : '';
  const syncUrl = getCachedSignedUrl(cleanPhoto);
  const [signed, setSigned] = useState(() => syncUrl);
  const [loading, setLoading] = useState(false);
  const [imgError, setImgError] = useState(false);

  const effectiveUrl = syncUrl || signed;
  const initials = (name || '?').trim().slice(0, 2).toUpperCase();

  const sizes = {
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-xs',
    lg: 'w-12 h-12 text-sm',
    xl: 'w-14 h-14 text-base',
    '2xl': 'w-[72px] h-[72px] text-lg',
  };
  const cls = sizes[size] || sizes.sm;

  useEffect(() => {
    let active = true;
    setImgError(false);
    if (!cleanPhoto) {
      setSigned(null);
      return;
    }
    const immediate = getCachedSignedUrl(cleanPhoto);
    if (immediate) {
      setSigned(immediate);
      preloadImage(immediate);
      if (!immediate.startsWith('blob:')) return;
    }
    setLoading(true);
    resolveStorageUrl(cleanPhoto)
      .then((url) => {
        if (active && url) setSigned(url);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [cleanPhoto]);

  const showImg = Boolean(effectiveUrl && !imgError);

  const openLightbox = (e) => {
    e.stopPropagation();
    if (!showImg) return;
    setOpen(true);
  };

  return (
    <>
      {showImg ? (
        <button
          type="button"
          onClick={openLightbox}
          className={`${cls} ${className} rounded-full overflow-hidden flex items-center justify-center bg-muted text-foreground font-bold flex-shrink-0 active:scale-95 transition-transform relative border border-border`}
        >
          <img
            src={effectiveUrl}
            alt={name || 'Usuario'}
            loading="eager"
            decoding="sync"
            fetchPriority="high"
            className="w-full h-full object-cover"
            onError={() => {
              if (cleanPhoto && !isDirectImageUrl(cleanPhoto)) {
                signedUrlCache.delete(cleanPhoto);
                resolveStorageUrl(cleanPhoto).then((fresh) => {
                  if (fresh && fresh !== effectiveUrl) {
                    setSigned(fresh);
                    setImgError(false);
                  } else {
                    setImgError(true);
                  }
                });
              } else {
                setImgError(true);
              }
            }}
          />
        </button>
      ) : (
        <div
          className={`${cls} ${className} rounded-full bg-primary/15 text-primary flex items-center justify-center font-extrabold flex-shrink-0 border border-primary/20`}
        >
          {initials}
        </div>
      )}

      {open && (
        <div
          className="fixed inset-0 z-[2500] bg-black/90 flex items-center justify-center"
          onClick={(e) => {
            e.stopPropagation();
            setOpen(false);
          }}
        >
          {showImg ? (
            <img
              src={effectiveUrl}
              alt={name || 'Usuario'}
              className="max-w-[90vw] max-h-[85vh] rounded-2xl object-contain"
              onClick={(e) => e.stopPropagation()}
            />
          ) : (
            <div className="text-white/70 text-sm">{loading ? 'Cargando...' : 'Sin foto'}</div>
          )}
        </div>
      )}
    </>
  );
}
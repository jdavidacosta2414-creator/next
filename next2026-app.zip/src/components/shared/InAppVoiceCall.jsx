import React, { useState, useEffect, useRef, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Phone, PhoneOff, Mic, MicOff, Volume2, VolumeX, ShieldCheck, Lock } from 'lucide-react';
import ResolvedAvatar from '@/components/shared/ResolvedAvatar';
import { toast } from '@/components/ui/use-toast';

export const CALL_SIGNAL_PREFIX = '__CALL_SIGNAL__:';

export function isCallSignalMessage(msg) {
  const text = typeof msg === 'string' ? msg : msg?.message;
  return typeof text === 'string' && text.startsWith(CALL_SIGNAL_PREFIX);
}

function parseSignalMessage(msg) {
  if (!isCallSignalMessage(msg)) return null;
  try {
    const raw = (typeof msg === 'string' ? msg : msg.message).slice(CALL_SIGNAL_PREFIX.length);
    const data = JSON.parse(raw);
    return {
      ...data,
      _msgId: msg?.id,
      _senderType: msg?.sender_type,
      _senderName: msg?.sender_name,
      _createdDate: msg?.created_date,
    };
  } catch {
    return null;
  }
}

const RTC_CONFIG = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ],
};

function formatDuration(sec) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export function useInAppVoiceCall({
  serviceId,
  selfRole, // 'cliente' | 'movil'
  selfName,
  peerName,
  peerPhoto,
  peerSubtitle,
  enabled = true,
}) {
  const [callState, setCallState] = useState('idle'); // 'idle' | 'outgoing' | 'incoming' | 'connecting' | 'connected'
  const [callId, setCallId] = useState(null);
  const [callerName, setCallerName] = useState('');
  const [muted, setMuted] = useState(false);
  const [speakerOn, setSpeakerOn] = useState(true);
  const [durationSec, setDurationSec] = useState(0);

  const callStateRef = useRef('idle');
  const callIdRef = useRef(null);
  const pcRef = useRef(null);
  const localStreamRef = useRef(null);
  const remoteAudioRef = useRef(null);
  const pendingOfferRef = useRef(null);
  const pendingCandidatesRef = useRef([]);
  const processedMsgIdsRef = useRef(new Set());
  const mountTimeRef = useRef(Date.now());
  const ringIntervalRef = useRef(null);

  useEffect(() => {
    callStateRef.current = callState;
  }, [callState]);

  useEffect(() => {
    callIdRef.current = callId;
  }, [callId]);

  const stopRingTone = useCallback(() => {
    if (ringIntervalRef.current) {
      clearInterval(ringIntervalRef.current);
      ringIntervalRef.current = null;
    }
  }, []);

  const startRingTone = useCallback((mode = 'incoming') => {
    stopRingTone();
    const playBeep = () => {
      try {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!AudioCtx) return;
        const ctx = new AudioCtx();
        const freqs = mode === 'incoming' ? [523.25, 659.25, 783.99] : [440, 480];
        freqs.forEach((f, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.value = f;
          const start = ctx.currentTime + idx * 0.14;
          gain.gain.setValueAtTime(0.001, start);
          gain.gain.exponentialRampToValueAtTime(0.18, start + 0.03);
          gain.gain.exponentialRampToValueAtTime(0.001, start + 0.22);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(start);
          osc.stop(start + 0.24);
        });
      } catch {}
      if (mode === 'incoming') {
        try {
          navigator.vibrate?.([300, 150, 300]);
        } catch {}
      }
    };
    playBeep();
    ringIntervalRef.current = setInterval(playBeep, 2400);
  }, [stopRingTone]);

  const sendSignal = useCallback(
    async (payload) => {
      if (!serviceId) return;
      const body = CALL_SIGNAL_PREFIX + JSON.stringify({ ...payload, ts: Date.now() });
      try {
        await base44.entities.ServiceMessage.create({
          service_id: serviceId,
          sender_type: selfRole,
          sender_name: selfName || (selfRole === 'movil' ? 'Conductor' : 'Pasajero'),
          message: body,
        });
      } catch {}
    },
    [serviceId, selfRole, selfName]
  );

  const cleanupMedia = useCallback(() => {
    stopRingTone();
    if (pcRef.current) {
      try {
        pcRef.current.onicecandidate = null;
        pcRef.current.ontrack = null;
        pcRef.current.onconnectionstatechange = null;
        pcRef.current.close();
      } catch {}
      pcRef.current = null;
    }
    if (localStreamRef.current) {
      try {
        localStreamRef.current.getTracks().forEach((t) => t.stop());
      } catch {}
      localStreamRef.current = null;
    }
    if (remoteAudioRef.current) {
      try {
        remoteAudioRef.current.srcObject = null;
      } catch {}
    }
    pendingOfferRef.current = null;
    pendingCandidatesRef.current = [];
    setCallState('idle');
    setCallId(null);
    setMuted(false);
    setDurationSec(0);
  }, [stopRingTone]);

  const ensurePeerConnection = useCallback(
    (activeCallId) => {
      if (pcRef.current) return pcRef.current;
      const pc = new RTCPeerConnection(RTC_CONFIG);

      pc.onicecandidate = (ev) => {
        if (ev.candidate && activeCallId) {
          sendSignal({
            type: 'ice',
            callId: activeCallId,
            candidate: ev.candidate.toJSON ? ev.candidate.toJSON() : ev.candidate,
          });
        }
      };

      pc.ontrack = (ev) => {
        const [remoteStream] = ev.streams || [];
        if (remoteStream && remoteAudioRef.current) {
          remoteAudioRef.current.srcObject = remoteStream;
          remoteAudioRef.current.play?.().catch(() => {});
        }
      };

      pc.onconnectionstatechange = () => {
        const st = pc.connectionState;
        if (st === 'connected') {
          stopRingTone();
          setCallState('connected');
        } else if (st === 'failed' || st === 'Closed') {
          cleanupMedia();
        }
      };

      pcRef.current = pc;
      return pc;
    },
    [sendSignal, stopRingTone, cleanupMedia]
  );

  const flushPendingCandidates = useCallback(async (pc) => {
    if (!pc || !pc.remoteDescription) return;
    const queue = [...pendingCandidatesRef.current];
    pendingCandidatesRef.current = [];
    for (const c of queue) {
      try {
        await pc.addIceCandidate(new RTCIceCandidate(c));
      } catch {}
    }
  }, []);

  const acquireMicrophone = useCallback(async () => {
    if (localStreamRef.current) return localStreamRef.current;
    if (!navigator.mediaDevices?.getUserMedia) {
      throw new Error('Tu dispositivo no permite acceso al micrófono en este navegador.');
    }
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
      },
      video: false,
    });
    localStreamRef.current = stream;
    return stream;
  }, []);

  const startCall = useCallback(async () => {
    if (!serviceId || callStateRef.current !== 'idle') return;
    const newCallId = `call_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    setCallId(newCallId);
    setCallerName(peerName || (selfRole === 'movil' ? 'Pasajero' : 'Conductor'));
    setCallState('outgoing');
    startRingTone('outgoing');

    try {
      const stream = await acquireMicrophone();
      const pc = ensurePeerConnection(newCallId);
      stream.getTracks().forEach((track) => pc.addTrack(track, stream));

      const offer = await pc.createOffer({ offerToReceiveAudio: true });
      await pc.setLocalDescription(offer);

      await sendSignal({
        type: 'offer',
        callId: newCallId,
        sdp: { type: offer.type, sdp: offer.sdp },
      });

      base44.functions
        .invoke('notifyNearbyDrivers', {
          action: 'service_message',
          service_id: serviceId,
          sender_type: selfRole,
          sender_name: selfName || (selfRole === 'movil' ? 'Conductor' : 'Pasajero'),
          message: '📞 Llamada entrante en la app NEXT',
        })
        .catch(() => {});
    } catch (err) {
      cleanupMedia();
      toast({
        title: 'Permiso de micrófono requerido',
        description:
          err?.message || 'Permite el uso del micrófono para realizar llamadas internas en NEXT.',
        variant: 'destructive',
      });
    }
  }, [
    serviceId,
    peerName,
    selfRole,
    selfName,
    startRingTone,
    acquireMicrophone,
    ensurePeerConnection,
    sendSignal,
    cleanupMedia,
  ]);

  const acceptCall = useCallback(async () => {
    const activeCallId = callIdRef.current;
    const offerSdp = pendingOfferRef.current;
    if (!activeCallId || !offerSdp) return;

    stopRingTone();
    setCallState('connecting');

    try {
      const stream = await acquireMicrophone();
      const pc = ensurePeerConnection(activeCallId);
      stream.getTracks().forEach((track) => pc.addTrack(track, stream));

      await pc.setRemoteDescription(new RTCSessionDescription(offerSdp));
      await flushPendingCandidates(pc);

      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);

      await sendSignal({
        type: 'answer',
        callId: activeCallId,
        sdp: { type: answer.type, sdp: answer.sdp },
      });

      setCallState('connected');
    } catch (err) {
      await sendSignal({ type: 'hangup', callId: activeCallId });
      cleanupMedia();
      toast({
        title: 'No se pudo conectar la llamada',
        description: 'Verifica el permiso del micrófono e inténtalo nuevamente.',
        variant: 'destructive',
      });
    }
  }, [
    stopRingTone,
    acquireMicrophone,
    ensurePeerConnection,
    flushPendingCandidates,
    sendSignal,
    cleanupMedia,
  ]);

  const rejectCall = useCallback(async () => {
    const activeCallId = callIdRef.current;
    if (activeCallId) {
      await sendSignal({ type: 'reject', callId: activeCallId });
    }
    cleanupMedia();
  }, [sendSignal, cleanupMedia]);

  const endCall = useCallback(async () => {
    const activeCallId = callIdRef.current;
    if (activeCallId) {
      await sendSignal({ type: 'hangup', callId: activeCallId });
    }
    cleanupMedia();
  }, [sendSignal, cleanupMedia]);

  const toggleMute = useCallback(() => {
    const stream = localStreamRef.current;
    if (!stream) return;
    const nextMuted = !muted;
    stream.getAudioTracks().forEach((t) => {
      t.enabled = !nextMuted;
    });
    setMuted(nextMuted);
  }, [muted]);

  const toggleSpeaker = useCallback(() => {
    const nextSpeaker = !speakerOn;
    setSpeakerOn(nextSpeaker);
    if (remoteAudioRef.current) {
      remoteAudioRef.current.volume = nextSpeaker ? 1.0 : 0.35;
    }
  }, [speakerOn]);

  // Contador de segundos durante llamada conectada y timeout de 40s si no contestan
  useEffect(() => {
    if (callState === 'connected') {
      const t = setInterval(() => setDurationSec((s) => s + 1), 1000);
      return () => clearInterval(t);
    }
    if (callState === 'outgoing') {
      const t = setTimeout(() => {
        if (callStateRef.current === 'outgoing') {
          toast({
            title: 'No contestaron la llamada',
            description: 'Puedes intentarlo de nuevo o enviar un mensaje en el chat.',
          });
          endCall();
        }
      }, 40000);
      return () => clearTimeout(t);
    }
  }, [callState, endCall]);

  // Procesar señales entrantes de la contraparte
  const handleSignal = useCallback(
    async (sig) => {
      if (!sig || !sig.callId) return;
      if (sig._senderType === selfRole) return;
      if (sig._msgId && processedMsgIdsRef.current.has(sig._msgId)) return;
      if (sig._msgId) processedMsgIdsRef.current.add(sig._msgId);

      const signalTs = Number(sig.ts) || 0;
      if (signalTs > 0 && Date.now() - signalTs > 45000) return;
      if (!signalTs && sig._createdDate) {
        const createdMs = new Date(
          sig._createdDate.endsWith('Z') ? sig._createdDate : sig._createdDate + 'Z'
        ).getTime();
        if (createdMs < mountTimeRef.current - 15000) return;
      }

      if (sig.type === 'offer') {
        if (callStateRef.current !== 'idle' && callIdRef.current !== sig.callId) {
          return;
        }
        pendingOfferRef.current = sig.sdp;
        pendingCandidatesRef.current = [];
        setCallId(sig.callId);
        setCallerName(sig._senderName || peerName || 'Usuario NEXT');
        setCallState('incoming');
        startRingTone('incoming');
        return;
      }

      if (sig.callId !== callIdRef.current) return;

      if (sig.type === 'answer' && sig.sdp && pcRef.current) {
        stopRingTone();
        try {
          await pcRef.current.setRemoteDescription(new RTCSessionDescription(sig.sdp));
          await flushPendingCandidates(pcRef.current);
          setCallState('connected');
        } catch {}
        return;
      }

      if (sig.type === 'ice' && sig.candidate) {
        if (pcRef.current && pcRef.current.remoteDescription) {
          try {
            await pcRef.current.addIceCandidate(new RTCIceCandidate(sig.candidate));
          } catch {}
        } else {
          pendingCandidatesRef.current.push(sig.candidate);
        }
        return;
      }

      if (sig.type === 'reject') {
        cleanupMedia();
        toast({
          title: 'Llamada ocupada o rechazada',
          description: 'Puedes dejarle un mensaje en el chat de la app.',
        });
        return;
      }

      if (sig.type === 'hangup') {
        cleanupMedia();
        toast({ description: 'Llamada finalizada.' });
      }
    },
    [selfRole, peerName, startRingTone, stopRingTone, flushPendingCandidates, cleanupMedia]
  );

  useEffect(() => {
    if (!serviceId || !enabled) return;
    let alive = true;

    const checkSignals = async () => {
      try {
        const res = await base44.entities.ServiceMessage.filter(
          { service_id: serviceId },
          '-created_date',
          25
        );
        if (!alive) return;
        const items = (Array.isArray(res) ? res : res?.items || []).slice().reverse();
        for (const m of items) {
          const parsed = parseSignalMessage(m);
          if (parsed) {
            await handleSignal(parsed);
          }
        }
      } catch {}
    };

    checkSignals();
    const unsub = base44.entities.ServiceMessage.subscribe((ev) => {
      const m = ev?.data;
      if (m && m.service_id === serviceId && isCallSignalMessage(m)) {
        const parsed = parseSignalMessage(m);
        if (parsed) handleSignal(parsed);
      }
    });
    const poll = setInterval(checkSignals, 1500);

    return () => {
      alive = false;
      unsub();
      clearInterval(poll);
    };
  }, [serviceId, enabled, handleSignal]);

  useEffect(() => {
    return () => {
      cleanupMedia();
    };
  }, [cleanupMedia]);

  return {
    callState,
    callerName: callerName || peerName,
    peerPhoto,
    peerSubtitle,
    muted,
    speakerOn,
    durationSec,
    remoteAudioRef,
    startCall,
    acceptCall,
    rejectCall,
    endCall,
    toggleMute,
    toggleSpeaker,
  };
}

export default function InAppVoiceCallModal({ call }) {
  if (!call) return null;
  const {
    callState,
    callerName,
    peerPhoto,
    peerSubtitle,
    muted,
    speakerOn,
    durationSec,
    remoteAudioRef,
    acceptCall,
    rejectCall,
    endCall,
    toggleMute,
    toggleSpeaker,
  } = call;

  return (
    <>
      <audio ref={remoteAudioRef} autoPlay playsInline className="hidden" />
      {callState !== 'idle' && (
        <div
          className="fixed inset-0 z-[2500] bg-gradient-to-b from-[#04122C] via-[#07204E] to-[#04122C] text-white flex flex-col justify-between px-6 py-10 max-w-md mx-auto w-full select-none animate-in fade-in"
          data-testid="in-app-voice-call-modal"
        >
          {/* Encabezado de privacidad tipo inDrive */}
          <div className="flex flex-col items-center text-center pt-2">
            <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-emerald-500/15 border border-emerald-400/30 text-emerald-300 text-xs font-extrabold mb-6">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Llamada interna NEXT · Número privado protegido</span>
            </div>

            <div className="relative mb-4">
              {(callState === 'incoming' || callState === 'outgoing') && (
                <>
                  <span className="absolute -inset-3 rounded-full bg-[#1E6BFF]/30 animate-ping" />
                  <span className="absolute -inset-6 rounded-full bg-[#00E5FF]/15 animate-pulse" />
                </>
              )}
              <ResolvedAvatar
                photo={peerPhoto}
                name={callerName || 'Usuario'}
                className="relative w-28 h-28 rounded-full bg-[#0B439C] border-4 border-[#38BDF8] text-white font-black text-3xl shadow-2xl"
              />
            </div>

            <h2 className="text-2xl font-black tracking-tight text-white">
              {callerName || 'Usuario NEXT'}
            </h2>
            {peerSubtitle && (
              <p className="text-xs font-bold text-sky-200/85 mt-1">{peerSubtitle}</p>
            )}

            <div className="mt-4">
              {callState === 'incoming' && (
                <p className="text-base font-extrabold text-emerald-300 animate-pulse">
                  Llamada entrante en la app...
                </p>
              )}
              {callState === 'outgoing' && (
                <p className="text-base font-extrabold text-sky-300 animate-pulse">
                  Llamando por la app...
                </p>
              )}
              {callState === 'connecting' && (
                <p className="text-base font-extrabold text-sky-300">Conectando audio seguro...</p>
              )}
              {callState === 'connected' && (
                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 text-white font-mono font-black text-lg">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>{formatDuration(durationSec)}</span>
                </div>
              )}
            </div>
          </div>

          {/* Aviso de seguridad de números ocultos */}
          <div className="rounded-2xl bg-white/8 border border-white/12 px-4 py-3 flex items-center gap-3 text-left max-w-xs mx-auto">
            <div className="w-9 h-9 rounded-xl bg-sky-400/15 flex items-center justify-center flex-shrink-0">
              <Lock className="w-4 h-4 text-sky-300" />
            </div>
            <p className="text-[11.5px] text-slate-200 leading-snug">
              Por tu seguridad, tu número de teléfono y WhatsApp están ocultos durante toda la llamada.
            </p>
          </div>

          {/* Controles inferiores */}
          <div className="pb-6">
            {callState === 'incoming' ? (
              <div className="flex items-center justify-around max-w-xs mx-auto">
                <div className="flex flex-col items-center gap-2">
                  <button
                    type="button"
                    onClick={rejectCall}
                    data-testid="reject-inapp-call-btn"
                    className="w-16 h-16 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-xl shadow-rose-600/40 active:scale-95 transition-transform"
                  >
                    <PhoneOff className="w-7 h-7" />
                  </button>
                  <span className="text-xs font-extrabold text-rose-200">Rechazar</span>
                </div>

                <div className="flex flex-col items-center gap-2">
                  <button
                    type="button"
                    onClick={acceptCall}
                    data-testid="accept-inapp-call-btn"
                    className="w-16 h-16 rounded-full bg-emerald-500 hover:bg-emerald-400 text-white flex items-center justify-center shadow-xl shadow-emerald-500/40 active:scale-95 transition-transform animate-bounce"
                  >
                    <Phone className="w-7 h-7" />
                  </button>
                  <span className="text-xs font-extrabold text-emerald-200">Contestar</span>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center gap-7">
                <div className="flex flex-col items-center gap-1.5">
                  <button
                    type="button"
                    onClick={toggleMute}
                    className={`w-13 h-13 w-12 h-12 rounded-full flex items-center justify-center border transition-colors ${
                      muted
                        ? 'bg-amber-500 text-slate-950 border-amber-400'
                        : 'bg-white/12 text-white border-white/20'
                    }`}
                  >
                    {muted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                  </button>
                  <span className="text-[11px] font-bold text-slate-300">
                    {muted ? 'Silenciado' : 'Micrófono'}
                  </span>
                </div>

                <div className="flex flex-col items-center gap-1.5">
                  <button
                    type="button"
                    onClick={endCall}
                    data-testid="end-inapp-call-btn"
                    className="w-16 h-16 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-xl shadow-rose-600/40 active:scale-95 transition-transform"
                  >
                    <PhoneOff className="w-7 h-7" />
                  </button>
                  <span className="text-xs font-extrabold text-rose-200">Colgar</span>
                </div>

                <div className="flex flex-col items-center gap-1.5">
                  <button
                    type="button"
                    onClick={toggleSpeaker}
                    className={`w-12 h-12 rounded-full flex items-center justify-center border transition-colors ${
                      speakerOn
                        ? 'bg-sky-500/30 text-sky-200 border-sky-400/50'
                        : 'bg-white/12 text-white border-white/20'
                    }`}
                  >
                    {speakerOn ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
                  </button>
                  <span className="text-[11px] font-bold text-slate-300">Altavoz</span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
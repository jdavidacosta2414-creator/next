import React, { useState, useEffect } from 'react';
import { Camera, Image as ImageIcon, Loader2, X } from 'lucide-react';
import { getCachedSignedUrl, resolveStorageUrl, seedStorageUrlCache } from '@/components/shared/ResolvedAvatar';
import { uploadRegistrationPhoto } from '@/lib/image';
import InAppCameraModal from '@/components/shared/InAppCameraModal';

// Captura o selecciona una imagen de galería y la sube al almacenamiento PRIVADO de la app.
export default function PrivateImageCapture({
  label,
  onChange,
  value,
  facing = null,
  maxSize = 1280,
  height = 'h-40',
}) {
  const [loading, setLoading] = useState(false);
  const [cameraOpen, setCameraOpen] = useState(false);
  const [signed, setSigned] = useState(() => getCachedSignedUrl(value) || '');
  const [error, setError] = useState(null);

  useEffect(() => {
    let active = true;
    if (!value) {
      setSigned('');
      return;
    }
    const cached = getCachedSignedUrl(value);
    if (cached) {
      setSigned(cached);
      if (!cached.startsWith('blob:')) return;
    }
    resolveStorageUrl(value)
      .then((url) => {
        if (active && url) setSigned(url);
      })
      .catch(() => {
        if (active) setError('No se pudo cargar la imagen.');
      });
    return () => {
      active = false;
    };
  }, [value]);

  const markPickerOpen = () => {
    if (typeof window !== 'undefined') {
      window.__nextFilePickerOpenUntil = Date.now() + 60000;
    }
  };

  const processFile = async (file) => {
    if (!file) return;
    const localBlobUrl = URL.createObjectURL(file);
    setSigned(localBlobUrl);
    setLoading(true);
    setError(null);
    try {
      const { file_uri, previewUrl } = await uploadRegistrationPhoto(file, maxSize, 0.78);
      seedStorageUrlCache(file_uri, previewUrl || localBlobUrl);
      resolveStorageUrl(file_uri).catch(() => {});
      onChange(file_uri);
    } catch {
      setError('No se pudo subir la imagen. Intenta de nuevo.');
      setSigned(getCachedSignedUrl(value) || '');
    } finally {
      setLoading(false);
    }
  };

  const handleGalleryInput = (e) => {
    const file = e.target.files?.[0];
    if (e.target) e.target.value = '';
    if (file) processFile(file);
  };

  return (
    <div className="relative space-y-2" data-photo-picker="true">
      <InAppCameraModal
        open={cameraOpen}
        facing={facing || 'environment'}
        title={label || 'Tomar foto'}
        onClose={() => setCameraOpen(false)}
        onCaptureFile={processFile}
      />

      {value ? (
        <div className="relative">
          <img
            src={signed}
            alt={label}
            loading="eager"
            decoding="sync"
            className={`w-full ${height} object-cover rounded-xl border border-white/10 bg-white/5`}
          />
          <button
            type="button"
            onClick={() => onChange('')}
            className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1.5 shadow-lg z-20"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ) : loading ? (
        <div
          className={`w-full ${height} flex flex-col items-center justify-center gap-2 border-2 border-dashed border-white/15 rounded-xl text-[#8B95A8]`}
        >
          <Loader2 className="w-6 h-6 animate-spin text-[#00E5FF]" />
          <span className="text-xs font-medium">Subiendo imagen...</span>
        </div>
      ) : facing ? (
        <div className="grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={() => setCameraOpen(true)}
            className="h-24 flex flex-col items-center justify-center gap-1.5 border-2 border-dashed border-[#00E5FF]/40 bg-[#00E5FF]/5 hover:bg-[#00E5FF]/10 rounded-xl text-white transition-colors"
          >
            <Camera className="w-6 h-6 text-[#00E5FF]" />
            <span className="text-xs font-bold">Tomar foto</span>
          </button>
          <div className="relative overflow-hidden h-24 flex flex-col items-center justify-center gap-1.5 border-2 border-dashed border-white/15 bg-white/5 hover:bg-white/10 rounded-xl text-white transition-colors cursor-pointer">
            <ImageIcon className="w-6 h-6 text-[#00E5FF]" />
            <span className="text-xs font-bold">Galería</span>
            <input
              type="file"
              accept="image/*"
              onChange={handleGalleryInput}
              onClick={markPickerOpen}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
            />
          </div>
        </div>
      ) : (
        <div
          className={`relative overflow-hidden w-full ${height} flex flex-col items-center justify-center gap-2 border-2 border-dashed border-white/15 rounded-xl text-[#8B95A8] hover:bg-white/5 transition-colors cursor-pointer`}
        >
          <ImageIcon className="w-6 h-6 text-[#00E5FF]" />
          <span className="text-sm font-medium">{label}</span>
          <input
            type="file"
            accept="image/*"
            onChange={handleGalleryInput}
            onClick={markPickerOpen}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
          />
        </div>
      )}
      {error && <p className="text-sm text-red-400">{error}</p>}
    </div>
  );
}
import React, { useEffect, useRef, useState } from 'react';
import { Camera, RefreshCw, X, Image as ImageIcon, Loader2, Check } from 'lucide-react';
import { useBackButton } from '@/hooks/useBackButton';

// Cámara integrada dentro de la aplicación (con respaldo automático al selector del teléfono sin atributo capture)
// para evitar pantallas blancas o bloqueos de WebChromeClient en APK de Android.
export default function InAppCameraModal({
  open,
  facing = 'environment',
  title = 'Tomar foto',
  // Solo cámara: sin galería ni selector de archivos. Si la cámara no abre, se pide permitirla y reintentar.
  cameraOnly = false,
  onClose,
  onCaptureFile,
}) {
  useBackButton(() => {
    stopStream();
    onClose?.();
    return true;
  }, Boolean(open));
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const [currentFacing, setCurrentFacing] = useState(facing || 'environment');
  const [starting, setStarting] = useState(true);
  const [camError, setCamError] = useState('');
  const [capturedBlobUrl, setCapturedBlobUrl] = useState('');
  const [capturedFile, setCapturedFile] = useState(null);
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    setCurrentFacing(facing || 'environment');
  }, [facing]);

  const stopStream = () => {
    if (streamRef.current) {
      try {
        streamRef.current.getTracks().forEach((t) => t.stop());
      } catch {}
      streamRef.current = null;
    }
  };

  useEffect(() => {
    if (!open) {
      stopStream();
      setCapturedBlobUrl('');
      setCapturedFile(null);
      setCamError('');
      return;
    }

    let alive = true;
    setStarting(true);
    setCamError('');

    const startCamera = async () => {
      stopStream();
      if (
        typeof navigator === 'undefined' ||
        !navigator.mediaDevices ||
        typeof navigator.mediaDevices.getUserMedia !== 'function'
      ) {
        if (alive) {
          setStarting(false);
          setCamError('Selecciona o toma la foto desde el selector de tu teléfono.');
        }
        return;
      }

      try {
        const stream = await Promise.race([
          navigator.mediaDevices.getUserMedia({
            video: {
              facingMode: { ideal: currentFacing },
              width: { ideal: 1280 },
              height: { ideal: 960 },
            },
            audio: false,
          }),
          new Promise((_, reject) =>
            setTimeout(() => reject(new Error('camera_timeout')), 4500)
          ),
        ]);

        if (!alive) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }

        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          try {
            await videoRef.current.play();
          } catch {}
        }
        setStarting(false);
      } catch {
        if (!alive) return;
        // Segundo intento con configuración básica de video
        try {
          const fallbackStream = await navigator.mediaDevices.getUserMedia({
            video: true,
            audio: false,
          });
          if (!alive) {
            fallbackStream.getTracks().forEach((t) => t.stop());
            return;
          }
          streamRef.current = fallbackStream;
          if (videoRef.current) {
            videoRef.current.srcObject = fallbackStream;
            try {
              await videoRef.current.play();
            } catch {}
          }
          setStarting(false);
        } catch {
          if (alive) {
            setStarting(false);
            setCamError(
              'El permiso directo de cámara no está activo en este dispositivo. Toca el botón de abajo para elegir o tomar la foto.'
            );
          }
        }
      }
    };

    startCamera();

    return () => {
      alive = false;
      stopStream();
    };
  }, [open, currentFacing, attempt]);

  if (!open) return null;

  const takeSnapshot = () => {
    const video = videoRef.current;
    if (!video || !video.videoWidth || !video.videoHeight) return;
    try {
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      canvas.toBlob(
        (blob) => {
          if (!blob) return;
          const file = new File([blob], `captura_${Date.now()}.jpg`, {
            type: 'image/jpeg',
          });
          const preview = URL.createObjectURL(blob);
          setCapturedFile(file);
          setCapturedBlobUrl(preview);
          stopStream();
        },
        'image/jpeg',
        0.85
      );
    } catch {}
  };

  const confirmCaptured = () => {
    if (!capturedFile) return;
    const f = capturedFile;
    onClose?.();
    onCaptureFile?.(f);
  };

  const retake = () => {
    setCapturedFile(null);
    setCapturedBlobUrl('');
    setCurrentFacing((prev) => prev);
    // Re-trigger stream
    setStarting(true);
    navigator.mediaDevices
      ?.getUserMedia({ video: { facingMode: { ideal: currentFacing } }, audio: false })
      .then((stream) => {
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(() => {});
        }
        setStarting(false);
      })
      .catch(() => {
        setStarting(false);
        setCamError('Toca el botón de abajo para elegir la foto desde tu dispositivo.');
      });
  };

  const handleFallbackInput = (e) => {
    const file = e.target.files?.[0];
    if (e.target) e.target.value = '';
    if (file) {
      stopStream();
      onClose?.();
      onCaptureFile?.(file);
    }
  };

  return (
    <div
      className="fixed inset-0 z-[3500] bg-[#040B16]/95 flex flex-col justify-between p-4 select-none"
      data-photo-picker="true"
    >
      {/* Encabezado */}
      <div className="flex items-center justify-between gap-3 pt-2">
        <div className="min-w-0">
          <p className="text-white font-extrabold text-base truncate">{title}</p>
          <p className="text-xs text-sky-200/80">
            {facing === 'user'
              ? 'Selfie normal: que se vea bien tu rostro, sin gafas oscuras, gorra ni tapabocas'
              : 'Centra bien la imagen y asegúrate de que sea legible'}
          </p>
        </div>
        <button
          type="button"
          onClick={() => {
            stopStream();
            onClose?.();
          }}
          className="w-10 h-10 rounded-full bg-white/10 text-white flex items-center justify-center flex-shrink-0"
          aria-label="Cerrar cámara"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Visor de cámara o imagen capturada */}
      <div className="relative flex-1 my-4 rounded-3xl overflow-hidden bg-[#0B1324] border border-white/15 flex items-center justify-center">
        {capturedBlobUrl ? (
          <img
            src={capturedBlobUrl}
            alt="Vista previa"
            className="w-full h-full object-contain"
          />
        ) : camError ? (
          <div className="p-6 text-center max-w-xs space-y-4">
            <div className="w-16 h-16 rounded-full bg-[#1E6BFF]/20 border border-[#00E5FF]/40 flex items-center justify-center mx-auto">
              <Camera className="w-8 h-8 text-[#00E5FF]" />
            </div>
            <p className="text-sm font-bold text-white leading-relaxed">
              {cameraOnly
                ? 'No se pudo abrir la cámara. Activa el permiso de cámara para NEXT en los ajustes de tu celular y toca Reintentar. Esta foto solo se puede tomar con la cámara.'
                : camError}
            </p>
            {cameraOnly ? (
              <button
                type="button"
                onClick={() => setAttempt((n) => n + 1)}
                className="w-full rounded-2xl bg-gradient-to-r from-[#1E6BFF] to-[#00B8D4] text-white font-extrabold text-sm h-12 flex items-center justify-center gap-2 shadow-lg"
              >
                <RefreshCw className="w-5 h-5" />
                <span>Reintentar</span>
              </button>
            ) : (
              <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#1E6BFF] to-[#00B8D4] text-white font-extrabold text-sm h-12 flex items-center justify-center gap-2 shadow-lg">
                <ImageIcon className="w-5 h-5" />
                <span>Seleccionar o tomar foto</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFallbackInput}
                  onClick={() => {
                    if (typeof window !== 'undefined') {
                      window.__nextFilePickerOpenUntil = Date.now() + 60000;
                    }
                  }}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                />
              </div>
            )}
          </div>
        ) : (
          <>
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover"
            />
            {starting && (
              <div className="absolute inset-0 bg-[#0B1324]/80 flex flex-col items-center justify-center gap-2">
                <Loader2 className="w-8 h-8 animate-spin text-[#00E5FF]" />
                <span className="text-xs font-semibold text-white">Iniciando cámara...</span>
              </div>
            )}
          </>
        )}
      </div>

      {/* Controles inferiores */}
      <div className="pb-2 space-y-2.5">
        {capturedBlobUrl ? (
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={retake}
              className="h-12 rounded-2xl bg-white/10 border border-white/20 text-white font-bold text-sm flex items-center justify-center gap-2"
            >
              <RefreshCw className="w-4 h-4" /> Tomar otra
            </button>
            <button
              type="button"
              onClick={confirmCaptured}
              className="h-12 rounded-2xl bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg"
            >
              <Check className="w-5 h-5" /> Usar esta foto
            </button>
          </div>
        ) : (
          <div className="flex items-center justify-between gap-3">
            {/* Botón directo de galería como alternativa rápida (no aparece cuando la foto es solo con cámara) */}
            {!cameraOnly && (
              <div className="relative overflow-hidden h-12 px-4 rounded-2xl bg-white/10 border border-white/15 text-white text-xs font-bold flex items-center justify-center gap-2">
                <ImageIcon className="w-4 h-4 text-[#00E5FF]" />
                <span>Galería</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFallbackInput}
                  onClick={() => {
                    if (typeof window !== 'undefined') {
                      window.__nextFilePickerOpenUntil = Date.now() + 60000;
                    }
                  }}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                />
              </div>
            )}

            {!camError && (
              <button
                type="button"
                disabled={starting}
                onClick={takeSnapshot}
                className="flex-1 h-14 rounded-full bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg disabled:opacity-50 active:scale-95 transition-transform"
              >
                <Camera className="w-5 h-5" />
                <span>Capturar foto</span>
              </button>
            )}

            {!camError && (
              <button
                type="button"
                onClick={() =>
                  setCurrentFacing((prev) => (prev === 'user' ? 'environment' : 'user'))
                }
                className="w-12 h-12 rounded-2xl bg-white/10 border border-white/15 text-white flex items-center justify-center flex-shrink-0"
                title="Cambiar cámara"
              >
                <RefreshCw className="w-5 h-5" />
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
import React from 'react';
import { Navigation, MapPin } from 'lucide-react';
import { fmtKm, fmtMin } from '@/lib/routeEstimate';

// Muestra los dos tramos del recorrido: Conductor → A y A → B,
// con distancia y tiempo aproximados en badges de color.
export default function RouteSegments({ seg1Km, seg1Min, seg2Km, seg2Min, compact = false }) {
  return (
    <div className={compact ? 'space-y-1.5' : 'space-y-2'}>
      {/* Tramo 1: Conductor → Punto A */}
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1 flex-shrink-0">
          <Navigation className={compact ? 'w-3 h-3' : 'w-3.5 h-3.5'} style={{ color: '#1E6BFF' }} />
          <span className="w-5 h-5 rounded bg-[#1E6BFF] text-white flex items-center justify-center font-bold text-[10px]">A</span>
        </div>
        <div className="flex items-center gap-1.5 ml-auto flex-wrap">
          {seg1Min != null && (
            <span className="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-[#1E6BFF]/10 text-[#1E6BFF]">
              {fmtMin(seg1Min)}
            </span>
          )}
          {seg1Km != null && (
            <span className="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-[#1E6BFF]/10 text-[#1E6BFF]">
              {fmtKm(seg1Km)}
            </span>
          )}
        </div>
      </div>

      {/* Tramo 2: Punto A → Punto B */}
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1 flex-shrink-0">
          <span className="w-5 h-5 rounded bg-[#1E6BFF] text-white flex items-center justify-center font-bold text-[10px]">A</span>
          <span className="w-5 h-5 rounded bg-[#3DDC84] text-white flex items-center justify-center font-bold text-[10px]">B</span>
        </div>
        <div className="flex items-center gap-1.5 ml-auto flex-wrap">
          {seg2Min != null && (
            <span className="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-[#3DDC84]/10 text-[#1A9E4E]">
              {fmtMin(seg2Min)}
            </span>
          )}
          {seg2Km != null && (
            <span className="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-[#3DDC84]/10 text-[#1A9E4E]">
              {fmtKm(seg2Km)}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
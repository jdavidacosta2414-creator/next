import React from 'react';
import { resolveVehicleColorPalette, FACTORY_VEHICLE_COLORS } from '@/lib/mapboxMarkers';
import Vehicle3DIcon from '@/components/shared/Vehicle3DIcon';

export { FACTORY_VEHICLE_COLORS };

// Renders 3D reales de estudio por marca, línea y carrocería (Valledupar / Colombia)
export const VEHICLE_3D_STUDIO_IMAGES = {
  city_hatch: 'https://media.base44.com/images/public/6ab13aed46d61158e305a1ce/cc57b2a87_generated_image.png',
  hatchback: 'https://media.base44.com/images/public/6ab13aed46d61158e305a1ce/0b031eff9_generated_image.png',
  renault_sedan: 'https://media.base44.com/images/public/6ab13aed46d61158e305a1ce/a2ac35636_generated_image.png',
  chevrolet_sedan: 'https://media.base44.com/images/public/6ab13aed46d61158e305a1ce/987b49dc5_generated_image.png',
  mazda_sedan: 'https://media.base44.com/images/public/6ab13aed46d61158e305a1ce/f938c3719_generated_image.png',
  sedan: 'https://media.base44.com/images/public/6ab13aed46d61158e305a1ce/987b49dc5_generated_image.png',
  suv: 'https://media.base44.com/images/public/6ab13aed46d61158e305a1ce/ed8541d2e_generated_image.png',
  pickup: 'https://media.base44.com/images/public/6ab13aed46d61158e305a1ce/0114e426e_generated_image.png',
  taxi: 'https://media.base44.com/images/public/6ab13aed46d61158e305a1ce/e8551840e_generated_image.png',
  moto: 'https://media.base44.com/images/public/6ab13aed46d61158e305a1ce/dc499356e_generated_image.png',
  mensajeria: 'https://media.base44.com/images/public/6ab13aed46d61158e305a1ce/dbc636d13_generated_image.png',
};

// Catálogo oficial de marcas y modelos más utilizados en plataformas de movilidad en Colombia (Valledupar)
export const COLOMBIA_CAR_CATALOG = [
  {
    brand: 'Chevrolet',
    models: ['Spark', 'Spark GT', 'Beat', 'Sail', 'Joy', 'Onix', 'Tracker', 'Trailblazer', 'Aveo'],
  },
  {
    brand: 'Renault',
    models: ['Kwid', 'Sandero', 'Stepway', 'Logan', 'Duster', 'Symbol'],
  },
  {
    brand: 'Kia',
    models: ['Picanto', 'Rio', 'Soluto', 'Sportage', 'Cerato'],
  },
  {
    brand: 'Mazda',
    models: ['Mazda 2', 'Mazda 3', 'CX-30', 'CX-5'],
  },
  {
    brand: 'Toyota',
    models: ['Hilux', 'Fortuner', 'Corolla Cross', 'Corolla', 'Prado', 'Yaris'],
  },
  {
    brand: 'Nissan',
    models: ['March', 'Versa', 'Sentra', 'Kicks', 'Frontier'],
  },
  {
    brand: 'Hyundai',
    models: ['Grand i10', 'Accent', 'Tucson', 'Atos'],
  },
  {
    brand: 'Suzuki',
    models: ['Swift', 'Alto', 'Baleno', 'Vitara'],
  },
  {
    brand: 'Volkswagen',
    models: ['Gol', 'Voyage', 'Polo', 'Virtus'],
  },
];

/**
 * Detecta la marca, línea/modelo, carrocería 3D y color de fábrica con los que el conductor registró su vehículo.
 * En Colombia:
 * - Placa amarilla (plate_type === 'amarilla') = Carro particular (NO es taxi).
 * - Placa blanca (plate_type === 'blanca') o car_subtype === 'taxi' = Servicio público / Taxi.
 */
export function resolveRegisteredVehicleSpec(driver = {}, service = {}) {
  const vType = driver?.vehicle_type || service?.vehicle_type || 'moto';
  const rawBrand = String(driver?.vehicle_brand || '').trim();
  const rawModel = String(driver?.vehicle_model || '').trim();
  const rawYear = driver?.vehicle_year ? String(driver.vehicle_year) : '';

  const isTaxi =
    vType === 'carro' &&
    (driver?.car_subtype === 'taxi' ||
      driver?.plate_type === 'blanca' ||
      /taxi/i.test(`${rawBrand} ${rawModel}`));

  const rawColor =
    String(driver?.vehicle_color || '').trim() ||
    (driver?.car_subtype === 'taxi' ? 'Amarillo' : vType === 'carro' ? 'Blanco' : 'Azul');

  const palette = resolveVehicleColorPalette(rawColor, driver?.car_subtype === 'taxi');
  const combinedLower = `${rawBrand} ${rawModel}`
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');

  let brandKey = 'generic';
  let brandDisplay = rawBrand || (vType === 'carro' ? 'Automóvil' : 'Motocicleta');

  if (
    combinedLower.includes('renault') ||
    /logan|sandero|stepway|kwid|duster|twingo|symbol|clio|oroch/.test(combinedLower)
  ) {
    brandKey = 'renault';
    if (!rawBrand) brandDisplay = 'Renault';
  } else if (
    combinedLower.includes('chevrolet') ||
    /spark|beat|sail|saild|joy|onix|aveo|optra|tracker|trailblazer|captiva/.test(combinedLower)
  ) {
    brandKey = 'chevrolet';
    if (!rawBrand) brandDisplay = 'Chevrolet';
  } else if (
    combinedLower.includes('mazda') ||
    /mazda|cx-30|cx30|cx-5|cx5|allegro/.test(combinedLower)
  ) {
    brandKey = 'mazda';
    if (!rawBrand) brandDisplay = 'Mazda';
  } else if (
    combinedLower.includes('kia') ||
    /picanto|pica|rio|soluto|sportage|cerato|tonic/.test(combinedLower)
  ) {
    brandKey = 'kia';
    if (!rawBrand) brandDisplay = 'Kia';
  } else if (
    combinedLower.includes('toyota') ||
    /hilux|fortuner|corolla|prado|yaris|etios|txl/.test(combinedLower)
  ) {
    brandKey = 'toyota';
    if (!rawBrand) brandDisplay = 'Toyota';
  } else if (
    combinedLower.includes('nissan') ||
    /march|versa|sentra|kicks|frontier|tiida/.test(combinedLower)
  ) {
    brandKey = 'nissan';
    if (!rawBrand) brandDisplay = 'Nissan';
  } else if (
    combinedLower.includes('hyundai') ||
    /atos|i10|grand i10|accent|elantra|tucson|getz/.test(combinedLower)
  ) {
    brandKey = 'hyundai';
    if (!rawBrand) brandDisplay = 'Hyundai';
  } else if (
    combinedLower.includes('suzuki') ||
    /swift|alto|baleno|vitara|ertiga|dzire/.test(combinedLower)
  ) {
    brandKey = 'suzuki';
    if (!rawBrand) brandDisplay = 'Suzuki';
  } else if (
    combinedLower.includes('volkswagen') ||
    combinedLower.includes('vw') ||
    /gol|voyage|polo|virtus|jetta/.test(combinedLower)
  ) {
    brandKey = 'vw';
    if (!rawBrand) brandDisplay = 'Volkswagen';
  } else if (
    combinedLower.includes('ford') ||
    /fiesta|focus|ecosport|escape|ranger/.test(combinedLower)
  ) {
    brandKey = 'ford';
    if (!rawBrand) brandDisplay = 'Ford';
  }

  let bodyStyle = 'sedan';
  if (vType !== 'carro') {
    bodyStyle = service?.service_type === 'mensajeria' ? 'mensajeria' : 'moto';
  } else if (/hilux|frontier|ranger|d-max|dmax|oroch|pickup/.test(combinedLower)) {
    bodyStyle = 'pickup';
  } else if (
    /tracker|trailblazer|captiva|duster|cx-30|cx30|cx-5|cx5|sportage|fortuner|corolla cross|prado|txl|kicks|tucson|vitara|ecosport|escape/.test(
      combinedLower
    )
  ) {
    bodyStyle = 'suv';
  } else if (
    /picanto|pica|spark|beat|kwid|march|i10|atos|twingo|alto/.test(combinedLower)
  ) {
    bodyStyle = 'city_hatch';
  } else if (
    /sandero|stepway|clio|swift|baleno|gol|polo|fiesta|rio|mazda 2|\b2\b/.test(
      combinedLower
    )
  ) {
    bodyStyle = 'hatchback';
  } else {
    bodyStyle = 'sedan';
  }

  const plate = (service?.mobile_plate || driver?.plate || '').trim().toUpperCase();
  const cleanModel = rawModel
    ? rawYear && !rawModel.includes(rawYear)
      ? `${rawModel} ${rawYear}`
      : rawModel
    : rawYear;
  const modelLine = [brandDisplay, cleanModel].filter(Boolean).join(' ').trim();

  // Seleccionar el render 3D real de estudio correspondiente a la marca y modelo registrados
  let image3dUrl = VEHICLE_3D_STUDIO_IMAGES.chevrolet_sedan;
  let usesYellowTaxiBase = false;

  if (vType !== 'carro') {
    image3dUrl =
      service?.service_type === 'mensajeria'
        ? VEHICLE_3D_STUDIO_IMAGES.mensajeria
        : VEHICLE_3D_STUDIO_IMAGES.moto;
  } else if (bodyStyle === 'pickup') {
    image3dUrl = VEHICLE_3D_STUDIO_IMAGES.pickup;
  } else if (bodyStyle === 'suv') {
    image3dUrl = VEHICLE_3D_STUDIO_IMAGES.suv;
  } else if (bodyStyle === 'city_hatch') {
    if (isTaxi && palette.label === 'amarillo') {
      image3dUrl = VEHICLE_3D_STUDIO_IMAGES.taxi;
      usesYellowTaxiBase = true;
    } else {
      image3dUrl = VEHICLE_3D_STUDIO_IMAGES.city_hatch;
    }
  } else if (bodyStyle === 'hatchback') {
    image3dUrl = VEHICLE_3D_STUDIO_IMAGES.hatchback;
  } else if (brandKey === 'renault') {
    image3dUrl = VEHICLE_3D_STUDIO_IMAGES.renault_sedan;
  } else if (brandKey === 'mazda' || brandKey === 'toyota' || brandKey === 'nissan' || brandKey === 'hyundai') {
    image3dUrl = VEHICLE_3D_STUDIO_IMAGES.mazda_sedan;
  } else if (brandKey === 'kia' && !/soluto|cerato/.test(combinedLower)) {
    if (isTaxi && palette.label === 'amarillo') {
      image3dUrl = VEHICLE_3D_STUDIO_IMAGES.taxi;
      usesYellowTaxiBase = true;
    } else {
      image3dUrl = VEHICLE_3D_STUDIO_IMAGES.city_hatch;
    }
  } else if (isTaxi && brandKey === 'generic' && palette.label === 'amarillo') {
    image3dUrl = VEHICLE_3D_STUDIO_IMAGES.taxi;
    usesYellowTaxiBase = true;
  } else {
    image3dUrl = VEHICLE_3D_STUDIO_IMAGES.chevrolet_sedan;
  }

  return {
    vType,
    isTaxi,
    brandKey,
    brandDisplay,
    rawModel,
    rawYear,
    bodyStyle,
    plate,
    image3dUrl,
    usesYellowTaxiBase,
    colorLabel: palette.displayName || rawColor,
    modelLine: modelLine || (vType === 'carro' ? 'Vehículo verificado' : 'Moto verificada'),
    palette,
  };
}

/**
 * Muestra el render 3D real de estudio del vehículo registrado por el conductor
 * (exclusivamente para que el pasajero identifique la marca, modelo y color del vehículo).
 */
export default function VehicleBrandIllustration({
  driver,
  service,
  className = 'w-28 h-16',
}) {
  const spec = resolveRegisteredVehicleSpec(driver, service);
  const {
    vType,
    brandKey,
    bodyStyle,
    palette,
    image3dUrl,
    usesYellowTaxiBase,
    modelLine,
  } = spec;

  const isCar = vType === 'carro';
  const tintHex =
    isCar && !usesYellowTaxiBase && palette?.label && palette.label !== 'blanco'
      ? palette.bodyFill
      : null;

  return (
    <div
      className={`relative flex items-center justify-center select-none ${className}`}
      data-testid="vehicle-brand-illustration"
      data-body-style={bodyStyle}
      data-brand-key={brandKey}
      data-color-label={palette?.label || 'blanco'}
    >
      <Vehicle3DIcon
        src={image3dUrl}
        alt={modelLine}
        flip={!isCar && bodyStyle === 'moto'}
        protectCar={isCar && !usesYellowTaxiBase}
        tintHex={tintHex}
        className="w-full h-full"
      />
    </div>
  );
}
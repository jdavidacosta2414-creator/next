import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Maximize2, Minimize2, ExternalLink, Layers, Navigation, X, Sparkles } from 'lucide-react';
import NextLogoMark from '@/components/NextLogoMark';
import { toast } from '@/components/ui/use-toast';

const STORAGE_POS_KEY = 'next_floating_bubble_pos_v1';
const STORAGE_ENABLED_KEY = 'next_floating_bubble_enabled_v1';

const STATUS_TEXT = {
  pendiente: 'Buscando conductor',
  asignado: 'Conductor asignado',
  en_camino: 'En camino a recogida',
  recogida: 'En viaje a destino',
};

export function isFloatingBubbleEnabled() {
  try {
    const raw = localStorage.getItem(STORAGE_ENABLED_KEY);
    return raw === null ? true : raw === '1';
  } catch {
    return true;
  }
}

export function setFloatingBubbleEnabled(enabled) {
  try {
    localStorage.setItem(STORAGE_ENABLED_KEY, enabled ? '1' : '0');
    window.dispatchEvent(new CustomEvent('next-floating-bubble-toggle', { detail: { enabled } }));
  } catch {}
}

export default function NextFloatingBubble({
  role = 'conductor', // 'conductor' | 'pasajero'
  isConnected = true,
  activeService = null,
  pendingCount = 0,
  onReturnToActive,
}) {
  const [enabled, setEnabled] = useState(() => isFloatingBubbleEnabled());
  const [expanded, setExpanded] = useState(false);
  const [pipActive, setPipActive] = useState(false);
  const [pos, setPos] = useState(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_POS_KEY) || 'null');
      if (saved && typeof saved.x === 'number' && typeof saved.y === 'number') {
        return saved;
      }
    } catch {}
    return { x: 14, y: 150, side: 'right' };
  });

  const dragRef = useRef({
    dragging: false,
    moved: false,
    startX: 0,
    startY: 0,
    origX: 0,
    origY: 0,
  });

  const canvasRef = useRef(null);
  const videoRef = useRef(null);
  const animRef = useRef(null);
  const stateRef = useRef({ isConnected, activeService, pendingCount, role });
  stateRef.current = { isConnected, activeService, pendingCount, role };

  useEffect(() => {
    const handler = (e) => {
      if (typeof e?.detail?.enabled === 'boolean') {
        setEnabled(e.detail.enabled);
      } else {
        setEnabled(isFloatingBubbleEnabled());
      }
    };
    window.addEventListener('next-floating-bubble-toggle', handler);
    return () => window.removeEventListener('next-floating-bubble-toggle', handler);
  }, []);

  // Dibuja el estado en vivo en el canvas para el modo flotante sobre otras apps (Picture-in-Picture)
  const renderCanvasFrame = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { isConnected: conn, activeService: svc, pendingCount: count, role: currentRole } = stateRef.current;
    const w = canvas.width;
    const h = canvas.height;

    // Fondo degradado institucional NEXT
    const bgGrad = ctx.createLinearGradient(0, 0, w, h);
    bgGrad.addColorStop(0, '#041434');
    bgGrad.addColorStop(0.55, '#082E72');
    bgGrad.addColorStop(1, '#0D4FB8');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, w, h);

    // Halo circular detrás del logo
    const glow = ctx.createRadialGradient(78, h / 2, 8, 78, h / 2, 62);
    glow.addColorStop(0, 'rgba(0, 229, 255, 0.45)');
    glow.addColorStop(1, 'rgba(0, 229, 255, 0)');
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(78, h / 2, 62, 0, Math.PI * 2);
    ctx.fill();

    // Burbuja del logo NEXT
    ctx.save();
    ctx.beginPath();
    ctx.arc(78, h / 2, 42, 0, Math.PI * 2);
    ctx.fillStyle = '#051A44';
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.strokeStyle = svc ? '#3DDC84' : conn ? '#00E5FF' : '#EF4444';
    ctx.stroke();

    // Doble chevron NEXT en el círculo
    ctx.translate(46, h / 2 - 32);
    ctx.scale(1.33, 1.33);
    const chevGrad = ctx.createLinearGradient(0, 0, 48, 48);
    chevGrad.addColorStop(0, '#00E5FF');
    chevGrad.addColorStop(1, '#1E6BFF');
    ctx.fillStyle = chevGrad;

    ctx.beginPath();
    ctx.moveTo(15, 7);
    ctx.lineTo(29, 24);
    ctx.lineTo(15, 41);
    ctx.lineTo(15, 34);
    ctx.lineTo(22, 24);
    ctx.lineTo(15, 14);
    ctx.closePath();
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(27, 7);
    ctx.lineTo(41, 24);
    ctx.lineTo(27, 41);
    ctx.lineTo(27, 34);
    ctx.lineTo(34, 24);
    ctx.lineTo(27, 14);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    // Punto indicador de estado
    ctx.beginPath();
    ctx.arc(108, h / 2 + 28, 9, 0, Math.PI * 2);
    ctx.fillStyle = svc ? '#3DDC84' : conn ? '#3DDC84' : '#EF4444';
    ctx.fill();
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = '#041434';
    ctx.stroke();

    // Textos a la derecha
    ctx.fillStyle = '#38BDF8';
    ctx.font = 'bold 18px sans-serif';
    ctx.fillText('NEXT · MODO FLOTANTE', 142, 54);

    if (svc) {
      const statusTxt = STATUS_TEXT[svc.status] || 'Servicio en curso';
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 26px sans-serif';
      ctx.fillText(statusTxt, 142, 92);

      const addr = (svc.status === 'recogida' ? svc.destination_address : svc.pickup_address) || '';
      ctx.fillStyle = '#BAE6FD';
      ctx.font = '600 18px sans-serif';
      ctx.fillText(addr.length > 26 ? addr.slice(0, 26) + '…' : addr, 142, 124);

      const fareTxt = '$' + Number(svc.fare || 0).toLocaleString('es-CO');
      ctx.fillStyle = '#3DDC84';
      ctx.font = 'bold 22px sans-serif';
      ctx.fillText(`${fareTxt} · Toca para volver a NEXT`, 142, 158);
    } else {
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 26px sans-serif';
      const mainLine =
        currentRole === 'conductor'
          ? conn
            ? count > 0
              ? `¡${count} solicitud${count > 1 ? 'es' : ''} disponible${count > 1 ? 's' : ''}!`
              : 'Conectado · Radar activo'
            : 'Conductor desconectado'
          : 'NEXT listo para tu viaje';
      ctx.fillText(mainLine, 142, 95);

      ctx.fillStyle = '#BAE6FD';
      ctx.font = '600 18px sans-serif';
      ctx.fillText('Toca la ventana flotante para abrir NEXT', 142, 132);
    }
  }, []);

  // Activar ventana flotante sobre otras aplicaciones (Picture-in-Picture)
  const toggleSystemFloatingWindow = async () => {
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
        setPipActive(false);
        return;
      }

      const canvas = canvasRef.current;
      const video = videoRef.current;
      if (!canvas || !video) return;

      renderCanvasFrame();

      if (typeof canvas.captureStream !== 'function' || !document.pictureInPictureEnabled) {
        toast({
          title: 'Burbuja flotante NEXT activa en pantalla',
          description: 'Puedes mover la burbuja con el logo NEXT a cualquier lado de la pantalla.',
        });
        setExpanded(false);
        return;
      }

      if (!video.srcObject) {
        const stream = canvas.captureStream(10);
        video.srcObject = stream;
      }

      await video.play();
      try {
        video.autoPictureInPicture = true;
      } catch {}

      await video.requestPictureInPicture();
      setPipActive(true);
      setExpanded(false);

      if (animRef.current) clearInterval(animRef.current);
      animRef.current = setInterval(renderCanvasFrame, 1000);

      toast({
        title: 'Burbuja flotante activada sobre otras apps',
        description: 'Ahora puedes salir a Waze, WhatsApp o inicio y NEXT quedará flotando para volver con un toque.',
      });
    } catch (err) {
      toast({
        title: 'Burbuja flotante NEXT lista',
        description: 'Arrastra la burbuja con el logo NEXT a cualquier borde y tócala para volver rápido.',
      });
      setExpanded(false);
    }
  };

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const onLeave = () => {
      setPipActive(false);
      if (animRef.current) {
        clearInterval(animRef.current);
        animRef.current = null;
      }
    };
    const onEnter = () => {
      setPipActive(true);
      renderCanvasFrame();
    };
    video.addEventListener('leavepictureinpicture', onLeave);
    video.addEventListener('enterpictureinpicture', onEnter);
    return () => {
      video.removeEventListener('leavepictureinpicture', onLeave);
      video.removeEventListener('enterpictureinpicture', onEnter);
      if (animRef.current) clearInterval(animRef.current);
    };
  }, [renderCanvasFrame]);

  useEffect(() => {
    if (pipActive) {
      renderCanvasFrame();
    }
  }, [pipActive, isConnected, activeService, pendingCount, renderCanvasFrame]);

  // Manejo de arrastre táctil / mouse estilo burbuja de Messenger
  const handlePointerDown = (e) => {
    e.stopPropagation();
    const clientX = e.clientX ?? e.touches?.[0]?.clientX ?? 0;
    const clientY = e.clientY ?? e.touches?.[0]?.clientY ?? 0;
    dragRef.current = {
      dragging: true,
      moved: false,
      startX: clientX,
      startY: clientY,
      origX: pos.x,
      origY: pos.y,
    };
    try {
      e.currentTarget.setPointerCapture?.(e.pointerId);
    } catch {}
  };

  const handlePointerMove = (e) => {
    if (!dragRef.current.dragging) return;
    const clientX = e.clientX ?? e.touches?.[0]?.clientX ?? 0;
    const clientY = e.clientY ?? e.touches?.[0]?.clientY ?? 0;
    const dx = clientX - dragRef.current.startX;
    const dy = clientY - dragRef.current.startY;
    if (Math.abs(dx) > 6 || Math.abs(dy) > 6) {
      dragRef.current.moved = true;
    }

    const vw = window.innerWidth || 390;
    const vh = window.innerHeight || 800;
    const nextY = Math.max(72, Math.min(vh - 130, dragRef.current.origY + dy));

    // Posición horizontal libre durante el arrastre
    const currentLeft =
      pos.side === 'right' ? vw - 62 - dragRef.current.origX + dx : dragRef.current.origX + dx;
    const clampedLeft = Math.max(8, Math.min(vw - 64, currentLeft));
    const side = clampedLeft + 28 > vw / 2 ? 'right' : 'left';
    const edgeOffset = side === 'right' ? Math.max(10, vw - 64 - clampedLeft) : Math.max(10, clampedLeft);

    setPos({ x: edgeOffset, y: nextY, side });
  };

  const handlePointerUp = () => {
    if (!dragRef.current.dragging) return;
    const wasMoved = dragRef.current.moved;
    dragRef.current.dragging = false;

    // Imán suave al borde más cercano como Messenger / Telegram
    setPos((prev) => {
      const snapped = { ...prev, x: 12 };
      try {
        localStorage.setItem(STORAGE_POS_KEY, JSON.stringify(snapped));
      } catch {}
      return snapped;
    });

    if (!wasMoved) {
      if (onReturnToActive) {
        onReturnToActive();
      }
      setExpanded((v) => !v);
    }
  };

  if (!enabled) return null;

  const badgeCount = activeService ? 1 : pendingCount;
  const vw = typeof window !== 'undefined' ? window.innerWidth : 390;
  const containerOffset = vw > 480 ? Math.max(0, Math.round((vw - 448) / 2)) : 0;
  const bubbleStyle =
    pos.side === 'right'
      ? { right: `${pos.x + containerOffset}px`, top: `${pos.y}px` }
      : { left: `${pos.x + containerOffset}px`, top: `${pos.y}px` };

  return (
    <>
      {/* Canvas y video ocultos para proyectar la burbuja flotante sobre otras apps (PiP) */}
      <canvas ref={canvasRef} width={520} height={200} className="hidden" />
      <video ref={videoRef} muted playsInline className="hidden" />

      {/* Burbuja flotante arrastrable con el logo NEXT */}
      <div
        style={bubbleStyle}
        className="fixed z-[1900] select-none touch-none"
        data-testid="next-floating-bubble-container"
      >
        <button
          type="button"
          data-testid="next-floating-bubble"
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          aria-label="Burbuja flotante NEXT"
          className="relative w-14 h-14 rounded-full bg-gradient-to-br from-[#04163B] via-[#082E72] to-[#0E56B8] border-2 border-[#00E5FF] shadow-[0_8px_28px_rgba(0,184,255,0.55)] flex items-center justify-center active:scale-95 transition-transform"
        >
          {/* Halo pulsante cuando hay viaje o conexión */}
          {(activeService || isConnected) && (
            <span className="absolute inset-0 rounded-full border-2 border-[#00E5FF]/60 animate-ping pointer-events-none" />
          )}

          <NextLogoMark size={32} />

          {/* Punto de estado en vivo */}
          <span
            className={`absolute bottom-0.5 right-0.5 w-3.5 h-3.5 rounded-full border-2 border-[#04163B] ${
              activeService
                ? 'bg-[#3DDC84] shadow-[0_0_8px_#3DDC84]'
                : isConnected
                ? 'bg-[#3DDC84]'
                : 'bg-red-500'
            }`}
          />

          {/* Contador de servicio activo o solicitudes */}
          {badgeCount > 0 && (
            <span className="absolute -top-1 -left-1 min-w-[20px] h-5 px-1.5 rounded-full bg-[#3DDC84] text-[#04163B] text-[10px] font-black flex items-center justify-center shadow-md border border-white">
              {activeService ? 'EN CURSO' : badgeCount}
            </span>
          )}
        </button>

        {/* Mini tarjeta desplegable al tocar la burbuja */}
        {expanded && (
          <div
            className={`mt-2 w-72 rounded-2xl bg-[#051A44]/95 backdrop-blur-md border border-[#00E5FF]/40 p-3.5 text-white shadow-2xl space-y-2.5 animate-in fade-in zoom-in-95 ${
              pos.side === 'right' ? ' right-0 absolute' : 'left-0 absolute'
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-8 h-8 rounded-full bg-white/10 border border-[#00E5FF]/40 flex items-center justify-center flex-shrink-0">
                  <NextLogoMark size={20} />
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-extrabold tracking-wide text-white truncate">
                    Burbuja flotante NEXT
                  </p>
                  <p className="text-[10px] text-sky-300 font-semibold truncate">
                    {pipActive ? 'Flotando sobre otras apps' : 'Arrástrala a cualquier lado'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setExpanded(false)}
                className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center text-white/70 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            {activeService ? (
              <div className="rounded-xl bg-white/10 border border-white/15 p-2.5 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-extrabold uppercase tracking-wider text-[#3DDC84]">
                    {STATUS_TEXT[activeService.status] || 'Servicio activo'}
                  </span>
                  <span className="text-xs font-black text-white">
                    ${Number(activeService.fare || 0).toLocaleString('es-CO')}
                  </span>
                </div>
                <p className="text-[11px] text-sky-100 truncate">
                  {activeService.status === 'recogida'
                    ? activeService.destination_address
                    : activeService.pickup_address}
                </p>
                {onReturnToActive && (
                  <button
                    type="button"
                    onClick={() => {
                      onReturnToActive();
                      setExpanded(false);
                    }}
                    className="w-full mt-1.5 h-8 rounded-lg bg-[#3DDC84] text-[#04163B] font-extrabold text-xs flex items-center justify-center gap-1.5 shadow"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    Ir al servicio ahora
                  </button>
                )}
              </div>
            ) : (
              <p className="text-[11px] text-sky-100/90 leading-relaxed">
                Mantén el logo de <strong className="text-white">NEXT</strong> flotando encima de Waze, Maps o WhatsApp para regresar con un solo toque donde dejaste la app.
              </p>
            )}

            <button
              type="button"
              data-testid="activate-pip-floating-btn"
              onClick={toggleSystemFloatingWindow}
              className="w-full h-9 rounded-xl bg-gradient-to-r from-[#00B8FF] to-[#1E6BFF] text-white font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-transform"
            >
              {pipActive ? (
                <>
                  <Minimize2 className="w-3.5 h-3.5" />
                  Desactivar ventana sobre otras apps
                </>
              ) : (
                <>
                  <Layers className="w-3.5 h-3.5" />
                  Flotar sobre otras apps (Waze / WhatsApp)
                </>
              )}
            </button>
          </div>
        )}
      </div>
    </>
  );
}
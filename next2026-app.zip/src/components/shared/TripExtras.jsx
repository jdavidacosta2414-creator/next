import React from 'react';
import { Users, Briefcase, Battery, PawPrint, MessageSquare } from 'lucide-react';

// Muestra al conductor los detalles que pidió el pasajero: número de personas,
// equipaje (maleta), carga para celular, mascota y nota. Solo aparecen los
// campos que aplican al tipo de servicio.
export default function TripExtras({ service, variant = 'light' }) {
  if (!service) return null;
  const isMensajeria = service.service_type === 'mensajeria';
  const items = [];
  if (!isMensajeria) {
    const n = Number(service.passenger_count) || 1;
    if (n > 1) items.push({ icon: Users, label: `${n} personas` });
    if (service.need_extra_space) items.push({ icon: Briefcase, label: 'Lleva equipaje' });
    if (service.need_charger) items.push({ icon: Battery, label: 'Necesita carga' });
    if (service.with_pet) items.push({ icon: PawPrint, label: 'Viaja con mascota' });
  }
  if (service.driver_comment) items.push({ icon: MessageSquare, label: service.driver_comment });
  if (items.length === 0) return null;

  const chipCls = variant === 'dark'
    ? 'bg-white/5 border border-white/8 text-white'
    : 'bg-muted border border-border text-foreground';
  const iconCls = variant === 'dark' ? 'text-[#00E5FF]' : 'text-[#1E6BFF]';

  return (
    <div className="flex flex-wrap gap-2">
      {items.map((it, i) => (
        <span key={i} className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${chipCls}`}>
          <it.icon className={`w-3.5 h-3.5 ${iconCls}`} /> {it.label}
        </span>
      ))}
    </div>
  );
}
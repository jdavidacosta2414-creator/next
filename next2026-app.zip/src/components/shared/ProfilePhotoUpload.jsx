import React, { useState, useEffect } from 'react';
import { Camera, Image as ImageIcon, Loader2, X, User } from 'lucide-react';
import { getCachedSignedUrl, resolveStorageUrl, seedStorageUrlCache } from '@/components/shared/ResolvedAvatar';
import { uploadRegistrationPhoto } from '@/lib/image';
import InAppCameraModal from '@/components/shared/InAppCameraModal';
import { checkDocument } from '@/lib/checkDocument';

// Subida de foto de perfil con Cámara integrada en la app y selector directo de Galería (sin capture en <input>)
// para evitar pantallas blancas o bloqueos en navegador móvil y APK.
export default function ProfilePhotoUpload({ value, onChange }) {
  const [loading, setLoading] = useState(false);
  const [cameraOpen, setCameraOpen] = useState(false);
  const [preview, setPreview] = useState(() => getCachedSignedUrl(value) || '');
  const [error, setError] = useState(null);

  useEffect(() => {
    let active = true;
    if (!value) {
      setPreview('');
      return;
    }
    const cached = getCachedSignedUrl(value);
    if (cached) {
      setPreview(cached);
      if (!cached.startsWith('blob:')) return;
    }
    resolveStorageUrl(value)
      .then((signedUrl) => {
        if (active && signedUrl) setPreview(signedUrl);
      })
      .catch(() => {
        if (active) setError('No se pudo cargar la imagen.');
      });
    return () => {
      active = false;
    };
  }, [value]);

  const markPickerOpen = () => {
    if (typeof window !== 'undefined') {
      window.__nextFilePickerOpenUntil = Date.now() + 60000;
    }
  };

  const processFile = async (file) => {
    if (!file) return;
    setLoading(true);
    setError(null);
    try {
      const { file_uri, previewUrl } = await uploadRegistrationPhoto(file, 1024, 0.78);
      const check = await checkDocument({ kind: 'perfil', file_uri });
      if (!check.ok) {
        setError(check.message || 'La foto de perfil debe ser tu rostro real.');
        setPreview(getCachedSignedUrl(value) || '');
        return;
      }
      if (previewUrl) setPreview(previewUrl);
      seedStorageUrlCache(file_uri, previewUrl);
      resolveStorageUrl(file_uri).catch(() => {});
      onChange(file_uri);
    } catch {
      setError('No se pudo subir la foto. Intenta de nuevo.');
      setPreview(getCachedSignedUrl(value) || '');
    } finally {
      setLoading(false);
    }
  };

  const handleGalleryInput = (e) => {
    const file = e.target.files?.[0];
    if (e.target) e.target.value = '';
    if (file) processFile(file);
  };

  return (
    <div className="relative flex flex-col items-center w-full" data-photo-picker="true">
      <InAppCameraModal
        open={cameraOpen}
        facing="user"
        title="Foto de perfil"
        onClose={() => setCameraOpen(false)}
        onCaptureFile={processFile}
      />

      <div className="relative mb-4">
        <div className="relative overflow-hidden w-28 h-28 rounded-full bg-gray-100 dark:bg-white/5 border-2 border-gray-200 dark:border-white/10 flex items-center justify-center cursor-pointer">
          {preview ? (
            <img
              src={preview}
              alt="perfil"
              loading="eager"
              decoding="sync"
              className="w-full h-full object-cover"
            />
          ) : loading ? (
            <Loader2 className="w-8 h-8 animate-spin text-[#1E6BFF]" />
          ) : (
            <User className="w-12 h-12 text-gray-300 dark:text-[#5A6478]" />
          )}
          <input
            type="file"
            accept="image/*"
            onChange={handleGalleryInput}
            onClick={markPickerOpen}
            disabled={loading}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
          />
        </div>
        {preview ? (
          <button
            type="button"
            onClick={() => {
              setPreview('');
              onChange('');
            }}
            className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-red-500 text-white flex items-center justify-center shadow-md z-20"
          >
            <X className="w-4 h-4" />
          </button>
        ) : (
          <button
            type="button"
            disabled={loading}
            onClick={() => setCameraOpen(true)}
            className="absolute -bottom-1 -right-1 w-9 h-9 rounded-full bg-[#1E6BFF] text-white flex items-center justify-center shadow-md cursor-pointer z-20 disabled:opacity-50"
          >
            <Camera className="w-4 h-4" />
          </button>
        )}
      </div>

      <div className="flex items-center justify-center gap-2.5 w-full max-w-xs">
        <button
          type="button"
          disabled={loading}
          onClick={() => setCameraOpen(true)}
          className="flex-1 flex items-center justify-center gap-1.5 px-3 h-10 rounded-xl border-2 border-[#00E5FF]/50 bg-[#00E5FF]/10 text-[#1E6BFF] dark:text-[#00E5FF] font-semibold text-xs cursor-pointer active:scale-95 transition-transform disabled:opacity-50"
        >
          <Camera className="w-4 h-4 flex-shrink-0" />
          <span>Tomar foto</span>
        </button>

        <div
          className={`relative overflow-hidden flex-1 flex items-center justify-center gap-1.5 px-3 h-10 rounded-xl border-2 border-[#1E6BFF]/50 bg-[#1E6BFF]/10 text-[#1E6BFF] dark:text-[#00E5FF] font-semibold text-xs cursor-pointer active:scale-95 transition-transform ${
            loading ? 'opacity-50 pointer-events-none' : ''
          }`}
        >
          <ImageIcon className="w-4 h-4 flex-shrink-0" />
          <span>Galería</span>
          <input
            type="file"
            accept="image/*"
            onChange={handleGalleryInput}
            onClick={markPickerOpen}
            disabled={loading}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
          />
        </div>
      </div>
      {error && <p className="text-xs text-red-500 mt-2">{error}</p>}
    </div>
  );
}
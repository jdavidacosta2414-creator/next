import React, { useState } from 'react';
import { Calendar as CalendarIcon, X } from 'lucide-react';
import { Calendar } from '@/components/ui/calendar';
import { Button } from '@/components/ui/button';
import { es } from 'date-fns/locale';
import { format } from 'date-fns';

export default function DateRangePicker({ range, onChange }) {
  const [open, setOpen] = useState(false);
  const [tempRange, setTempRange] = useState(range);

  const fmt = (d) => d ? format(d, 'd MMM', { locale: es }) : '';
  const label = range?.from ? `${fmt(range.from)} - ${range.to ? fmt(range.to) : fmt(range.from)}` : 'Seleccionar fecha';

  const confirm = () => {
    onChange(tempRange);
    setOpen(false);
  };

  return (
    <>
      <button onClick={() => { setTempRange(range); setOpen(true); }} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
        <CalendarIcon className="w-4 h-4" />
        {label}
      </button>
      {open && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50" onClick={() => setOpen(false)}>
          <div className="bg-card rounded-t-2xl sm:rounded-2xl p-4 w-full max-w-sm max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-foreground">Seleccionar rango</h3>
              <button onClick={() => setOpen(false)}><X className="w-5 h-5 text-muted-foreground" /></button>
            </div>
            <Calendar
              mode="range"
              selected={tempRange}
              onSelect={setTempRange}
              locale={es}
              numberOfMonths={1}
              className="mx-auto"
            />
            <div className="flex gap-2 mt-3">
              <Button variant="outline" className="flex-1 h-10" onClick={() => setOpen(false)}>Cancelar</Button>
              <Button className="flex-1 h-10" disabled={!tempRange?.from} onClick={confirm}>Confirmar</Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
import React from 'react';

/**
 * Construye un enlace directo a la app nativa de WhatsApp (`whatsapp://send?...`)
 * para que en Android / iOS / APK abra WhatsApp automáticamente sin pasar por el navegador
 * ni mostrar el aviso "Open External Link? Do you want to open wa.me in your browser?".
 */
export function buildWhatsAppDirectUrl({ phone = '', text = '' } = {}) {
  const digits = String(phone || '').replace(/\D/g, '');
  const normalizedPhone = digits
    ? digits.startsWith('57')
      ? digits
      : `57${digits}`
    : '';
  const params = [];
  if (normalizedPhone) {
    params.push(`phone=${encodeURIComponent(normalizedPhone)}`);
  }
  if (text) {
    params.push(`text=${encodeURIComponent(text)}`);
  }
  return `whatsapp://send${params.length ? `?${params.join('&')}` : ''}`;
}

/**
 * Abre directamente la aplicación de WhatsApp sin diálogos de navegador externo.
 */
export function openWhatsAppDirect({ phone = '', text = '' } = {}) {
  if (typeof window === 'undefined') return;
  const directUrl = buildWhatsAppDirectUrl({ phone, text });
  try {
    window.location.href = directUrl;
  } catch {}
}

// Ícono original oficial de WhatsApp (burbuja verde #25D366 con borde blanco y auricular telefónico blanco)
export function WhatsAppOriginalIcon({ className = 'w-6 h-6' }) {
  return (
    <svg
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <circle cx="24" cy="24" r="22" fill="#25D366" />
      <path
        d="M24.04 10.5C16.57 10.5 10.5 16.54 10.5 23.98C10.5 26.37 11.13 28.7 12.32 30.75L10.4 37.75L17.58 35.87C19.56 36.95 21.78 37.52 24.04 37.52C31.51 37.52 37.58 31.48 37.58 24.04C37.58 16.57 31.51 10.5 24.04 10.5Z"
        fill="#25D366"
        stroke="#FFFFFF"
        strokeWidth="2.3"
        strokeLinejoin="round"
      />
      <path
        d="M30.42 27.32C30.07 27.14 28.34 26.29 28.02 26.17C27.7 26.05 27.46 26 27.23 26.35C26.99 26.7 26.32 27.49 26.11 27.73C25.91 27.96 25.7 27.99 25.35 27.82C25 27.64 23.87 27.27 22.53 26.08C21.49 25.15 20.78 24 20.58 23.65C20.37 23.3 20.56 23.11 20.73 22.94C20.89 22.78 21.08 22.53 21.26 22.32C21.43 22.12 21.49 21.97 21.61 21.74C21.73 21.5 21.67 21.3 21.58 21.12C21.49 20.95 20.79 19.22 20.5 18.52C20.22 17.84 19.93 17.93 19.71 17.92C19.51 17.91 19.27 17.91 19.04 17.91C18.8 17.91 18.42 18 18.1 18.35C17.78 18.7 16.87 19.55 16.87 21.28C16.87 23.01 18.13 24.68 18.31 24.91C18.48 25.15 20.79 28.71 24.33 30.24C25.17 30.6 25.83 30.82 26.34 30.98C27.19 31.25 27.96 31.21 28.57 31.12C29.25 31.02 30.67 30.26 30.96 29.44C31.26 28.62 31.26 27.91 31.17 27.76C31.08 27.61 30.77 27.49 30.42 27.32Z"
        fill="#FFFFFF"
      />
    </svg>
  );
}

// Ícono original de Llamada telefónica (círculo azul con auricular blanco nítido)
export function PhoneCallOriginalIcon({ className = 'w-6 h-6' }) {
  return (
    <svg
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <circle cx="24" cy="24" r="22" fill="#1463FF" />
      <path
        d="M31.9 28.35C30.42 28.35 28.98 28.11 27.64 27.67C27.22 27.53 26.74 27.64 26.42 27.96L24.22 30.72C20.66 28.84 17.96 26.22 16.12 22.62L18.82 20.34C19.16 20 19.27 19.52 19.13 19.08C18.69 17.74 18.45 16.3 18.45 14.82C18.45 13.82 17.63 13 16.63 13H12.82C11.82 13 11 13.82 11 14.82C11 26.52 20.48 36 32.18 36C33.18 36 34 35.18 34 34.18V30.17C34 29.17 33.18 28.35 31.9 28.35Z"
        fill="#FFFFFF"
      />
    </svg>
  );
}

// Ícono original de Mensaje de chat interno (burbuja de chat azul con líneas blancas)
export function ChatMessageOriginalIcon({ className = 'w-6 h-6' }) {
  return (
    <svg
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <circle cx="24" cy="24" r="22" fill="#0B439C" />
      <path
        d="M13 17.5C13 15.01 15.01 13 17.5 13H30.5C32.99 13 35 15.01 35 17.5V26.5C35 28.99 32.99 31 30.5 31H21.2L15.4 35.2C14.6 35.78 13.5 35.21 13.5 34.22V31C13.18 30.36 13 29.65 13 28.9V17.5Z"
        fill="#FFFFFF"
      />
      <rect x="18" y="19" width="12" height="2.4" rx="1.2" fill="#1463FF" />
      <rect x="18" y="23.8" width="8.5" height="2.4" rx="1.2" fill="#1463FF" />
    </svg>
  );
}

// Ícono original de Compartir viaje en tiempo real
export function ShareTripOriginalIcon({ className = 'w-6 h-6' }) {
  return (
    <svg
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <circle cx="24" cy="24" r="22" fill="#1E6BFF" />
      <circle cx="30.5" cy="15.5" r="3.8" fill="#FFFFFF" />
      <circle cx="16.5" cy="24" r="3.8" fill="#FFFFFF" />
      <circle cx="30.5" cy="32.5" r="3.8" fill="#FFFFFF" />
      <path
        d="M19.8 22.1L27.2 17.4M19.8 25.9L27.2 30.6"
        stroke="#FFFFFF"
        strokeWidth="2.8"
        strokeLinecap="round"
      />
    </svg>
  );
}
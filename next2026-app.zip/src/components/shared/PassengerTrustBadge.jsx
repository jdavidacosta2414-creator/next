import React from 'react';
import { Star } from 'lucide-react';

// Muestra las estrellas del pasajero y cuántos viajes finalizados lleva.
export default function PassengerTrustBadge({ stats, extraText = null, dark = false }) {
  const trips = Number(stats?.trips ?? 0);
  const hasRating = stats?.rating != null && Number(stats.rating) > 0;
  const ratingNum = hasRating ? Number(stats.rating) : 5.0;
  const filledStars = Math.max(1, Math.min(5, Math.round(ratingNum)));

  const tripsFormatted = trips.toLocaleString('es-CO');
  const tripsLabel = `${tripsFormatted} ${trips === 1 ? 'viaje' : 'viajes'}`;

  return (
    <div className="flex items-center gap-1.5 flex-wrap text-xs">
      {/* Estrellitas visuales (1 a 5) */}
      <span className="inline-flex items-center gap-0.5" title={`${ratingNum.toFixed(1)} estrellas`}>
        {[1, 2, 3, 4, 5].map((n) => (
          <Star
            key={n}
            className={`w-3.5 h-3.5 ${
              n <= filledStars
                ? 'text-amber-400 fill-amber-400'
                : dark
                  ? 'text-white/25'
                  : 'text-muted-foreground/35'
            }`}
          />
        ))}
      </span>

      <span className={`font-extrabold ${dark ? 'text-white' : 'text-foreground'}`}>
        {ratingNum.toFixed(1)}
      </span>

      <span className={dark ? 'text-white/40' : 'text-muted-foreground'}>·</span>

      <span
        className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-bold ${
          trips > 0
            ? 'bg-[#1E6BFF]/12 text-[#1E6BFF] dark:text-sky-300'
            : dark
              ? 'bg-white/10 text-[#8B95A8]'
              : 'bg-muted text-muted-foreground'
        }`}
      >
        {tripsLabel}
      </span>

      {extraText && (
        <>
          <span className={dark ? 'text-white/40' : 'text-muted-foreground'}>·</span>
          <span className={dark ? 'text-[#8B95A8]' : 'text-muted-foreground'}>{extraText}</span>
        </>
      )}
    </div>
  );
}
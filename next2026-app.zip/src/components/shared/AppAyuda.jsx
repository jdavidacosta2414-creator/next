import React, { useState } from 'react';
import { ChevronLeft, HelpCircle, ChevronDown, PackageSearch, MessageSquare, ShieldCheck } from 'lucide-react';

// Preguntas del pasajero. En modo conductor se muestran las de '@/lib/driverFaqs'.
const FAQS = [
  {
    q: '¿Cómo solicito un viaje o servicio de mensajería?',
    a: 'Selecciona el tipo de vehículo (Moto, Carro o Mensajería), toca "¿A dónde y por cuánto?", ingresa tu punto de recogida y destino, ajusta tu tarifa si lo deseas y pulsa "Buscar conductor".',
  },
  {
    q: '¿Cuáles son las tarifas mínimas?',
    a: 'La tarifa mínima sugerida es de $5.000 COP para servicios en moto o mensajería, y $8.000 COP para viajes en carro.',
  },
  {
    q: '¿Qué métodos de pago puedo usar?',
    a: 'Puedes pagar directamente al conductor en efectivo o mediante transferencia (Nequi, DaviPlata, Bancolombia o Paga con llave).',
  },
  {
    q: '¿Cómo funcionan los Puntos y Recompensas?',
    a: 'Ganas puntos al interactuar con las ofertas promocionales aliadas y al completar tus metas semanales de viajes para canjear premios o viajes gratis.',
  },
  {
    q: '¿Qué hago si olvidé un objeto en el vehículo?',
    a: 'Puedes reportar un objeto perdido desde esta sección o comunicarte directamente con nuestro equipo de Soporte por WhatsApp.',
  },
];

export default function AppAyuda({ onBack, onOpenSoporte, onOpenObjetos, onOpenSeguridad, faqs = FAQS }) {
  const [openIdx, setOpenIdx] = useState(0);

  return (
    <div className="fixed inset-0 z-[1800] bg-background flex flex-col max-w-md mx-auto w-full pb-[56px]">
      <div className="flex items-center gap-3 px-4 pt-5 pb-3 border-b border-border bg-card flex-shrink-0">
        <button onClick={onBack} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-muted">
          <ChevronLeft className="w-6 h-6 text-foreground" />
        </button>
        <h1 className="text-foreground font-bold text-lg">Centro de ayuda</h1>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar px-4 py-5 space-y-4">
        <div className="flex items-center gap-3 bg-card rounded-2xl p-4 shadow-sm border border-border">
          <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center flex-shrink-0">
            <HelpCircle className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h2 className="text-foreground font-bold text-base">¿En qué podemos ayudarte?</h2>
            <p className="text-muted-foreground text-xs">Resuelve tus dudas frecuentes o comunícate con nosotros.</p>
          </div>
        </div>

        {/* Accesos rápidos */}
        <div className="grid grid-cols-2 gap-3">
          {onOpenObjetos && (
            <button
              type="button"
              onClick={onOpenObjetos}
              className="bg-card rounded-2xl p-4 text-left shadow-sm border border-border hover:bg-muted/40 transition-colors"
            >
              <div className="w-10 h-10 rounded-xl bg-amber-500/15 flex items-center justify-center mb-2">
                <PackageSearch className="w-5 h-5 text-amber-600 dark:text-amber-400" />
              </div>
              <p className="text-foreground font-bold text-sm">Objetos perdidos</p>
              <p className="text-muted-foreground text-xs">Reportar un olvido</p>
            </button>
          )}
          {onOpenSeguridad && (
            <button
              type="button"
              onClick={onOpenSeguridad}
              className="bg-card rounded-2xl p-4 text-left shadow-sm border border-border hover:bg-muted/40 transition-colors"
            >
              <div className="w-10 h-10 rounded-xl bg-emerald-500/15 flex items-center justify-center mb-2">
                <ShieldCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              </div>
              <p className="text-foreground font-bold text-sm">Seguridad</p>
              <p className="text-muted-foreground text-xs">Emergencias y apoyo</p>
            </button>
          )}
        </div>

        {/* Preguntas frecuentes */}
        <div className="bg-card rounded-2xl shadow-sm border border-border overflow-hidden">
          <div className="px-4 py-3 border-b border-border">
            <h3 className="text-foreground font-bold text-sm">Preguntas frecuentes</h3>
          </div>
          <div className="divide-y divide-border">
            {faqs.map((item, idx) => {
              const isOpen = openIdx === idx;
              return (
                <div key={item.q}>
                  <button
                    type="button"
                    onClick={() => setOpenIdx(isOpen ? -1 : idx)}
                    className="w-full flex items-center justify-between gap-3 px-4 py-3.5 text-left hover:bg-muted/40"
                  >
                    <span className="text-foreground font-semibold text-sm">{item.q}</span>
                    <ChevronDown
                      className={`w-4 h-4 text-muted-foreground flex-shrink-0 transition-transform ${
                        isOpen ? 'rotate-180' : ''
                      }`}
                    />
                  </button>
                  {isOpen && (
                    <div className="px-4 pb-3.5 text-muted-foreground text-xs leading-relaxed">
                      {item.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {onOpenSoporte && (
          <button
            type="button"
            onClick={onOpenSoporte}
            className="w-full h-12 rounded-2xl bg-primary text-primary-foreground font-bold text-sm flex items-center justify-center gap-2 shadow-sm"
          >
            <MessageSquare className="w-5 h-5" /> Ir a Soporte directo
          </button>
        )}
      </div>
    </div>
  );
}
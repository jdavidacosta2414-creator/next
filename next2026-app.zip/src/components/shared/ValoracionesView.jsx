import React, { useEffect, useState, useCallback } from 'react';
import { ChevronLeft, Loader2, Star, MessageSquareText } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import ValoracionItem from '@/components/shared/ValoracionItem';

const PAGE = 30;

// Sección "Valoración y comentario".
// role 'conductor': ve lo que los pasajeros le calificaron (rating / rating_comment).
// role 'pasajero': ve lo que los conductores le calificaron (driver_rating / driver_rating_comment).
export default function ValoracionesView({ role, mobile, user, onBack }) {
  const isDriver = role === 'conductor';
  const starField = isDriver ? 'rating' : 'driver_rating';
  const commentField = isDriver ? 'rating_comment' : 'driver_rating_comment';

  const ownerQuery = isDriver
    ? { mobile_id: mobile?.id }
    : user?.phone
    ? { $or: [{ created_by_id: user?.id }, { client_phone: user.phone }] }
    : { created_by_id: user?.id };
  const query = { ...ownerQuery, [starField]: { $gt: 0 } };
  const queryKey = JSON.stringify(query);

  const [items, setItems] = useState([]);
  const [cursor, setCursor] = useState(null);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [summary, setSummary] = useState({ avg: 0, count: 0 });

  const loadPage = useCallback(async (nextCursor) => {
    const page = await base44.entities.Service.filter(JSON.parse(queryKey), {
      sort: '-updated_date',
      limit: PAGE,
      ...(nextCursor ? { cursor: nextCursor } : {}),
    });
    setItems((prev) => (nextCursor ? [...prev, ...page.items] : page.items));
    setCursor(page.next_cursor);
    setHasMore(page.has_more);
  }, [queryKey]);

  useEffect(() => {
    if (isDriver ? !mobile?.id : !user?.id) return;
    setLoading(true);
    Promise.all([
      loadPage(null),
      base44.entities.Service.aggregate({ query: JSON.parse(queryKey), groupBy: 'service_type', avg: [starField] }),
    ])
      .then(([, agg]) => {
        const rows = agg?.rows || [];
        const count = rows.reduce((a, r) => a + (r.count || 0), 0);
        const total = rows.reduce((a, r) => a + (r[`avg_${starField}`] || 0) * (r.count || 0), 0);
        setSummary({ avg: count ? total / count : 0, count });
      })
      .finally(() => setLoading(false));
  }, [loadPage, queryKey, starField, isDriver, mobile?.id, user?.id]);

  const loadMore = async () => {
    setLoadingMore(true);
    await loadPage(cursor).finally(() => setLoadingMore(false));
  };

  return (
    <div className="fixed inset-0 z-[1800] bg-background flex flex-col max-w-md mx-auto w-full overflow-y-auto pb-[56px]">
      <div className="flex items-center gap-3 px-4 pt-5 pb-3 flex-shrink-0">
        <button onClick={onBack} className="w-10 h-10 flex items-center justify-center">
          <ChevronLeft className="w-6 h-6 text-foreground" />
        </button>
        <h1 className="text-foreground font-bold text-lg">Valoración y comentario</h1>
      </div>

      <div className="flex-1 px-5 pb-8">
        <div className="bg-card border border-border rounded-2xl p-5 shadow-sm mb-5 text-center">
          <p className="text-muted-foreground text-xs font-semibold uppercase tracking-wider">
            {isDriver ? 'Calificación de tus pasajeros' : 'Calificación de tus conductores'}
          </p>
          <div className="flex items-center justify-center gap-2 mt-2">
            <Star className="w-7 h-7 fill-amber-400 text-amber-400" />
            <span className="text-3xl font-extrabold text-foreground">
              {summary.count ? summary.avg.toFixed(1).replace('.', ',') : '—'}
            </span>
          </div>
          <p className="text-muted-foreground text-xs mt-1">
            {summary.count} {summary.count === 1 ? 'valoración' : 'valoraciones'}
          </p>
        </div>

        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-7 h-7 animate-spin text-primary" />
          </div>
        ) : items.length === 0 ? (
          <div className="text-center py-12">
            <MessageSquareText className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-foreground font-bold">Aún no tienes valoraciones</p>
            <p className="text-muted-foreground text-sm mt-1">
              {isDriver
                ? 'Cuando un pasajero te califique, verás aquí sus estrellas y comentarios.'
                : 'Cuando un conductor te califique, verás aquí sus estrellas y comentarios.'}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {items.map((s) => (
              <ValoracionItem
                key={s.id}
                name={isDriver ? s.client_name : s.mobile_name}
                photo={isDriver ? s.client_photo : s.mobile_photo}
                stars={s[starField]}
                comment={s[commentField]}
                date={s.updated_date}
              />
            ))}
            {hasMore && (
              <button
                onClick={loadMore}
                disabled={loadingMore}
                className="w-full h-11 rounded-2xl bg-muted text-foreground font-bold text-sm flex items-center justify-center"
              >
                {loadingMore ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Ver más'}
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
import { WifiOff } from 'lucide-react';

// Overlay de error de teselas: se muestra cuando el mapa no puede cargar
// los tiles (token inválido, red caída). Se posiciona sobre el mapa sin
// bloquear la interacción una vez que el mapa recupera la carga.
export default function MapTileError({ dark = false }) {
  return (
    <div
      className="absolute inset-0 z-[500] flex flex-col items-center justify-center pointer-events-none"
      style={{ background: dark ? 'rgba(11,15,26,0.92)' : 'rgba(232,234,237,0.92)' }}
    >
      <WifiOff className="w-7 h-7 mb-1.5" style={{ color: dark ? '#00E5FF' : '#1E6BFF' }} />
      <p className="text-xs" style={{ color: dark ? '#8B95A8' : '#5A6478' }}>
        No se pudo cargar el mapa
      </p>
    </div>
  );
}
import React, { useEffect, useState } from 'react';

const CACHE_VERSION = 'v10';
const processedCache = new Map();
const pendingPromises = new Map();

function hexToRgb(hex) {
  const clean = String(hex || '').replace('#', '').trim();
  if (clean.length !== 6) return null;
  const num = parseInt(clean, 16);
  if (Number.isNaN(num)) return null;
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255,
  };
}

/**
 * Remueve el fondo blanco exterior de los renders 3D de estudio protegiendo
 * la carrocería blanca del vehículo, y aplica opcionalmente pintura 3D
 * metalizada en el color registrado por el conductor.
 */
function processVehicleImage(src, protectCarHood = false, tintHex = null) {
  const cleanTint = tintHex ? String(tintHex).toUpperCase() : 'NONE';
  const cacheKey = `${CACHE_VERSION}:${protectCarHood ? 'car' : 'std'}:${cleanTint}:${src}`;
  if (processedCache.has(cacheKey)) {
    return Promise.resolve(processedCache.get(cacheKey));
  }
  if (pendingPromises.has(cacheKey)) {
    return pendingPromises.get(cacheKey);
  }

  const promise = new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const size = 384;
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        ctx.drawImage(img, 0, 0, size, size);

        const imgData = ctx.getImageData(0, 0, size, size);
        const data = imgData.data;
        const total = size * size;
        const visited = new Uint8Array(total);
        const isBg = new Uint8Array(total);
        const queue = new Int32Array(total);
        let head = 0;
        let tail = 0;

        const isClassicSedan = Boolean(src && src.includes('ac3f196ed'));

        // Protege el capó y techo de carros blancos para que el flood-fill exterior no entre a la pintura
        const isInsideCarHood = (x, y) => {
          if (!protectCarHood) return false;
          if (isClassicSedan) {
            if (x < 216 || x > 330) return false;
            const hoodTopY = 155 + ((187 - 155) * (x - 216)) / (330 - 216);
            return y >= hoodTopY && y <= 193;
          }
          // Para los nuevos renders 3D de estudio sobre fondo #FFFFFF puro, proteger el núcleo central
          // cuando la luminancia baja de 252 (borde sombreado de la carrocería).
          return false;
        };

        const isCandidateBg = (idx4, x, y) => {
          if (isInsideCarHood(x, y)) return false;
          const r = data[idx4];
          const g = data[idx4 + 1];
          const b = data[idx4 + 2];
          const a = data[idx4 + 3];
          if (a < 15) return true;
          const max = Math.max(r, g, b);
          const min = Math.min(r, g, b);
          const sat = max - min;
          const lum = (r + g + b) / 3;

          if (protectCarHood && !isClassicSedan) {
            // En renders 3D de carros blancos, el fondo exterior es blanco puro (#FAFAFA - #FFFFFF)
            if (lum >= 250 && sat <= 6) return true;
            // Sombra suave de piso debajo de las llantas
            if (y > size * 0.68 && lum >= 165 && sat <= 16) return true;
            return false;
          }

          // Blanco del fondo exterior
          if (lum >= 240 && sat <= 14) return true;
          // Gris muy claro del fondo
          if (lum >= 224 && sat <= 8) return true;
          // En la zona baja (piso bajo el chasis y llantas), remover toda sombra gris/blanca del suelo
          if (y > size * 0.56 && lum >= 125 && sat <= 20) return true;
          return false;
        };

        const push = (p) => {
          if (p < 0 || p >= total || visited[p]) return;
          visited[p] = 1;
          const x = p % size;
          const y = (p - x) / size;
          if (isCandidateBg(p * 4, x, y)) {
            isBg[p] = 1;
            queue[tail++] = p;
          }
        };

        for (let x = 0; x < size; x++) {
          push(x);
          push((size - 1) * size + x);
        }
        for (let y = 0; y < size; y++) {
          push(y * size);
          push(y * size + (size - 1));
        }

        while (head < tail) {
          const p = queue[head++];
          const x = p % size;
          const y = (p - x) / size;
          if (x > 0) push(p - 1);
          if (x < size - 1) push(p + 1);
          if (y > 0) push(p - size);
          if (y < size - 1) push(p + size);
          if (y > size * 0.54) {
            if (x > 0 && y > 0) push(p - size - 1);
            if (x < size - 1 && y > 0) push(p - size + 1);
            if (x > 0 && y < size - 1) push(p + size - 1);
            if (x < size - 1 && y < size - 1) push(p + size + 1);
          }
        }

        for (let p = 0; p < total; p++) {
          if (isBg[p]) {
            data[p * 4 + 3] = 0;
          }
        }

        // Defringing: elimina cualquier filo blanco/gris claro pegado a píxeles transparentes
        const defringePasses = protectCarHood && !isClassicSedan ? 2 : 4;
        for (let pass = 0; pass < defringePasses; pass++) {
          const nextAlpha = new Uint8ClampedArray(total);
          for (let p = 0; p < total; p++) {
            nextAlpha[p] = data[p * 4 + 3];
          }

          for (let y = 1; y < size - 1; y++) {
            for (let x = 1; x < size - 1; x++) {
              if (isInsideCarHood(x, y)) continue;
              const p = y * size + x;
              const i = p * 4;
              const a = data[i + 3];
              if (a === 0) continue;

              const hasTransparentNeighbor =
                data[(p - 1) * 4 + 3] < 35 ||
                data[(p + 1) * 4 + 3] < 35 ||
                data[(p - size) * 4 + 3] < 35 ||
                data[(p + size) * 4 + 3] < 35;

              if (hasTransparentNeighbor) {
                const r = data[i];
                const g = data[i + 1];
                const b = data[i + 2];
                const lum = (r + g + b) / 3;
                const sat = Math.max(r, g, b) - Math.min(r, g, b);

                if (lum > 150 && sat < 20) {
                  if (lum >= 230) {
                    nextAlpha[p] = 0;
                  } else {
                    const factor = Math.max(0, (230 - lum) / 80);
                    nextAlpha[p] = Math.round(a * factor);
                  }
                }
              }
            }
          }

          for (let p = 0; p < total; p++) {
            data[p * 4 + 3] = nextAlpha[p];
          }
        }

        // Calcular caja delimitadora del vehículo limpio
        let minX = size, minY = size, maxX = 0, maxY = 0;
        for (let y = 0; y < size; y++) {
          for (let x = 0; x < size; x++) {
            const a = data[(y * size + x) * 4 + 3];
            if (a > 25) {
              if (x < minX) minX = x;
              if (x > maxX) maxX = x;
              if (y < minY) minY = y;
              if (y > maxY) maxY = y;
            }
          }
        }

        // Aplicar pintura 3D metalizada en el color registrado del vehículo (conservando vidrios, llantas, rines y luces)
        const targetRgb = tintHex ? hexToRgb(tintHex) : null;
        if (targetRgb && maxX > minX && maxY > minY) {
          const carW = maxX - minX + 1;
          const carH = maxY - minY + 1;
          const targetLum = (targetRgb.r + targetRgb.g + targetRgb.b) / 3;
          const isWhiteTarget = targetLum >= 235 && Math.max(targetRgb.r, targetRgb.g, targetRgb.b) - Math.min(targetRgb.r, targetRgb.g, targetRgb.b) <= 18;

          if (!isWhiteTarget) {
            for (let y = minY; y <= maxY; y++) {
              const relY = (y - minY) / carH;
              for (let x = minX; x <= maxX; x++) {
                const i = (y * size + x) * 4;
                const a = data[i + 3];
                if (a < 25) continue;

                const r = data[i];
                const g = data[i + 1];
                const b = data[i + 2];
                const max = Math.max(r, g, b);
                const min = Math.min(r, g, b);
                const sat = max - min;
                const lum = (r + g + b) / 3;

                // No teñir vidrios polarizados, llantas negras ni parrilla oscura
                if (lum < 138) continue;
                // No teñir stops rojos, direccionales ámbar ni emblemas con color propio
                if (sat > 26) continue;

                // Preservar el brillo metálico de los rines dentro de la zona baja de las ruedas
                const relX = (x - minX) / carW;
                const inWheelZone =
                  relY > 0.56 &&
                  ((relX > 0.14 && relX < 0.38) || (relX > 0.64 && relX < 0.89));
                if (inWheelZone && lum < 228) continue;

                // Curva de sombreado 3D de estudio con reflejo especular suave
                const normalized = Math.min(1, Math.max(0, (lum - 135) / 120));
                const shade = 0.35 + normalized * 0.72;
                const specular = lum > 244 ? ((lum - 244) / 11) * 0.42 : 0;

                const paintedR = Math.min(255, Math.round(targetRgb.r * shade + 255 * specular));
                const paintedG = Math.min(255, Math.round(targetRgb.g * shade + 255 * specular));
                const paintedB = Math.min(255, Math.round(targetRgb.b * shade + 255 * specular));

                const blend = lum >= 165 ? 0.92 : (lum - 138) / 27;
                data[i] = Math.round(r * (1 - blend) + paintedR * blend);
                data[i + 1] = Math.round(g * (1 - blend) + paintedG * blend);
                data[i + 2] = Math.round(b * (1 - blend) + paintedB * blend);
              }
            }
          }
        }

        ctx.putImageData(imgData, 0, 0);

        if (maxX > minX && maxY > minY) {
          const pad = 12;
          minX = Math.max(0, minX - pad);
          minY = Math.max(0, minY - pad);
          maxX = Math.min(size - 1, maxX + pad);
          maxY = Math.min(size - 1, maxY + pad);
          const cropW = maxX - minX + 1;
          const cropH = maxY - minY + 1;
          const out = document.createElement('canvas');
          out.width = cropW;
          out.height = cropH;
          out.getContext('2d').drawImage(canvas, minX, minY, cropW, cropH, 0, 0, cropW, cropH);
          const url = out.toDataURL('image/png');
          processedCache.set(cacheKey, url);
          resolve(url);
          return;
        }

        const url = canvas.toDataURL('image/png');
        processedCache.set(cacheKey, url);
        resolve(url);
      } catch {
        resolve(src);
      }
    };
    img.onerror = () => resolve(src);
    img.src = src;
  });

  pendingPromises.set(cacheKey, promise);
  return promise;
}

export default function Vehicle3DIcon({
  src,
  alt = '',
  flip = false,
  scale = 1,
  protectCar = null,
  tintHex = null,
  className = '',
}) {
  const protectCarHood =
    protectCar != null
      ? Boolean(protectCar)
      : Boolean(
          src &&
            (src.includes('ac3f196ed') ||
              src.includes('cc57b2a87') ||
              src.includes('0b031eff9') ||
              src.includes('ed8541d2e') ||
              src.includes('0114e426e') ||
              src.includes('f938c3719') ||
              src.includes('987b49dc5') ||
              src.includes('a2ac35636'))
        );
  const cleanTint = tintHex ? String(tintHex).toUpperCase() : 'NONE';
  const cacheKey = `${CACHE_VERSION}:${protectCarHood ? 'car' : 'std'}:${cleanTint}:${src}`;
  const [cleanSrc, setCleanSrc] = useState(() => processedCache.get(cacheKey) || null);

  useEffect(() => {
    let active = true;
    processVehicleImage(src, protectCarHood, tintHex).then((res) => {
      if (active) setCleanSrc(res);
    });
    return () => {
      active = false;
    };
  }, [src, protectCarHood, tintHex, cacheKey]);

  const transforms = [
    flip ? 'scaleX(-1)' : '',
    scale && scale !== 1 ? `scale(${scale})` : '',
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <div className={`relative flex items-center justify-center select-none ${className}`}>
      {cleanSrc ? (
        <img
          src={cleanSrc}
          alt={alt}
          draggable={false}
          className="relative z-10 w-full h-full object-contain drop-shadow-[0_4px_6px_rgba(0,0,0,0.4)] dark:drop-shadow-[0_6px_10px_rgba(0,0,0,0.92)] transition-transform duration-200"
          style={transforms ? { transform: transforms } : undefined}
        />
      ) : (
        <div className="w-full h-full" />
      )}
    </div>
  );
}
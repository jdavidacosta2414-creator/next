import React from 'react';
import { Bell, MessageCircle, X } from 'lucide-react';

// Contexto de audio compartido y precalentado para reproducir sonidos en 0ms sin latencia en APK/móvil
let sharedAudioCtx = null;

export function getUnlockedAudioContext() {
  if (typeof window === 'undefined') return null;
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return null;
    if (!sharedAudioCtx || sharedAudioCtx.state === 'closed') {
      sharedAudioCtx = new AudioCtx();
    }
    if (sharedAudioCtx.state === 'suspended') {
      sharedAudioCtx.resume?.().catch(() => {});
    }
    return sharedAudioCtx;
  } catch {
    return null;
  }
}

export function ensurePushNotificationPermission() {
  if (typeof window === 'undefined' || typeof Notification === 'undefined') return;
  try {
    if (Notification.permission === 'default') {
      Notification.requestPermission?.().catch(() => {});
    }
  } catch {}
}

export function showSystemPushNotification({
  title,
  body,
  tag,
  vibrate = [240, 90, 240, 90, 280],
}) {
  if (typeof window === 'undefined' || typeof Notification === 'undefined') return;
  try {
    if (Notification.permission !== 'granted') return;
    const notifTitle = title || 'Notificación NEXT';
    const options = {
      body: body || '',
      tag: tag || `next-push-${Date.now()}`,
      renotify: true,
      vibrate,
    };
    if (navigator.serviceWorker?.ready) {
      navigator.serviceWorker.ready
        .then((reg) => {
          if (reg?.showNotification) {
            return reg.showNotification(notifTitle, options);
          }
          new Notification(notifTitle, options);
        })
        .catch(() => {
          try {
            new Notification(notifTitle, options);
          } catch {}
        });
    } else {
      new Notification(notifTitle, options);
    }
  } catch {}
}

if (typeof window !== 'undefined') {
  const unlock = () => {
    ensurePushNotificationPermission();
    const ctx = getUnlockedAudioContext();
    if (ctx && ctx.state === 'running') {
      window.removeEventListener('touchstart', unlock, true);
      window.removeEventListener('click', unlock, true);
    }
  };
  window.addEventListener('touchstart', unlock, { capture: true, passive: true });
  window.addEventListener('click', unlock, { capture: true, passive: true });
}

// Timbre sonoro + vibración + notificación push del sistema cuando llega un nuevo mensaje entre conductor y pasajero
export function playMessageChime(senderLabel = '', messagePreview = '') {
  try {
    const ctx = getUnlockedAudioContext();
    if (ctx) {
      const now = ctx.currentTime;
      const tones = [
        { freq: 880, start: 0, dur: 0.14, peak: 0.38 },
        { freq: 1174.66, start: 0.14, dur: 0.22, peak: 0.42 },
        { freq: 1318.51, start: 0.30, dur: 0.28, peak: 0.36 },
      ];
      tones.forEach(({ freq, start, dur, peak }) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + start);
        gain.gain.setValueAtTime(0.001, now + start);
        gain.gain.exponentialRampToValueAtTime(peak, now + start + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, now + start + dur);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + start);
        osc.stop(now + start + dur + 0.02);
      });
    }
  } catch {}
  try {
    navigator.vibrate?.([240, 80, 260, 80, 240]);
  } catch {}
  if (senderLabel || messagePreview) {
    showSystemPushNotification({
      title: `💬 ${senderLabel || 'Nuevo mensaje en NEXT'}`,
      body: messagePreview || 'Tienes un nuevo mensaje del servicio.',
      tag: `next-msg-${Date.now()}`,
    });
  }
}

export default function ServiceMessageAlertBanner({ alert, onOpen, onDismiss }) {
  const startXRef = React.useRef(null);
  const [dragX, setDragX] = React.useState(0);
  const [swipingOut, setSwipingOut] = React.useState(null);

  React.useEffect(() => {
    setDragX(0);
    setSwipingOut(null);
    if (!alert) return;
    const timer = setTimeout(() => {
      onDismiss?.();
    }, 2500);
    return () => clearTimeout(timer);
  }, [alert?.id, alert?.title, alert?.message]);

  if (!alert) return null;

  const handleStart = (clientX) => {
    if (swipingOut) return;
    startXRef.current = clientX;
  };

  const handleMove = (clientX) => {
    if (startXRef.current == null || swipingOut) return;
    setDragX(clientX - startXRef.current);
  };

  const handleEnd = () => {
    if (startXRef.current == null || swipingOut) return;
    startXRef.current = null;
    if (Math.abs(dragX) > 40) {
      const dir = dragX > 0 ? 1 : -1;
      setSwipingOut(dir);
      setTimeout(() => {
        onDismiss?.();
      }, 140);
    } else {
      setDragX(0);
    }
  };

  const translateX = swipingOut ? swipingOut * 380 : dragX;
  const opacity = swipingOut ? 0 : Math.max(0.25, 1 - Math.abs(dragX) / 240);

  return (
    <div
      className="fixed top-[calc(var(--apk-status-bar-height,0px)+10px)] left-3 right-3 z-[2500] max-w-[360px] mx-auto animate-in fade-in slide-in-from-top-3 duration-150 select-none touch-pan-y"
      data-testid="service-message-alert-banner"
      onTouchStart={(e) => {
        if (e.touches?.[0]) handleStart(e.touches[0].clientX);
      }}
      onTouchMove={(e) => {
        if (e.touches?.[0]) handleMove(e.touches[0].clientX);
      }}
      onTouchEnd={handleEnd}
      onTouchCancel={handleEnd}
      style={{
        transform: `translate3d(${translateX}px, 0, 0)`,
        opacity,
        transition:
          startXRef.current != null
            ? 'none'
            : 'transform 150ms ease-out, opacity 150ms ease-out',
      }}
    >
      <div
        role="button"
        tabIndex={0}
        onClick={() => {
          if (Math.abs(dragX) > 10) return;
          onOpen?.(alert);
        }}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') onOpen?.(alert);
        }}
        className="w-full rounded-2xl bg-[#0F172A]/95 dark:bg-[#111827]/95 backdrop-blur-md border border-[#00E5FF]/80 shadow-xl shadow-[#1E6BFF]/30 px-3 py-2.5 flex items-center gap-2.5 cursor-pointer active:scale-[0.99] transition-transform"
      >
        <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#1E6BFF] to-[#00E5FF] flex items-center justify-center flex-shrink-0 text-white shadow-sm">
          <Bell className="w-4 h-4" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] font-extrabold text-[#00E5FF] truncate">
              {alert.title || 'Tienes un nuevo mensaje'}
            </span>
            <span className="px-2 py-0.5 rounded-full bg-[#1E6BFF] text-white text-[9px] font-extrabold whitespace-nowrap flex-shrink-0 flex items-center gap-1">
              <MessageCircle className="w-2.5 h-2.5" /> Chat
            </span>
          </div>
          <p className="text-xs font-bold text-white line-clamp-1 break-words leading-snug mt-0.5">
            {alert.message}
          </p>
        </div>

        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onDismiss?.();
          }}
          aria-label="Cerrar notificación"
          className="w-6 h-6 rounded-lg bg-white/10 hover:bg-white/20 text-white/80 flex items-center justify-center flex-shrink-0"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}
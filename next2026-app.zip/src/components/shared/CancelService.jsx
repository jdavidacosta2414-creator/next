import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';
import { XCircle, Loader2 } from 'lucide-react';
import { withRetry } from '@/lib/api-helpers';

const REASONS = [
  { value: 'ya_no_necesito', label: 'Ya no necesito el servicio' },
  { value: 'pedi_por_error', label: 'Pedí por error / equivocación' },
  { value: 'conductor_demora', label: 'El conductor se demora demasiado' },
  { value: 'cambie_direccion', label: 'Cambié la dirección de recogida o destino' },
  { value: 'precio_no_conviene', label: 'El precio no me convence' },
  { value: 'otro', label: 'Otro' },
];

export default function CancelService({ serviceId, mobileId, onCancelled, label = 'Cancelar servicio' }) {
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState('');
  const [detail, setDetail] = useState('');
  const [loading, setLoading] = useState(false);

  const cancel = async () => {
    setLoading(true);
    try {
      const payload = {
        status: 'cancelado',
        cancelled_by: 'pasajero',
        cancel_reason: reason,
        ...(reason === 'otro' && detail ? { client_cancel_detail: detail } : {}),
      };
      await withRetry(() => base44.entities.Service.update(serviceId, payload));

      // If a driver was assigned, free them and notify via chat (y registrar que canceló el pasajero, sin penalizar al conductor)
      if (mobileId) {
        await withRetry(() => base44.entities.Mobile.update(mobileId, { status: 'disponible' }));
        base44.functions.invoke('driverPerformance', {
          action: 'record_event',
          mobile_id: mobileId,
          service_id: serviceId,
          event_type: 'cancelled_by_passenger',
          cancelled_by: 'pasajero',
          cancel_reason: reason,
        }).catch(() => {});
        const reasonLabel = REASONS.find(r => r.value === reason)?.label || reason;
        try {
          await base44.entities.ServiceMessage.create({
            service_id: serviceId,
            sender_type: 'cliente',
            sender_name: 'Cliente',
            message: `El cliente canceló el servicio. Motivo: ${reasonLabel}${detail && reason === 'otro' ? ` — ${detail}` : ''}`,
          });
        } catch (e) {
          console.error('Notify driver error:', e);
        }
      }

      setOpen(false);
      if (onCancelled) onCancelled();
    } catch (err) {
      toast({ title: 'No se pudo cancelar', description: err.message || 'Intenta de nuevo', variant: 'destructive' });
    } finally { setLoading(false); }
  };

  if (!open) {
    return (
      <Button variant="outline" className="w-full h-10 border-destructive/30 text-destructive hover:bg-destructive/10" onClick={() => setOpen(true)}>
        <XCircle className="w-4 h-4 mr-2" />{label}
      </Button>
    );
  }

  return (
    <div className="bg-destructive/10 rounded-xl p-4 border border-destructive/20">
      <p className="font-semibold text-sm text-destructive mb-2">Motivo de cancelación</p>
      <Select onValueChange={setReason} value={reason}>
        <SelectTrigger className="h-10 bg-card mb-2"><SelectValue placeholder="Selecciona un motivo" /></SelectTrigger>
        <SelectContent>
          {REASONS.map(r => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}
        </SelectContent>
      </Select>
      {reason === 'otro' && (
        <Input
          placeholder="Cuéntanos qué pasó (opcional)"
          value={detail}
          onChange={e => setDetail(e.target.value)}
          className="h-10 mb-2 bg-card"
        />
      )}
      <div className="flex gap-2">
        <Button variant="outline" size="sm" className="flex-1 h-9" onClick={() => setOpen(false)}>Volver</Button>
        <Button size="sm" className="flex-1 h-9 bg-destructive hover:bg-destructive/90 text-destructive-foreground" disabled={!reason || loading} onClick={cancel}>
          {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}Confirmar
        </Button>
      </div>
    </div>
  );
}
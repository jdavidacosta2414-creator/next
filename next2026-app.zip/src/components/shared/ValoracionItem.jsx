import React from 'react';
import { Star } from 'lucide-react';
import ResolvedAvatar from '@/components/shared/ResolvedAvatar';
import { fmtBogotaFullDateTime } from '@/lib/dateBogota';

// Tarjeta de una valoración: quién calificó, estrellas, comentario y fecha.
export default function ValoracionItem({ name, photo, stars, comment, date }) {
  return (
    <div className="bg-card border border-border rounded-2xl p-4 shadow-sm">
      <div className="flex items-center gap-3">
        <ResolvedAvatar
          photo={photo}
          name={name}
          className="w-10 h-10 rounded-full bg-muted text-foreground font-bold text-sm"
        />
        <div className="flex-1 min-w-0">
          <p className="text-foreground font-bold text-sm truncate">{name || 'Usuario'}</p>
          <p className="text-muted-foreground text-[11px]">{date ? fmtBogotaFullDateTime(date) : ''}</p>
        </div>
        <div className="flex items-center gap-0.5 flex-shrink-0">
          {[1, 2, 3, 4, 5].map((n) => (
            <Star
              key={n}
              className={`w-4 h-4 ${n <= stars ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground/30'}`}
            />
          ))}
        </div>
      </div>
      <p className={`mt-3 text-sm leading-relaxed ${comment ? 'text-foreground' : 'text-muted-foreground italic'}`}>
        {comment || 'Sin comentario'}
      </p>
    </div>
  );
}
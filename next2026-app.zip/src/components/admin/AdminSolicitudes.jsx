import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import {
  Plus, MapPin, Navigation, Phone, CreditCard, Loader2, X, Package, Users,
  Link as LinkIcon, MessageCircle, Bike, Car, Check, Trash2, Tag,
} from 'lucide-react';
import StatusBadge from '@/components/StatusBadge';
import { isPickupInCoverage } from '@/lib/coverage';
import { useMapboxToken } from '@/hooks/useMapboxToken';
import { searchPlacesValledupar, resolvePlaceSelection, normalizeColombiaCoords } from '@/lib/geocode';
import { joinBarrio } from '@/lib/shortAddress';
import BarrioFields from '@/components/central/BarrioFields';

const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');

const inputCls =
  'h-10 w-full rounded-lg border border-[#262626] bg-[#0A0A0A] px-3 text-sm text-white placeholder:text-[#5A6478] focus:outline-none focus:ring-2 focus:ring-[#1E6BFF]/30';

export default function AdminSolicitudes() {
  const [services, setServices] = useState([]);
  const [mobiles, setMobiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [assigning, setAssigning] = useState(null);
  const [busy, setBusy] = useState(null); // { service_id, mobile_id, action }

  const load = async () => {
    // Solo servicios en tiempo real: pendientes creados en los últimos 10 min.
    // Los más viejos ya expiraron (nadie los tomó o el cliente los abandonó)
    // y una limpieza programada los borra de la base de datos.
    const since = new Date(Date.now() - 10 * 60 * 1000).toISOString();
    const [page, mobs] = await Promise.all([
      base44.entities.Service.filter({ status: 'pendiente', created_date: { $gte: since } }, { sort: '-created_date', limit: 50 }),
      base44.entities.Mobile.list(),
    ]);
    setServices(page.items || []);
    setMobiles(mobs.filter((m) => m.status === 'disponible'));
    setLoading(false);
  };

  useEffect(() => {
    load();
    const unsub = base44.entities.Service.subscribe(() => load().catch(() => {}));
    return unsub;
  }, []);

  // Asignación directa para servicios que NO son de WhatsApp (flujo actual).
  const assignDirect = async (serviceId, mobileId) => {
    try {
      const m = mobiles.find((x) => x.id === mobileId);
      await base44.entities.Service.update(serviceId, {
        status: 'asignado',
        mobile_id: mobileId,
        mobile_name: m?.name,
        mobile_plate: m?.plate,
        mobile_photo: m?.photo_url,
        mobile_phone: m?.phone,
      });
      await base44.entities.Mobile.update(mobileId, { status: 'ocupado' });
      setAssigning(null);
      load();
    } catch (e) {
      console.error('Assign error:', e);
      setAssigning(null);
    }
  };

  // Aceptar oferta: la Central ya confirmó con el cliente por WhatsApp.
  const acceptOffer = async (serviceId, mobileId) => {
    setBusy({ service_id: serviceId, mobile_id: mobileId, action: 'accept' });
    try {
      await base44.functions.invoke('assignWhatsAppOffer', { service_id: serviceId, mobile_id: mobileId });
      load();
    } catch (e) {
      console.error('Accept offer error:', e);
    } finally {
      setBusy(null);
    }
  };

  // Rechazar oferta: el cliente no aceptó la tarifa. Se descarta al conductor
  // de las propuestas y el servicio sigue pendiente para recibir nuevas ofertas.
  const rejectOffer = async (service, mobileId) => {
    setBusy({ service_id: service.id, mobile_id: mobileId, action: 'reject' });
    try {
      const remaining = (service.candidates || []).filter((c) => c.mobile_id !== mobileId);
      await base44.entities.Service.update(service.id, { candidates: remaining });
      load();
    } catch (e) {
      console.error('Reject offer error:', e);
    } finally {
      setBusy(null);
    }
  };

  const waServices = services.filter((s) => s.origin === 'whatsapp');
  const otherServices = services.filter((s) => s.origin !== 'whatsapp');

  return (
    <div className="space-y-5">
      <button
        onClick={() => setShowForm((f) => !f)}
        className="w-full h-11 rounded-xl bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white font-semibold text-sm flex items-center justify-center gap-2"
      >
        {showForm ? <><X className="w-4 h-4" />Cancelar</> : <><Plus className="w-4 h-4" />Cargar servicio de WhatsApp</>}
      </button>

      {showForm && <WhatsAppForm onDone={() => { setShowForm(false); load(); }} />}

      {/* Servicios WhatsApp: ofertas y contraofertas */}
      <Section
        title={`Solicitudes WhatsApp (${waServices.length})`}
        empty="No hay solicitudes WhatsApp pendientes"
        loading={loading}
        items={waServices}
        renderItem={(s) => (
          <WhatsAppCard
            key={s.id}
            service={s}
            busy={busy}
            onAccept={acceptOffer}
            onReject={rejectOffer}
          />
        )}
      />

      {/* Servicios normales: asignación directa (flujo actual) */}
      <Section
        title={`Otros servicios (${otherServices.length})`}
        empty="No hay otros servicios pendientes"
        loading={false}
        items={otherServices}
        renderItem={(s) => (
          <DirectCard
            key={s.id}
            service={s}
            mobiles={mobiles}
            assigning={assigning}
            setAssigning={setAssigning}
            onAssign={assignDirect}
          />
        )}
      />
    </div>
  );
}

function Section({ title, empty, loading, items, renderItem }) {
  return (
    <div>
      <h3 className="text-sm font-semibold text-[#8B8C94] mb-2">{title}</h3>
      {loading && items.length === 0 ? (
        <div className="flex justify-center py-6"><Loader2 className="w-6 h-6 animate-spin text-[#1E6BFF]" /></div>
      ) : items.length === 0 ? (
        <p className="text-center text-sm text-[#8B8C94] py-6">{empty}</p>
      ) : (
        <div>{items.map(renderItem)}</div>
      )}
    </div>
  );
}

function WhatsAppCard({ service, busy, onAccept, onReject }) {
  const candidates = service.candidates || [];
  const initials = (service.client_name || '?').trim().slice(0, 2).toUpperCase();

  return (
    <div className="bg-[#0D0D0D] rounded-xl p-4 border border-[#1F1F1F] mb-3">
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-full bg-[#1E6BFF]/15 text-[#1E6BFF] flex items-center justify-center text-xs font-bold">
            {initials}
          </div>
          <div>
            <span className="font-medium text-sm text-white block">{service.client_name}</span>
            <span className="text-[11px] text-emerald-400 font-bold">
              Precio fijo (WhatsApp): {fmtCOP(service.fare)}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <MessageCircle className="w-3.5 h-3.5 text-[#25D366]" />
          <StatusBadge status={service.status} />
        </div>
      </div>

      <div className="space-y-1 text-xs text-[#8B8C94] mb-3">
        <div className="flex items-start gap-1.5"><MapPin className="w-3.5 h-3.5 text-[#1E6BFF] mt-0.5" />{joinBarrio(service.pickup_address, service.pickup_barrio)}</div>
        <div className="flex items-start gap-1.5"><Navigation className="w-3.5 h-3.5 text-[#F59E0B] mt-0.5" />{joinBarrio(service.destination_address, service.destination_barrio)}</div>
        {service.client_phone && <div className="flex items-center gap-1.5"><Phone className="w-3.5 h-3.5" />{service.client_phone}</div>}
        <div className="flex items-center gap-1.5"><CreditCard className="w-3.5 h-3.5" />{service.payment_method}</div>
      </div>

      {/* Ofertas / contraofertas de conductores */}
      <div className="border-t border-[#1F1F1F] pt-3">
        <p className="text-[11px] font-semibold text-[#8B8C94] uppercase tracking-wide mb-2 flex items-center gap-1.5">
          <Tag className="w-3.5 h-3.5" /> Ofertas recibidas ({candidates.length})
        </p>
        {candidates.length === 0 ? (
          <p className="text-xs text-[#5A6478] py-2">Esperando ofertas de conductores…</p>
        ) : (
          <div className="space-y-2">
            {candidates.map((c) => {
              const isBusy = busy && busy.service_id === service.id && busy.mobile_id === c.mobile_id;
              const isCounter = c.offered_fare != null && c.offered_fare !== service.fare;
              return (
                <div key={c.mobile_id} className="bg-[#0A0A0A] rounded-lg border border-[#1F1F1F] p-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-[#1E6BFF]/15 text-[#1E6BFF] flex items-center justify-center">
                        {service.vehicle_type === 'carro' ? <Car className="w-3.5 h-3.5" /> : <Bike className="w-3.5 h-3.5" />}
                      </div>
                      <div>
                        <span className="text-sm text-white font-medium">{c.mobile_name || 'Conductor'}</span>
                        {isCounter && (
                          <span className="ml-2 text-[10px] px-2 py-0.5 rounded-full bg-[#F59E0B]/15 text-[#F59E0B] font-semibold">Contraoferta</span>
                        )}
                      </div>
                    </div>
                    <span className="text-sm font-bold text-[#CCFF00]">{fmtCOP(c.offered_fare)}</span>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => onAccept(service.id, c.mobile_id)}
                      disabled={!!isBusy}
                      className="flex-1 h-9 rounded-lg bg-[#CCFF00] text-black font-semibold text-xs flex items-center justify-center gap-1.5 disabled:opacity-50"
                    >
                      {isBusy && isBusy.action === 'accept' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <><Check className="w-3.5 h-3.5" />Aceptar</>}
                    </button>
                    <button
                      onClick={() => onReject(service, c.mobile_id)}
                      disabled={!!isBusy}
                      className="flex-1 h-9 rounded-lg border border-[#262626] text-[#8B8C94] font-semibold text-xs flex items-center justify-center gap-1.5 hover:text-red-400 hover:border-red-500/40 disabled:opacity-50"
                    >
                      {isBusy && isBusy.action === 'reject' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <><Trash2 className="w-3.5 h-3.5" />Rechazar</>}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
        <p className="text-[10px] text-[#5A6478] mt-2 leading-relaxed">
          Confirma la tarifa con el cliente por WhatsApp antes de aceptar. Al rechazar, el servicio sigue disponible para nuevas ofertas.
        </p>
      </div>
    </div>
  );
}

function DirectCard({ service, mobiles, assigning, setAssigning, onAssign }) {
  return (
    <div className="bg-[#0D0D0D] rounded-xl p-4 border border-[#1F1F1F] mb-3">
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center gap-2">
          {service.service_type === 'mensajeria' ? <Package className="w-4 h-4 text-[#1E6BFF]" /> : <Users className="w-4 h-4 text-[#1E6BFF]" />}
          <span className="font-medium text-sm text-white">{service.client_name}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <LinkIcon className="w-3.5 h-3.5 text-[#8B8C94]" />
          <StatusBadge status={service.status} />
        </div>
      </div>
      <div className="space-y-1 text-xs text-[#8B8C94] mb-3">
        <div className="flex items-start gap-1.5"><MapPin className="w-3.5 h-3.5 text-[#1E6BFF] mt-0.5" />{joinBarrio(service.pickup_address, service.pickup_barrio)}</div>
        <div className="flex items-start gap-1.5"><Navigation className="w-3.5 h-3.5 text-[#F59E0B] mt-0.5" />{joinBarrio(service.destination_address, service.destination_barrio)}</div>
        {service.client_phone && <div className="flex items-center gap-1.5"><Phone className="w-3.5 h-3.5" />{service.client_phone}</div>}
      </div>
      {assigning === service.id ? (
        <div className="flex gap-2">
          <select
            onChange={(e) => e.target.value && onAssign(service.id, e.target.value)}
            defaultValue=""
            className="h-9 text-sm flex-1 rounded-lg border border-[#262626] bg-[#0A0A0A] px-3 text-white focus:outline-none focus:ring-2 focus:ring-[#1E6BFF]/30"
          >
            <option value="" disabled>Seleccionar móvil</option>
            {mobiles.map((m) => <option key={m.id} value={m.id}>{m.name} — {m.plate}</option>)}
          </select>
          <button onClick={() => setAssigning(null)} className="h-9 px-3 rounded-lg border border-[#262626] text-[#8B8C94] text-sm">Cancelar</button>
        </div>
      ) : (
        <button onClick={() => setAssigning(service.id)} className="w-full h-9 rounded-lg bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white font-semibold text-sm">Asignar móvil</button>
      )}
    </div>
  );
}

function WhatsAppForm({ onDone }) {
  const [form, setForm] = useState({
    client_name: '',
    client_phone: '',
    pickup_address: '',
    pickup_barrio: '',
    destination_address: '',
    destination_barrio: '',
    service_type: 'transporte',
    vehicle_type: 'moto',
    payment_method: 'efectivo',
    fare: 5000,
  });
  const [pickupPlace, setPickupPlace] = useState(null);
  const [destPlace, setDestPlace] = useState(null);
  const [activeField, setActiveField] = useState(null);
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const token = useMapboxToken();

  const currentQuery =
    activeField === 'pickup'
      ? form.pickup_address
      : activeField === 'destination'
      ? form.destination_address
      : '';

  useEffect(() => {
    const q = (currentQuery || '').trim();
    if (!activeField || q.length < 2) {
      setSuggestions([]);
      return;
    }
    let cancelled = false;
    const t = setTimeout(async () => {
      const res = await searchPlacesValledupar(q, token);
      if (!cancelled) setSuggestions(res);
    }, 200);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [currentQuery, activeField, token]);

  const handleSelectSuggestion = async (item) => {
    const resolved = await resolvePlaceSelection(item);
    if (!resolved) return;
    if (activeField === 'pickup') {
      set('pickup_address', resolved.name);
      setPickupPlace(resolved);
    } else if (activeField === 'destination') {
      set('destination_address', resolved.name);
      setDestPlace(resolved);
    }
    setSuggestions([]);
    setActiveField(null);
  };

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      if (!pickupPlace?.lat || !destPlace?.lat) {
        setError('Selecciona una opción de la lista para recogida y destino.');
        setLoading(false);
        return;
      }
      const cov = await isPickupInCoverage(form.pickup_address);
      if (!cov.ok) {
        setError(`Fuera de zona de cobertura. Barrios: ${cov.zone.neighborhoods.join(', ')}`);
        setLoading(false);
        return;
      }
      const pCoords = normalizeColombiaCoords(pickupPlace.lat, pickupPlace.lng);
      const dCoords = normalizeColombiaCoords(destPlace.lat, destPlace.lng);
      const created = await base44.entities.Service.create({
        ...form,
        pickup_barrio: form.pickup_barrio.trim(),
        destination_barrio: form.destination_barrio.trim(),
        fare: Number(form.fare) || 5000,
        origin: 'whatsapp',
        status: 'pendiente',
        rejected_by: [],
        candidates: [],
        ...(pCoords ? { pickup_lat: pCoords.lat, pickup_lng: pCoords.lng } : {}),
        ...(dCoords ? { destination_lat: dCoords.lat, destination_lng: dCoords.lng } : {}),
      });
      // Aviso al celular de los conductores cercanos, igual que los servicios creados desde la Central.
      if (created?.id) {
        base44.functions.invoke('notifyNearbyDrivers', { service_id: created.id }).catch(() => {});
      }
      onDone();
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={submit} className="bg-[#0D0D0D] rounded-xl p-4 border border-[#1F1F1F] space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <div>
          <label className="text-xs text-[#8B8C94] mb-1 block">Cliente</label>
          <input required value={form.client_name} onChange={(e) => set('client_name', e.target.value)} className={inputCls} placeholder="Nombre" />
        </div>
        <div>
          <label className="text-xs text-[#8B8C94] mb-1 block">Teléfono</label>
          <input value={form.client_phone} onChange={(e) => set('client_phone', e.target.value)} className={inputCls} placeholder="Tel" />
        </div>
      </div>
      <div>
        <label className="text-xs text-[#8B8C94] mb-1 block">Recogida</label>
        <input
          required
          value={form.pickup_address}
          onFocus={() => setActiveField('pickup')}
          onChange={(e) => {
            setActiveField('pickup');
            setPickupPlace(null);
            set('pickup_address', e.target.value);
          }}
          className={inputCls}
          placeholder="Dirección o lugar de recogida"
        />
      </div>
      <div>
        <label className="text-xs text-[#8B8C94] mb-1 block">Destino</label>
        <input
          required
          value={form.destination_address}
          onFocus={() => setActiveField('destination')}
          onChange={(e) => {
            setActiveField('destination');
            setDestPlace(null);
            set('destination_address', e.target.value);
          }}
          className={inputCls}
          placeholder="Dirección o lugar de destino"
        />
      </div>
      {suggestions.length > 0 && (
        <div className="rounded-lg border border-[#262626] bg-[#141923] divide-y divide-white/5 max-h-44 overflow-y-auto">
          {suggestions.map((item, idx) => (
            <button
              key={`${item.place_id || item.name}-${idx}`}
              type="button"
              onClick={() => handleSelectSuggestion(item)}
              className="w-full px-3 py-2 text-left hover:bg-white/5 flex items-center justify-between gap-2"
            >
              <div className="min-w-0">
                <p className="text-xs font-bold text-white truncate">{item.name}</p>
                <p className="text-[10px] text-[#8B8C94] truncate">{item.subtitle}</p>
              </div>
            </button>
          ))}
        </div>
      )}
      <BarrioFields form={form} onChange={set} inputClassName={inputCls} />
      <div className="grid grid-cols-2 gap-2">
        <div>
          <label className="text-xs text-[#8B8C94] mb-1 block">Tipo</label>
          <select value={form.service_type} onChange={(e) => set('service_type', e.target.value)} className={inputCls}>
            <option value="transporte">Transporte</option>
            <option value="mensajeria">Mensajería</option>
          </select>
        </div>
        <div>
          <label className="text-xs text-[#8B8C94] mb-1 block">Vehículo requerido</label>
          <select value={form.vehicle_type} onChange={(e) => set('vehicle_type', e.target.value)} className={inputCls}>
            <option value="moto">Moto</option>
            <option value="carro">Carro</option>
          </select>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div>
          <label className="text-xs text-[#8B8C94] mb-1 block">Pago</label>
          <select value={form.payment_method} onChange={(e) => set('payment_method', e.target.value)} className={inputCls}>
            <option value="efectivo">Efectivo</option>
            <option value="transferencia">Transferencia</option>
            <option value="nequi">Nequi</option>
            <option value="daviplata">Daviplata</option>
            <option value="bancolombia">Bancolombia</option>
            <option value="paga_con_llave">Paga con llave</option>
          </select>
        </div>
        <div>
          <label className="text-xs text-emerald-400 font-semibold mb-1 block">
            Precio fijo WhatsApp (COP)
          </label>
          <input type="number" min="1000" step="500" value={form.fare} onChange={(e) => set('fare', e.target.value)} className={inputCls} placeholder="5000" />
        </div>
      </div>
      {error && <p className="text-xs text-red-400 bg-red-500/10 rounded-lg p-2">{error}</p>}
      <button type="submit" disabled={loading} className="w-full h-10 rounded-lg bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white font-semibold text-sm flex items-center justify-center gap-2 disabled:opacity-50">
        {loading && <Loader2 className="w-4 h-4 animate-spin" />}Crear servicio
      </button>
    </form>
  );
}
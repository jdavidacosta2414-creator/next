import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Search, Loader2, PackageSearch, Phone, MessageCircle, Bike, Car, X } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const STATUS = {
  nuevo: { label: 'Nuevo', cls: 'bg-[#00E5FF]/15 text-[#00E5FF]' },
  en_gestion: { label: 'En gestión', cls: 'bg-amber-500/15 text-amber-400' },
  recuperado: { label: 'Recuperado', cls: 'bg-green-500/15 text-green-400' },
  cerrado: { label: 'Cerrado', cls: 'bg-white/10 text-[#8B95A8]' },
};

const fmtDateTime = (d) => d ? new Date(d).toLocaleString('es-CO', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hour12: true, timeZone: 'America/Bogota' }) : '—';

// Panel de objetos perdidos para Central: lista los reportes recibidos desde
// la app del pasajero y permite ver el viaje asociado, contactar al conductor
// y registrar el seguimiento hasta cerrar el caso.
export default function LostItemsView() {
  const { toast } = useToast();
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState(null);
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  const load = async () => {
    try {
      const page = await base44.entities.LostItemReport.filter({}, { sort: '-created_date', limit: 100 });
      setReports(page.items || []);
    } catch (e) {}
    setLoading(false);
  };

  useEffect(() => {
    load();
    const unsub = base44.entities.LostItemReport.subscribe(() => load().catch(() => {}));
    return unsub;
  }, []);

  const filtered = reports.filter((r) => {
    if (!query) return true;
    const q = query.toLowerCase();
    return [r.reporter_name, r.reporter_phone, r.mobile_name, r.mobile_plate, r.object_description, r.pickup_address].some((v) => (v || '').toLowerCase().includes(q));
  });

  const open = (r) => { setSelected(r); setNotes(r.notes || ''); };

  const updateStatus = async (status) => {
    if (!selected) return;
    setSaving(true);
    try {
      await base44.entities.LostItemReport.update(selected.id, { status, notes });
      toast({ description: `Estado actualizado a "${STATUS[status].label}".` });
      setSelected((s) => ({ ...s, status, notes }));
      load();
    } catch (e) { toast({ description: 'No se pudo actualizar.' }); }
    setSaving(false);
  };

  const saveNotes = async () => {
    if (!selected) return;
    setSaving(true);
    try {
      await base44.entities.LostItemReport.update(selected.id, { notes });
      toast({ description: 'Notas guardadas.' });
      setSelected((s) => ({ ...s, notes }));
    } catch (e) { toast({ description: 'No se pudo guardar.' }); }
    setSaving(false);
  };

  const waDriver = (r) => r.mobile_phone ? `https://wa.me/${r.mobile_phone.replace(/\D/g, '')}?text=${encodeURIComponent('Hola ' + (r.mobile_name || '') + ', un pasajero reportó que olvidó un objeto en el servicio de ' + (r.pickup_address || '') + ' a ' + (r.destination_address || '') + '. ¿Lo tienes contigo?')}` : null;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">Objetos perdidos</h2>
          <p className="text-sm text-[#8B95A8]">Reportes de pasajeros y seguimiento de recuperación.</p>
        </div>
        <div className="relative w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5A6478]" />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar reporte..."
            className="w-full h-10 rounded-lg bg-[#161b22] border border-white/8 pl-10 pr-4 text-sm text-white placeholder:text-[#5A6478] outline-none focus:border-[#1E6BFF]/40" />
        </div>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center h-40 text-[#5A6478]">
          <Loader2 className="w-6 h-6 animate-spin mb-2" />
          <p className="text-sm">Cargando reportes...</p>
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-60 text-[#5A6478]">
          <PackageSearch className="w-10 h-10 mb-3 text-[#2a313d]" />
          <p className="text-sm font-medium text-white mb-1">No hay reportes</p>
          <p className="text-xs">Los reportes de objetos perdidos aparecerán aquí.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          {filtered.map((r) => {
            const st = STATUS[r.status] || STATUS.nuevo;
            return (
              <button key={r.id} onClick={() => open(r)} className="text-left bg-[#0f1419] border border-white/8 rounded-xl p-4 hover:border-[#1E6BFF]/40 transition-colors">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center">
                      {r.vehicle_type === 'carro' ? <Car className="w-4 h-4 text-[#8B95A8]" /> : <Bike className="w-4 h-4 text-[#8B95A8]" />}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-white">{r.mobile_name || 'Conductor'}</p>
                      <p className="text-[11px] text-[#5A6478]">{r.mobile_plate || 'Sin placa'} · {fmtDateTime(r.service_date)}</p>
                    </div>
                  </div>
                  <span className={`text-[11px] font-bold px-2 py-1 rounded-full ${st.cls}`}>{st.label}</span>
                </div>
                <p className="text-xs text-[#8B95A8] line-clamp-2 mb-2">{r.object_description}</p>
                <div className="flex items-center justify-between text-[11px] text-[#5A6478]">
                  <span>{r.reporter_name} · {r.reporter_phone}</span>
                  <span>{r.pickup_address || '—'}</span>
                </div>
              </button>
            );
          })}
        </div>
      )}

      {/* Detalle / seguimiento */}
      {selected && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setSelected(null)} />
          <div className="relative w-full max-w-lg max-h-[90vh] overflow-y-auto thin-scroll bg-[#0f1419] border border-white/10 rounded-2xl shadow-2xl">
            <div className="flex items-center justify-between p-5 border-b border-white/8 sticky top-0 bg-[#0f1419]">
              <h3 className="text-lg font-bold text-white">Seguimiento de objeto</h3>
              <button onClick={() => setSelected(null)} className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-[#8B95A8] hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              {/* Estado */}
              <div className="flex items-center gap-2 flex-wrap">
                {Object.entries(STATUS).map(([k, v]) => (
                  <button key={k} disabled={saving} onClick={() => updateStatus(k)}
                    className={`text-xs font-bold px-3 py-1.5 rounded-full transition-colors ${selected.status === k ? v.cls + ' ring-1 ring-current' : 'bg-white/5 text-[#8B95A8] hover:text-white'}`}>
                    {v.label}
                  </button>
                ))}
              </div>

              {/* Viaje */}
              <div className="bg-[#161b22] rounded-xl p-4">
                <p className="text-[10px] font-bold text-[#5A6478] tracking-wider mb-2">VIAJE ASOCIADO</p>
                <div className="flex items-center gap-2 mb-2">
                  {selected.vehicle_type === 'carro' ? <Car className="w-4 h-4 text-[#8B95A8]" /> : <Bike className="w-4 h-4 text-[#8B95A8]" />}
                  <p className="text-sm font-bold text-white">{selected.mobile_name || 'Conductor'}</p>
                  <span className="text-xs text-[#5A6478]">{selected.mobile_plate || 'Sin placa'}</span>
                </div>
                <p className="text-xs text-[#8B95A8]">{selected.pickup_address || '—'} → {selected.destination_address || '—'}</p>
                <p className="text-[11px] text-[#5A6478] mt-1">{fmtDateTime(selected.service_date)}</p>
              </div>

              {/* Objeto */}
              <div>
                <p className="text-[10px] font-bold text-[#5A6478] tracking-wider mb-1">OBJETO REPORTADO</p>
                <p className="text-sm text-white bg-[#161b22] rounded-xl p-3">{selected.object_description}</p>
              </div>

              {/* Contacto pasajero */}
              <div>
                <p className="text-[10px] font-bold text-[#5A6478] tracking-wider mb-1">PASAJERO</p>
                <p className="text-sm text-white">{selected.reporter_name}</p>
                <a href={`tel:${selected.reporter_phone}`} className="text-sm text-[#1E6BFF]">{selected.reporter_phone}</a>
              </div>

              {/* Acciones contacto conductor */}
              <div className="flex gap-2">
                {selected.mobile_phone && (
                  <a href={`tel:${selected.mobile_phone}`} className="flex-1 h-10 rounded-xl bg-[#1E6BFF]/15 text-[#1E6BFF] font-bold text-sm flex items-center justify-center gap-1.5">
                    <Phone className="w-4 h-4" /> Llamar conductor
                  </a>
                )}
                {waDriver(selected) && (
                  <a href={waDriver(selected)} target="_blank" rel="noreferrer" className="flex-1 h-10 rounded-xl bg-[#25D366]/15 text-[#1a8e3a] font-bold text-sm flex items-center justify-center gap-1.5">
                    <MessageCircle className="w-4 h-4" /> WhatsApp
                  </a>
                )}
              </div>

              {/* Notas */}
              <div>
                <p className="text-[10px] font-bold text-[#5A6478] tracking-wider mb-1">NOTAS DE SEGUIMIENTO</p>
                <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3}
                  placeholder="Registra avances, llamadas, acuerdos..."
                  className="w-full bg-[#161b22] rounded-xl p-3 text-sm text-white placeholder:text-[#5A6478] outline-none border border-white/8 focus:border-[#1E6BFF]/40 resize-none" />
                <button onClick={saveNotes} disabled={saving}
                  className="mt-2 h-9 px-4 rounded-lg bg-white/5 text-white text-sm font-medium hover:bg-white/10 disabled:opacity-50">
                  {saving ? 'Guardando...' : 'Guardar notas'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
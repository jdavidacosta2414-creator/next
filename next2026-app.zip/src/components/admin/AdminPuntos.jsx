import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Search, Loader2, Gift, Sparkles, TrendingUp, UserCheck, Send, Coins, Wallet, Check, X, Store, Users, Award } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { REFERRAL_POINTS, resolveReferrerByCode } from '@/lib/referrals';
import DriverRewardsConfigCard from '@/components/admin/DriverRewardsConfigCard';

const fmtDate = (d) => new Date(d).toLocaleDateString('es-CO', { day: '2-digit', month: 'short', timeZone: 'America/Bogota' });
const fmtTime = (d) => new Date(d).toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit', hour12: true, timeZone: 'America/Bogota' });
const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');

const PURCHASE_POINTS = 50;

const TYPE_META = {
  interaccion_click: { label: 'Interacción en publicidad', tone: 'text-[#00E5FF] bg-[#00E5FF]/10' },
  compra_confirmada: { label: 'Servicio / alimento adquirido (+50 pts)', tone: 'text-emerald-400 bg-emerald-400/10' },
  referido_pendiente: { label: 'Referido registrado (por aprobar)', tone: 'text-amber-400 bg-amber-400/10' },
  referido_aprobado: { label: 'Bono por referido aprobado (+100 pts)', tone: 'text-emerald-400 bg-emerald-400/10' },
  canje: { label: 'Canje', tone: 'text-amber-400 bg-amber-400/10' },
  ajuste: { label: 'Ajuste manual', tone: 'text-gray-300 bg-white/5' },
};

function parseBonusCOP(rewardText) {
  if (!rewardText) return 0;
  const m = String(rewardText).match(/\$\s*([\d.]+)/);
  if (!m) return 0;
  return Number(m[1].replace(/\./g, '')) || 0;
}

// Directorio de pasajeros derivado de su actividad: registros de puntos
// (quien abrió anuncios) y servicios solicitados. El SDK de usuarios no
// permite listar cuentas, así que se construye desde la actividad auditable.
async function loadPassengerDirectory() {
  const byUser = new Map();
  const add = (id, name, email) => {
    if (!id) return;
    if (!byUser.has(id)) byUser.set(id, { id, name: name || '', email: email || '' });
  };
  try {
    const page = await base44.entities.PointsTransaction.filter({}, { sort: '-created_date', limit: 100 });
    (page.items || []).forEach((t) => add(t.user_id, t.user_name, ''));
  } catch (e) {}
  try {
    const page = await base44.entities.Service.filter({}, { sort: '-created_date', limit: 100, fields: ['client_name', 'client_phone'] });
    (page.items || []).forEach((s) => add(s.created_by_id, s.client_name, ''));
  } catch (e) {}
  return Array.from(byUser.values());
}

// Panel de Puntos y recompensas para Central: busca pasajeros (según su
// actividad en la app), les acredita puntos por compras confirmadas (el
// restaurante envía el comprobante por WhatsApp) y revisa su historial.
export default function AdminPuntos() {
  const { user: admin } = useAuth();
  const { toast } = useToast();
  const [query, setQuery] = useState('');
  const [directory, setDirectory] = useState([]);
  const [loadingDir, setLoadingDir] = useState(true);
  const [selected, setSelected] = useState(null);
  const [balance, setBalance] = useState(0);
  const [moves, setMoves] = useState([]);
  const [loadingMoves, setLoadingMoves] = useState(false);
  const [form, setForm] = useState({ amount: PURCHASE_POINTS, business_name: '', description: '' });
  const [saving, setSaving] = useState(false);
  const [pendingWithdrawals, setPendingWithdrawals] = useState([]);
  const [confirmingId, setConfirmingId] = useState(null);
  const [pendingPurchases, setPendingPurchases] = useState([]);
  const [pendingReferrals, setPendingReferrals] = useState([]);
  const [pendingRewardClaims, setPendingRewardClaims] = useState([]);
  const [reviewingPurchaseId, setReviewingPurchaseId] = useState(null);
  const [reviewingClaimId, setReviewingClaimId] = useState(null);
  const [adsList, setAdsList] = useState([]);

  const loadWithdrawals = useCallback(async () => {
    try {
      const page = await base44.entities.PassengerWalletTx.filter(
        { type: 'retiro', status: 'pendiente_transferencia' },
        { sort: '-created_date', limit: 30 }
      );
      setPendingWithdrawals(page?.items || []);
    } catch {}
  }, []);

  const loadPendingPurchases = useCallback(async () => {
    try {
      const page = await base44.entities.PointsTransaction.filter(
        { status: 'pendiente' },
        { sort: '-created_date', limit: 60 }
      );
      const items = page?.items || [];
      setPendingPurchases(items.filter((t) => t.type !== 'referido_pendiente'));
      setPendingReferrals(items.filter((t) => t.type === 'referido_pendiente'));
    } catch {}
  }, []);

  const loadPendingRewardClaims = useCallback(async () => {
    try {
      const page = await base44.entities.RewardClaim.filter(
        { status: 'pendiente' },
        { sort: '-created_date', limit: 40 }
      );
      setPendingRewardClaims(page?.items || (Array.isArray(page) ? page : []));
    } catch {}
  }, []);

  const loadAds = useCallback(async () => {
    try {
      const page = await base44.entities.Advertisement.filter({ active: true }, { sort: '-created_date', limit: 50 });
      setAdsList(page?.items || []);
    } catch {}
  }, []);

  useEffect(() => {
    loadPassengerDirectory()
      .then((d) => setDirectory(d))
      .catch(() => setDirectory([]))
      .finally(() => setLoadingDir(false));
    loadWithdrawals();
    loadPendingPurchases();
    loadPendingRewardClaims();
    loadAds();
    const unsubWallet = base44.entities.PassengerWalletTx.subscribe(() => loadWithdrawals().catch(() => {}));
    const unsubPoints = base44.entities.PointsTransaction.subscribe(() => {
      loadPendingPurchases().catch(() => {});
      loadPassengerDirectory().then(setDirectory).catch(() => {});
    });
    const unsubClaims = base44.entities.RewardClaim.subscribe(() => {
      loadPendingRewardClaims().catch(() => {});
    });
    return () => { unsubWallet(); unsubPoints(); unsubClaims(); };
  }, [loadWithdrawals, loadPendingPurchases, loadPendingRewardClaims, loadAds]);

  const approveReferral = async (tx) => {
    setReviewingPurchaseId(tx.id);
    try {
      let resolved = null;
      if (tx.referrer_code && (tx.user_id?.startsWith('ref:') || !tx.referrer_mobile_id)) {
        resolved = await resolveReferrerByCode(tx.referrer_code);
      }
      const finalUserId = !tx.user_id?.startsWith('ref:') ? tx.user_id : (resolved?.user_id || tx.user_id);
      const finalUserName = !tx.user_name?.startsWith('Referente') ? tx.user_name : (resolved?.user_name || tx.user_name);
      const finalMobileId = tx.referrer_mobile_id || resolved?.referrer_mobile_id;
      const finalScope = tx.referrer_scope || resolved?.referrer_scope || (finalMobileId ? 'conductor' : 'pasajero');

      await base44.entities.PointsTransaction.update(tx.id, {
        user_id: finalUserId,
        user_name: finalUserName,
        referrer_scope: finalScope,
        ...(finalMobileId ? { referrer_mobile_id: finalMobileId } : {}),
        status: 'aprobado',
        type: 'referido_aprobado',
        amount: REFERRAL_POINTS,
        description: `Referido aprobado por Central (${tx.referred_user_name || 'Nuevo usuario'}) · +${REFERRAL_POINTS} puntos`,
      });

      if (finalMobileId) {
        try {
          const mob = await base44.entities.Mobile.get(finalMobileId);
          if (mob) {
            const nextWallet = Number(mob.points_wallet_balance || 0) + REFERRAL_POINTS;
            await base44.entities.Mobile.update(finalMobileId, { points_wallet_balance: nextWallet });
          }
        } catch {}
      }

      toast({
        title: `+${REFERRAL_POINTS} puntos por referido aprobados`,
        description: `Se acreditaron +${REFERRAL_POINTS} puntos y se envió la notificación a ${finalUserName}.`,
      });
      await loadPendingPurchases();
      if (selected?.id === finalUserId) loadMoves();
    } catch {
      toast({ title: 'No se pudo aprobar el referido', variant: 'destructive' });
    } finally {
      setReviewingPurchaseId(null);
    }
  };

  const approveRewardClaim = async (claim) => {
    setReviewingClaimId(claim.id);
    try {
      await base44.entities.RewardClaim.update(claim.id, {
        status: 'entregado',
      });
      if (claim.scope === 'conductor' && claim.mobile_id) {
        const bonus = parseBonusCOP(claim.reward);
        if (bonus > 0) {
          try {
            const mob = await base44.entities.Mobile.get(claim.mobile_id);
            if (mob) {
              const nextWallet = Number(mob.points_wallet_balance || 0) + bonus;
              await base44.entities.Mobile.update(claim.mobile_id, { points_wallet_balance: nextWallet });
            }
          } catch {}
        }
      }
      toast({
        title: 'Recompensa aprobada y notificada',
        description: `Se notificó al ${claim.scope === 'conductor' ? 'conductor' : 'pasajero'} la aprobación de "${claim.reward}".`,
      });
      await loadPendingRewardClaims();
    } catch {
      toast({ title: 'No se pudo aprobar la recompensa', variant: 'destructive' });
    } finally {
      setReviewingClaimId(null);
    }
  };

  const rejectRewardClaim = async (claim) => {
    setReviewingClaimId(claim.id);
    try {
      await base44.entities.RewardClaim.update(claim.id, { status: 'rechazado' });
      toast({ title: 'Solicitud de recompensa descartada' });
      await loadPendingRewardClaims();
    } catch {
      toast({ title: 'No se pudo descartar', variant: 'destructive' });
    } finally {
      setReviewingClaimId(null);
    }
  };

  const approvePurchase = async (tx) => {
    setReviewingPurchaseId(tx.id);
    try {
      await base44.entities.PointsTransaction.update(tx.id, {
        status: 'aprobado',
        type: 'compra_confirmada',
        amount: PURCHASE_POINTS,
        description: `Compra o servicio adquirido verificado por Central · ${tx.business_name || 'Anunciante'}`,
      });
      toast({
        title: `+${PURCHASE_POINTS} puntos aprobados y acreditados`,
        description: `Se acreditaron +${PURCHASE_POINTS} puntos a ${tx.user_name || 'el pasajero'} por su compra en ${tx.business_name || 'el negocio'}.`,
      });
      await loadPendingPurchases();
      if (selected?.id === tx.user_id) loadMoves();
    } catch {
      toast({ title: 'No se pudo aprobar la compra', variant: 'destructive' });
    } finally {
      setReviewingPurchaseId(null);
    }
  };

  const rejectPurchase = async (tx) => {
    setReviewingPurchaseId(tx.id);
    try {
      await base44.entities.PointsTransaction.update(tx.id, {
        status: 'rechazado',
        amount: 0,
      });
      toast({
        title: 'Solicitud descartada',
        description: `No se acreditaron puntos a ${tx.user_name || 'el pasajero'}.`,
      });
      await loadPendingPurchases();
      if (selected?.id === tx.user_id) loadMoves();
    } catch {
      toast({ title: 'No se pudo descartar la solicitud', variant: 'destructive' });
    } finally {
      setReviewingPurchaseId(null);
    }
  };

  const confirmTransfer = async (w) => {
    setConfirmingId(w.id);
    try {
      await base44.entities.PassengerWalletTx.update(w.id, {
        status: 'transferido',
        transferred_at: new Date().toISOString(),
      });
      if (w.incidence_id) {
        await base44.entities.Incidence.update(w.incidence_id, {
          status: 'resuelta',
          resolution: 'Puntos redimidos y transferencia realizada a la cuenta del cliente. Billetera en $0.',
          resolved_at: new Date().toISOString(),
        }).catch(() => {});
      }
      toast({
        title: 'Transferencia confirmada',
        description: `Se notificó a ${w.user_name || 'el cliente'} que sus puntos fueron redimidos y su billetera quedó en $0.`,
      });
      await loadWithdrawals();
    } catch {
      toast({ title: 'No se pudo confirmar la transferencia', variant: 'destructive' });
    } finally {
      setConfirmingId(null);
    }
  };

  const refreshDir = () => loadPassengerDirectory().then(setDirectory).catch(() => {});

  const filtered = query.trim()
    ? directory.filter((u) => (u.name + ' ' + u.email).toLowerCase().includes(query.trim().toLowerCase()))
    : directory;

  const loadMoves = useCallback(async () => {
    if (!selected) return;
    setLoadingMoves(true);
    try {
      const [agg, page] = await Promise.all([
        base44.entities.PointsTransaction.aggregate({ query: { user_id: selected.id }, sum: 'amount' }),
        base44.entities.PointsTransaction.filter({ user_id: selected.id }, { sort: '-created_date', limit: 30 }),
      ]);
      setBalance(agg.rows?.[0]?.sum_amount || 0);
      setMoves(page.items || []);
    } catch (e) {}
    setLoadingMoves(false);
  }, [selected]);

  useEffect(() => { if (selected) loadMoves(); }, [loadMoves]);

  const submit = async () => {
    if (!selected) return;
    const amount = Number(form.amount);
    if (!amount || amount <= 0) { toast({ title: 'Ingresa una cantidad válida de puntos.' }); return; }
    if (!form.business_name.trim()) { toast({ title: 'Indica el comercio que confirma la compra.' }); return; }
    setSaving(true);
    try {
      await base44.entities.PointsTransaction.create({
        user_id: selected.id,
        user_name: selected.name || 'Pasajero',
        amount,
        type: 'compra_confirmada',
        status: 'aprobado',
        business_name: form.business_name.trim(),
        description: form.description.trim() || 'Compra o servicio adquirido confirmado por ' + form.business_name.trim(),
      });
      toast({ title: 'Puntos acreditados', description: '+' + amount + ' puntos a ' + (selected.name || 'pasajero') + '.' });
      setForm({ amount: PURCHASE_POINTS, business_name: '', description: '' });
      loadMoves();
      refreshDir();
    } catch (e) {
      toast({ title: 'No se pudo acreditar', description: 'Intenta de nuevo.' });
    }
    setSaving(false);
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold text-white flex items-center gap-2">
          <Gift className="w-5 h-5 text-[#00E5FF]" /> Puntos y compras en publicidad
        </h1>
        <p className="text-sm text-[#8B95A8] mt-1">
          Aprueba y acredita +{PURCHASE_POINTS} puntos cuando el pasajero dé clic en el anuncio, interactúe con el negocio y adquiera el alimento, producto o servicio.
        </p>
      </div>

      {/* Cola de compras en publicidad pendientes por aprobar */}
      <div className="bg-[#11161d] rounded-2xl border border-amber-500/30 p-4 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <p className="text-sm font-bold text-white flex items-center gap-2">
            <Store className="w-4 h-4 text-amber-400" />
            Compras en publicidad pendientes por aprobar ({pendingPurchases.length})
          </p>
          <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-amber-500/15 text-amber-400">
            +{PURCHASE_POINTS} pts por compra confirmada
          </span>
        </div>
        {pendingPurchases.length === 0 ? (
          <p className="text-xs text-[#8B95A8] py-2">
            Cuando un pasajero toque una publicidad para preguntar y comprar por WhatsApp, aparecerá aquí para que Central apruebe sus +{PURCHASE_POINTS} puntos tras confirmar la compra.
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {pendingPurchases.map((p) => (
              <div key={p.id} className="bg-[#0c0f14] rounded-xl border border-white/10 p-3.5 flex flex-col justify-between gap-3">
                <div className="min-w-0 space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-bold text-white truncate">{p.user_name || 'Pasajero'}</p>
                    <span className="text-[10px] text-[#8B95A8] flex-shrink-0">
                      {fmtDate(p.created_date)} · {fmtTime(p.created_date)}
                    </span>
                  </div>
                  <p className="text-xs font-semibold text-amber-400 truncate">
                    Comercio: {p.business_name || 'Anunciante'}
                  </p>
                  {p.description && (
                    <p className="text-[11px] text-[#8B95A8] line-clamp-2">{p.description}</p>
                  )}
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    disabled={reviewingPurchaseId === p.id}
                    onClick={() => approvePurchase(p)}
                    className="flex-1 h-9 px-3 rounded-xl bg-[#00E676] text-slate-950 font-extrabold text-xs flex items-center justify-center gap-1.5 disabled:opacity-50"
                  >
                    {reviewingPurchaseId === p.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                    <span>Aprobar +{PURCHASE_POINTS} pts</span>
                  </button>
                  <button
                    type="button"
                    disabled={reviewingPurchaseId === p.id}
                    onClick={() => rejectPurchase(p)}
                    className="h-9 px-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 font-bold text-xs flex items-center justify-center gap-1 disabled:opacity-50"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>Descartar</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Cola de referidos pendientes por aprobar (+100 pts) */}
      <div className="bg-[#11161d] rounded-2xl border border-[#1E6BFF]/30 p-4 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <p className="text-sm font-bold text-white flex items-center gap-2">
            <Users className="w-4 h-4 text-[#00E5FF]" />
            Referidos pendientes por aprobar ({pendingReferrals.length})
          </p>
          <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-[#1E6BFF]/15 text-[#00E5FF]">
            +{REFERRAL_POINTS} pts por referido aprobado
          </span>
        </div>
        {pendingReferrals.length === 0 ? (
          <p className="text-xs text-[#8B95A8] py-2">
            Cuando un pasajero o conductor comparta su código/enlace y alguien se registre, aparecerá aquí para aprobar sus +{REFERRAL_POINTS} puntos.
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {pendingReferrals.map((r) => (
              <div key={r.id} className="bg-[#0c0f14] rounded-xl border border-white/10 p-3.5 flex flex-col justify-between gap-3">
                <div className="min-w-0 space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-bold text-white truncate">
                      Quien invitó: {r.user_name || `Código ${r.referrer_code}`}
                    </p>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#1E6BFF]/15 text-[#00E5FF] capitalize">
                      {r.referrer_scope || 'usuario'}
                    </span>
                  </div>
                  <p className="text-xs font-semibold text-amber-400 truncate">
                    Nuevo registrado: {r.referred_user_name || 'Usuario'} ({r.referred_role || 'pasajero'}) · Código: {r.referrer_code}
                  </p>
                  <p className="text-[11px] text-[#8B95A8]">
                    {fmtDate(r.created_date)} · {fmtTime(r.created_date)}
                  </p>
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    disabled={reviewingPurchaseId === r.id}
                    onClick={() => approveReferral(r)}
                    className="flex-1 h-9 px-3 rounded-xl bg-[#00E676] text-slate-950 font-extrabold text-xs flex items-center justify-center gap-1.5 disabled:opacity-50"
                  >
                    {reviewingPurchaseId === r.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                    <span>Aprobar referido (+{REFERRAL_POINTS} pts)</span>
                  </button>
                  <button
                    type="button"
                    disabled={reviewingPurchaseId === r.id}
                    onClick={() => rejectPurchase(r)}
                    className="h-9 px-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 font-bold text-xs flex items-center justify-center gap-1 disabled:opacity-50"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>Descartar</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Configuración de incentivos semanales de conductores (automáticos) */}
      <DriverRewardsConfigCard />

      {/* Cola de recompensas adquiridas por conductores y pasajeros */}
      <div className="bg-[#11161d] rounded-2xl border border-emerald-500/30 p-4 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <p className="text-sm font-bold text-white flex items-center gap-2">
            <Award className="w-4 h-4 text-emerald-400" />
            Recompensas adquiridas pendientes por entregar ({pendingRewardClaims.length})
          </p>
        </div>
        {pendingRewardClaims.length === 0 ? (
          <p className="text-xs text-[#8B95A8] py-2">
            Las recompensas reclamadas por conductores (racha de días conectado, metas de viajes) o pasajeros aparecerán aquí para aprobarlas y notificarles.
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {pendingRewardClaims.map((c) => (
              <div key={c.id} className="bg-[#0c0f14] rounded-xl border border-white/10 p-3.5 flex flex-col justify-between gap-3">
                <div className="min-w-0 space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-bold text-white truncate">
                      {c.mobile_name || c.user_name || (c.scope === 'conductor' ? 'Conductor' : 'Pasajero')}
                    </p>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 uppercase">
                      {c.scope}
                    </span>
                  </div>
                  <p className="text-xs font-semibold text-[#00E5FF] truncate">
                    Recompensa: {c.reward}
                  </p>
                  <p className="text-[11px] text-[#8B95A8]">
                    Meta: {c.goal_type} ({c.goal || ''}) · {fmtDate(c.created_date)}
                  </p>
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    disabled={reviewingClaimId === c.id}
                    onClick={() => approveRewardClaim(c)}
                    className="flex-1 h-9 px-3 rounded-xl bg-[#00E676] text-slate-950 font-extrabold text-xs flex items-center justify-center gap-1.5 disabled:opacity-50"
                  >
                    {reviewingClaimId === c.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                    <span>Aprobar y notificar</span>
                  </button>
                  <button
                    type="button"
                    disabled={reviewingClaimId === c.id}
                    onClick={() => rejectRewardClaim(c)}
                    className="h-9 px-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 font-bold text-xs flex items-center justify-center gap-1 disabled:opacity-50"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>Descartar</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {pendingWithdrawals.length > 0 && (
        <div className="bg-[#11161d] rounded-2xl border border-[#00E5FF]/30 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-sm font-bold text-white flex items-center gap-2">
              <Wallet className="w-4 h-4 text-[#00E5FF]" />
              Solicitudes de retiro de Billetera pendientes ({pendingWithdrawals.length})
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {pendingWithdrawals.map((w) => (
              <div key={w.id} className="bg-[#0c0f14] rounded-xl border border-white/10 p-3.5 flex items-start justify-between gap-3">
                <div className="min-w-0 space-y-0.5">
                  <p className="text-sm font-bold text-white">{w.user_name || 'Pasajero'}</p>
                  <p className="text-xs text-[#00E676] font-extrabold">
                    Valor a transferir: {fmtCOP(w.amount)} ({w.points_redeemed || Math.round((w.amount || 0) / 10)} pts)
                  </p>
                  <p className="text-xs text-[#8B95A8]">
                    {w.bank_type} · Cuenta/Celular: <span className="text-white font-semibold">{w.account_number}</span>
                  </p>
                  <p className="text-xs text-[#8B95A8]">
                    NIT / Cédula: <span className="text-white font-semibold">{w.holder_nit}</span> · Titular: {w.holder_name}
                  </p>
                </div>
                <button
                  type="button"
                  disabled={confirmingId === w.id}
                  onClick={() => confirmTransfer(w)}
                  className="h-9 px-3 rounded-xl bg-[#00E676] text-slate-950 font-extrabold text-xs flex items-center gap-1.5 flex-shrink-0 disabled:opacity-50"
                >
                  {confirmingId === w.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                  <span>Confirmar transferencia</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-5">
        {/* Buscador + selección */}
        <div className="lg:col-span-2 bg-[#11161d] rounded-2xl border border-white/8 p-4 space-y-3">
          <label className="text-[11px] font-bold text-[#5A6478] uppercase tracking-wider">Buscar pasajero</label>
          <div className="flex items-center gap-2 bg-[#0c0f14] rounded-xl px-3 h-10 border border-white/5">
            <Search className="w-4 h-4 text-[#5A6478]" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Nombre del pasajero"
              className="flex-1 bg-transparent text-sm text-white placeholder:text-[#5A6478] outline-none"
            />
            {loadingDir && <Loader2 className="w-4 h-4 text-[#5A6478] animate-spin" />}
          </div>

          {filtered.length > 0 && (
            <div className="space-y-1.5 max-h-72 overflow-y-auto thin-scroll">
              {filtered.map((u) => (
                <button key={u.id} onClick={() => setSelected(u)}
                  className={`w-full flex items-center gap-3 p-2.5 rounded-xl text-left transition-colors ${
                    selected?.id === u.id ? 'bg-[#1E6BFF]/15 border border-[#1E6BFF]/40' : 'bg-[#0c0f14] border border-white/5 hover:bg-white/5'
                  }`}>
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#1E6BFF] to-[#00E5FF] flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                    {(u.name || u.id || '?').charAt(0).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-white truncate">{u.name || 'Sin nombre'}</p>
                    <p className="text-[11px] text-[#5A6478] truncate">{u.email || 'Pasajero NEXT'}</p>
                  </div>
                  {selected?.id === u.id && <UserCheck className="w-4 h-4 text-[#00E5FF] flex-shrink-0" />}
                </button>
              ))}
            </div>
          )}
          {!loadingDir && filtered.length === 0 && (
            <p className="text-xs text-[#5A6478] py-4 text-center">
              {directory.length === 0 ? 'Aún no hay pasajeros con actividad.' : 'No se encontraron pasajeros.'}
            </p>
          )}

          {/* Formulario de acreditación */}
          {selected && (
            <div className="pt-3 mt-3 border-t border-white/8 space-y-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#00E5FF]" />
                <p className="text-sm font-bold text-white">Acreditar puntos</p>
              </div>
              <div>
                <label className="text-[10px] text-[#5A6478] font-medium">Puntos a acreditar</label>
                <input type="number" value={form.amount} onChange={(e) => setForm((f) => ({ ...f, amount: e.target.value }))}
                  className="mt-1 w-full h-10 bg-[#0c0f14] rounded-xl px-3 text-sm text-white border border-white/5 outline-none focus:border-[#1E6BFF]" />
              </div>
              <div>
                <label className="text-[10px] text-[#5A6478] font-medium">Comercio / anunciante</label>
                {adsList.length > 0 && (
                  <select
                    value={adsList.some((a) => a.business_name === form.business_name) ? form.business_name : ''}
                    onChange={(e) => e.target.value && setForm((f) => ({ ...f, business_name: e.target.value }))}
                    className="mt-1 mb-1.5 w-full h-10 bg-[#0c0f14] rounded-xl px-3 text-sm text-white border border-white/5 outline-none focus:border-[#1E6BFF]"
                  >
                    <option value="">Seleccionar anunciante activo...</option>
                    {Array.from(new Set(adsList.map((a) => a.business_name).filter(Boolean))).map((name) => (
                      <option key={name} value={name}>{name}</option>
                    ))}
                  </select>
                )}
                <input value={form.business_name} onChange={(e) => setForm((f) => ({ ...f, business_name: e.target.value }))}
                  placeholder="Ej. Comidas El Punto del Sabor"
                  className="mt-1 w-full h-10 bg-[#0c0f14] rounded-xl px-3 text-sm text-white border border-white/5 outline-none focus:border-[#1E6BFF]" />
              </div>
              <div>
                <label className="text-[10px] text-[#5A6478] font-medium">Detalle (opcional)</label>
                <textarea value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                  placeholder="Referencia del comprobante, observaciones..."
                  rows={2}
                  className="mt-1 w-full bg-[#0c0f14] rounded-xl px-3 py-2 text-sm text-white border border-white/5 outline-none focus:border-[#1E6BFF] resize-none" />
              </div>
              <button onClick={submit} disabled={saving}
                className="w-full h-11 rounded-xl bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white font-bold flex items-center justify-center gap-2 disabled:opacity-50">
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Send className="w-4 h-4" /> Acreditar puntos</>}
              </button>
            </div>
          )}
        </div>

        {/* Detalle del pasajero seleccionado */}
        <div className="lg:col-span-3 space-y-4">
          {!selected ? (
            <div className="bg-[#11161d] rounded-2xl border border-white/8 p-10 text-center">
              <div className="w-14 h-14 rounded-2xl bg-[#1E6BFF]/10 flex items-center justify-center mx-auto mb-3">
                <Coins className="w-6 h-6 text-[#00E5FF]" />
              </div>
              <p className="text-sm font-semibold text-white">Selecciona un pasajero</p>
              <p className="text-xs text-[#5A6478] mt-1">Busca por nombre para ver y acreditar sus puntos.</p>
              <div className="mt-5 flex items-center justify-center gap-4 text-[11px] text-[#5A6478]">
                <span className="flex items-center gap-1.5"><TrendingUp className="w-3.5 h-3.5 text-emerald-400" /> Adquirir alimento, producto o servicio del anunciante: +{PURCHASE_POINTS} puntos</span>
              </div>
            </div>
          ) : (
            <>
              {/* Tarjeta de saldo */}
              <div className="bg-gradient-to-br from-[#1E6BFF] to-[#0a3aa8] rounded-2xl p-5 text-white">
                <p className="text-white/70 text-xs uppercase tracking-wider">Saldo del pasajero</p>
                <div className="flex items-end justify-between mt-1">
                  <div>
                    <p className="text-3xl font-extrabold">{(balance || 0).toLocaleString('es-CO')}</p>
                    <p className="text-sm font-semibold mt-1">{selected.name || 'Sin nombre'}</p>
                    <p className="text-[11px] text-white/70">{selected.email || 'Pasajero NEXT'}</p>
                  </div>
                  <Sparkles className="w-8 h-8 text-[#00E5FF]" />
                </div>
              </div>

              {/* Historial */}
              <div className="bg-[#11161d] rounded-2xl border border-white/8 p-4">
                <p className="text-[11px] font-bold text-[#5A6478] uppercase tracking-wider mb-3">Movimientos recientes</p>
                {loadingMoves ? (
                  <div className="flex justify-center py-8"><Loader2 className="w-5 h-5 text-[#5A6478] animate-spin" /></div>
                ) : moves.length === 0 ? (
                  <p className="text-sm text-[#5A6478] py-8 text-center">Sin movimientos registrados.</p>
                ) : (
                  <div className="space-y-2">
                    {moves.map((m) => {
                      const meta = TYPE_META[m.type] || TYPE_META.ajuste;
                      const positive = m.amount >= 0;
                      return (
                        <div key={m.id} className="flex items-center gap-3 bg-[#0c0f14] rounded-xl p-3 border border-white/5">
                          <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${meta.tone}`}>
                            <TrendingUp className={`w-4 h-4 ${positive ? '' : 'rotate-180'}`} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-semibold text-white truncate">{meta.label}</p>
                            <p className="text-[11px] text-[#5A6478] truncate">
                              {m.business_name ? m.business_name + ' · ' : ''}{fmtDate(m.created_date)} · {fmtTime(m.created_date)}
                            </p>
                          </div>
                          <span className={`text-sm font-extrabold flex-shrink-0 ${positive ? 'text-emerald-400' : 'text-amber-400'}`}>
                            {positive ? '+' : ''}{m.amount}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
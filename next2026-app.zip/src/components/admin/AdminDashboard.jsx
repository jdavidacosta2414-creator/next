import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { FileText, Users, Bike, DollarSign, Loader2, ClipboardList, Star, MapPin } from 'lucide-react';

const fmtCOP = (n) => 'COP ' + Number(n || 0).toLocaleString('es-CO', { minimumFractionDigits: 0 });
const today = () => new Date().toISOString().split('T')[0];

// Dashboard del panel administrativo: métricas clave + áreas de gráficas.
export default function AdminDashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [services, mobiles, users] = await Promise.all([
          base44.entities.Service.list('-created_date', 200),
          base44.entities.Mobile.list(),
          base44.entities.User.list(),
        ]);
        const todaySvcs = services.filter(s => s.created_date?.startsWith(today()));
        const finalized = todaySvcs.filter(s => s.status === 'finalizado');
        const activeNow = mobiles.filter(m => m.status !== 'offline');
        const disponibles = mobiles.filter(m => m.status === 'disponible').length;
        const ingresos = finalized.reduce((sum, s) => sum + (s.collected_amount || s.fare || 5000), 0);
        setData({
          viajesTotales: todaySvcs.length,
          usuarios: users.length,
          conductoresActivos: activeNow.length,
          disponiblesAhora: disponibles,
          ingresosTotales: ingresos,
        });
      } catch (e) {
        console.error('Admin dashboard load error:', e);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  if (loading) {
    return <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-[#1E6BFF]" /></div>;
  }

  const d = data || {};
  const metrics = [
    { icon: FileText, value: d.viajesTotales, label: 'Viajes totales', sub: '0% vs 7 días previos', accent: 'text-[#1E6BFF]' },
    { icon: Users, value: d.usuarios, label: 'Usuarios registrados', sub: '0% vs 7 días previos', accent: 'text-[#00E5FF]' },
    { icon: Bike, value: d.conductoresActivos, label: 'Conductores activos', sub: d.disponiblesAhora + ' disponibles ahora', accent: 'text-[#00E676]' },
    { icon: DollarSign, value: fmtCOP(d.ingresosTotales), label: 'Ingresos totales', sub: '0% vs 7 días previos', accent: 'text-amber-400' },
  ];

  return (
    <div className="space-y-5">
      {/* Encabezado */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold text-white">Centro ejecutivo de operaciones</h1>
          <p className="text-sm text-[#8B95A8] mt-0.5">Indicadores comerciales, operativos y de crecimiento actualizados en tiempo real.</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="h-9 px-4 rounded-lg bg-[#161b22] border border-white/8 text-[#8B95A8] text-sm font-medium hover:bg-white/5">Últimos 7 días</button>
          <span className="flex items-center gap-1.5 h-9 px-3 rounded-lg bg-[#00E676]/10 text-[#00E676] text-sm font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00E676] animate-pulse" /> En vivo
          </span>
        </div>
      </div>

      {/* Tarjetas de métricas */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
        {metrics.map((m, i) => {
          const Icon = m.icon;
          return (
            <div key={i} className="bg-[#161b22] rounded-xl p-4 border border-white/8">
              <div className={'w-9 h-9 rounded-lg flex items-center justify-center mb-3 bg-white/5 ' + m.accent}>
                <Icon className="w-5 h-5" />
              </div>
              <p className="text-2xl font-bold text-white leading-none">{m.value}</p>
              <p className="text-xs text-[#8B95A8] mt-1.5">{m.label}</p>
              <p className="text-[11px] text-[#5A6478] mt-0.5">{m.sub}</p>
            </div>
          );
        })}
      </div>

      {/* Gráficas y widgets */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Viajes — gráfica grande */}
        <div className="lg:col-span-2 bg-[#161b22] rounded-xl p-5 border border-white/8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white">Viajes</h3>
              <p className="text-xs text-[#5A6478] mt-0.5">Volumen diario de los últimos 7 días</p>
            </div>
            <span className="text-sm font-bold text-[#00E5FF]">{fmtCOP(d.ingresosTotales)}</span>
          </div>
          <div className="h-48 flex items-end justify-between gap-2">
            {[40, 65, 35, 80, 55, 70, 45].map((h, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-1.5">
                <div className="w-full rounded-t-md transition-all hover:opacity-80" style={{ height: h + '%', background: 'linear-gradient(to top, #1E6BFF, #00E5FF)' }} />
                <span className="text-[10px] text-[#5A6478]">{['L', 'M', 'X', 'J', 'V', 'S', 'D'][i]}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Viajes por estado */}
        <div className="bg-[#161b22] rounded-xl p-5 border border-white/8 flex flex-col items-center justify-center text-center">
          <ClipboardList className="w-10 h-10 text-[#5A6478] mb-3" />
          <h3 className="text-sm font-bold text-white mb-1">Viajes por estado</h3>
          <p className="text-xs text-[#5A6478]">Aún no hay viajes para graficar.</p>
        </div>

        {/* Ingresos */}
        <div className="lg:col-span-2 bg-[#161b22] rounded-xl p-5 border border-white/8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white">Ingresos</h3>
              <p className="text-xs text-[#5A6478] mt-0.5">Facturación por día</p>
            </div>
            <span className="text-sm font-bold text-[#00E676]">+ {fmtCOP(d.ingresosTotales)}</span>
          </div>
          <div className="h-40 flex items-end justify-between gap-2">
            {[30, 50, 40, 70, 60, 85, 55].map((h, i) => (
              <div key={i} className="flex-1 rounded-t-md transition-all hover:opacity-80" style={{ height: h + '%', background: 'linear-gradient(to top, #00E676, #00E5FF)' }} />
            ))}
          </div>
        </div>

        {/* Top conductores */}
        <div className="bg-[#161b22] rounded-xl p-5 border border-white/8 flex flex-col items-center justify-center text-center">
          <Star className="w-10 h-10 text-[#5A6478] mb-3" />
          <h3 className="text-sm font-bold text-white mb-1">Top conductores</h3>
          <p className="text-xs text-[#5A6478]">No hay conductores para rankear.</p>
        </div>

        {/* Viajes por servicio */}
        <div className="lg:col-span-3 bg-[#161b22] rounded-xl p-5 border border-white/8 flex flex-col items-center justify-center text-center py-10">
          <MapPin className="w-10 h-10 text-[#5A6478] mb-3" />
          <h3 className="text-sm font-bold text-white mb-1">Viajes por servicio</h3>
          <p className="text-xs text-[#5A6478]">No hay servicios con viajes registrados.</p>
        </div>
      </div>
    </div>
  );
}
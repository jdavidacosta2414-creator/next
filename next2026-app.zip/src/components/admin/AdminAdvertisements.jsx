import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, Plus, Pencil, Trash2, X, Upload, MessageCircle, Star, StarOff, CalendarClock, Wallet, MousePointerClick, Tag } from 'lucide-react';

const EMPTY = {
  business_name: '', whatsapp_number: '', business_email: '', business_address: '',
  offer_badge: '', offer_title: '', category: '', cta_text: 'Ver oferta',
  image_url: '', active: true,
  start_date: '', end_date: '',
  payment_amount: 0, payment_method: '', payment_date: '', payment_notes: '',
};

const PAYMENT_METHODS = [
  { value: 'nequi', label: 'Nequi' },
  { value: 'daviplata', label: 'Daviplata' },
  { value: 'bancolombia', label: 'Bancolombia' },
  { value: 'efectivo', label: 'Efectivo' },
  { value: 'transferencia', label: 'Transferencia' },
  { value: 'otro', label: 'Otro' },
];

const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');
const todayStr = () => new Date().toISOString().slice(0, 10);
const addDays = (str, days) => {
  const d = str ? new Date(str + 'T00:00:00') : new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
};

// Estado de vigencia de una publicidad según sus fechas.
function adStatus(ad) {
  const t = todayStr();
  if (ad.start_date && t < ad.start_date) return 'programada';
  if (ad.end_date && t > ad.end_date) return 'vencida';
  return 'vigente';
}

// Sección "Publicidad Negocio" del panel admin: crea, edita, activa/desactiva
// y elimina los banners que ven los pasajeros. Lleva la vigencia por fechas
// (suscripción mensual) y el control de los pagos de cada negocio.
export default function AdminAdvertisements() {
  const { toast } = useToast();
  const [ads, setAds] = useState([]);
  const [stats, setStats] = useState({ rows: [], total: 0 });
  const [clicksByAd, setClicksByAd] = useState({});
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null); // null | 'new' | ad object
  const [form, setForm] = useState(EMPTY);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef(null);

  const load = async () => {
    try {
      const page = await base44.entities.Advertisement.filter({}, { sort: '-created_date', limit: 100 });
      setAds(page.items || []);
    } catch (e) {}
    setLoading(false);
  };

  const loadStats = async () => {
    try {
      const res = await base44.entities.Advertisement.aggregate({
        groupBy: 'business_name',
        sum: ['payment_amount'],
        sort: '-sum_payment_amount',
        limit: 100,
      });
      const rows = (res.rows || []).map((r) => ({ name: r.business_name, count: r.count, total: r.sum_payment_amount || 0 }));
      const total = rows.reduce((s, r) => s + (r.total || 0), 0);
      setStats({ rows, total });
    } catch (e) {}
  };

  const loadClicks = async () => {
    try {
      const res = await base44.entities.PointsTransaction.aggregate({
        query: { type: { $in: ['interaccion_click', 'compra_confirmada'] } },
        groupBy: 'advertisement_id',
        limit: 200,
      });
      const map = {};
      (res.rows || []).forEach((r) => {
        if (r.advertisement_id) map[r.advertisement_id] = r.count || 0;
      });
      setClicksByAd(map);
    } catch (e) {}
  };

  useEffect(() => {
    load();
    loadStats();
    loadClicks();
    const unsub = base44.entities.Advertisement.subscribe(() => {
      load().catch(() => {});
      loadStats().catch(() => {});
      loadClicks().catch(() => {});
    });
    return unsub;
  }, []);

  const openNew = () => {
    const start = todayStr();
    setForm({ ...EMPTY, start_date: start, end_date: addDays(start, 30) });
    setEditing('new');
  };
  const openEdit = (ad) => { setForm({ ...EMPTY, ...ad }); setEditing(ad); };

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      // El banner se muestra a pasajeros (incluso por link sin login): almacenamiento público.
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      set('image_url', file_url);
    } catch (err) {
      toast({ description: 'No se pudo subir la imagen.', variant: 'destructive' });
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const save = async () => {
    if (!form.business_name || !form.whatsapp_number || !form.image_url) {
      toast({ description: 'Completa nombre, WhatsApp e imagen.', variant: 'destructive' });
      return;
    }
    setSaving(true);
    try {
      const payload = {
        business_name: form.business_name,
        whatsapp_number: form.whatsapp_number,
        business_email: form.business_email || null,
        business_address: form.business_address || null,
        offer_badge: form.offer_badge || null,
        offer_title: form.offer_title || null,
        category: form.category || null,
        cta_text: form.cta_text || null,
        image_url: form.image_url,
        active: form.active,
        start_date: form.start_date || null,
        end_date: form.end_date || null,
        payment_amount: Number(form.payment_amount) || 0,
        payment_method: form.payment_method || null,
        payment_date: form.payment_date || null,
        payment_notes: form.payment_notes || null,
      };
      if (editing === 'new') {
        await base44.entities.Advertisement.create(payload);
      } else {
        await base44.entities.Advertisement.update(editing.id, payload);
      }
      toast({ description: 'Publicidad guardada.' });
      setEditing(null);
      setForm(EMPTY);
      load();
      loadStats();
    } catch (e) {
      toast({ description: 'No se pudo guardar.', variant: 'destructive' });
    }
    setSaving(false);
  };

  const toggleActive = async (ad) => {
    try {
      await base44.entities.Advertisement.update(ad.id, { active: !ad.active });
      load();
    } catch (e) { toast({ description: 'No se pudo actualizar.', variant: 'destructive' }); }
  };

  const remove = async (ad) => {
    if (!confirm(`¿Eliminar la publicidad de "${ad.business_name}"?`)) return;
    try {
      await base44.entities.Advertisement.delete(ad.id);
      toast({ description: 'Publicidad eliminada.' });
      load();
      loadStats();
    } catch (e) { toast({ description: 'No se pudo eliminar.', variant: 'destructive' }); }
  };

  const waLink = (number, name) => {
    const digits = (number || '').replace(/\D/g, '');
    const text = encodeURIComponent(`Hola ${name || ''}, vengo de la app NEXT y quiero información de sus servicios.`);
    return `https://wa.me/${digits}?text=${text}`;
  };

  const activeCount = ads.filter((a) => a.active && adStatus(a) === 'vigente').length;
  const expiredCount = ads.filter((a) => adStatus(a) === 'vencida').length;
  const scheduledCount = ads.filter((a) => adStatus(a) === 'programada').length;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">Publicidad Negocio</h2>
          <p className="text-sm text-[#8B95A8]">Crea los banners que ven los pasajeros. Lleva la vigencia y el pago de cada negocio.</p>
        </div>
        <button onClick={openNew}
          className="inline-flex items-center gap-2 h-10 px-4 rounded-lg bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white font-bold text-sm shadow-lg">
          <Plus className="w-4 h-4" /> Crear publicidad
        </button>
      </div>

      {/* Resumen de control: recaudo total y estado de las publicidades */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <SummaryCard icon={<Wallet className="w-4 h-4" />} label="Total recaudado" value={fmtCOP(stats.total)} accent="from-[#1E6BFF] to-[#00E5FF]" />
        <SummaryCard icon={<Star className="w-4 h-4" />} label="Vigentes" value={activeCount} accent="from-green-500 to-emerald-500" />
        <SummaryCard icon={<CalendarClock className="w-4 h-4" />} label="Programadas" value={scheduledCount} accent="from-amber-500 to-orange-500" />
        <SummaryCard icon={<StarOff className="w-4 h-4" />} label="Vencidas" value={expiredCount} accent="from-red-500 to-rose-500" />
      </div>

      {/* Control por negocio: cuántas publicidades y cuánto pagó cada uno */}
      {stats.rows.length > 0 && (
        <div className="bg-[#0f1419] border border-white/8 rounded-xl overflow-hidden">
          <div className="px-4 py-3 border-b border-white/8">
            <p className="text-sm font-bold text-white">Control por negocio</p>
            <p className="text-[11px] text-[#5A6478]">Total pagado y cantidad de publicidades por negocio.</p>
          </div>
          <div className="divide-y divide-white/5">
            {stats.rows.map((r) => (
              <div key={r.name} className="flex items-center justify-between px-4 py-2.5">
                <div className="min-w-0">
                  <p className="text-sm text-white truncate">{r.name}</p>
                  <p className="text-[11px] text-[#5A6478]">{r.count} {r.count === 1 ? 'publicidad' : 'publicidades'}</p>
                </div>
                <p className="text-sm font-bold text-[#00E5FF] flex-shrink-0">{fmtCOP(r.total)}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex flex-col items-center justify-center h-40 text-[#5A6478]">
          <Loader2 className="w-6 h-6 animate-spin mb-2" />
          <p className="text-sm">Cargando...</p>
        </div>
      ) : ads.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-60 text-[#5A6478]">
          <MessageCircle className="w-10 h-10 mb-3 text-[#2a313d]" />
          <p className="text-sm font-medium text-white mb-1">Sin publicidad</p>
          <p className="text-xs">Crea tu primera publicidad para que los pasajeros la vean.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
          {ads.map((ad) => {
            const status = adStatus(ad);
            const statusStyle = status === 'vigente' ? 'bg-green-500/85 text-white'
              : status === 'programada' ? 'bg-amber-500/85 text-white'
              : 'bg-red-500/85 text-white';
            return (
              <div key={ad.id} className="bg-[#0f1419] border border-white/8 rounded-xl overflow-hidden">
                <div className="relative h-32 bg-[#161b22]">
                  {ad.image_url ? (
                    <img src={ad.image_url} alt={ad.business_name} className="w-full h-full object-contain" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-[#5A6478] text-xs">Sin imagen</div>
                  )}
                  <span className={`absolute top-2 left-2 text-[10px] font-bold px-2 py-0.5 rounded-full ${ad.active ? statusStyle : 'bg-black/60 text-[#8B95A8]'}`}>
                    {!ad.active ? 'Pausada' : status === 'vigente' ? 'Vigente' : status === 'programada' ? 'Programada' : 'Vencida'}
                  </span>
                  {ad.payment_amount > 0 && (
                    <span className="absolute top-2 right-2 text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#1E6BFF]/85 text-white">
                      {fmtCOP(ad.payment_amount)}
                    </span>
                  )}
                </div>
                <div className="p-3">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-bold text-white truncate">{ad.business_name}</p>
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-sky-500/15 text-[#00E5FF] flex-shrink-0">
                      <MousePointerClick className="w-3 h-3" />
                      {clicksByAd[ad.id] || 0} clics
                    </span>
                  </div>
                  {(ad.offer_badge || ad.offer_title) && (
                    <p className="text-xs font-semibold text-amber-400 truncate mt-0.5">
                      <Tag className="w-3 h-3 inline mr-1 -mt-0.5" />
                      {[ad.offer_badge, ad.offer_title].filter(Boolean).join(' · ')}
                    </p>
                  )}
                  <p className="text-[11px] text-[#5A6478] truncate">{ad.whatsapp_number}{ad.business_address ? ` · ${ad.business_address}` : ''}</p>
                  {(ad.start_date || ad.end_date) && (
                    <p className="text-[11px] text-[#8B95A8] mt-0.5 truncate">
                      <CalendarClock className="w-3 h-3 inline mr-1 -mt-0.5" />
                      {ad.start_date || '—'} al {ad.end_date || '—'}
                    </p>
                  )}
                  {ad.business_email && <p className="text-[11px] text-[#5A6478] truncate">{ad.business_email}</p>}
                  <div className="flex items-center gap-2 mt-3">
                    <button onClick={() => openEdit(ad)} className="flex-1 h-8 rounded-lg bg-white/5 text-white text-xs font-medium flex items-center justify-center gap-1 hover:bg-white/10">
                      <Pencil className="w-3.5 h-3.5" /> Editar
                    </button>
                    <button onClick={() => toggleActive(ad)} title={ad.active ? 'Pausar' : 'Activar'}
                      className="h-8 px-2.5 rounded-lg bg-white/5 text-[#8B95A8] hover:text-white flex items-center justify-center">
                      {ad.active ? <StarOff className="w-3.5 h-3.5" /> : <Star className="w-3.5 h-3.5 text-amber-400" />}
                    </button>
                    <button onClick={() => remove(ad)} title="Eliminar"
                      className="h-8 px-2.5 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 flex items-center justify-center">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal crear/editar */}
      {editing && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setEditing(null)} />
          <div className="relative w-full max-w-lg max-h-[90vh] overflow-y-auto thin-scroll bg-[#0f1419] border border-white/10 rounded-2xl shadow-2xl">
            <div className="flex items-center justify-between p-5 border-b border-white/8 sticky top-0 bg-[#0f1419]">
              <h3 className="text-lg font-bold text-white">{editing === 'new' ? 'Crear publicidad' : 'Editar publicidad'}</h3>
              <button onClick={() => setEditing(null)} className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-[#8B95A8] hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              {/* Imagen del banner */}
              <div>
                <p className="text-[10px] font-bold text-[#5A6478] tracking-wider mb-2">IMAGEN DEL BANNER</p>
                <p className="text-[11px] text-[#8B95A8] mb-2">Usa una imagen alargada 16:5 (por ejemplo 1600 × 500 px) para que llene todo el recuadro del banner.</p>
                <div className="flex items-center gap-3">
                  <div className="w-40 h-24 rounded-xl bg-[#161b22] border border-white/8 overflow-hidden flex items-center justify-center flex-shrink-0">
                    {form.image_url ? (
                      <img src={form.image_url} alt="banner" className="w-full h-full object-contain" />
                    ) : uploading ? (
                      <Loader2 className="w-6 h-6 animate-spin text-[#8B95A8]" />
                    ) : (
                      <span className="text-xs text-[#5A6478]">Sin imagen</span>
                    )}
                  </div>
                  <div className="flex flex-col gap-2" data-photo-picker="true">
                    <div
                      className={`relative overflow-hidden inline-flex items-center gap-2 h-9 px-3 rounded-lg border border-[#1E6BFF]/40 text-[#1E6BFF] text-xs font-medium cursor-pointer ${
                        uploading ? 'opacity-50 pointer-events-none' : ''
                      }`}
                    >
                      <Upload className="w-3.5 h-3.5" /> {uploading ? 'Subiendo...' : 'Subir imagen'}
                      <input
                        ref={fileRef}
                        type="file"
                        accept="image/*"
                        onChange={handleFile}
                        disabled={uploading}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                      />
                    </div>
                    {form.image_url && (
                      <button type="button" onClick={() => set('image_url', '')}
                        className="text-xs text-red-400 hover:text-red-300">Quitar imagen</button>
                    )}
                  </div>
                </div>
              </div>

              <Field label="NOMBRE DEL NEGOCIO">
                <input value={form.business_name} onChange={(e) => set('business_name', e.target.value)} placeholder="Ej. Restaurante Vegetariano"
                  className="w-full h-11 bg-[#161b22] rounded-xl px-3 text-sm text-white placeholder:text-[#5A6478] outline-none border border-white/8 focus:border-[#1E6BFF]/40" />
              </Field>

              <Field label="NÚMERO DE WHATSAPP">
                <input value={form.whatsapp_number} onChange={(e) => set('whatsapp_number', e.target.value)} placeholder="573001234567"
                  className="w-full h-11 bg-[#161b22] rounded-xl px-3 text-sm text-white placeholder:text-[#5A6478] outline-none border border-white/8 focus:border-[#1E6BFF]/40" />
              </Field>

              <Field label="CORREOS DEL NEGOCIO">
                <input value={form.business_email} onChange={(e) => set('business_email', e.target.value)} placeholder="negocio@email.com, ventas@email.com"
                  className="w-full h-11 bg-[#161b22] rounded-xl px-3 text-sm text-white placeholder:text-[#5A6478] outline-none border border-white/8 focus:border-[#1E6BFF]/40" />
              </Field>

              <Field label="DIRECCIÓN DEL NEGOCIO">
                <input value={form.business_address} onChange={(e) => set('business_address', e.target.value)} placeholder="Cra 12 # 34-56"
                  className="w-full h-11 bg-[#161b22] rounded-xl px-3 text-sm text-white placeholder:text-[#5A6478] outline-none border border-white/8 focus:border-[#1E6BFF]/40" />
              </Field>

              {/* Oferta atractiva y llamado a la acción */}
              <div className="rounded-xl border border-amber-500/20 p-3 space-y-3 bg-[#0b0f14]">
                <p className="text-[10px] font-bold text-amber-400 tracking-wider">OFERTA DESTACADA Y LLAMADO A LA ACCIÓN (PARA ATRAER MÁS CLICS)</p>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <p className="text-[11px] text-[#8B95A8] mb-1">Etiqueta corta (ej. 2x1 HOY)</p>
                    <input value={form.offer_badge || ''} onChange={(e) => set('offer_badge', e.target.value)} placeholder="2x1 HOY / 15% DTO"
                      className="w-full h-11 bg-[#161b22] rounded-xl px-3 text-sm text-white placeholder:text-[#5A6478] outline-none border border-white/8 focus:border-[#1E6BFF]/40" />
                  </div>
                  <div>
                    <p className="text-[11px] text-[#8B95A8] mb-1">Categoría</p>
                    <input value={form.category || ''} onChange={(e) => set('category', e.target.value)} placeholder="Comidas rápidas, Café..."
                      className="w-full h-11 bg-[#161b22] rounded-xl px-3 text-sm text-white placeholder:text-[#5A6478] outline-none border border-white/8 focus:border-[#1E6BFF]/40" />
                  </div>
                </div>
                <div>
                  <p className="text-[11px] text-[#8B95A8] mb-1">Título de la oferta en el banner</p>
                  <input value={form.offer_title || ''} onChange={(e) => set('offer_title', e.target.value)} placeholder="Ej. 2x1 en Hamburguesas + Domicilio gratis"
                    className="w-full h-11 bg-[#161b22] rounded-xl px-3 text-sm text-white placeholder:text-[#5A6478] outline-none border border-white/8 focus:border-[#1E6BFF]/40" />
                </div>
                <div>
                  <p className="text-[11px] text-[#8B95A8] mb-1">Texto del botón (CTA)</p>
                  <input value={form.cta_text || ''} onChange={(e) => set('cta_text', e.target.value)} placeholder="Ver oferta / Reclamar descuento / Pedir ahora"
                    className="w-full h-11 bg-[#161b22] rounded-xl px-3 text-sm text-white placeholder:text-[#5A6478] outline-none border border-white/8 focus:border-[#1E6BFF]/40" />
                </div>
              </div>

              {/* Vigencia de la publicidad */}
              <div className="rounded-xl border border-white/8 p-3 space-y-3 bg-[#0b0f14]">
                <div className="flex items-center justify-between">
                  <p className="text-[10px] font-bold text-[#5A6478] tracking-wider">VIGENCIA DE LA PUBLICIDAD</p>
                  <button type="button" onClick={() => {
                    const start = form.start_date || todayStr();
                    set('start_date', start);
                    set('end_date', addDays(start, 30));
                  }}
                    className="text-[11px] font-medium text-[#1E6BFF] hover:underline">
                    30 días (suscripción mensual)
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <p className="text-[11px] text-[#8B95A8] mb-1">Desde</p>
                    <input type="date" value={form.start_date || ''} onChange={(e) => set('start_date', e.target.value)}
                      className="w-full h-11 bg-[#161b22] rounded-xl px-3 text-sm text-white outline-none border border-white/8 focus:border-[#1E6BFF]/40" />
                  </div>
                  <div>
                    <p className="text-[11px] text-[#8B95A8] mb-1">Hasta</p>
                    <input type="date" value={form.end_date || ''} onChange={(e) => set('end_date', e.target.value)}
                      className="w-full h-11 bg-[#161b22] rounded-xl px-3 text-sm text-white outline-none border border-white/8 focus:border-[#1E6BFF]/40" />
                  </div>
                </div>
                {form.start_date && form.end_date && (
                  <p className="text-[11px] text-[#5A6478]">
                    {Math.round((new Date(form.end_date + 'T00:00:00') - new Date(form.start_date + 'T00:00:00')) / 86400000) + 1} días de vigencia.
                  </p>
                )}
              </div>

              {/* Pago de la suscripción */}
              <div className="rounded-xl border border-white/8 p-3 space-y-3 bg-[#0b0f14]">
                <p className="text-[10px] font-bold text-[#5A6478] tracking-wider">PAGO DE LA SUSCRIPCIÓN</p>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <p className="text-[11px] text-[#8B95A8] mb-1">Monto pagado (COP)</p>
                    <input type="number" min="0" value={form.payment_amount || ''} onChange={(e) => set('payment_amount', e.target.value)} placeholder="30000"
                      className="w-full h-11 bg-[#161b22] rounded-xl px-3 text-sm text-white placeholder:text-[#5A6478] outline-none border border-white/8 focus:border-[#1E6BFF]/40" />
                  </div>
                  <div>
                    <p className="text-[11px] text-[#8B95A8] mb-1">Fecha del pago</p>
                    <input type="date" value={form.payment_date || ''} onChange={(e) => set('payment_date', e.target.value)}
                      className="w-full h-11 bg-[#161b22] rounded-xl px-3 text-sm text-white outline-none border border-white/8 focus:border-[#1E6BFF]/40" />
                  </div>
                </div>
                <div>
                  <p className="text-[11px] text-[#8B95A8] mb-1">Método de pago</p>
                  <select value={form.payment_method || ''} onChange={(e) => set('payment_method', e.target.value)}
                    className="w-full h-11 bg-[#161b22] rounded-xl px-3 text-sm text-white outline-none border border-white/8 focus:border-[#1E6BFF]/40">
                    <option value="">Selecciona...</option>
                    {PAYMENT_METHODS.map((m) => <option key={m.value} value={m.value}>{m.label}</option>)}
                  </select>
                </div>
                <div>
                  <p className="text-[11px] text-[#8B95A8] mb-1">Notas del pago (opcional)</p>
                  <input value={form.payment_notes || ''} onChange={(e) => set('payment_notes', e.target.value)} placeholder="Referencia, observaciones..."
                    className="w-full h-11 bg-[#161b22] rounded-xl px-3 text-sm text-white placeholder:text-[#5A6478] outline-none border border-white/8 focus:border-[#1E6BFF]/40" />
                </div>
              </div>

              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={form.active} onChange={(e) => set('active', e.target.checked)} className="w-4 h-4 accent-[#1E6BFF]" />
                <span className="text-sm text-white">Publicidad activa (visible para pasajeros)</span>
              </label>

              {form.image_url && form.whatsapp_number && (
                <a href={waLink(form.whatsapp_number, form.business_name)} target="_blank" rel="noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs text-[#25D366]">
                  <MessageCircle className="w-3.5 h-3.5" /> Probar enlace de WhatsApp
                </a>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 p-5 border-t border-white/8 sticky bottom-0 bg-[#0f1419]">
              <button onClick={() => setEditing(null)} className="h-10 px-4 rounded-lg bg-white/5 text-white text-sm font-medium hover:bg-white/10">Cancelar</button>
              <button onClick={save} disabled={saving}
                className="h-10 px-5 rounded-lg bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white font-bold text-sm disabled:opacity-50">
                {saving ? 'Guardando...' : 'Guardar'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function SummaryCard({ icon, label, value, accent }) {
  return (
    <div className="bg-[#0f1419] border border-white/8 rounded-xl p-3">
      <div className={`inline-flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-br ${accent} text-white mb-2`}>{icon}</div>
      <p className="text-[11px] text-[#8B95A8]">{label}</p>
      <p className="text-lg font-bold text-white">{value}</p>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <p className="text-[10px] font-bold text-[#5A6478] tracking-wider mb-1.5">{label}</p>
      {children}
    </div>
  );
}
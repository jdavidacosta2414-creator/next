import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Store, Loader2, Copy, KeyRound, Plus } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { generateNegocioKey } from '@/lib/negociosKey';
import NegociosConexionCard from '@/components/admin/NegociosConexionCard';
import NegociosPortalCard from '@/components/admin/NegociosPortalCard';

const PORTAL_NAME = 'Portal NEXT Negocios';

const inputCls =
  'h-10 rounded-xl bg-[#0c0f14] border border-white/8 px-3 text-sm text-white placeholder:text-[#5A6478] outline-none focus:border-[#00E5FF]/40';

export default function AdminNegocios() {
  const [partners, setPartners] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ name: '', phone: '', address: '' });
  const [busy, setBusy] = useState(false);
  const [shownKey, setShownKey] = useState(null);

  const load = async () => {
    const res = await base44.entities.BusinessPartner.list('-created_date', 200);
    setPartners(Array.isArray(res) ? res : res?.items || []);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  // La conexión del portal usa una sola clave; los demás registros son los comercios.
  const portal = partners.find((p) => p.is_portal);
  const comercios = partners.filter((p) => !p.is_portal);

  const createPortal = async () => {
    if (busy) return;
    setBusy(true);
    const { key, key_hash, key_hint } = await generateNegocioKey();
    await base44.entities.BusinessPartner.create({ name: PORTAL_NAME, is_portal: true, key_hash, key_hint, active: true });
    setShownKey({ name: PORTAL_NAME, key });
    setBusy(false);
    load();
  };

  const createPartner = async (e) => {
    e.preventDefault();
    if (!form.name.trim() || busy) return;
    setBusy(true);
    const { key, key_hash, key_hint } = await generateNegocioKey();
    await base44.entities.BusinessPartner.create({
      name: form.name.trim(),
      phone: form.phone.trim(),
      address: form.address.trim(),
      key_hash,
      key_hint,
      active: true,
    });
    setShownKey({ name: form.name.trim(), key });
    setForm({ name: '', phone: '', address: '' });
    setBusy(false);
    load();
  };

  const renewKey = async (p) => {
    if (!window.confirm(`¿Generar una clave nueva para ${p.name}? La clave anterior dejará de funcionar.`)) return;
    const { key, key_hash, key_hint } = await generateNegocioKey();
    await base44.entities.BusinessPartner.update(p.id, { key_hash, key_hint });
    setShownKey({ name: p.name, key });
    load();
  };

  const toggleActive = async (p) => {
    await base44.entities.BusinessPartner.update(p.id, { active: !p.active });
    load();
  };

  const copyKey = async () => {
    await navigator.clipboard.writeText(shownKey.key);
    toast({ title: 'Clave copiada' });
  };

  return (
    <div className="space-y-4 max-w-3xl">
      <NegociosPortalCard
        portal={portal}
        loading={loading}
        busy={busy}
        onCreate={createPortal}
        onRenew={renewKey}
        onToggle={toggleActive}
      />

      {shownKey && (
        <div className="bg-[#00E5FF]/10 rounded-2xl border border-[#00E5FF]/30 p-4 space-y-2">
          <p className="text-white font-bold text-sm">Clave de {shownKey.name}</p>
          <p className="text-xs text-[#8B95A8]">Cópiala ahora: no se volverá a mostrar. Guárdala solo en el servidor de NEXT Negocios.</p>
          <div className="flex items-center gap-2">
            <code className="flex-1 min-w-0 truncate text-xs text-[#00E5FF] bg-[#0c0f14] rounded-lg px-3 py-2 border border-white/8">{shownKey.key}</code>
            <button onClick={copyKey} className="h-9 px-3 rounded-lg bg-[#1E6BFF] text-white text-xs font-bold flex items-center gap-1.5 flex-shrink-0">
              <Copy className="w-3.5 h-3.5" /> Copiar
            </button>
            <button onClick={() => setShownKey(null)} className="h-9 px-3 rounded-lg bg-white/5 text-white text-xs font-bold flex-shrink-0">Listo</button>
          </div>
        </div>
      )}

      <form onSubmit={createPartner} className="bg-[#161C28] rounded-2xl border border-white/8 p-4 space-y-3">
        <p className="text-white font-bold text-sm flex items-center gap-2">
          <Store className="w-4 h-4 text-[#00E5FF]" /> Nuevo comercio aliado
        </p>
        <p className="text-xs text-[#8B95A8]">Solo para un comercio que envía pedidos desde su propio sistema. Los que se registran en la web no necesitan este paso.</p>
        <div className="grid sm:grid-cols-3 gap-2">
          <input className={inputCls} placeholder="Nombre del comercio" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <input className={inputCls} placeholder="Teléfono" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          <input className={inputCls} placeholder="Dirección" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
        </div>
        <button type="submit" disabled={busy || !form.name.trim()} className="h-10 px-4 rounded-xl bg-[#1E6BFF] text-white text-sm font-bold flex items-center gap-2 disabled:opacity-50">
          {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />} Crear y generar clave
        </button>
      </form>

      <div className="bg-[#161C28] rounded-2xl border border-white/8 divide-y divide-white/5">
        {loading && <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-[#00E5FF]" /></div>}
        {!loading && comercios.length === 0 && <p className="text-center text-[#8B95A8] text-sm py-8">Aún no hay comercios conectados</p>}
        {comercios.map((p) => (
          <div key={p.id} className="p-3 flex items-center gap-3 flex-wrap">
            <div className="flex-1 min-w-[160px]">
              <p className="text-white font-medium text-sm">{p.name}</p>
              <p className="text-[11px] text-[#8B95A8]">{[p.phone, p.address].filter(Boolean).join(' · ') || 'Sin datos de contacto'}</p>
              <p className="text-[11px] text-[#5A6478]">
                {p.external_id ? 'Conectado automáticamente desde la web' : `Clave terminada en ····${p.key_hint}`}
              </p>
            </div>
            {!p.external_id && (
              <button onClick={() => renewKey(p)} className="h-8 px-3 rounded-lg bg-white/5 text-white text-xs font-medium flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5" /> Nueva clave
              </button>
            )}
            <button onClick={() => toggleActive(p)} className={`h-8 px-3 rounded-lg text-xs font-bold ${p.active ? 'bg-[#00E676]/10 text-[#00E676]' : 'bg-[#FF5252]/10 text-[#FF5252]'}`}>
              {p.active ? 'Activo' : 'Inactivo'}
            </button>
          </div>
        ))}
      </div>

      <NegociosConexionCard />
    </div>
  );
}
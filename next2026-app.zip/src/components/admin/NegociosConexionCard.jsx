import React from 'react';
import { Link2, Copy } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const ENDPOINT = 'https://next2026-app.base44.app/functions/negociosApi';

// Texto completo para pegar en el chat del proyecto del portal NEXT Negocios.
const INSTRUCTIONS = `Conecta este portal con la app NEXT para que cada domicilio publicado les llegue a los mensajeros.

1. Guarda la clave del portal como secreto del servidor (NEXT_NEGOCIOS_KEY). Nunca en el navegador.

2. Cuando un comercio publique un domicilio, envíalo desde el servidor:

POST ${ENDPOINT}
Encabezados:
  Content-Type: application/json
  x-negocios-key: (clave del portal)

{
  "action": "create_order",
  "business_id": "id del comercio en este portal",
  "business_name": "Nombre del comercio",
  "business_phone": "3001234567",
  "business_address": "Calle 16 # 9-30",
  "business_logo": "https://(enlace público de la foto de perfil del comercio)",
  "external_order_id": "PED-1024",
  "pickup_address": "Calle 16 # 9-30",
  "destination_address": "Carrera 19 # 5-12",
  "customer_name": "Nombre del cliente",
  "customer_phone": "3001234567",
  "fare": 6000,
  "order_value": 32000,
  "payment_method": "efectivo",
  "content_description": "2 hamburguesas",
  "notes": "Timbre apto 302"
}

- business_id y business_name identifican al comercio: queda conectado en NEXT con su primer pedido, sin registrarlo a mano.
- business_logo es el enlace https público de la foto de perfil del comercio: es la foto que el mensajero ve en el pedido. Si el comercio no tiene foto, no envíes el campo.
- fare es el valor del domicilio que define el comercio (entre 3000 y 500000). NEXT no calcula la tarifa: un pedido sin fare se rechaza.
- order_value es la base que el mensajero paga al comercio al recoger y cobra al cliente al entregar (0 si no aplica).
- payment_method: "efectivo" o "transferencia".
- Las coordenadas ya no son obligatorias: basta con pickup_address y destination_address. NEXT ubica cada dirección en Valledupar, calcula la ruta por calles y responde con distance_km y duration_min. Sirve la dirección con su placa ("Calle 16 # 9-30", "Cra 9 No 16-25 local 3") o el nombre del conjunto, urbanización, barrio, edificio, centro comercial o local ("Mz 2 casa 42 Urbanización Santorini", "Conjunto Rosales torre 2 apto 301"): la manzana, casa, torre o apartamento se le muestran al mensajero, y el punto en el mapa es el del conjunto o barrio.
- No envíes coordenadas, salvo que sean el punto real elegido en un mapa: en ese caso manda pickup_lat/pickup_lng y destination_lat/destination_lng y NEXT las usa. Coordenadas fuera de Valledupar se ignoran.
- Si NEXT no logra ubicar una dirección con exactitud, no crea el pedido y responde 422 con code "address_not_found" y field ("pickup_address" o "destination_address"): muestra el mensaje para que el comercio corrija esa dirección. Con 503 "geocoder_unavailable", reintenta en unos segundos con el mismo external_order_id.
- Repetir el mismo external_order_id del mismo comercio no crea duplicados.

3. La respuesta trae order_id, status, status_label y tracking_url (enlace de seguimiento en vivo para el comercio y su cliente, válido 24 horas). Si NEXT responde con error, muéstralo y no marques el domicilio como publicado.

4. Para consultar el estado, con la misma clave:
{ "action": "get_order", "business_id": "id del comercio en este portal", "order_id": "..." }
Estados: pendiente (buscando mensajero), asignado, en_camino, recogida, finalizado, cancelado.
Si ningún mensajero toma el pedido en 10 minutos, NEXT lo cancela; para pedirlo otra vez envía un pedido nuevo con otro external_order_id.
En un pedido cancelado, cancelled_by indica quién lo canceló ("negocio": el comercio; "sistema": ningún mensajero lo tomó) y cancel_detail trae el motivo.
Cuando el pedido tiene mensajero, courier trae name, plate, phone, photo_url y motorcycle_model (también en la respuesta de create_order y de cancel_order):
- photo_url: enlace https de su foto de perfil, o null si no tiene foto. Es un enlace temporal que vence en 1 hora y cada respuesta trae uno nuevo: no lo guardes como dato permanente. Para que la foto no se recargue en cada consulta, conserva el que ya estás mostrando y cámbialo por el más reciente cuando lleve más de 50 minutos.
- motorcycle_model: marca y modelo de la moto registrados en su perfil (por ejemplo "Yamaha 2021"), o null si no están registrados.
Fotos de constancia: NEXT entrega dos fotos que toma el mensajero y el portal debe dejarlas guardadas en el detalle de cada domicilio.
- pickup_photo_url: la foto que tomó al recoger el pedido en el comercio. Llega desde que el pedido pasa a "recogida" y se sigue entregando en las consultas posteriores, también con el pedido entregado o cancelado.
- delivery_photo_url: la foto que tomó al entregar, la constancia de que el domicilio fue entregado. Llega cuando el pedido está "finalizado".
- Cada una llega en null mientras la foto no exista, o si ya no está disponible en NEXT.
- Son enlaces https temporales: vencen en 1 hora y cada respuesta trae uno nuevo. No guardes el enlace: en cuanto llegue, descarga la imagen desde el servidor del portal y guarda tu propia copia privada asociada al domicilio. Si la descarga falla, vuelve a consultar get_order para recibir un enlace nuevo.
- Cada vez que consultes get_order, revisa si trae una foto que el domicilio aún no tiene guardada y descárgala en ese momento. Haz también esa consulta al abrir el detalle de un domicilio recogido, entregado o cancelado al que le falte alguna foto. Una foto ya guardada no se vuelve a descargar.
- En el detalle del domicilio muestra siempre la copia guardada en el portal, la de recogida y la de entrega, con la opción de abrirla en grande; si el domicilio no tiene alguna, no muestres una imagen rota, solo omítela. Así las fotos quedan en el historial del comercio aunque pase el tiempo: NEXT las garantiza durante 90 días después de la entrega y luego pueden dejar de estar disponibles.

5. Asignar el domicilio a un mensajero específico (opcional). En el formulario de publicar domicilio agrega un campo opcional "ID del mensajero" y, cuando el comercio lo llene, envíalo en el mismo create_order:
  "courier_id": "482913"
- Es el ID de 6 dígitos que cada mensajero ve en su perfil de la app NEXT. Nunca cambia.
- Si se pudo asignar, la respuesta llega con status "asignado" y los datos del mensajero en courier: el pedido ya está en su lista "En curso" y no se ofrece a nadie más.
- Cada mensajero admite máximo 3 servicios en curso a la vez, sumando los de todos los comercios.
- Si no se pudo asignar, NEXT no crea el pedido ni lo ofrece a otro mensajero. Responde con error (el mensaje para mostrar) y code:
    404 courier_not_found: no existe un mensajero con ese ID.
    409 courier_full: el mensajero ya tiene 3 servicios en curso.
    409 courier_unavailable: el mensajero está bloqueado o aún no ha sido aprobado en NEXT.
    503 courier_busy: NEXT le está asignando otro pedido en ese instante; reintenta en unos segundos con el mismo external_order_id.
  Muestra el mensaje al comercio, no marques el domicilio como publicado y deja que elija: corregir el ID, usar otro mensajero o publicarlo sin courier_id para que lo tome cualquier mensajero disponible.
- Sin courier_id todo funciona igual que antes.

6. Cancelar un domicilio ya publicado. En cada domicilio que no esté entregado ni cancelado agrega un botón "Cancelar domicilio" que pida el motivo (opcional) y envíe, con la misma clave:
{ "action": "cancel_order", "business_id": "id del comercio en este portal", "order_id": "...", "reason": "Motivo que escribe el comercio" }
- Sirve order_id o external_order_id. reason es opcional (máximo 200 caracteres) y es el motivo que ve el mensajero.
- El comercio puede cancelar por cualquier motivo, tenga o no mensajero asignado, mientras el pedido no esté entregado. NEXT le avisa de inmediato al mensajero y el pedido sale de su lista.
- Respuesta 200: el pedido con status "cancelado" y cancelled_by "negocio"; marca el domicilio como cancelado solo con esta respuesta. Si tenía mensajero, courier trae su nombre, placa y teléfono, por si el comercio necesita coordinar con él un pedido que ya había recogido.
- Si el pedido ya estaba cancelado responde 200 igual, sin error.
- 409 con code "already_delivered": el pedido ya fue entregado y no se puede cancelar. 404: pedido no encontrado. Muestra al comercio el mensaje que llega en error.`;

export default function NegociosConexionCard() {
  const copyInstructions = async () => {
    await navigator.clipboard.writeText(INSTRUCTIONS);
    toast({ title: 'Instrucciones copiadas' });
  };

  return (
    <div className="bg-[#161C28] rounded-2xl border border-white/8 p-4 space-y-3">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <p className="text-white font-bold text-sm flex items-center gap-2">
          <Link2 className="w-4 h-4 text-[#00E5FF]" /> Cómo conectar NEXT Negocios
        </p>
        <button onClick={copyInstructions} className="h-8 px-3 rounded-lg bg-[#1E6BFF] text-white text-xs font-bold flex items-center gap-1.5">
          <Copy className="w-3.5 h-3.5" /> Copiar instrucciones
        </button>
      </div>
      <ol className="text-xs text-[#8B95A8] space-y-1.5 list-decimal pl-4">
        <li>Genera arriba la clave del portal y cópiala (solo se muestra una vez).</li>
        <li>Copia estas instrucciones y pégalas en el chat del proyecto NEXT Negocios. Cuando te pida la clave, guárdala como secreto.</li>
        <li>Desde ese momento, todo comercio que se registre en la web queda conectado con su primer pedido y aparece en esta lista.</li>
        <li>Para que los comercios asignen pedidos a un mensajero con su ID (punto 5), publiquen domicilios solo con direcciones, sin coordenadas, cancelen un domicilio ya publicado (punto 6) o vean la foto del mensajero y tengan guardadas en cada domicilio las fotos de constancia de recogida y de entrega (punto 4), vuelve a copiar estas instrucciones y pégalas en el chat del proyecto NEXT Negocios.</li>
      </ol>
      <pre className="text-[11px] leading-relaxed text-[#8B95A8] bg-[#0c0f14] rounded-xl p-3 overflow-x-auto thin-scroll border border-white/8 whitespace-pre-wrap break-words">{INSTRUCTIONS}</pre>
    </div>
  );
}
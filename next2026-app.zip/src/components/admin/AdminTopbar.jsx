import React, { useState, useEffect } from 'react';
import { Search, LogOut, ChevronRight } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import CentralNotificationsBell from '@/components/central/CentralNotificationsBell';

const SECTION_LABELS = {
  dashboard: 'Resumen',
  solicitudes: 'Solicitudes',
  mapa: 'Mapa conductores',
  despachador: 'Despachador',
  conductores: 'Conductores',
  pasajeros: 'Pasajeros',
  historial: 'Historial de viajes',
  recargas: 'Historial de recargas',
  servicios: 'Servicios',
  cancelaciones: 'Cancelaciones',
  calif_conductores: 'Calif. conductores',
  objetos_perdidos: 'Objetos perdidos',
  next_club: 'NEXT CLUB',
  negocios: 'NEXT Negocios',
};

export default function AdminTopbar({ active }) {
  const { user, logout } = useAuth();
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(t);
  }, []);

  const time = now.toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit', hour12: true, timeZone: 'America/Bogota' });
  const initial = (user?.full_name || user?.email || 'A').charAt(0).toUpperCase();
  const label = SECTION_LABELS[active] || 'Resumen';

  return (
    <header className="sticky top-0 z-20 h-16 bg-[#0a0d11]/90 backdrop-blur-lg border-b border-white/8 flex items-center gap-3 px-4 lg:px-6">
      {/* Breadcrumb */}
      <div className="flex items-center gap-1.5 text-sm flex-shrink-0">
        <span className="text-[#5A6478]">Centro de operaciones</span>
        <ChevronRight className="w-3.5 h-3.5 text-[#5A6478]" />
        <span className="text-white font-medium">{label}</span>
      </div>

      {/* Buscador */}
      <div className="flex-1 max-w-md hidden md:block mx-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5A6478]" />
          <input
            placeholder="Buscar..."
            className="w-full h-10 rounded-lg bg-[#161b22] border border-white/8 pl-10 pr-4 text-sm text-white placeholder:text-[#5A6478] outline-none focus:border-[#1E6BFF]/40 transition-colors"
          />
        </div>
      </div>
      <div className="flex-1 md:hidden" />

      {/* Estado en vivo */}
      <div className="hidden lg:flex items-center gap-1.5 text-xs text-[#8B95A8] flex-shrink-0">
        <span className="w-1.5 h-1.5 rounded-full bg-[#00E676] animate-pulse" /> Sistema activo
      </div>

      <div className="hidden sm:flex flex-col items-end leading-tight flex-shrink-0">
        <span className="text-sm text-white font-medium">{time}</span>
      </div>

      <CentralNotificationsBell />

      <div className="flex items-center gap-2 pl-2 border-l border-white/8 flex-shrink-0">
        <div className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-sm" style={{ background: 'linear-gradient(135deg, #1E6BFF, #00E5FF)' }}>
          {initial}
        </div>
        <div className="hidden sm:block leading-tight">
          <p className="text-sm text-white font-medium">{user?.full_name || 'Administrador'}</p>
          <p className="text-[10px] text-[#5A6478]">Admin</p>
        </div>
      </div>

      <button
        onClick={() => logout()}
        className="w-9 h-9 rounded-lg bg-white/5 flex items-center justify-center text-[#8B95A8] hover:text-red-400 hover:bg-red-500/10 transition-colors flex-shrink-0"
        aria-label="Cerrar sesión"
      >
        <LogOut className="w-4 h-4" />
      </button>
    </header>
  );
}
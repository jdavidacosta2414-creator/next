import React from 'react';
import {
  LayoutDashboard, Package, Map, Radio, Bike, Users, BarChart3, Wallet,
  Truck, ShieldAlert, Star, PackageSearch, Megaphone, Gift, Award, Crown, Store,
} from 'lucide-react';

// Navegación del panel administrativo agrupada en secciones.
// Se eliminaron las secciones placeholder no utilizadas (método de pago,
// notificaciones, roles, configuración, administrador).
const SECTIONS = [
  {
    title: 'OPERACIÓN',
    items: [
      { v: 'dashboard', label: 'Resumen', icon: LayoutDashboard },
      { v: 'solicitudes', label: 'Solicitudes', icon: Package, badge: true },
      { v: 'mapa', label: 'Mapa conductores', icon: Map },
      { v: 'despachador', label: 'Despachador', icon: Radio },
    ],
  },
  {
    title: 'GESTIÓN',
    items: [
      { v: 'conductores', label: 'Conductores', icon: Bike, badge: true },
      { v: 'pasajeros', label: 'Pasajeros', icon: Users },
      { v: 'historial', label: 'Historial de viajes', icon: BarChart3 },
      { v: 'recargas', label: 'Historial de recargas', icon: Wallet },
      { v: 'servicios', label: 'Servicios', icon: Truck },
      { v: 'cancelaciones', label: 'Cancelaciones', icon: ShieldAlert },
      { v: 'objetos_perdidos', label: 'Objetos perdidos', icon: PackageSearch, badge: true },
      { v: 'calif_conductores', label: 'Calif. conductores', icon: Star },
      { v: 'niveles_rendimiento', label: 'Niveles y rendimiento', icon: Award },
      { v: 'publicidad', label: 'Publicidad Negocio', icon: Megaphone },
      { v: 'negocios', label: 'NEXT Negocios', icon: Store },
      { v: 'next_club', label: 'NEXT CLUB', icon: Crown },
      { v: 'puntos', label: 'Puntos (anterior)', icon: Gift },
    ],
  },
];

export default function AdminSidebar({ active, onChange, pendingCount = 0, lostCount = 0, pendingMobilesCount = 0 }) {
  return (
    <aside className="hidden lg:flex flex-col w-60 h-screen sticky top-0 bg-[#0a0d11] border-r border-white/8 flex-shrink-0">
      {/* Logo */}
      <div className="px-5 py-5 border-b border-white/8">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #00E5FF, #1E6BFF)' }}>
            <svg viewBox="0 0 48 48" className="w-5 h-5">
              <path d="M15 7 L29 24 L15 41 L15 34 L22 24 L15 14 Z" fill="white" />
              <path d="M27 7 L41 24 L27 41 L27 34 L34 24 L27 14 Z" fill="white" opacity="0.85" />
            </svg>
          </div>
          <div>
            <p className="text-sm font-bold text-white tracking-wide">NEXT</p>
            <p className="text-[9px] text-[#1E6BFF] uppercase tracking-[0.15em]">Panel admin</p>
          </div>
        </div>
      </div>

      {/* Navegación agrupada */}
      <nav className="flex-1 overflow-y-auto thin-scroll px-3 py-3">
        {SECTIONS.map((section) => (
          <div key={section.title} className="mb-4">
            <p className="px-3 mb-1 text-[10px] font-bold text-[#5A6478] uppercase tracking-wider">{section.title}</p>
            {section.items.map((item) => {
              const Icon = item.icon;
              const isActive = active === item.v;
              return (
                <button
                  key={item.v}
                  onClick={() => onChange(item.v)}
                  className={`w-full flex items-center gap-2.5 h-9 px-3 rounded-lg text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-[#1E6BFF] text-white'
                      : 'text-[#8B95A8] hover:bg-white/5 hover:text-white'
                  }`}
                >
                  <Icon className="w-4 h-4 flex-shrink-0" />
                  <span className="flex-1 text-left truncate">{item.label}</span>
                  {item.badge && item.v === 'solicitudes' && pendingCount > 0 && (
                    <span className="inline-flex items-center justify-center min-w-5 h-5 px-1.5 rounded-full text-xs font-bold bg-[#00E5FF] text-[#0B0F1A]">
                      {pendingCount}
                    </span>
                  )}
                  {item.badge && item.v === 'conductores' && pendingMobilesCount > 0 && (
                    <span className="inline-flex items-center justify-center min-w-5 h-5 px-1.5 rounded-full text-xs font-bold bg-amber-400 text-[#0B0F1A]">
                      {pendingMobilesCount}
                    </span>
                  )}
                  {item.badge && item.v === 'objetos_perdidos' && lostCount > 0 && (
                    <span className="inline-flex items-center justify-center min-w-5 h-5 px-1.5 rounded-full text-xs font-bold bg-amber-500 text-white">
                      {lostCount}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        ))}
      </nav>
    </aside>
  );
}
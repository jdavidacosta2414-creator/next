import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Award,
  Activity,
  Search,
  RefreshCw,
  AlertTriangle,
  TrendingUp,
  CheckCircle2,
  ShieldCheck,
  Clock,
  Bell,
  Star,
  FileCheck,
  Loader2,
  X,
} from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useBackButton } from '@/hooks/useBackButton';
import { useToast } from '@/components/ui/use-toast';
import ResolvedAvatar from '@/components/shared/ResolvedAvatar';

const LEVEL_BADGE = {
  oro: {
    label: 'Oro',
    cls: 'bg-amber-500/20 text-amber-300 border-amber-400/50',
  },
  plata: {
    label: 'Plata',
    cls: 'bg-slate-400/20 text-slate-200 border-slate-300/40',
  },
  bronce: {
    label: 'Bronce',
    cls: 'bg-amber-800/30 text-amber-400 border-amber-700/50',
  },
};

const PERF_STATUS_LABELS = {
  excelente: { label: 'Excelente', cls: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30' },
  bueno: { label: 'Bueno', cls: 'bg-sky-500/15 text-sky-400 border-sky-500/30' },
  en_observacion: { label: 'En observación', cls: 'bg-amber-500/15 text-amber-400 border-amber-500/30' },
  necesita_mejorar: { label: 'Necesita mejorar', cls: 'bg-rose-500/15 text-rose-400 border-rose-500/30' },
  sin_datos_suficientes: { label: 'Muestra < 20', cls: 'bg-white/10 text-slate-300 border-white/15' },
};

function fmtDateTime(iso) {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleDateString('es-CO', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      timeZone: 'America/Bogota',
    });
  } catch {
    return '—';
  }
}

export default function AdminNivelesRendimiento() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [subTab, setSubTab] = useState('conductores');
  const [data, setData] = useState({
    totals: {
      totalDrivers: 0,
      oro: 0,
      plata: 0,
      bronce: 0,
      inRecovery: 0,
      nearPromotion: 0,
      atRiskOfDemotion: 0,
    },
    drivers: [],
    cancellationEvents: [],
    levelHistory: [],
    notifications: [],
  });

  const [search, setSearch] = useState('');
  const [levelFilter, setLevelFilter] = useState('todos');
  const [statusFilter, setStatusFilter] = useState('todos');

  // Modal de justificación administrativa de cancelación
  const [reviewingCancel, setReviewingCancel] = useState(null);

  useBackButton(() => {
    if (reviewingCancel) {
      setReviewingCancel(null);
      return true;
    }
    return false;
  }, true);
  const [justifReason, setJustifReason] = useState('');
  const [adminObs, setAdminObs] = useState('');
  const [savingJustif, setSavingJustif] = useState(false);

  const loadDashboard = useCallback(async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('driverPerformance', {
        action: 'admin_dashboard',
      });
      const payload = res?.data || res;
      if (payload?.ok) {
        setData({
          totals: payload.totals || {},
          drivers: payload.drivers || [],
          cancellationEvents: payload.cancellationEvents || [],
          levelHistory: payload.levelHistory || [],
          notifications: payload.notifications || [],
        });
      }
    } catch (e) {
      toast({
        title: 'Error al cargar supervisión de niveles',
        description: e?.message || 'Intenta nuevamente',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    loadDashboard();
  }, [loadDashboard]);

  const filteredDrivers = useMemo(() => {
    const q = search.trim().toLowerCase();
    return (data.drivers || []).filter((d) => {
      if (levelFilter !== 'todos' && d.currentLevel !== levelFilter) return false;
      if (statusFilter === 'recuperacion' && !d.recovery?.active) return false;
      else if (statusFilter === 'proximos_ascender' && !d.nearPromotion) return false;
      else if (statusFilter === 'en_riesgo' && !d.atRiskOfDemotion) return false;
      else if (
        statusFilter !== 'todos' &&
        statusFilter !== 'recuperacion' &&
        statusFilter !== 'proximos_ascender' &&
        statusFilter !== 'en_riesgo' &&
        d.performanceStatus !== statusFilter
      ) {
        return false;
      }
      if (!q) return true;
      return (
        (d.name || '').toLowerCase().includes(q) ||
        (d.plate || '').toLowerCase().includes(q) ||
        (d.email || '').toLowerCase().includes(q)
      );
    });
  }, [data.drivers, search, levelFilter, statusFilter]);

  const handleDecisionCancellation = async (decision) => {
    if (!reviewingCancel) return;
    if (!justifReason.trim() || !adminObs.trim()) {
      toast({
        title: 'Campos requeridos',
        description: 'Ingresa el motivo y la observación administrativa para dejar constancia en auditoría.',
        variant: 'destructive',
      });
      return;
    }
    setSavingJustif(true);
    try {
      const res = await base44.functions.invoke('driverPerformance', {
        action: 'justify_cancellation',
        event_id: reviewingCancel.id,
        decision,
        justification_reason: justifReason.trim(),
        admin_observation: adminObs.trim(),
      });
      const out = res?.data || res;
      if (out?.ok) {
        toast({
          title:
            decision === 'justificada'
              ? 'Cancelación marcada como justificada'
              : 'Justificación rechazada',
          description:
            'Se recalculó automáticamente el rendimiento de 30 días del conductor y se guardó el registro de auditoría.',
        });
        setReviewingCancel(null);
        setJustifReason('');
        setAdminObs('');
        await loadDashboard();
      }
    } catch (e) {
      toast({
        title: 'No se pudo procesar la decisión',
        description: e?.message || 'Verifica tus permisos de administrador',
        variant: 'destructive',
      });
    } finally {
      setSavingJustif(false);
    }
  };

  const t = data.totals || {};

  return (
    <div className="space-y-6 text-white">
      {/* Encabezado */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-black text-white flex items-center gap-2">
            <Award className="w-6 h-6 text-[#00E5FF]" />
            Supervisión de Niveles (Trayectoria) y Rendimiento (30 días)
          </h2>
          <p className="text-xs text-[#8B95A8] mt-0.5">
            Control automático de niveles Oro, Plata y Bronce, periodos de recuperación de 7 días, justificación de cancelaciones y auditoría
          </p>
        </div>

        <button
          type="button"
          onClick={loadDashboard}
          disabled={loading}
          className="h-10 px-4 rounded-xl bg-[#1E6BFF] hover:bg-[#1E6BFF]/90 text-white text-xs font-extrabold flex items-center gap-2 self-start"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          <span>Recalcular y actualizar</span>
        </button>
      </div>

      {/* Tarjetas de métricas globales */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div
          onClick={() => {
            setLevelFilter('oro');
            setStatusFilter('todos');
          }}
          className="cursor-pointer rounded-2xl bg-[#11161d] border border-amber-400/30 p-3.5 hover:border-amber-400/60 transition"
        >
          <p className="text-[11px] font-bold text-amber-300 uppercase">Nivel Oro</p>
          <p className="text-2xl font-black text-white mt-1">{t.oro ?? 0}</p>
          <p className="text-[10px] text-[#8B95A8]">Máxima prioridad</p>
        </div>

        <div
          onClick={() => {
            setLevelFilter('plata');
            setStatusFilter('todos');
          }}
          className="cursor-pointer rounded-2xl bg-[#11161d] border border-slate-400/30 p-3.5 hover:border-slate-300/60 transition"
        >
          <p className="text-[11px] font-bold text-slate-300 uppercase">Nivel Plata</p>
          <p className="text-2xl font-black text-white mt-1">{t.plata ?? 0}</p>
          <p className="text-[10px] text-[#8B95A8]">Prioridad preferencial</p>
        </div>

        <div
          onClick={() => {
            setLevelFilter('bronce');
            setStatusFilter('todos');
          }}
          className="cursor-pointer rounded-2xl bg-[#11161d] border border-amber-700/40 p-3.5 hover:border-amber-600/60 transition"
        >
          <p className="text-[11px] font-bold text-amber-500 uppercase">Nivel Bronce</p>
          <p className="text-2xl font-black text-white mt-1">{t.bronce ?? 0}</p>
          <p className="text-[10px] text-[#8B95A8]">Prioridad estándar</p>
        </div>

        <div
          onClick={() => {
            setLevelFilter('todos');
            setStatusFilter('recuperacion');
          }}
          className="cursor-pointer rounded-2xl bg-[#11161d] border border-amber-500/35 p-3.5 hover:border-amber-500/70 transition"
        >
          <p className="text-[11px] font-bold text-amber-400 uppercase">En recuperación (7d)</p>
          <p className="text-2xl font-black text-white mt-1">{t.inRecovery ?? 0}</p>
          <p className="text-[10px] text-[#8B95A8]">Advertencia activa</p>
        </div>

        <div
          onClick={() => {
            setLevelFilter('todos');
            setStatusFilter('proximos_ascender');
          }}
          className="cursor-pointer rounded-2xl bg-[#11161d] border border-emerald-500/35 p-3.5 hover:border-emerald-500/70 transition"
        >
          <p className="text-[11px] font-bold text-emerald-400 uppercase">Próximos a ascender</p>
          <p className="text-2xl font-black text-white mt-1">{t.nearPromotion ?? 0}</p>
          <p className="text-[10px] text-[#8B95A8]">Cerca del siguiente nivel</p>
        </div>

        <div
          onClick={() => {
            setLevelFilter('todos');
            setStatusFilter('en_riesgo');
          }}
          className="cursor-pointer rounded-2xl bg-[#11161d] border border-rose-500/35 p-3.5 hover:border-rose-500/70 transition"
        >
          <p className="text-[11px] font-bold text-rose-400 uppercase">En riesgo de bajar</p>
          <p className="text-2xl font-black text-white mt-1">{t.atRiskOfDemotion ?? 0}</p>
          <p className="text-[10px] text-[#8B95A8]">Requieren seguimiento</p>
        </div>
      </div>

      {/* Sub-navegación del módulo administrativo */}
      <div className="flex flex-wrap gap-2 border-b border-white/10 pb-3">
        {[
          { id: 'conductores', label: `Conductores (${data.drivers.length})`, icon: Activity },
          {
            id: 'cancelaciones',
            label: `Cancelaciones y Justificaciones (${data.cancellationEvents.length})`,
            icon: FileCheck,
          },
          {
            id: 'historial_niveles',
            label: `Historial de Cambios y Auditoría (${data.levelHistory.length})`,
            icon: Clock,
          },
          {
            id: 'notificaciones',
            label: `Advertencias y Notificaciones (${data.notifications.length})`,
            icon: Bell,
          },
        ].map((tab) => {
          const Icon = tab.icon;
          const active = subTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setSubTab(tab.id)}
              className={`h-9 px-3.5 rounded-xl text-xs font-extrabold flex items-center gap-2 transition ${
                active
                  ? 'bg-[#1E6BFF] text-white'
                  : 'bg-[#11161d] text-[#8B95A8] hover:text-white border border-white/10'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {loading ? (
        <div className="py-16 flex flex-col items-center justify-center gap-2">
          <Loader2 className="w-7 h-7 animate-spin text-[#00E5FF]" />
          <p className="text-xs text-[#8B95A8]">Evaluando trayectoria y rendimiento en tiempo real...</p>
        </div>
      ) : subTab === 'conductores' ? (
        <div className="space-y-4">
          {/* Filtros de búsqueda, nivel y estado de rendimiento */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 bg-[#11161d] p-3.5 rounded-2xl border border-white/10">
            <div className="relative">
              <Search className="w-4 h-4 text-[#8B95A8] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Buscar por nombre, placa o correo..."
                className="w-full h-10 pl-9 pr-3 rounded-xl bg-[#0a0d11] border border-white/10 text-xs text-white placeholder:text-[#5A6478] focus:outline-none focus:border-[#1E6BFF]"
              />
            </div>

            <select
              value={levelFilter}
              onChange={(e) => setLevelFilter(e.target.value)}
              className="h-10 px-3 rounded-xl bg-[#0a0d11] border border-white/10 text-xs text-white focus:outline-none focus:border-[#1E6BFF]"
            >
              <option value="todos">Todos los niveles ({data.drivers.length})</option>
              <option value="oro">Nivel Oro ({t.oro ?? 0})</option>
              <option value="plata">Nivel Plata ({t.plata ?? 0})</option>
              <option value="bronce">Nivel Bronce ({t.bronce ?? 0})</option>
            </select>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="h-10 px-3 rounded-xl bg-[#0a0d11] border border-white/10 text-xs text-white focus:outline-none focus:border-[#1E6BFF]"
            >
              <option value="todos">Todos los estados de rendimiento</option>
              <option value="excelente">Estado: Excelente</option>
              <option value="bueno">Estado: Bueno</option>
              <option value="en_observacion">Estado: En observación</option>
              <option value="necesita_mejorar">Estado: Necesita mejorar</option>
              <option value="sin_datos_suficientes">Muestra insuficiente (&lt; 20)</option>
              <option value="recuperacion">En periodo de recuperación (7 días)</option>
              <option value="proximos_ascender">Próximos a ascender</option>
              <option value="en_riesgo">En riesgo de descender</option>
            </select>
          </div>

          {/* Tabla de conductores */}
          <div className="overflow-x-auto rounded-2xl border border-white/10 bg-[#11161d]">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-white/10 text-[#8B95A8] uppercase text-[10px]">
                  <th className="py-3 px-4">Conductor</th>
                  <th className="py-3 px-3">Nivel</th>
                  <th className="py-3 px-3">Trayectoria Acumulada</th>
                  <th className="py-3 px-3">Aceptación (30d)</th>
                  <th className="py-3 px-3">Cancelación (30d)</th>
                  <th className="py-3 px-3">Calificación</th>
                  <th className="py-3 px-3">Rendimiento (30d)</th>
                  <th className="py-3 px-3">Recuperación / Alertas</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/8">
                {filteredDrivers.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-10 text-center text-[#8B95A8]">
                      No se encontraron conductores con los filtros seleccionados.
                    </td>
                  </tr>
                ) : (
                  filteredDrivers.map((d) => {
                    const lvl = LEVEL_BADGE[d.currentLevel] || LEVEL_BADGE.bronce;
                    const perf =
                      PERF_STATUS_LABELS[d.performanceStatus] ||
                      PERF_STATUS_LABELS.sin_datos_suficientes;
                    return (
                      <tr key={d.id} className="hover:bg-white/[0.03]">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2.5">
                            <ResolvedAvatar
                              photo={d.photo_url}
                              name={d.name}
                              className="w-9 h-9 rounded-full bg-[#1E6BFF]/20 text-white font-bold text-xs"
                            />
                            <div>
                              <p className="font-bold text-white">{d.name}</p>
                              <p className="text-[11px] text-[#8B95A8]">
                                {d.plate || 'Sin placa'} · {d.vehicle_type === 'carro' ? 'Carro' : 'Moto'}
                              </p>
                            </div>
                          </div>
                        </td>

                        <td className="py-3 px-3">
                          <span
                            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-extrabold border ${lvl.cls}`}
                          >
                            <Award className="w-3 h-3" /> {lvl.label}
                          </span>
                        </td>

                        <td className="py-3 px-3">
                          <p className="font-bold text-white">
                            {d.completedServices} servicios
                          </p>
                          <p className="text-[11px] text-[#8B95A8]">
                            {d.connectedDays} días conectados
                          </p>
                        </td>

                        <td className="py-3 px-3">
                          <span
                            className={`font-extrabold text-sm ${
                              d.acceptanceRate30d >= 90
                                ? 'text-emerald-400'
                                : d.acceptanceRate30d >= 80
                                  ? 'text-sky-400'
                                  : 'text-amber-400'
                            }`}
                          >
                            {d.acceptanceRate30d}%
                          </span>
                          <p className="text-[10px] text-[#8B95A8]">
                            Muestra: {d.validSample30d}/20
                          </p>
                        </td>

                        <td className="py-3 px-3">
                          <span
                            className={`font-extrabold text-sm ${
                              d.cancellationRate30d <= 3
                                ? 'text-emerald-400'
                                : d.cancellationRate30d <= 5
                                  ? 'text-sky-400'
                                  : 'text-rose-400'
                            }`}
                          >
                            {d.cancellationRate30d}%
                          </span>
                          <p className="text-[10px] text-[#8B95A8]">
                            {d.driverCancellationsPenalized30d} penalizadas ·{' '}
                            {d.driverCancellationsJustified30d} justificadas
                          </p>
                        </td>

                        <td className="py-3 px-3">
                          <div className="flex items-center gap-1 font-bold text-white">
                            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                            <span>{d.avgRating > 0 ? d.avgRating.toFixed(1) : '5.0'}</span>
                            <span className="text-[10px] text-[#8B95A8]">({d.ratingsCount})</span>
                          </div>
                        </td>

                        <td className="py-3 px-3">
                          <span
                            className={`inline-flex px-2.5 py-1 rounded-full text-[11px] font-bold border ${perf.cls}`}
                          >
                            {perf.label}
                          </span>
                        </td>

                        <td className="py-3 px-3">
                          {d.recovery?.active ? (
                            <div className="space-y-0.5">
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-extrabold">
                                ⏳ Recuperación ({d.recovery.daysRemaining}d restantes)
                              </span>
                              <p className="text-[10px] text-[#8B95A8] max-w-[200px] truncate">
                                {d.recovery.reason}
                              </p>
                            </div>
                          ) : d.nearPromotion ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-extrabold">
                              🚀 Próximo a subir a {d.pendingForNextLevel?.nextLevelName}
                            </span>
                          ) : d.atRiskOfDemotion ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 text-[10px] font-extrabold">
                              ⚠️ En riesgo de bajar
                            </span>
                          ) : (
                            <span className="text-[11px] text-[#8B95A8]">Estable</span>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : subTab === 'cancelaciones' ? (
        <div className="space-y-3">
          <div className="bg-[#11161d] border border-white/10 rounded-2xl p-4">
            <h3 className="text-sm font-extrabold text-white mb-1">
              Gestión de Cancelaciones Justificadas
            </h3>
            <p className="text-xs text-[#8B95A8]">
              Revisa las cancelaciones atribuibles a conductores. Al aprobar una justificación, se excluye del cálculo de penalización, se recalcula el rendimiento de 30 días y se guarda auditoría con administrador responsable y fecha.
            </p>
          </div>

          {data.cancellationEvents.length === 0 ? (
            <div className="bg-[#11161d] border border-white/10 rounded-2xl p-8 text-center text-xs text-[#8B95A8]">
              No hay cancelaciones de conductores registradas.
            </div>
          ) : (
            <div className="space-y-2.5">
              {data.cancellationEvents.map((ev) => {
                const isJustified = ev.justified || ev.justification_status === 'justificada';
                const isRejected = ev.justification_status === 'rechazada';
                return (
                  <div
                    key={ev.id}
                    className="bg-[#11161d] border border-white/10 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-extrabold text-sm text-white">
                          {ev.mobile_name || 'Conductor'}
                        </span>
                        <span className="px-2 py-0.5 rounded-full bg-white/10 text-[11px] text-slate-200 font-semibold">
                          Motivo reportado: {ev.cancel_reason || 'Liberado'}
                        </span>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[11px] font-extrabold ${
                            isJustified
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/35'
                              : isRejected
                                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/35'
                                : 'bg-amber-500/20 text-amber-300 border border-amber-500/35'
                          }`}
                        >
                          {isJustified
                            ? '✓ Justificada (Excluida de penalización)'
                            : isRejected
                              ? 'Justificación rechazada (Penaliza)'
                              : 'Sin revisar (Penaliza)'}
                        </span>
                      </div>
                      <p className="text-xs text-[#8B95A8]">
                        Servicio: {ev.pickup_address || 'Recogida'} → {ev.destination_address || 'Destino'} · Fecha:{' '}
                        {fmtDateTime(ev.cancelled_at || ev.created_date)}
                      </p>
                      {(ev.justification_reason || ev.admin_observation) && (
                        <p className="text-xs text-emerald-300/90">
                          Auditoría ({ev.reviewed_by_admin} · {fmtDateTime(ev.reviewed_at)}): Motivo: {ev.justification_reason} — Obs: {ev.admin_observation}
                        </p>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setReviewingCancel(ev);
                        setJustifReason(ev.justification_reason || ev.cancel_reason || '');
                        setAdminObs(ev.admin_observation || '');
                      }}
                      className="h-9 px-3.5 rounded-xl bg-[#1E6BFF] hover:bg-[#1E6BFF]/90 text-white text-xs font-extrabold flex-shrink-0 self-start sm:self-center"
                    >
                      {isJustified ? 'Editar revisión' : 'Revisar / Justificar'}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : subTab === 'historial_niveles' ? (
        <div className="space-y-2.5">
          {data.levelHistory.length === 0 ? (
            <div className="bg-[#11161d] border border-white/10 rounded-2xl p-8 text-center text-xs text-[#8B95A8]">
              Aún no hay cambios de nivel ni auditorías registradas.
            </div>
          ) : (
            data.levelHistory.map((h) => (
              <div
                key={h.id}
                className="bg-[#11161d] border border-white/10 rounded-2xl p-4 space-y-1 text-xs"
              >
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="font-extrabold text-white text-sm">
                    {h.mobile_name || 'Conductor'} ·{' '}
                    <span className="text-[#00E5FF] uppercase">{h.change_type}</span> (
                    {h.previous_level?.toUpperCase()} → {h.new_level?.toUpperCase()})
                  </span>
                  <span className="text-[#8B95A8]">{fmtDateTime(h.created_date)}</span>
                </div>
                <p className="text-slate-200 leading-relaxed">{h.reason}</p>
                <p className="text-[11px] text-[#8B95A8]">
                  Indicadores al momento del registro: {h.completed_services} servicios ·{' '}
                  {h.connected_days} días conectados · {h.acceptance_rate}% aceptación ·{' '}
                  {h.cancellation_rate}% cancelación (Muestra: {h.sample_size})
                  {h.admin_name ? ` · Admin responsable: ${h.admin_name}` : ''}
                </p>
              </div>
            ))
          )}
        </div>
      ) : (
        <div className="space-y-2.5">
          {data.notifications.length === 0 ? (
            <div className="bg-[#11161d] border border-white/10 rounded-2xl p-8 text-center text-xs text-[#8B95A8]">
              No hay notificaciones de nivel o rendimiento enviadas.
            </div>
          ) : (
            data.notifications.map((n) => (
              <div
                key={n.id}
                className="bg-[#11161d] border border-white/10 rounded-2xl p-4 space-y-1 text-xs"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-extrabold text-white">
                    {n.mobile_name} — {n.title}
                  </span>
                  <span className="text-[#8B95A8]">{fmtDateTime(n.created_date)}</span>
                </div>
                <p className="text-slate-300 leading-relaxed">{n.message}</p>
                {n.how_to_improve && (
                  <p className="text-[#00E5FF] text-[11px]">
                    Recomendación enviada: {n.how_to_improve}
                  </p>
                )}
              </div>
            ))
          )}
        </div>
      )}

      {/* Modal de Justificación Administrativa de Cancelación */}
      {reviewingCancel && (
        <div className="fixed inset-0 z-[2500] bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-3xl bg-[#11161d] border border-white/15 p-5 space-y-4 text-white shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-extrabold">
                Revisión Administrativa de Cancelación
              </h3>
              <button
                type="button"
                onClick={() => setReviewingCancel(null)}
                className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="rounded-2xl bg-[#0a0d11] border border-white/10 p-3 text-xs space-y-1">
              <p className="font-bold text-white">
                Conductor: {reviewingCancel.mobile_name}
              </p>
              <p className="text-[#8B95A8]">
                Motivo reportado: {reviewingCancel.cancel_reason || 'Liberado'}
              </p>
              <p className="text-[#8B95A8]">
                Fecha: {fmtDateTime(reviewingCancel.cancelled_at || reviewingCancel.created_date)}
              </p>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-200 mb-1">
                  Motivo de la justificación *
                </label>
                <input
                  type="text"
                  value={justifReason}
                  onChange={(e) => setJustifReason(e.target.value)}
                  placeholder="Ej. Falla mecánica comprobada / emergencia / fuerza mayor"
                  className="w-full h-10 px-3 rounded-xl bg-[#0a0d11] border border-white/15 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-200 mb-1">
                  Observación administrativa (Auditoría) *
                </label>
                <textarea
                  rows={3}
                  value={adminObs}
                  onChange={(e) => setAdminObs(e.target.value)}
                  placeholder="Describe la verificación realizada por el administrador..."
                  className="w-full p-3 rounded-xl bg-[#0a0d11] border border-white/15 text-xs text-white resize-none"
                />
              </div>
            </div>

            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                disabled={savingJustif}
                onClick={() => handleDecisionCancellation('rechazada')}
                className="flex-1 h-11 rounded-xl border border-rose-500/40 bg-rose-500/15 text-rose-300 font-extrabold text-xs"
              >
                Mantener penalización
              </button>
              <button
                type="button"
                disabled={savingJustif}
                onClick={() => handleDecisionCancellation('justificada')}
                className="flex-1 h-11 rounded-xl bg-emerald-500 text-slate-950 font-extrabold text-xs flex items-center justify-center gap-1.5"
              >
                {savingJustif && <Loader2 className="w-4 h-4 animate-spin" />}
                Aprobar como Justificada
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
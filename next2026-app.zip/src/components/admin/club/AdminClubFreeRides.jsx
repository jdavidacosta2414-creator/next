import React, { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { base44 } from '@/api/base44Client';
import { fmtCOP } from '@/lib/club';

const CLS = { disponible: 'text-emerald-400', reservado: 'text-amber-400', usado: 'text-[#8B95A8]' };

export default function AdminClubFreeRides() {
  const [status, setStatus] = useState('all');
  const [page, setPage] = useState(null);

  const load = async (cursor) => {
    const res = await base44.entities.ClubFreeRide.filter(status === 'all' ? {} : { status }, { sort: '-created_date', limit: 30, ...(cursor ? { cursor } : {}) });
    setPage((p) => ({ ...res, items: cursor ? [...(p?.items || []), ...res.items] : res.items }));
  };
  useEffect(() => { setPage(null); load(); }, [status]);

  return (
    <div className="space-y-3">
      <select value={status} onChange={(e) => setStatus(e.target.value)} className="h-9 rounded-lg bg-[#0c0f14] border border-white/10 text-white text-xs px-2">
        <option value="all">Todos</option>
        <option value="disponible">Generados sin usar</option>
        <option value="reservado">Reservados en un viaje</option>
        <option value="usado">Utilizados</option>
      </select>
      {!page ? (
        <div className="flex justify-center py-10"><Loader2 className="w-6 h-6 animate-spin text-[#00E5FF]" /></div>
      ) : page.items.length === 0 ? (
        <p className="text-sm text-[#8B95A8] text-center py-8">Aún no hay viajes gratis.</p>
      ) : (
        page.items.map((r) => (
          <div key={r.id} className="rounded-2xl bg-white/5 border border-white/10 p-3 flex items-center gap-3">
            <div className="flex-1 min-w-0">
              <p className="text-white font-bold text-sm">{r.user_name} · {r.code}</p>
              <p className="text-xs text-[#8B95A8]">
                Generado {format(new Date(r.created_date), 'dd/MM/yy')}
                {r.used_at ? ` · Usado ${format(new Date(r.used_at), 'dd/MM/yy')} · NEXT cubrió ${fmtCOP(r.discount_applied)}` : ` · Cubre hasta ${fmtCOP(r.max_value)}`}
              </p>
            </div>
            <span className={`text-xs font-bold capitalize ${CLS[r.status]}`}>{r.status}</span>
          </div>
        ))
      )}
      {page?.has_more && <button type="button" onClick={() => load(page.next_cursor)} className="w-full h-10 rounded-xl bg-white/5 text-white text-sm font-bold">Ver más</button>}
    </div>
  );
}
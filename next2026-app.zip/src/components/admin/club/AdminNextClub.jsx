import React, { useState } from 'react';
import AdminClubStats from '@/components/admin/club/AdminClubStats';
import AdminClubRedemptions from '@/components/admin/club/AdminClubRedemptions';
import AdminClubRewards from '@/components/admin/club/AdminClubRewards';
import AdminClubAccounts from '@/components/admin/club/AdminClubAccounts';
import AdminClubFreeRides from '@/components/admin/club/AdminClubFreeRides';
import AdminClubPartners from '@/components/admin/club/AdminClubPartners';
import AdminClubRules from '@/components/admin/club/AdminClubRules';

const TABS = [
  ['resumen', 'Resumen', AdminClubStats],
  ['canjes', 'Canjes y pedidos', AdminClubRedemptions],
  ['productos', 'Regalos y comidas', AdminClubRewards],
  ['pasajeros', 'Pasajeros', AdminClubAccounts],
  ['viajes', 'Viajes gratis', AdminClubFreeRides],
  ['comercios', 'Comercios aliados', AdminClubPartners],
  ['reglas', 'Reglas', AdminClubRules],
];

export default function AdminNextClub() {
  const [tab, setTab] = useState('resumen');
  const Current = TABS.find((t) => t[0] === tab)[2];
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-black text-white">NEXT CLUB</h1>
        <p className="text-sm text-[#8B95A8]">Viaja, acumula puntos y disfruta tus recompensas</p>
      </div>
      <div className="flex gap-2 overflow-x-auto no-scrollbar">
        {TABS.map(([k, label]) => (
          <button
            key={k}
            type="button"
            onClick={() => setTab(k)}
            className={`h-9 px-4 rounded-full text-xs font-bold whitespace-nowrap ${tab === k ? 'bg-[#1E6BFF] text-white' : 'bg-white/5 text-[#8B95A8]'}`}
          >
            {label}
          </button>
        ))}
      </div>
      <Current />
    </div>
  );
}
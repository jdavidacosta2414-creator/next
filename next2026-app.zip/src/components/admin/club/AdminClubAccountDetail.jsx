import React, { useEffect, useState } from 'react';
import { format } from 'date-fns';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { TX_LABELS, fmtPts, invokeClub } from '@/lib/club';
import { useToast } from '@/components/ui/use-toast';

const inp = 'h-10 rounded-lg bg-[#0c0f14] border border-white/10 text-white text-sm px-3';

export default function AdminClubAccountDetail({ account, onClose, onChanged }) {
  const { toast } = useToast();
  const [txs, setTxs] = useState([]);
  const [refs, setRefs] = useState([]);
  const [amount, setAmount] = useState('');
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);

  const load = async () => {
    const [t, r] = await Promise.all([
      base44.entities.ClubTransaction.filter({ user_id: account.user_id }, '-created_date', 50),
      base44.entities.ClubReferral.filter({ inviter_user_id: account.user_id }, '-created_date', 50),
    ]);
    setTxs(t);
    setRefs(r);
  };
  useEffect(() => { load(); }, [account.user_id]);

  const adjust = async () => {
    setBusy(true);
    try {
      await invokeClub('clubAdmin', { action: 'adjust_points', user_id: account.user_id, amount: Number(amount), reason });
      toast({ description: 'Ajuste registrado' });
      setAmount(''); setReason('');
      await load();
      onChanged?.();
    } catch (e) {
      toast({ description: e.message });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="bg-[#11161d] border-white/10 text-white max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>{account.user_name}</DialogTitle></DialogHeader>
        <p className="text-xs text-[#8B95A8]">{account.user_email} · {account.user_phone || 'sin celular'} · Código {account.referral_code}</p>
        <p className="text-xs text-[#8B95A8]">Invitado por: {account.referred_by_code || '—'} · Referidos bonificados: {account.referral_bonus_count || 0} (total {account.referrals_total || 0})</p>

        <div className="rounded-xl bg-white/5 p-3 space-y-2">
          <p className="text-sm font-bold">Ajuste manual (queda en el historial)</p>
          <div className="flex gap-2">
            <input type="number" className={`${inp} w-28`} placeholder="+/- pts" value={amount} onChange={(e) => setAmount(e.target.value)} />
            <input className={`${inp} flex-1`} placeholder="Motivo" value={reason} onChange={(e) => setReason(e.target.value)} />
          </div>
          <button type="button" disabled={busy || !Number(amount) || !reason.trim()} onClick={adjust} className="h-9 px-4 rounded-lg bg-[#1E6BFF] text-sm font-bold disabled:opacity-40">Aplicar</button>
        </div>

        {refs.length > 0 && (
          <div className="space-y-1">
            <p className="text-sm font-bold">Referidos</p>
            {refs.map((r) => (
              <p key={r.id} className="text-xs text-[#8B95A8]">{r.invitee_name} · {r.invitee_phone} · +{r.inviter_points} pts</p>
            ))}
          </div>
        )}

        <div className="space-y-1.5">
          <p className="text-sm font-bold">Historial</p>
          {txs.length === 0 && <p className="text-xs text-[#8B95A8]">Sin movimientos.</p>}
          {txs.map((t) => (
            <div key={t.id} className="flex justify-between gap-2 text-xs border-b border-white/5 pb-1.5">
              <div className="min-w-0">
                <p className="text-white font-semibold">{TX_LABELS[t.type] || t.type}</p>
                <p className="text-[#8B95A8] truncate">{t.description} · {format(new Date(t.created_date), 'dd/MM/yy HH:mm')}</p>
              </div>
              <div className="text-right flex-shrink-0">
                <p className={t.amount >= 0 ? 'text-emerald-400 font-bold' : 'text-red-400 font-bold'}>{t.amount >= 0 ? '+' : ''}{fmtPts(t.amount)}</p>
                <p className="text-[#8B95A8]">{fmtPts(t.balance_after)}</p>
              </div>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
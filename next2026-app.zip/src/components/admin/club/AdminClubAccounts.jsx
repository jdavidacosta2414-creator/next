import React, { useEffect, useState } from 'react';
import { Loader2, Search } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { fmtPts } from '@/lib/club';
import AdminClubAccountDetail from '@/components/admin/club/AdminClubAccountDetail';

export default function AdminClubAccounts() {
  const [q, setQ] = useState('');
  const [page, setPage] = useState(null);
  const [open, setOpen] = useState(null);

  const load = async (cursor) => {
    const term = q.trim();
    const query = term
      ? { $or: [{ user_name: { $regex: term, $options: 'i' } }, { user_email: { $regex: term, $options: 'i' } }, { referral_code: term.toUpperCase() }] }
      : {};
    const res = await base44.entities.ClubAccount.filter(query, {
      sort: '-balance', limit: 30, ...(cursor ? { cursor } : {}),
      fields: ['id', 'user_id', 'user_name', 'user_email', 'user_phone', 'balance', 'total_earned', 'transport_rides_count', 'free_ride_cycle_count', 'referral_code', 'referred_by_code', 'referral_bonus_count', 'referrals_total'],
    });
    setPage((p) => ({ ...res, items: cursor ? [...(p?.items || []), ...res.items] : res.items }));
  };

  useEffect(() => { const t = setTimeout(() => load(), 300); return () => clearTimeout(t); }, [q]);

  return (
    <div className="space-y-3">
      <div className="relative">
        <Search className="w-4 h-4 text-[#8B95A8] absolute left-3 top-3" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar por nombre, correo o código" className="w-full h-10 rounded-xl bg-white/5 border border-white/10 text-white text-sm pl-9 pr-3" />
      </div>
      {!page ? (
        <div className="flex justify-center py-10"><Loader2 className="w-6 h-6 animate-spin text-[#00E5FF]" /></div>
      ) : page.items.length === 0 ? (
        <p className="text-sm text-[#8B95A8] text-center py-8">Sin pasajeros inscritos.</p>
      ) : (
        page.items.map((a) => (
          <button key={a.id} type="button" onClick={() => setOpen(a)} className="w-full text-left rounded-2xl bg-white/5 border border-white/10 p-3 flex items-center gap-3">
            <div className="flex-1 min-w-0">
              <p className="text-white font-bold text-sm truncate">{a.user_name}</p>
              <p className="text-xs text-[#8B95A8] truncate">{a.user_email} · {a.referral_code} · Carreras {a.transport_rides_count || 0} · Ciclo {a.free_ride_cycle_count || 0}/8 · Referidos {a.referral_bonus_count || 0}</p>
            </div>
            <p className="text-[#00E5FF] font-black text-sm flex-shrink-0">{fmtPts(a.balance)} pts</p>
          </button>
        ))
      )}
      {page?.has_more && <button type="button" onClick={() => load(page.next_cursor)} className="w-full h-10 rounded-xl bg-white/5 text-white text-sm font-bold">Ver más</button>}
      {open && <AdminClubAccountDetail account={open} onClose={() => setOpen(null)} onChanged={() => load()} />}
    </div>
  );
}
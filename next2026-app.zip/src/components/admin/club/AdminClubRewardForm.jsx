import React, { useState } from 'react';
import { Loader2, Upload } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

const inp = 'w-full h-10 rounded-lg bg-[#0c0f14] border border-white/10 text-white text-sm px-3';

export default function AdminClubRewardForm({ reward, partners, onClose, onSaved }) {
  const [f, setF] = useState({
    category: 'regalo', name: '', description: '', image_url: '', points_cost: 0, stock: 0,
    active: true, partner_id: '', internal_cost: 0, delivery_cost: 0, sort_order: 0, ...reward,
  });
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const set = (k, v) => setF((p) => ({ ...p, [k]: v }));
  const num = (k) => (e) => set(k, Number(e.target.value));

  const upload = async (file) => {
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
    set('image_url', file_url);
    setUploading(false);
  };

  const save = async () => {
    setSaving(true);
    const partner = partners.find((p) => p.id === f.partner_id);
    const { id, created_date, updated_date, created_by_id, is_sample, ...data } = f;
    data.partner_name = partner?.name || '';
    if (reward?.id) await base44.entities.ClubReward.update(reward.id, data);
    else await base44.entities.ClubReward.create(data);
    setSaving(false);
    onSaved();
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="bg-[#11161d] border-white/10 text-white max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>{reward?.id ? 'Editar producto' : 'Nuevo producto'}</DialogTitle></DialogHeader>
        <div className="space-y-2.5">
          <select className={inp} value={f.category} onChange={(e) => set('category', e.target.value)}>
            <option value="regalo">Regalo tecnológico</option>
            <option value="comida">Comida por puntos</option>
          </select>
          <input className={inp} placeholder="Nombre" value={f.name} onChange={(e) => set('name', e.target.value)} />
          <textarea className={`${inp} h-20 py-2`} placeholder="Descripción" value={f.description} onChange={(e) => set('description', e.target.value)} />
          <div className="flex items-center gap-3">
            {f.image_url && <img src={f.image_url} alt="" className="w-16 h-16 rounded-lg object-cover" />}
            <label className="h-10 px-3 rounded-lg bg-white/10 text-sm font-bold flex items-center gap-2 cursor-pointer">
              {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />} Subir foto
              <input type="file" accept="image/*" className="hidden" onChange={(e) => upload(e.target.files?.[0])} />
            </label>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <label className="text-xs text-[#8B95A8]">Puntos<input type="number" className={inp} value={f.points_cost} onChange={num('points_cost')} /></label>
            <label className="text-xs text-[#8B95A8]">Inventario<input type="number" className={inp} value={f.stock} onChange={num('stock')} /></label>
            <label className="text-xs text-[#8B95A8]">Costo interno (COP)<input type="number" className={inp} value={f.internal_cost} onChange={num('internal_cost')} /></label>
            <label className="text-xs text-[#8B95A8]">Costo domicilio (COP)<input type="number" className={inp} value={f.delivery_cost} onChange={num('delivery_cost')} /></label>
          </div>
          {f.category === 'comida' && (
            <select className={inp} value={f.partner_id || ''} onChange={(e) => set('partner_id', e.target.value)}>
              <option value="">Comercio aliado (sin asignar)</option>
              {partners.map((p) => <option key={p.id} value={p.id}>{p.name}{p.active ? '' : ' (inactivo)'}</option>)}
            </select>
          )}
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.active} onChange={(e) => set('active', e.target.checked)} /> Activo</label>
          <button type="button" disabled={saving || !f.name || f.points_cost <= 0} onClick={save} className="w-full h-11 rounded-xl bg-[#1E6BFF] font-bold disabled:opacity-40">
            {saving ? 'Guardando...' : 'Guardar'}
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
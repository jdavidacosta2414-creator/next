import React, { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';

const NUMS = [
  ['points_per_1000', 'Puntos por cada $1.000 pagados'],
  ['free_ride_every', 'Carreras para un viaje gratis'],
  ['free_ride_max_value', 'Valor máximo del viaje gratis (COP)'],
  ['referral_points_inviter', 'Puntos para quien invita'],
  ['referral_points_new', 'Puntos para el nuevo usuario'],
  ['referral_limit', 'Referidos bonificados por usuario'],
];
const FLAGS = [
  ['earn_enabled', 'Acumular puntos por servicios'],
  ['gifts_enabled', 'Canje de regalos'],
  ['food_enabled', 'Canje de comidas'],
  ['free_ride_enabled', 'Viaje gratis'],
  ['referrals_enabled', 'Referidos'],
];

export default function AdminClubRules() {
  const { toast } = useToast();
  const [cfg, setCfg] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    base44.entities.ClubConfig.filter({ key: 'main' }, '-created_date', 1).then((l) => setCfg(l[0] || { key: 'main' }));
  }, []);

  const save = async () => {
    setSaving(true);
    const { id, created_date, updated_date, created_by_id, is_sample, ...data } = cfg;
    const saved = id ? await base44.entities.ClubConfig.update(id, data) : await base44.entities.ClubConfig.create(data);
    setCfg(saved);
    setSaving(false);
    toast({ description: 'Reglas guardadas' });
  };

  if (!cfg) return <div className="flex justify-center py-10"><Loader2 className="w-6 h-6 animate-spin text-[#00E5FF]" /></div>;

  return (
    <div className="max-w-xl space-y-3">
      {NUMS.map(([k, label]) => (
        <label key={k} className="flex items-center justify-between gap-3 rounded-xl bg-white/5 border border-white/10 p-3 text-sm text-white">
          {label}
          <input type="number" min={0} value={cfg[k] ?? ''} onChange={(e) => setCfg({ ...cfg, [k]: Number(e.target.value) })} className="w-28 h-9 rounded-lg bg-[#0c0f14] border border-white/10 px-2 text-right" />
        </label>
      ))}
      {FLAGS.map(([k, label]) => (
        <label key={k} className="flex items-center justify-between gap-3 rounded-xl bg-white/5 border border-white/10 p-3 text-sm text-white">
          {label}
          <input type="checkbox" checked={cfg[k] !== false} onChange={(e) => setCfg({ ...cfg, [k]: e.target.checked })} className="w-5 h-5" />
        </label>
      ))}
      <p className="text-xs text-[#8B95A8]">Los puntos no vencen y no sirven para pagar carreras. Los cambios aplican a los servicios que se completen desde ahora.</p>
      <button type="button" disabled={saving} onClick={save} className="h-11 px-6 rounded-xl bg-[#1E6BFF] text-white font-bold disabled:opacity-50">
        {saving ? 'Guardando...' : 'Guardar reglas'}
      </button>
    </div>
  );
}
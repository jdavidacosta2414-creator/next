import React, { useEffect, useState } from 'react';
import { Trash2, Plus } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const inp = 'h-10 rounded-lg bg-[#0c0f14] border border-white/10 text-white text-sm px-3';

export default function AdminClubPartners() {
  const [items, setItems] = useState([]);
  const [f, setF] = useState({ name: '', phone: '', address: '' });

  const load = () => base44.entities.ClubPartner.list('name', 100).then(setItems);
  useEffect(() => { load(); }, []);

  const add = async () => {
    await base44.entities.ClubPartner.create({ ...f, active: true });
    setF({ name: '', phone: '', address: '' });
    load();
  };
  const toggle = async (p) => { await base44.entities.ClubPartner.update(p.id, { active: !p.active }); load(); };
  const remove = async (p) => {
    if (!window.confirm(`¿Eliminar ${p.name}?`)) return;
    await base44.entities.ClubPartner.delete(p.id);
    load();
  };

  return (
    <div className="space-y-3">
      <div className="rounded-2xl bg-white/5 border border-white/10 p-3 grid grid-cols-1 lg:grid-cols-4 gap-2">
        <input className={inp} placeholder="Nombre del comercio" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        <input className={inp} placeholder="Teléfono" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
        <input className={inp} placeholder="Dirección" value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} />
        <button type="button" disabled={!f.name.trim()} onClick={add} className="h-10 rounded-lg bg-[#1E6BFF] text-white text-sm font-bold flex items-center justify-center gap-2 disabled:opacity-40">
          <Plus className="w-4 h-4" /> Agregar
        </button>
      </div>
      {items.length === 0 && <p className="text-sm text-[#8B95A8] text-center py-6">Aún no hay comercios aliados.</p>}
      {items.map((p) => (
        <div key={p.id} className="rounded-2xl bg-white/5 border border-white/10 p-3 flex items-center gap-3">
          <div className="flex-1 min-w-0">
            <p className="text-white font-bold text-sm">{p.name}</p>
            <p className="text-xs text-[#8B95A8]">{p.phone} · {p.address}</p>
          </div>
          <button type="button" onClick={() => toggle(p)} className={`text-[11px] font-bold px-2.5 py-1 rounded-full ${p.active ? 'bg-emerald-500/20 text-emerald-400' : 'bg-white/10 text-[#8B95A8]'}`}>
            {p.active ? 'Activo' : 'Inactivo'}
          </button>
          <button type="button" onClick={() => remove(p)} className="p-2 text-red-400"><Trash2 className="w-4 h-4" /></button>
        </div>
      ))}
    </div>
  );
}
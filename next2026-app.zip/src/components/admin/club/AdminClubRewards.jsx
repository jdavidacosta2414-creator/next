import React, { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { fmtPts } from '@/lib/club';
import AdminClubRewardForm from '@/components/admin/club/AdminClubRewardForm';

export default function AdminClubRewards() {
  const [items, setItems] = useState(null);
  const [partners, setPartners] = useState([]);
  const [editing, setEditing] = useState(null);

  const load = async () => {
    const [r, p] = await Promise.all([
      base44.entities.ClubReward.list('sort_order', 100),
      base44.entities.ClubPartner.list('name', 100),
    ]);
    setItems(r);
    setPartners(p);
  };
  useEffect(() => { load(); }, []);

  const toggle = async (r) => { await base44.entities.ClubReward.update(r.id, { active: !r.active }); load(); };
  const remove = async (r) => {
    if (!window.confirm(`¿Eliminar "${r.name}"?`)) return;
    await base44.entities.ClubReward.delete(r.id);
    load();
  };

  if (!items) return <div className="flex justify-center py-10"><Loader2 className="w-6 h-6 animate-spin text-[#00E5FF]" /></div>;

  return (
    <div className="space-y-4">
      <button type="button" onClick={() => setEditing({})} className="h-10 px-4 rounded-xl bg-[#1E6BFF] text-white text-sm font-bold flex items-center gap-2">
        <Plus className="w-4 h-4" /> Nuevo producto
      </button>
      {['regalo', 'comida'].map((cat) => (
        <div key={cat} className="space-y-2">
          <p className="text-white font-extrabold text-sm">{cat === 'regalo' ? 'Regalos tecnológicos' : 'Comidas por puntos'}</p>
          {items.filter((r) => r.category === cat).map((r) => (
            <div key={r.id} className="rounded-2xl bg-white/5 border border-white/10 p-2.5 flex items-center gap-3">
              <img src={r.image_url} alt="" className="w-12 h-12 rounded-lg object-cover bg-white/10" />
              <div className="flex-1 min-w-0">
                <p className="text-white font-bold text-sm truncate">{r.name}</p>
                <p className="text-xs text-[#8B95A8]">{fmtPts(r.points_cost)} pts · Inventario {r.stock}{r.partner_name ? ` · ${r.partner_name}` : ''}</p>
              </div>
              <button type="button" onClick={() => toggle(r)} className={`text-[11px] font-bold px-2.5 py-1 rounded-full ${r.active ? 'bg-emerald-500/20 text-emerald-400' : 'bg-white/10 text-[#8B95A8]'}`}>
                {r.active ? 'Activo' : 'Inactivo'}
              </button>
              <button type="button" onClick={() => setEditing(r)} className="p-2 text-[#8B95A8]"><Pencil className="w-4 h-4" /></button>
              <button type="button" onClick={() => remove(r)} className="p-2 text-red-400"><Trash2 className="w-4 h-4" /></button>
            </div>
          ))}
        </div>
      ))}
      {editing && (
        <AdminClubRewardForm reward={editing} partners={partners} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); load(); }} />
      )}
    </div>
  );
}
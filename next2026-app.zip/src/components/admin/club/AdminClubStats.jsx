import React, { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { fmtPts, fmtCOP } from '@/lib/club';

function Stat({ label, value }) {
  return (
    <div className="rounded-2xl bg-white/5 border border-white/10 p-4">
      <p className="text-[11px] font-bold uppercase tracking-wide text-[#8B95A8]">{label}</p>
      <p className="text-2xl font-black text-white mt-1">{value}</p>
    </div>
  );
}

export default function AdminClubStats() {
  const [s, setS] = useState(null);

  useEffect(() => {
    (async () => {
      const [acc, participants, reds, referrals, rides] = await Promise.all([
        base44.entities.ClubAccount.aggregate({ sum: ['total_earned', 'total_redeemed'] }),
        base44.entities.ClubAccount.count(),
        base44.entities.ClubRedemption.aggregate({
          query: { status: { $ne: 'cancelado' } },
          groupBy: 'category',
          sum: ['internal_cost', 'delivery_cost'],
        }),
        base44.entities.ClubReferral.count(),
        base44.entities.ClubFreeRide.aggregate({ groupBy: 'status', sum: ['discount_applied'] }),
      ]);
      const a = acc?.rows?.[0] || {};
      const byCat = Object.fromEntries((reds?.rows || []).map((r) => [r.category, r]));
      const byRide = Object.fromEntries((rides?.rows || []).map((r) => [r.status, r]));
      const redCost = (reds?.rows || []).reduce((t, r) => t + (r.sum_internal_cost || 0) + (r.sum_delivery_cost || 0), 0);
      const generated = (rides?.rows || []).reduce((t, r) => t + (r.count || 0), 0);
      setS({
        emitted: a.sum_total_earned || 0,
        redeemed: a.sum_total_redeemed || 0,
        participants,
        gifts: byCat.regalo?.count || 0,
        foods: byCat.comida?.count || 0,
        referrals,
        ridesGenerated: generated,
        ridesUsed: byRide.usado?.count || 0,
        cost: redCost + (byRide.usado?.sum_discount_applied || 0),
      });
    })();
  }, []);

  if (!s) return <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-[#00E5FF]" /></div>;

  return (
    <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
      <Stat label="Puntos emitidos" value={fmtPts(s.emitted)} />
      <Stat label="Puntos redimidos" value={fmtPts(s.redeemed)} />
      <Stat label="Pasajeros participantes" value={fmtPts(s.participants)} />
      <Stat label="Regalos reclamados" value={fmtPts(s.gifts)} />
      <Stat label="Comidas reclamadas" value={fmtPts(s.foods)} />
      <Stat label="Referidos" value={fmtPts(s.referrals)} />
      <Stat label="Viajes gratis generados" value={fmtPts(s.ridesGenerated)} />
      <Stat label="Viajes gratis usados" value={fmtPts(s.ridesUsed)} />
      <Stat label="Costo estimado recompensas" value={fmtCOP(s.cost)} />
    </div>
  );
}
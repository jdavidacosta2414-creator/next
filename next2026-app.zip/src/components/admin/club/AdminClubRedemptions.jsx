import React, { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { base44 } from '@/api/base44Client';
import { invokeClub, fmtPts, statusLabel, GIFT_STATUS, FOOD_STATUS } from '@/lib/club';
import { useToast } from '@/components/ui/use-toast';

const sel = 'h-9 rounded-lg bg-[#0c0f14] border border-white/10 text-white text-xs px-2';

export default function AdminClubRedemptions() {
  const { toast } = useToast();
  const [category, setCategory] = useState('all');
  const [status, setStatus] = useState('open');
  const [page, setPage] = useState(null);
  const [busy, setBusy] = useState('');

  const load = async (cursor) => {
    const q = {};
    if (category !== 'all') q.category = category;
    if (status === 'open') q.status = { $nin: ['entregado', 'cancelado'] };
    else if (status !== 'all') q.status = status;
    const res = await base44.entities.ClubRedemption.filter(q, { sort: '-created_date', limit: 30, ...(cursor ? { cursor } : {}) });
    setPage((p) => ({ ...res, items: cursor ? [...(p?.items || []), ...res.items] : res.items }));
  };

  useEffect(() => { setPage(null); load(); }, [category, status]);

  const change = async (r, next) => {
    if (next === 'cancelado' && !window.confirm(`¿Cancelar ${r.code}? Se devolverán ${fmtPts(r.points)} puntos al pasajero.`)) return;
    setBusy(r.id);
    try {
      await invokeClub('clubAdmin', { action: 'update_status', redemption_id: r.id, status: next });
      toast({ description: 'Estado actualizado' });
      await load();
    } catch (e) {
      toast({ description: e.message });
    } finally {
      setBusy('');
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2">
        <select className={sel} value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="all">Regalos y comidas</option>
          <option value="regalo">Regalos</option>
          <option value="comida">Pedidos de comida</option>
        </select>
        <select className={sel} value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="open">Abiertos</option>
          <option value="all">Todos</option>
          <option value="entregado">Entregados</option>
          <option value="cancelado">Cancelados</option>
        </select>
      </div>
      {!page ? (
        <div className="flex justify-center py-10"><Loader2 className="w-6 h-6 animate-spin text-[#00E5FF]" /></div>
      ) : page.items.length === 0 ? (
        <p className="text-sm text-[#8B95A8] py-8 text-center">No hay canjes.</p>
      ) : (
        page.items.map((r) => {
          const opts = r.category === 'comida' ? FOOD_STATUS : GIFT_STATUS;
          const closed = ['entregado', 'cancelado'].includes(r.status);
          return (
            <div key={r.id} className="rounded-2xl bg-white/5 border border-white/10 p-3 flex flex-col lg:flex-row lg:items-center gap-2">
              <div className="flex-1 min-w-0">
                <p className="text-white font-bold text-sm">{r.reward_name} <span className="text-[#00E5FF]">· {r.code}</span></p>
                <p className="text-xs text-[#8B95A8]">{r.user_name} · {r.user_phone} · {fmtPts(r.points)} pts · {format(new Date(r.created_date), 'dd/MM/yyyy HH:mm')}</p>
                <p className="text-xs text-[#8B95A8] truncate">📍 {r.delivery_address}{r.notes ? ` · ${r.notes}` : ''}{r.partner_name ? ` · ${r.partner_name}` : ''}</p>
              </div>
              {closed ? (
                <span className="text-xs font-bold text-[#8B95A8]">{statusLabel(r.category, r.status)}</span>
              ) : (
                <select className={sel} disabled={busy === r.id} value={r.status} onChange={(e) => change(r, e.target.value)}>
                  {Object.entries(opts).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              )}
            </div>
          );
        })
      )}
      {page?.has_more && (
        <button type="button" onClick={() => load(page.next_cursor)} className="w-full h-10 rounded-xl bg-white/5 text-white text-sm font-bold">Ver más</button>
      )}
    </div>
  );
}
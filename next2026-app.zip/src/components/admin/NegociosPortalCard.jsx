import React from 'react';
import { Globe, KeyRound, Loader2 } from 'lucide-react';

// Conexión única del portal web: con su clave, todo comercio registrado en la web queda conectado solo.
export default function NegociosPortalCard({ portal, loading, busy, onCreate, onRenew, onToggle }) {
  return (
    <div className="bg-[#161C28] rounded-2xl border border-white/8 p-4 space-y-3">
      <p className="text-white font-bold text-sm flex items-center gap-2">
        <Globe className="w-4 h-4 text-[#00E5FF]" /> Conexión del portal web
      </p>
      <p className="text-xs text-[#8B95A8]">
        Con esta clave, todo comercio que se registre en la web de NEXT Negocios queda conectado automáticamente al enviar su primer pedido.
      </p>
      {loading ? (
        <Loader2 className="w-5 h-5 animate-spin text-[#00E5FF]" />
      ) : portal ? (
        <div className="flex items-center gap-3 flex-wrap">
          <p className="flex-1 min-w-[160px] text-[11px] text-[#5A6478]">Clave terminada en ····{portal.key_hint}</p>
          <button onClick={() => onRenew(portal)} className="h-8 px-3 rounded-lg bg-white/5 text-white text-xs font-medium flex items-center gap-1.5">
            <KeyRound className="w-3.5 h-3.5" /> Nueva clave
          </button>
          <button onClick={() => onToggle(portal)} className={`h-8 px-3 rounded-lg text-xs font-bold ${portal.active ? 'bg-[#00E676]/10 text-[#00E676]' : 'bg-[#FF5252]/10 text-[#FF5252]'}`}>
            {portal.active ? 'Activa' : 'Inactiva'}
          </button>
        </div>
      ) : (
        <button onClick={onCreate} disabled={busy} className="h-10 px-4 rounded-xl bg-[#1E6BFF] text-white text-sm font-bold flex items-center gap-2 disabled:opacity-50">
          {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <KeyRound className="w-4 h-4" />} Generar clave del portal
        </button>
      )}
    </div>
  );
}
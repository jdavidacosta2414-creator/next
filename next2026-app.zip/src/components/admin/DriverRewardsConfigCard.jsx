import React, { useState, useEffect } from 'react';
import { Award, Save, Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import {
  DRIVER_STREAK_MILESTONES,
  DRIVER_STREAK_REWARDS,
  DRIVER_DAILY_TRIP_GOAL,
  DRIVER_WEEKLY_TRIP_GOAL,
  DRIVER_DAILY_REWARD,
  DRIVER_WEEKLY_REWARD,
  fetchDriverRewardsConfig,
  saveDriverRewardsConfig,
} from '@/lib/rewards';

export default function DriverRewardsConfigCard() {
  const { toast } = useToast();
  const [cfg, setCfg] = useState({
    streakRewards: { ...DRIVER_STREAK_REWARDS },
    dailyGoal: DRIVER_DAILY_TRIP_GOAL,
    dailyReward: DRIVER_DAILY_REWARD,
    weeklyGoal: DRIVER_WEEKLY_TRIP_GOAL,
    weeklyReward: DRIVER_WEEKLY_REWARD,
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchDriverRewardsConfig()
      .then(setCfg)
      .catch(() => {});
  }, []);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await saveDriverRewardsConfig(cfg);
      toast({
        title: 'Recompensas de conductores actualizadas',
        description: 'Los nuevos incentivos ya son visibles para todos los conductores y se acreditan automáticamente al cumplir la meta.',
      });
    } catch {
      toast({ title: 'No se pudo guardar', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <form
      onSubmit={handleSave}
      className="bg-[#11161d] rounded-2xl border border-emerald-500/30 p-4 space-y-3"
    >
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div>
          <p className="text-sm font-bold text-white flex items-center gap-2">
            <Award className="w-4 h-4 text-emerald-400" />
            Incentivos semanales de conductores (acreditación automática en Cartera)
          </p>
          <p className="text-xs text-[#8B95A8] mt-0.5">
            Cambia las recompensas cuando quieras. El conductor se postula y la app le abona automáticamente el bono en su Cartera al cumplir la meta.
          </p>
        </div>
        <button
          type="submit"
          disabled={saving}
          className="h-9 px-4 rounded-xl bg-[#00E676] text-slate-950 font-extrabold text-xs flex items-center gap-1.5 disabled:opacity-50"
        >
          {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
          <span>Guardar incentivos</span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
        {DRIVER_STREAK_MILESTONES.map((m) => (
          <div key={m} className="bg-[#0c0f14] rounded-xl border border-white/10 p-2.5 space-y-1">
            <label className="text-[11px] font-bold text-[#00E5FF] block">
              Meta {m} días conectados
            </label>
            <input
              value={cfg.streakRewards[m] || ''}
              onChange={(e) =>
                setCfg((prev) => ({
                  ...prev,
                  streakRewards: { ...prev.streakRewards, [m]: e.target.value },
                }))
              }
              className="w-full h-8 rounded-lg bg-[#11161d] px-2.5 text-xs font-bold text-white border border-white/10 outline-none focus:border-[#00E5FF]"
            />
          </div>
        ))}
      </div>
    </form>
  );
}
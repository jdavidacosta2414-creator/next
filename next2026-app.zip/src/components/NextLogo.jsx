import React from 'react';
import { cn } from '@/lib/utils';

// Logo de marca NEXT: doble flecha en degradado azul/cian con efecto de brillo.
// Wordmark "NEXT" con la "X" en cian.
const SIZES = {
  sm: { icon: 40, text: 'text-2xl', sub: 'text-[9px]', gap: 'gap-1' },
  md: { icon: 56, text: 'text-3xl', sub: 'text-[11px]', gap: 'gap-1.5' },
  lg: { icon: 80, text: 'text-5xl', sub: 'text-sm', gap: 'gap-2.5' },
};

export default function NextLogo({ size = 'md', className, withGlow = true }) {
  const s = SIZES[size] || SIZES.md;
  const gradId = `nextGrad-${size}`;
  return (
    <div className={cn('flex flex-col items-center', s.gap, className)}>
      <div className="relative" style={{ width: s.icon, height: s.icon }}>
        <svg viewBox="0 0 48 48" className="relative w-full h-full">
          <defs>
            <linearGradient id={gradId} x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#00E5FF" />
              <stop offset="100%" stopColor="#1E6BFF" />
            </linearGradient>
          </defs>
          {/* Doble flecha hacia la derecha */}
          <path d="M15 7 L29 24 L15 41 L15 34 L22 24 L15 14 Z" fill={`url(#${gradId})`} />
          <path d="M27 7 L41 24 L27 41 L27 34 L34 24 L27 14 Z" fill={`url(#${gradId})`} />
        </svg>
      </div>
      <span className={cn(s.text, 'font-bold tracking-wide')}>
        <span className="text-gray-900 dark:text-white">NE</span>
        <span className="text-[#1E6BFF]">X</span>
        <span className="text-gray-900 dark:text-white">T</span>
      </span>
    </div>
  );
}
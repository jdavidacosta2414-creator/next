import { Navigate } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import { getHomeForRole, canAccess } from '@/lib/roles';

// Protege una ruta para que solo ciertos roles puedan accederla.
// Si el usuario no tiene el rol permitido, es redirigido a su propio panel.
export default function RoleRoute({ allowedRoles, children }) {
  const { user } = useAuth();
  const role = user?.role;

  if (!canAccess(role, allowedRoles)) {
    return <Navigate to={getHomeForRole(role)} replace />;
  }

  return children;
}
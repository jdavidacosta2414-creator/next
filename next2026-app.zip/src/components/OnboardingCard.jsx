import React from 'react';
import { cn } from '@/lib/utils';

// Pantalla completa de onboarding: fondo blanco en modo día, negro en modo noche.
// Sin marco — ocupa toda la pantalla.
export default function OnboardingCard({ children, className }) {
  return (
    <div className="min-h-screen bg-white dark:bg-black flex flex-col px-6 py-8 max-w-md mx-auto w-full">
      <div className={cn('w-full flex flex-col flex-1', className)}>
        {children}
      </div>
    </div>
  );
}
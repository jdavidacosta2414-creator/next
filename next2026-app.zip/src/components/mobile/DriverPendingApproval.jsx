import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Clock,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  ArrowLeft,
  Bike,
  Car,
  FileCheck,
  LogOut,
} from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { setExplicitUserMode } from '@/lib/roles';
import ResolvedAvatar from '@/components/shared/ResolvedAvatar';
import { useToast } from '@/components/ui/use-toast';
import DriverCategoryList from '@/components/driver/DriverCategoryList';

export default function DriverPendingApproval({ mobile, onRefresh }) {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [checking, setChecking] = useState(false);

  const isRejected = mobile?.approval_status === 'rechazado';
  const isCar = mobile?.vehicle_type === 'carro';

  const handleCheckStatus = async () => {
    setChecking(true);
    try {
      const list = await base44.entities.Mobile.filter({ id: mobile.id });
      const fresh = Array.isArray(list) ? list[0] : list?.items?.[0];
      if (fresh) {
        onRefresh?.(fresh);
        if (!fresh.approval_status || fresh.approval_status === 'aprobado') {
          toast({
            title: '¡Cuenta activada por la Central!',
            description: 'Tus documentos fueron verificados. Ya puedes trabajar como conductor.',
          });
          return;
        }
      }
      toast({
        title: isRejected ? 'Solicitud observada por Central' : 'Aún en revisión por la Central',
        description: isRejected
          ? 'Corrige los documentos indicados para enviarlos nuevamente.'
          : 'La Central sigue verificando tus documentos. Te activaremos apenas finalice la revisión.',
      });
    } catch {
    } finally {
      setChecking(false);
    }
  };

  const goBackToPassenger = () => {
    setExplicitUserMode('pasajero');
    window.location.replace('/cliente');
  };

  const docItems = [
    { label: 'Foto de perfil (rostro)', ok: Boolean(mobile?.photo_url) },
    { label: 'Cédula de ciudadanía', ok: Boolean(mobile?.verification_photo) },
    { label: 'Tarjeta de propiedad', ok: Boolean(mobile?.tarjeta_photo) },
    { label: 'Foto del vehículo con placa visible', ok: Boolean(mobile?.vehicle_photo) },
    ...(isCar
      ? [
          { label: 'SOAT vigente', ok: Boolean(mobile?.soat_photo) },
          { label: 'Revisión Técnico-Mecánica vigente', ok: Boolean(mobile?.tecno_photo) },
        ]
      : []),
  ];

  return (
    <div className="min-h-screen bg-[#F4F7FB] dark:bg-[#0B0F1A] flex flex-col px-6 py-8 max-w-md mx-auto w-full">
      <div className="flex items-center justify-between mb-6">
        <button
          type="button"
          onClick={goBackToPassenger}
          className="inline-flex items-center gap-2 px-3.5 h-10 rounded-full bg-white dark:bg-[#161C28] text-slate-900 dark:text-white text-xs font-bold shadow-sm border border-slate-200/70 dark:border-white/10"
        >
          <ArrowLeft className="w-4 h-4" />
          Modo pasajero
        </button>

        <button
          type="button"
          onClick={() => base44.auth.logout('/')}
          className="inline-flex items-center gap-1.5 px-3 h-9 rounded-full text-xs font-semibold text-slate-500 dark:text-[#8B95A8] hover:text-slate-900 dark:hover:text-white"
        >
          <LogOut className="w-4 h-4" />
          Salir
        </button>
      </div>

      <div className="bg-white dark:bg-[#121829] border border-slate-200/80 dark:border-white/10 rounded-3xl p-6 shadow-xl space-y-5">
        <div className="flex flex-col items-center text-center">
          <div className="relative mb-3">
            <ResolvedAvatar
              photo={mobile?.photo_url}
              name={mobile?.name || 'Conductor'}
              className="w-20 h-20 rounded-full bg-[#09357A] border-2 border-[#00D4FF] text-white font-extrabold text-2xl shadow-lg"
            />
            <span
              className={`absolute -bottom-1 -right-1 w-8 h-8 rounded-full flex items-center justify-center border-2 border-white dark:border-[#121829] ${
                isRejected ? 'bg-red-500 text-white' : 'bg-amber-400 text-[#0B0F1A]'
              }`}
            >
              {isRejected ? <AlertTriangle className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
            </span>
          </div>

          <span
            className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-extrabold uppercase tracking-wider mb-2 ${
              isRejected
                ? 'bg-red-500/15 text-red-500 border border-red-500/30'
                : 'bg-amber-500/15 text-amber-600 dark:text-amber-300 border border-amber-500/30'
            }`}
          >
            {isRejected ? 'Documentos rechazados por Central' : 'Esperando activación de la Central'}
          </span>

          <h1 className="text-slate-900 dark:text-white text-xl font-extrabold">
            {mobile?.name || 'Conductor'}
          </h1>
          <p className="text-xs text-slate-500 dark:text-[#8B95A8] mt-0.5 flex items-center gap-1.5">
            {isCar ? <Car className="w-3.5 h-3.5 text-[#1E6BFF]" /> : <Bike className="w-3.5 h-3.5 text-[#1E6BFF]" />}
            <span>
              {[mobile?.vehicle_brand, mobile?.vehicle_model].filter(Boolean).join(' ')} · Placa{' '}
              <strong className="text-slate-800 dark:text-white">{mobile?.plate || '—'}</strong>
            </span>
          </p>
        </div>

        {isRejected ? (
          <div className="rounded-2xl bg-red-500/10 border border-red-500/25 p-4 text-left space-y-1.5">
            <p className="text-xs font-extrabold text-red-500 uppercase tracking-wide">
              Motivo indicado por la Central:
            </p>
            <p className="text-sm text-slate-800 dark:text-red-200 leading-relaxed">
              {mobile?.approval_notes ||
                'Alguno de los documentos adjuntos no es legible o no coincide con los datos del vehículo. Por favor vuelve a subirlos.'}
            </p>
          </div>
        ) : (
          <div className="rounded-2xl bg-[#1E6BFF]/10 border border-[#1E6BFF]/25 p-4 text-left space-y-1.5">
            <div className="flex items-center gap-2 text-[#1E6BFF] dark:text-[#00E5FF] font-extrabold text-xs uppercase tracking-wide">
              <ShieldCheck className="w-4 h-4 flex-shrink-0" />
              <span>Verificación de documentos en curso</span>
            </div>
            <p className="text-xs text-slate-600 dark:text-[#CBD5E1] leading-relaxed">
              Tu registro como conductor fue enviado correctamente. La Central está verificando todos tus documentos y habilitará tu cuenta para que puedas conectarte y recibir servicios.
            </p>
          </div>
        )}

        <div className="space-y-2">
          <p className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-[#8B95A8] flex items-center gap-1.5">
            <FileCheck className="w-3.5 h-3.5 text-[#1E6BFF]" />
            Documentos enviados a la Central
          </p>
          <div className="space-y-1.5">
            {docItems.map((item) => (
              <div
                key={item.label}
                className="flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200/60 dark:border-white/8 text-xs"
              >
                <span className="text-slate-700 dark:text-slate-200 font-medium">{item.label}</span>
                <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-bold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Recibido
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <p className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-[#8B95A8]">
            Mis categorías
          </p>
          <DriverCategoryList mobile={mobile} />
        </div>

        <div className="space-y-2.5 pt-1">
          {isRejected ? (
            <button
              type="button"
              onClick={() => navigate('/vinculate/conductor')}
              className="w-full h-12 rounded-full bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#1E6BFF]/30"
            >
              Corregir y volver a enviar documentos
            </button>
          ) : (
            <button
              type="button"
              onClick={handleCheckStatus}
              disabled={checking}
              className="w-full h-12 rounded-full bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#1E6BFF]/30 disabled:opacity-60"
            >
              <RefreshCw className={`w-4 h-4 ${checking ? 'animate-spin' : ''}`} />
              {checking ? 'Consultando estado...' : 'Verificar si la Central ya me activó'}
            </button>
          )}

          <button
            type="button"
            onClick={goBackToPassenger}
            className="w-full h-11 rounded-full bg-slate-100 dark:bg-white/8 text-slate-800 dark:text-white font-semibold text-xs flex items-center justify-center gap-2 hover:opacity-90"
          >
            Seguir usando la app en Modo Pasajero
          </button>
        </div>
      </div>
    </div>
  );
}
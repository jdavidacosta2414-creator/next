import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { toast } from '@/components/ui/use-toast';
import {
  Bike, Phone, CreditCard, LogOut, Wallet, History, LifeBuoy, Gift,
  Map as MapIcon, BadgeCheck, Bell, FileText, BarChart3, Settings, ChevronRight,
  Plus, Shield, Loader2, XCircle, Copy, Check, Clock, Bike as BikeIcon
} from 'lucide-react';
import StatusBadge from '@/components/StatusBadge';
import TermsContent from '@/components/mobile/TermsContent';
import PrivateImageCapture from '@/components/shared/PrivateImageCapture';
import ResolvedAvatar from '@/components/shared/ResolvedAvatar';
import {
  getMinRecharge, isPassActive, passExpiry, canWork, getEffectiveBalance,
  PAYMENT_ACCOUNTS, PAYMENT_LABELS, qrCodeUrl, accountById,
} from '@/lib/recharge';

const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');

export default function DriverProfile({ mobile, user, onLogout, onNavigate, onBalanceUpdate }) {
  const [showRecharge, setShowRecharge] = useState(false);
  const [showTerms, setShowTerms] = useState(false);

  // Estado de recarga
  const [method, setMethod] = useState('nequi');
  const [amount, setAmount] = useState('');
  const [transferPhoto, setTransferPhoto] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [copied, setCopied] = useState(false);
  const [pendingReq, setPendingReq] = useState(null);

  const minAmount = getMinRecharge(mobile.vehicle_type);
  const paseActivo = isPassActive(mobile);
  const puedeTrabajar = canWork(mobile);
  const vence = passExpiry(mobile);
  const modo = mobile.pass_mode || 'comision';
  const effectiveBalance = getEffectiveBalance(mobile);

  // Cargar solicitud pendiente del conductor.
  useEffect(() => {
    (async () => {
      try {
        const list = await base44.entities.RechargeRequest.filter(
          { mobile_id: mobile.id, status: 'pendiente' },
          '-created_date', 1
        );
        if (list.length) setPendingReq(list[0]);
      } catch (e) {}
    })();
  }, [mobile.id]);

  const submitRecharge = async () => {
    const amt = parseInt(amount) || 0;
    if (amt < minAmount) {
      toast({ title: 'Monto insuficiente', description: `El mínimo es ${fmtCOP(minAmount)}`, variant: 'destructive' });
      return;
    }
    if (!transferPhoto) {
      toast({ title: 'Falta el comprobante', description: 'Sube la captura de la transferencia', variant: 'destructive' });
      return;
    }
    setSubmitting(true);
    try {
      const created = await base44.entities.RechargeRequest.create({
        mobile_id: mobile.id,
        mobile_name: mobile.name,
        amount: amt,
        payment_method: method,
        transfer_photo: transferPhoto,
        status: 'pendiente',
      });
      setPendingReq(created);
      toast({ title: 'Solicitud enviada', description: 'La central verificará tu transferencia.' });
      setShowRecharge(false);
      setAmount('');
      setTransferPhoto('');
    } catch (e) {
      toast({ title: 'No se pudo enviar', description: e.message || 'Intenta de nuevo', variant: 'destructive' });
    } finally {
      setSubmitting(false);
    }
  };

  const copyAccount = (num) => {
    navigator.clipboard?.writeText(num);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const QUICK_CARDS = [
    { id: 'ganancias', label: 'Ganancias', icon: Wallet },
    { id: 'historial', label: 'Historial', icon: History },
    { id: 'soporte', label: 'Soporte', icon: LifeBuoy },
    { id: 'incentivos', label: 'Incentivos', icon: Gift },
  ];

  const OPTIONS = [
    { id: 'mapa-calor', label: 'Mapa de calor', icon: MapIcon, desc: 'Zonas con más demanda' },
    { id: 'carnet', label: 'Carnet del conductor', icon: BadgeCheck, desc: 'Tu identificación MotoLink' },
    { id: 'notificaciones', label: 'Notificaciones', icon: Bell, desc: 'Versión 3.5.5' },
    { id: 'tendencia', label: 'Tendencia en tu zona', icon: BarChart3, desc: 'Estadísticas de demanda' },
    { id: 'terminos', label: 'Términos y condiciones', icon: FileText },
    { id: 'configuracion', label: 'Ir a configuración', icon: Settings },
  ];

  const selectedAccount = accountById(method);

  return (
    <div className="space-y-4">
      {/* Datos de contacto */}
      <div className="bg-card rounded-2xl p-5 shadow-sm border border-border">
        <div className="flex items-center gap-4 mb-4">
          <ResolvedAvatar
            photo={mobile.photo_url || user?.photo_url}
            name={mobile.name}
            className="w-16 h-16 rounded-full bg-primary/10 text-primary font-bold text-xl"
            fallback={<Bike className="w-8 h-8 text-primary" />}
          />
          <div className="min-w-0 flex-1">
            <h2 className="font-bold text-foreground truncate">{mobile.name}</h2>
            <p className="text-sm text-muted-foreground">Placa: {mobile.plate}</p>
            <div className="mt-1 flex items-center gap-2 flex-wrap">
              <StatusBadge status={mobile.status} />
              {mobile.blocked && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-destructive/15 text-destructive">
                  <Shield className="w-3 h-3" /> Bloqueado
                </span>
              )}
            </div>
          </div>
        </div>
        <div className="space-y-2 text-sm border-t border-border pt-3">
          {mobile.phone && (
            <div className="flex items-center gap-2 text-muted-foreground">
              <Phone className="w-4 h-4 text-muted-foreground" />{mobile.phone}
            </div>
          )}
          {user?.email && (
            <div className="flex items-center gap-2 text-muted-foreground">
              <CreditCard className="w-4 h-4 text-muted-foreground" />{user.email}
            </div>
          )}
        </div>
      </div>

      {/* Mi saldo / Pase diario */}
      <div className="bg-gradient-to-br from-primary to-primary/80 rounded-2xl p-5 text-primary-foreground shadow-sm">
        <div className="flex items-center justify-between mb-1">
          <span className="text-sm font-medium opacity-90">Saldo disponible</span>
          <Wallet className="w-5 h-5 opacity-90" />
        </div>
        <p className="text-3xl font-bold">{fmtCOP(effectiveBalance)}</p>

        {/* Estado del pase de 14 horas laborales */}
        <div className={`mt-3 rounded-xl px-3 py-2 flex items-center gap-2 ${puedeTrabajar ? 'bg-white/20' : 'bg-black/20'}`}>
          {paseActivo ? (
            <><Check className="w-4 h-4" /><span className="text-sm font-medium">Pase 14h activo · vence {new Date(vence).toLocaleString('es-CO', { timeZone: 'America/Bogota', dateStyle: 'short', timeStyle: 'short' })}</span></>
          ) : (
            <><Clock className="w-4 h-4" /><span className="text-sm font-medium">Pase de 14h vencido (saldo en $0) — debes recargar para seguir tomando servicios</span></>
          )}
        </div>

        <button onClick={() => setShowRecharge(true)} className="mt-3 w-full h-10 rounded-xl bg-white/20 hover:bg-white/30 flex items-center justify-center gap-2 text-sm font-medium transition-colors">
          <Plus className="w-4 h-4" /> Activar pase de 14h laborales
        </button>
        <p className="text-xs opacity-75 mt-2">Pase de 14 horas laborales: {fmtCOP(7000)} moto / {fmtCOP(10000)} carro · Sin descuento por porcentaje</p>
      </div>

      {/* Solicitud pendiente */}
      {pendingReq && (
        <div className="bg-[#F59E0B]/10 border border-[#F59E0B]/20 rounded-2xl p-4">
          <p className="text-sm font-medium text-[#F59E0B]">Solicitud de recarga en revisión</p>
          <p className="text-xs text-[#8B95A8] mt-1">Esperando verificación de la central · {fmtCOP(pendingReq.amount)} vía {PAYMENT_LABELS[pendingReq.payment_method]}</p>
        </div>
      )}

      {/* Accesos rápidos */}
      <div className="flex gap-3 overflow-x-auto pb-1">
        {QUICK_CARDS.map(card => {
          const Icon = card.icon;
          return (
            <button
              key={card.id}
              onClick={() => onNavigate?.(card.id)}
              className="flex-shrink-0 w-20 flex flex-col items-center gap-1.5 p-3 rounded-xl bg-card border border-border hover:border-primary/30 transition-colors"
            >
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Icon className="w-5 h-5 text-primary" />
              </div>
              <span className="text-xs font-medium text-foreground">{card.label}</span>
            </button>
          );
        })}
      </div>

      {/* Lista de opciones */}
      <div className="bg-card rounded-2xl shadow-sm border border-border overflow-hidden">
        {OPTIONS.map((opt, i) => {
          const Icon = opt.icon;
          return (
            <button
              key={opt.id}
              onClick={() => opt.id === 'terminos' ? setShowTerms(true) : onNavigate?.(opt.id)}
              className={`w-full flex items-center gap-3 p-4 hover:bg-accent/50 transition-colors ${i < OPTIONS.length - 1 ? 'border-b border-border' : ''}`}
            >
              <div className="w-9 h-9 rounded-lg bg-muted flex items-center justify-center">
                <Icon className="w-5 h-5 text-muted-foreground" />
              </div>
              <div className="flex-1 text-left min-w-0">
                <p className="text-sm font-medium text-foreground">{opt.label}</p>
                {opt.desc && <p className="text-xs text-muted-foreground">{opt.desc}</p>}
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </button>
          );
        })}
      </div>

      {/* Cerrar sesión */}
      <button
        onClick={onLogout}
        className="w-full flex items-center justify-center gap-2 h-12 rounded-xl bg-destructive/10 text-destructive font-medium text-sm hover:bg-destructive/20 transition-colors"
      >
        <LogOut className="w-4 h-4" /> Cerrar sesión
      </button>

      {/* Modal de Términos y Condiciones */}
      {showTerms && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50" onClick={() => setShowTerms(false)}>
          <div className="bg-card rounded-t-2xl sm:rounded-2xl p-5 w-full max-w-sm max-h-[85vh] flex flex-col" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-foreground">Términos y Condiciones</h3>
              <button onClick={() => setShowTerms(false)}><XCircle className="w-5 h-5 text-muted-foreground" /></button>
            </div>
            <div className="overflow-y-auto no-scrollbar flex-1 pr-1">
              <TermsContent />
            </div>
          </div>
        </div>
      )}

      {/* Modal de recarga */}
      {showRecharge && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60" onClick={() => setShowRecharge(false)}>
          <div className="bg-[#0B0F1A] rounded-t-3xl sm:rounded-3xl p-5 w-full max-w-md max-h-[92vh] overflow-y-auto no-scrollbar" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-white text-lg">Activar pase de 14h laborales</h3>
              <button onClick={() => setShowRecharge(false)}><XCircle className="w-5 h-5 text-[#8B95A8]" /></button>
            </div>

            <p className="text-sm text-[#8B95A8] mb-4">
              Transfiere <span className="text-white font-semibold">{fmtCOP(minAmount)}</span> a una de las cuentas, sube el comprobante y la Central activará tus 14 horas laborales (sin comisión por porcentaje). Al cumplirse las 14 horas, tu saldo volverá a $0.
            </p>

            {/* Selector de método */}
            <div className="flex gap-2 mb-3">
              {PAYMENT_ACCOUNTS.map((a) => (
                <button
                  key={a.id}
                  onClick={() => setMethod(a.id)}
                  className={`flex-1 h-10 rounded-xl text-xs font-semibold transition-all ${method === a.id ? 'bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white' : 'bg-white/5 border border-white/10 text-[#8B95A8]'}`}
                >
                  {a.label}
                </button>
              ))}
            </div>

            {/* Detalle de la cuenta */}
            <div className="bg-[#121829] rounded-2xl p-4 border border-white/8 mb-4">
              <div className="flex items-start gap-4">
                <img src={qrCodeUrl(selectedAccount.number)} alt="QR" className="w-24 h-24 rounded-xl bg-white p-1 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-[#8B95A8]">{selectedAccount.label}</p>
                  <p className="text-white font-bold text-lg break-all">{selectedAccount.number}</p>
                  <p className="text-xs text-[#8B95A8] mt-0.5">{selectedAccount.holder}</p>
                  {selectedAccount.accountType && <p className="text-xs text-[#8B95A8]">{selectedAccount.accountType}</p>}
                  <button onClick={() => copyAccount(selectedAccount.number)} className="mt-2 inline-flex items-center gap-1 text-xs text-[#00E5FF] font-medium">
                    {copied ? <><Check className="w-3.5 h-3.5" />Copiado</> : <><Copy className="w-3.5 h-3.5" />Copiar número</>}
                  </button>
                </div>
              </div>
            </div>

            {/* Monto */}
            <label className="text-xs text-[#8B95A8] font-medium">Monto transferido</label>
            <div className="relative mt-1 mb-2">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-[#8B95A8]">$</span>
              <input
                type="number"
                min={minAmount}
                placeholder={String(minAmount)}
                value={amount}
                onChange={e => setAmount(e.target.value)}
                className="w-full h-11 rounded-xl bg-[#121829] border border-white/10 pl-7 pr-3 text-white text-lg font-bold outline-none focus:border-[#00E5FF]/50"
              />
            </div>
            <div className="flex gap-2 mb-4">
              {[minAmount, minAmount + 2000, minAmount + 5000].map((amt, i) => (
                <button key={i} onClick={() => setAmount(String(amt))} className="flex-1 h-9 rounded-lg border border-white/10 text-sm font-medium text-[#8B95A8] hover:bg-white/5">
                  {fmtCOP(amt)}
                </button>
              ))}
            </div>

            {/* Comprobante */}
            <label className="text-xs text-[#8B95A8] font-medium">Comprobante de transferencia</label>
            <div className="mt-1 mb-4">
              <PrivateImageCapture label="Subir captura del comprobante" value={transferPhoto} onChange={setTransferPhoto} facing={null} height="h-36" />
            </div>

            <button
              onClick={submitRecharge}
              disabled={submitting}
              className="w-full h-12 rounded-full bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white font-bold text-sm hover:opacity-90 disabled:opacity-50 flex items-center justify-center gap-2 shadow-lg shadow-[#1E6BFF]/30"
            >
              {submitting ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Enviar solicitud'}
            </button>
            <p className="text-xs text-[#5A6478] text-center mt-3">El comprobante se guarda de forma privada y solo lo revisa la central.</p>
          </div>
        </div>
      )}
    </div>
  );
}
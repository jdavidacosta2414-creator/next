import React, { useState, useEffect, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { MapPin, Navigation, Star, Loader2, Bike, Trophy, Search } from 'lucide-react';
import StatusBadge from '@/components/StatusBadge';
import DateRangePicker from '@/components/shared/DateRangePicker';
import ClientAvatar from '@/components/shared/ClientAvatar';

const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');

export default function MobileHistory({ mobileId }) {
  const [services, setServices] = useState([]);
  const [rankInfo, setRankInfo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [range, setRange] = useState({ from: new Date(), to: new Date() });
  const [search, setSearch] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const [allServices, mobiles] = await Promise.all([
          base44.entities.Service.list('-created_date', 500),
          base44.entities.Mobile.list(),
        ]);
        const stats = mobiles.map(m => {
          const ms = allServices.filter(s => s.mobile_id === m.id);
          const completed = ms.filter(s => s.status === 'finalizado');
          const rated = completed.filter(s => s.rating != null);
          const avg = rated.length > 0 ? rated.reduce((s, x) => s + x.rating, 0) / rated.length : 0;
          return { id: m.id, name: m.name, total: completed.length, avg: Math.round(avg * 10) / 10 };
        });
        const sorted = [...stats].sort((a, b) => b.avg - a.avg);
        const pos = sorted.findIndex(s => s.id === mobileId);
        if (pos >= 0) setRankInfo({ position: pos + 1, total: sorted.length, ...sorted[pos] });
        setServices(allServices.filter(s => s.mobile_id === mobileId));
      } catch (e) {
        console.error('History load error:', e);
      } finally {
        setLoading(false);
      }
    })();
  }, [mobileId]);

  const filtered = useMemo(() => {
    return services.filter(s => {
      const d = new Date(s.created_date);
      const inRange = (!range?.from || d >= range.from) && (!range?.to || d <= new Date(range.to.getTime() + 86400000));
      const matchesSearch = !search ||
        s.pickup_address?.toLowerCase().includes(search.toLowerCase()) ||
        s.destination_address?.toLowerCase().includes(search.toLowerCase()) ||
        s.client_name?.toLowerCase().includes(search.toLowerCase()) ||
        s.service_type?.toLowerCase().includes(search.toLowerCase());
      return inRange && matchesSearch;
    });
  }, [services, range, search]);

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>;

  return (
    <div className="space-y-3">
      {rankInfo && (
        <div className="bg-gradient-to-r from-primary to-primary/80 rounded-2xl p-4 text-primary-foreground flex items-center gap-3">
          <Trophy className="w-6 h-6 flex-shrink-0" />
          <div>
            <p className="text-sm font-semibold">Tu posición: #{rankInfo.position} de {rankInfo.total}</p>
            <p className="text-xs opacity-80">{rankInfo.total} servicios · ⭐ {rankInfo.avg.toFixed(1)}</p>
          </div>
        </div>
      )}

      {/* Filtros */}
      <div className="flex items-center gap-3 bg-card rounded-xl p-3 border border-border">
        <DateRangePicker range={range} onChange={setRange} />
        <div className="flex-1 relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Buscar..."
            className="w-full h-9 rounded-lg border border-border pl-8 pr-3 text-sm text-foreground bg-card"
            style={{ color: '#1A1A1A', backgroundColor: '#fff' }}
          />
        </div>
      </div>

      <h3 className="text-sm font-semibold text-muted-foreground">Historial ({filtered.length})</h3>
      {filtered.length === 0 ? (
        <div className="text-center py-12"><Bike className="w-10 h-10 text-muted-foreground/30 mx-auto mb-2" /><p className="text-sm text-muted-foreground">No hay servicios en este rango</p></div>
      ) : filtered.map(s => (
        <div key={s.id} className="bg-card rounded-2xl p-4 shadow-sm border border-border">
          <div className="flex items-center justify-between gap-2 mb-2">
            <div className="flex items-center gap-2 min-w-0">
              <ClientAvatar photo={s.client_photo} name={s.client_name} size="sm" />
              <span className="text-sm font-medium text-foreground truncate">{s.client_name}</span>
            </div>
            <StatusBadge status={s.status} />
          </div>
          <div className="space-y-1 text-xs text-muted-foreground mb-2">
            <div className="flex items-start gap-1.5"><MapPin className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" /><span className="text-foreground">{s.pickup_address}</span></div>
            <div className="flex items-start gap-1.5"><Navigation className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" /><span className="text-foreground">{s.destination_address}</span></div>
            <p className="text-xs text-muted-foreground">{new Date(s.created_date).toLocaleDateString('es-CO', { day: 'numeric', month: 'short', year: 'numeric' })}</p>
          </div>
          {s.fare && s.status === 'finalizado' && (
            <div className="flex items-center justify-between pt-2 border-t border-border">
              <span className="text-sm font-bold text-primary">{fmtCOP(s.fare)}</span>
              {s.commission > 0 && <span className="text-xs text-destructive">Comisión: {fmtCOP(s.commission)}</span>}
            </div>
          )}
          {s.rating && (
            <div className="flex items-center gap-1 pt-2 border-t border-border">
              <span className="text-xs text-muted-foreground">Calificación:</span>
              {[1,2,3,4,5].map(n => <Star key={n} className={`w-3.5 h-3.5 ${n <= s.rating ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground/30'}`} />)}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
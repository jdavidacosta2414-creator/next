import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useBackButton } from '@/hooks/useBackButton';
import { toast } from '@/components/ui/use-toast';
import { safeInvoke, withRetry } from '@/lib/api-helpers';
import {
  Check,
  Loader2,
  Phone,
  Package,
  Users,
  MessageCircle,
  Navigation,
  MapPin,
  ArrowLeft,
  Star,
  Briefcase,
  Flag,
  Banknote,
} from 'lucide-react';
import ImageCapture from '@/components/shared/ImageCapture';
import ServiceChat from '@/components/shared/ServiceChat';
import ReassignService from '@/components/mobile/ReassignService';
import ServiceBaseNotice from '@/components/mobile/ServiceBaseNotice';
import ClientWhatsAppButton from '@/components/mobile/ClientWhatsAppButton';
import DriverMap from '@/components/client/DriverMap';
import TripExtras from '@/components/shared/TripExtras';
import ServiceRatingModal from '@/components/shared/ServiceRatingModal';
import ClientAvatar from '@/components/shared/ClientAvatar';
import PassengerTrustBadge from '@/components/shared/PassengerTrustBadge';
import ResolvedAvatar from '@/components/shared/ResolvedAvatar';
import ServiceMessageAlertBanner, { playMessageChime } from '@/components/shared/ServiceMessageAlertBanner';
import { fetchPassengerStatsMap } from '@/lib/passengerStats';
import { calibrateRouteMetrics, estimateKm, calcSegments } from '@/lib/routeEstimate';
import { seedSavedRoute } from '@/lib/mapRoute';
import { shortAddress, joinBarrio, isIncompleteStreetAddress } from '@/lib/shortAddress';
import { reverseGeocodeValledupar } from '@/lib/geocode';
import {
  PhoneCallOriginalIcon,
  ChatMessageOriginalIcon,
} from '@/components/shared/OriginalActionIcons';
import InAppVoiceCallModal, { useInAppVoiceCall, isCallSignalMessage } from '@/components/shared/InAppVoiceCall';

const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');

const PAYMENT_LABELS = {
  efectivo: 'Efectivo',
  transferencia: 'Transferencia',
  nequi: 'Nequi',
  daviplata: 'DaviPlata',
  bancolombia: 'Bancolombia',
  paga_con_llave: 'Paga con llave',
  redimido_puntos: '🎁 Redimido por puntos',
};

function haversine(lat1, lng1, lat2, lng2) {
  if (lat1 == null || lat2 == null || lng1 == null || lng2 == null) return Infinity;
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

const CANCEL_REASON_LABELS = {
  ya_no_necesito: 'Ya no necesita el servicio',
  pedi_por_error: 'Pidió por error',
  conductor_demora: 'El conductor se demora',
  cambie_direccion: 'Cambió la dirección',
  direccion_equivocada: 'Dirección equivocada',
  precio_no_conviene: 'El precio no le convence',
  otro: 'Otro motivo',
};

const describeCancel = (data) => {
  const r = CANCEL_REASON_LABELS[data?.cancel_reason] || data?.cancel_reason || '';
  const d = data?.client_cancel_detail || '';
  return [r, d].filter(Boolean).join(' — ');
};

export default function ActiveService({
  service,
  mobile,
  driverEarnings = 0,
  initialChatOpen = false,
  onOpenEarnings,
  onDone,
  onBack,
}) {
  const [current, setCurrent] = useState(service);
  const [loading, setLoading] = useState(false);
  const [pickupPhoto, setPickupPhoto] = useState(service?.evidence_pickup_photo || '');
  const [deliveryPhoto, setDeliveryPhoto] = useState(service?.evidence_delivery_photo || '');
  const [chatOpen, setChatOpen] = useState(() => Boolean(initialChatOpen));
  const [unreadCount, setUnreadCount] = useState(0);
  const [msgAlert, setMsgAlert] = useState(null);
  const [showRating, setShowRating] = useState(false);
  const [pStats, setPStats] = useState(null);
  const [liveRoutes, setLiveRoutes] = useState({
    driverPos: null,
    toPickupRoute: null,
    toDestRoute: null,
  });
  const onDoneRef = useRef(onDone);
  const chatSectionRef = useRef(null);
  const seenMsgIdsRef = useRef(null);
  const chatOpenRef = useRef(false);

  useEffect(() => {
    onDoneRef.current = onDone;
  });
  useEffect(() => {
    chatOpenRef.current = chatOpen;
    if (chatOpen) setUnreadCount(0);
  }, [chatOpen]);

  useBackButton(
    () => {
      if (showRating) {
        setShowRating(false);
        return true;
      }
      if (chatOpen) {
        setChatOpen(false);
        return true;
      }
      return false;
    },
    true
  );

  useEffect(() => {
    if (initialChatOpen) {
      setChatOpen(true);
      setUnreadCount(0);
      setTimeout(() => {
        chatSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 150);
    }
  }, [initialChatOpen]);

  useEffect(() => {
    setCurrent(service);
    if (service?.status === 'finalizado' && service?.driver_rating == null) {
      setShowRating(true);
    }
    if (service?.id) {
      fetchPassengerStatsMap([service])
        .then((m) => setPStats(m[service.id] || { trips: 0, rating: null }))
        .catch(() => {});
    }
  }, [service]);

  // La foto recién tomada se conserva aunque el servicio abierto se recargue con los cambios en vivo;
  // solo se reinicia al abrir otro servicio.
  useEffect(() => {
    setPickupPhoto(service?.evidence_pickup_photo || '');
    setDeliveryPhoto(service?.evidence_delivery_photo || '');
  }, [service?.id]);

  useEffect(() => {
    if (!current?.id) return;
    let cancelled = false;
    (async () => {
      const patch = {};
      if (
        current.pickup_lat != null &&
        current.pickup_lng != null &&
        (!current.pickup_address || /^(valledupar|cesar|colombia)$/i.test(current.pickup_address.trim()))
      ) {
        const revPick = await reverseGeocodeValledupar(
          parseFloat(current.pickup_lat),
          parseFloat(current.pickup_lng)
        );
        if (revPick && revPick !== current.pickup_address) patch.pickup_address = revPick;
      }
      if (
        current.destination_lat != null &&
        current.destination_lng != null &&
        (!current.destination_address || /^(valledupar|cesar|colombia)$/i.test(current.destination_address.trim()))
      ) {
        const revDest = await reverseGeocodeValledupar(
          parseFloat(current.destination_lat),
          parseFloat(current.destination_lng)
        );
        if (revDest && revDest !== current.destination_address) patch.destination_address = revDest;
      }
      if (Array.isArray(current.stops) && current.stops.length > 0) {
        let stopsChanged = false;
        const resolvedStops = await Promise.all(
          current.stops.map(async (st) => {
            if (st?.lat != null && st?.lng != null && isIncompleteStreetAddress(st.address)) {
              const revSt = await reverseGeocodeValledupar(st.lat, st.lng);
              if (revSt && revSt !== st.address) {
                stopsChanged = true;
                return { ...st, address: revSt };
              }
            }
            return st;
          })
        );
        if (stopsChanged) patch.stops = resolvedStops;
      }
      if (!cancelled && Object.keys(patch).length > 0) {
        setCurrent((prev) => (prev ? { ...prev, ...patch } : prev));
        base44.entities.Service.update(current.id, patch).catch(() => {});
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [
    current?.id,
    current?.pickup_address,
    current?.destination_address,
    current?.pickup_lat,
    current?.pickup_lng,
    current?.destination_lat,
    current?.destination_lng,
  ]);

  useEffect(() => {
    if (!current?.id) return;
    const unsub = base44.entities.Service.subscribe((event) => {
      if (event.id !== current.id || event.type !== 'update') return;
      if (event.data?.status === 'cancelado') {
        // La cancelación de un negocio ya la avisa el panel del mensajero, con tono, vibración y mensaje.
        if (event.data.cancelled_by !== 'negocio') {
          toast({
            title: 'El pasajero canceló el servicio',
            description: describeCancel(event.data) || 'El servicio fue cancelado.',
            variant: 'destructive',
          });
        }
        onDoneRef.current?.();
      }
    });
    return unsub;
  }, [current?.id]);

  // Escuchar mensajes del pasajero en 0ms + respaldo cada 1s
  useEffect(() => {
    if (!current?.id) return;
    seenMsgIdsRef.current = null;
    let alive = true;

    const notifyClientMessageInstant = (msg) => {
      if (!msg?.id || msg.sender_type !== 'cliente' || isCallSignalMessage(msg)) return;
      if (!seenMsgIdsRef.current) {
        seenMsgIdsRef.current = new Set();
      }
      if (seenMsgIdsRef.current.has(msg.id)) return;
      seenMsgIdsRef.current.add(msg.id);
      const senderTitle = `Nuevo mensaje de ${msg.sender_name || current?.client_name || 'Pasajero'}`;
      playMessageChime(senderTitle, msg.message);
      setMsgAlert({
        id: msg.id,
        title: senderTitle,
        message: msg.message,
      });
      if (!chatOpenRef.current) {
        setUnreadCount((c) => c + 1);
      }
    };

    const checkIncomingMessages = async () => {
      try {
        const res = await base44.entities.ServiceMessage.filter(
          { service_id: current.id },
          'created_date',
          100
        );
        if (!alive) return;
        const items = (Array.isArray(res) ? res : res?.items || []).filter((m) => !isCallSignalMessage(m));

        if (seenMsgIdsRef.current === null) {
          seenMsgIdsRef.current = new Set(items.map((m) => m.id));
          return;
        }

        const newFromClient = items.filter(
          (m) => m.id && !seenMsgIdsRef.current.has(m.id) && m.sender_type === 'cliente'
        );
        items.forEach((m) => {
          if (m.id && m.sender_type !== 'cliente') seenMsgIdsRef.current.add(m.id);
        });

        newFromClient.forEach((m) => notifyClientMessageInstant(m));
      } catch {}
    };

    checkIncomingMessages();
    const unsub = base44.entities.ServiceMessage.subscribe((ev) => {
      const msg = ev?.data;
      if (msg && msg.service_id === current.id) {
        if (msg.sender_type === 'cliente') {
          notifyClientMessageInstant(msg);
        } else if (msg.id && seenMsgIdsRef.current) {
          seenMsgIdsRef.current.add(msg.id);
        }
        return;
      }
      checkIncomingMessages();
    });
    const poll = setInterval(checkIncomingMessages, 1000);
    const onVisible = () => {
      if (typeof document === 'undefined' || document.visibilityState === 'visible') {
        checkIncomingMessages();
      }
    };
    window.addEventListener('focus', onVisible);
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      alive = false;
      unsub();
      clearInterval(poll);
      window.removeEventListener('focus', onVisible);
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, [current?.id, current?.client_name]);

  useEffect(() => {
    if (!msgAlert) return;
    const t = setTimeout(() => setMsgAlert(null), 9000);
    return () => clearTimeout(t);
  }, [msgAlert]);

  const handleOpenChatFromBanner = () => {
    setMsgAlert(null);
    setChatOpen(true);
    setUnreadCount(0);
    setTimeout(() => {
      const el = chatSectionRef.current;
      if (!el) return;
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 150);
  };

  useEffect(() => {
    if (
      current.status !== 'asignado' &&
      current.status !== 'en_camino' &&
      current.status !== 'recogida'
    ) {
      return;
    }
    const pushPosition = () => {
      navigator.geolocation?.getCurrentPosition(
        async (pos) => {
          try {
            await base44.entities.Mobile.update(mobile.id, {
              current_lat: pos.coords.latitude,
              current_lng: pos.coords.longitude,
            });
          } catch {}
        },
        () => {},
        { enableHighAccuracy: true, maximumAge: 1500, timeout: 6000 }
      );
    };
    pushPosition();
    const interval = setInterval(pushPosition, 3000);
    return () => clearInterval(interval);
  }, [current.status, mobile.id]);

  const notifyPassengerArrival = async () => {
    try {
      await base44.entities.ServiceMessage.create({
        service_id: current.id,
        sender_type: 'movil',
        sender_name: mobile?.name || 'Conductor',
        message: 'Tu conductor llegó al punto de recogida. Sal, por favor.',
      });
      toast({
        title: 'Aviso enviado al pasajero',
        description: 'Se notificó: "Tu conductor llegó al punto de recogida. Sal, por favor."',
      });
    } catch {}
  };

  const update = async (status, extra = {}) => {
    setLoading(true);
    try {
      if (status === 'finalizado') {
        const result = await safeInvoke('finalizeService', {
          service_id: current.id,
          collected_amount: current.fare,
          evidence_delivery_photo: extra.evidence_delivery_photo,
        });
        if (result.service) setCurrent(result.service);
        if (result.service?.driver_rating == null) {
          setShowRating(true);
        } else {
          onDone();
        }
      } else {
        const updated = await withRetry(() =>
          base44.entities.Service.update(current.id, { status, ...extra })
        );
        if (status === 'recogida') {
          base44.entities.ServiceMessage.create({
            service_id: current.id,
            sender_type: 'movil',
            sender_name: mobile?.name || 'Conductor',
            message: 'Tu conductor llegó al punto de recogida. Sal, por favor.',
          }).catch(() => {});
        }
        setCurrent(updated);
      }
    } catch (e) {
      toast({
        title: 'Error al actualizar',
        description: e.message || 'Intenta de nuevo',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const getPosition = () =>
    new Promise((resolve, reject) => {
      if (!navigator.geolocation) return reject(new Error('no-gps'));
      navigator.geolocation.getCurrentPosition((p) => resolve(p.coords), reject, {
        timeout: 8000,
        enableHighAccuracy: true,
      });
    });

  const guardAndAdvance = async (status, extra = {}) => {
    if (status === 'recogida' && current.pickup_lat != null && current.pickup_lng != null) {
      try {
        const c = await getPosition();
        const d = haversine(c.latitude, c.longitude, current.pickup_lat, current.pickup_lng);
        if (d > 0.2) {
          toast({
            title: 'No estás en el punto de recogida',
            description: `Estás a ${d.toFixed(2)} km. Acércate para continuar.`,
            variant: 'destructive',
          });
          return;
        }
      } catch {
        toast({
          title: 'Ubicación no disponible',
          description: 'Activa el GPS para confirmar la llegada.',
          variant: 'destructive',
        });
        return;
      }
    }
    if (
      status === 'finalizado' &&
      current.destination_lat != null &&
      current.destination_lng != null
    ) {
      try {
        const c = await getPosition();
        const d = haversine(
          c.latitude,
          c.longitude,
          current.destination_lat,
          current.destination_lng
        );
        if (d > 2) {
          toast({
            title: 'Aún no llegaste al destino',
            description: `Estás a ${d.toFixed(2)} km. Acércate para finalizar.`,
            variant: 'destructive',
          });
          return;
        }
      } catch {
        toast({
          title: 'Ubicación no disponible',
          description: 'Activa el GPS para finalizar.',
          variant: 'destructive',
        });
        return;
      }
    }
    update(status, extra);
  };

  const isMensajeria = current?.service_type === 'mensajeria';
  // Solo en mensajería: el mensajero contacta al cliente por su número (llamada normal del celular y WhatsApp).
  const clientPhone = isMensajeria ? String(current?.client_phone || '').replace(/[^\d+]/g, '') : '';
  const topAnchorRef = useRef(null);

  const drvLat = liveRoutes.driverPos?.[0] ?? mobile?.current_lat ?? current?.pickup_lat;
  const drvLng = liveRoutes.driverPos?.[1] ?? mobile?.current_lng ?? current?.pickup_lng;
  const vType = mobile?.vehicle_type || current?.vehicle_type || 'moto';
  const sType = current?.service_type || 'transporte';
  seedSavedRoute(current);
  const stopsCount = (current?.stops || []).filter((st) => st?.lat != null && st?.lng != null)
    .length;

  const fallbackSegs = calcSegments(
    drvLat,
    drvLng,
    current?.pickup_lat,
    current?.pickup_lng,
    current?.destination_lat,
    current?.destination_lng,
    vType,
    sType,
    current?.stops
  );

  const calPickup = calibrateRouteMetrics({
    routeInfo: liveRoutes.toPickupRoute,
    straightKm: estimateKm(drvLat, drvLng, current?.pickup_lat, current?.pickup_lng),
    stopsCount: 0,
    vehicleType: vType,
    serviceType: sType,
  });

  const calDest = calibrateRouteMetrics({
    routeInfo: liveRoutes.toDestRoute,
    straightKm: estimateKm(
      current?.status === 'recogida' ? drvLat : current?.pickup_lat,
      current?.status === 'recogida' ? drvLng : current?.pickup_lng,
      current?.destination_lat,
      current?.destination_lng
    ),
    stopsCount,
    vehicleType: vType,
    serviceType: sType,
  });

  const activePickupMin = Math.max(1, Math.round(calPickup.durationMin ?? fallbackSegs.seg1Min ?? 2));
  const activePickupKm = Number(calPickup.distanceKm ?? fallbackSegs.seg1Km ?? 0.4).toFixed(1);
  const activeDestMin = Math.max(1, Math.round(calDest.durationMin ?? fallbackSegs.seg2Min ?? 6));
  const activeDestKm = Number(calDest.distanceKm ?? fallbackSegs.seg2Km ?? 2.5).toFixed(1);
  const totalDistKm = (Number(activePickupKm) + Number(activeDestKm)).toFixed(1);

  useEffect(() => {
    try {
      window.scrollTo(0, 0);
      document.getElementById('driver-main-scroll')?.scrollTo({ top: 0, behavior: 'auto' });
      document.getElementById('apk-scroll-container')?.scrollTo({ top: 0, behavior: 'auto' });
    } catch {}
  }, [current?.id, current?.status]);

  const passengerPhoto = current?.client_photo || pStats?.photo || '';

  const voiceCall = useInAppVoiceCall({
    serviceId: current?.id,
    selfRole: 'movil',
    selfName: mobile?.name || 'Conductor',
    peerName: current?.client_name || 'Pasajero',
    peerPhoto: passengerPhoto,
    peerSubtitle: 'Pasajero verificado NEXT · Número protegido',
    enabled: Boolean(current?.id && current?.status !== 'finalizado' && current?.status !== 'cancelado'),
  });

  if (!current) {
    return (
      <div className="text-center py-12">
        <Navigation className="w-10 h-10 text-white/10 mx-auto mb-2" />
        <p className="text-sm text-[#8B95A8]">No tienes servicio activo</p>
      </div>
    );
  }

  return (
    <div ref={topAnchorRef} className="-mx-5 -mt-4 pb-6">
      <ServiceMessageAlertBanner
        alert={msgAlert}
        onOpen={handleOpenChatFromBanner}
        onDismiss={() => setMsgAlert(null)}
      />

      {/* Mapa de navegación inteligente cubriendo el 70% superior de la pantalla */}
      {current.status !== 'finalizado' && (
        <DriverMap
          mobileId={mobile.id}
          initialDriverLat={mobile.current_lat}
          initialDriverLng={mobile.current_lng}
          initialVehicleType={mobile.vehicle_type}
          initialVehicleColor={mobile.vehicle_color}
          initialIsTaxi={mobile.car_subtype === 'taxi'}
          driverEarnings={driverEarnings}
          onOpenEarnings={onOpenEarnings}
          pickupLat={current.pickup_lat != null ? parseFloat(current.pickup_lat) : null}
          pickupLng={current.pickup_lng != null ? parseFloat(current.pickup_lng) : null}
          destLat={current.destination_lat != null ? parseFloat(current.destination_lat) : null}
          destLng={current.destination_lng != null ? parseFloat(current.destination_lng) : null}
          stops={current.stops}
          pickupAddress={current.pickup_address}
          destAddress={current.destination_address}
          phase={current.status === 'recogida' ? 'to_dest' : 'to_pickup'}
          onRoutesUpdate={setLiveRoutes}
        />
      )}

      {/* Hoja inferior redondeada con foto del pasajero, estrellas, viajes realizados y detalles */}
      <div className="relative z-30 -mt-5 rounded-t-[28px] bg-white dark:bg-card border-t border-slate-200/80 dark:border-border shadow-[0_-10px_30px_rgba(15,23,42,0.16)] px-4 pt-3.5 pb-5 space-y-3">
        {onBack && (
          <button
            type="button"
            onClick={onBack}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 dark:text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Volver a lista de servicios
          </button>
        )}

        {/* Fila 1: Foto del pasajero + Nombre + Estrellas y viajes realizados + Estado */}
        <div className="flex items-center justify-between gap-3" data-testid="driver-active-passenger-header">
          <div className="flex items-center gap-3 min-w-0">
            <ClientAvatar
              photo={passengerPhoto}
              name={current.client_name || 'Pasajero'}
              size="lg"
            />
            <div className="min-w-0">
              <p
                className="text-[17px] font-extrabold text-[#0F172A] dark:text-white leading-tight truncate"
                data-testid="driver-active-passenger-name"
              >
                {current.client_name || 'Pasajero'}
              </p>
              <div className="mt-1" data-testid="driver-active-passenger-stats">
                <PassengerTrustBadge stats={pStats} />
              </div>
            </div>
          </div>

          <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 text-xs font-extrabold flex-shrink-0">
            <span className="w-2 h-2 rounded-full bg-[#22C55E]" />
            {current.status === 'recogida'
              ? 'En entrega'
              : current.status === 'finalizado'
              ? 'Finalizado'
              : 'En curso'}
          </span>
        </div>

        {/* Fila 2: Recogida y Entrega con minutos y km a la derecha (idéntico a la imagen 2) */}
        <div className="pt-2 border-t border-slate-100 dark:border-border/70">
          <div className="flex items-stretch gap-3">
            <div className="flex flex-col items-center py-1.5">
              <span className="w-3.5 h-3.5 rounded-full border-[3px] border-[#1463FF] bg-white flex-shrink-0" />
              <span className="w-0.5 flex-1 bg-slate-200 dark:bg-slate-700 my-1" />
              <span className="w-3.5 h-3.5 rounded-full bg-[#22C55E] flex-shrink-0" />
            </div>

            <div className="flex-1 min-w-0 space-y-3">
              {/* Tramo Recogida */}
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-xs font-bold text-[#0F172A] dark:text-white leading-tight">
                    Recogida
                  </p>
                  <p className={`text-[13px] font-medium text-slate-600 dark:text-slate-300 mt-0.5 ${current.origin === 'negocios' || current.pickup_barrio ? 'break-words' : 'truncate'}`}>
                    {current.origin === 'negocios' ? current.pickup_address : joinBarrio(shortAddress(current.pickup_address) || current.pickup_address, current.pickup_barrio)}
                  </p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-sm font-extrabold text-[#0F172A] dark:text-white leading-tight">
                    {activePickupMin} min
                  </p>
                  <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                    ({activePickupKm} km)
                  </p>
                </div>
              </div>

              {/* Paradas intermedias si existen */}
              {(current.stops || [])
                .filter((st) => (st?.address || '').trim())
                .map((st, idx) => (
                  <div key={idx} className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-amber-600 dark:text-amber-400 leading-tight">
                        Parada {idx + 1}
                      </p>
                      <p className={`text-xs font-medium text-slate-600 dark:text-slate-300 ${st.barrio ? 'break-words' : 'truncate'}`}>
                        {joinBarrio(shortAddress(st.address) || st.address, st.barrio)}
                      </p>
                    </div>
                  </div>
                ))}

              {/* Tramo Entrega / Destino */}
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-xs font-bold text-[#0F172A] dark:text-white leading-tight">
                    {isMensajeria ? 'Entrega' : 'Destino'}
                  </p>
                  <p className={`text-[13px] font-medium text-slate-600 dark:text-slate-300 mt-0.5 ${current.origin === 'negocios' || current.destination_barrio ? 'break-words' : 'truncate'}`}>
                    {current.origin === 'negocios' ? current.destination_address : joinBarrio(shortAddress(current.destination_address) || current.destination_address, current.destination_barrio)}
                  </p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-sm font-extrabold text-[#0F172A] dark:text-white leading-tight">
                    {activeDestMin} min
                  </p>
                  <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                    ({activeDestKm} km)
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Fila 3: Caja doble "Precio acordado $17.500" | "Distancia total 4.3 km" (idéntica a la imagen 2) */}
        <div className="rounded-2xl bg-slate-50 dark:bg-muted/70 border border-slate-200/80 dark:border-border p-3 grid grid-cols-2 divide-x divide-slate-200 dark:divide-border">
          <div className="flex items-center gap-2.5 pr-2">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center flex-shrink-0">
              <Banknote className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400 leading-tight">
                {current.origin === 'whatsapp' ? 'Precio fijo (WhatsApp)' : current.origin === 'negocios' ? 'Precio fijo (Negocio)' : 'Precio acordado'}
              </p>
              <p className="text-base font-black text-[#0F172A] dark:text-white leading-tight mt-0.5">
                {fmtCOP(current.fare || 5000)}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 pl-3">
            <div className="w-9 h-9 rounded-xl bg-[#EAF2FF] dark:bg-[#1E6BFF]/20 text-[#1463FF] dark:text-[#60A5FA] flex items-center justify-center flex-shrink-0">
              <Navigation className="w-4 h-4 fill-current" />
            </div>
            <div className="min-w-0">
              <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400 leading-tight">
                Distancia total
              </p>
              <p className="text-base font-black text-[#0F172A] dark:text-white leading-tight mt-0.5">
                {totalDistKm} km
              </p>
            </div>
          </div>
        </div>

        <ServiceBaseNotice value={current.order_value} format={fmtCOP} />

        {current.payment_method === 'redimido_puntos' && (
          <div className="rounded-2xl bg-[#00E5FF]/15 border border-[#00E5FF]/40 p-3 text-xs text-foreground">
            <p className="font-extrabold text-[#0091D5] dark:text-[#00E5FF]">
              🎁 Servicio redimido por puntos ({fmtCOP(current.fare || 5000)})
            </p>
            <p className="text-muted-foreground mt-0.5 leading-relaxed">
              No cobres efectivo al pasajero. Al finalizar, los {fmtCOP(current.fare || 5000)} se abonan a tu Cartera.
            </p>
          </div>
        )}

        {Number(current.free_ride_discount || 0) > 0 && (
          <div className="rounded-2xl bg-emerald-500/10 border border-emerald-500/30 p-3 text-xs text-foreground">
            <p className="font-extrabold text-emerald-600">🎁 Viaje gratis NEXT CLUB</p>
            <p className="text-muted-foreground mt-0.5 leading-relaxed">
              NEXT cubre {fmtCOP(current.free_ride_discount)}. Cobra al pasajero solo{' '}
              <b className="text-foreground">{fmtCOP(Math.max(0, Number(current.fare || 0) - Number(current.free_ride_discount || 0)))}</b>.
            </p>
          </div>
        )}

        <TripExtras service={current} />

        {/* Fila 4: Botón principal azul oscuro con bandera "🏁 Llegué al punto" */}
        <div className="space-y-2">
          {current.status === 'asignado' && (
            <button
              disabled={loading}
              onClick={() => update('en_camino')}
              className="w-full h-13 py-3.5 rounded-full bg-[#0B439C] hover:bg-[#09357A] text-white font-extrabold text-[15px] flex items-center justify-center gap-2 disabled:opacity-50 shadow-lg shadow-[#0B439C]/30"
            >
              {loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  <Flag className="w-4 h-4 fill-white" />
                  <span>Iniciar camino al punto</span>
                </>
              )}
            </button>
          )}

          {current.status === 'en_camino' && (
            <>
              {isMensajeria && !current.evidence_pickup_photo && (
                <div className="bg-muted rounded-2xl p-3 border border-border mb-2">
                  <p className="text-sm font-medium text-foreground mb-2">
                    Foto de evidencia de recogida
                  </p>
                  <ImageCapture
                    label="Tomar foto del paquete"
                    value={pickupPhoto}
                    onChange={setPickupPhoto}
                    facing="environment"
                    height="h-32"
                  />
                </div>
              )}
              <button
                disabled={loading || (isMensajeria && !pickupPhoto)}
                onClick={() =>
                  guardAndAdvance(
                    'recogida',
                    isMensajeria ? { evidence_pickup_photo: pickupPhoto } : {}
                  )
                }
                className="w-full h-13 py-3.5 rounded-full bg-[#0B439C] hover:bg-[#09357A] text-white font-extrabold text-[15px] flex items-center justify-center gap-2 disabled:opacity-50 shadow-lg shadow-[#0B439C]/30"
              >
                {loading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    <Flag className="w-4 h-4 fill-white" />
                    <span>Llegué al punto</span>
                  </>
                )}
              </button>
            </>
          )}

          {!isMensajeria && (current.status === 'asignado' || current.status === 'en_camino') && (
            <button
              type="button"
              disabled={loading}
              onClick={notifyPassengerArrival}
              className="w-full h-10 rounded-full bg-emerald-500/15 border border-emerald-500/35 text-emerald-700 dark:text-emerald-300 font-extrabold text-xs flex items-center justify-center gap-2 active:scale-[0.99] transition-transform"
            >
              🔔 Avisar al pasajero: Ya llegué al punto de recogida
            </button>
          )}

          {current.status === 'recogida' && (
            <>
              {isMensajeria && !current.evidence_delivery_photo && (
                <div className="bg-muted rounded-2xl p-3 border border-border mb-2">
                  <p className="text-sm font-medium text-foreground mb-2">
                    Foto de evidencia de entrega
                  </p>
                  <ImageCapture
                    label="Tomar foto de la entrega"
                    cameraOnly
                    value={deliveryPhoto}
                    onChange={setDeliveryPhoto}
                    facing="environment"
                    height="h-32"
                  />
                </div>
              )}
              <button
                disabled={loading || (isMensajeria && !deliveryPhoto)}
                onClick={() =>
                  guardAndAdvance(
                    'finalizado',
                    isMensajeria ? { evidence_delivery_photo: deliveryPhoto } : {}
                  )
                }
                className="w-full h-13 py-3.5 rounded-full bg-[#0B439C] hover:bg-[#09357A] text-white font-extrabold text-[15px] flex items-center justify-center gap-2 disabled:opacity-50 shadow-lg shadow-[#0B439C]/30"
              >
                {loading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    <Flag className="w-4 h-4 fill-white" />
                    <span>Llegué al punto (Finalizar)</span>
                  </>
                )}
              </button>
            </>
          )}

          {current.status === 'finalizado' && (
            <div className="space-y-2 pt-1">
              {current.driver_rating == null ? (
                <button
                  type="button"
                  onClick={() => setShowRating(true)}
                  className="w-full h-12 rounded-full bg-[#0B439C] text-white font-bold flex items-center justify-center gap-2 shadow-lg"
                >
                  <Star className="w-4 h-4 fill-white" /> Calificar al pasajero
                </button>
              ) : (
                <button
                  type="button"
                  onClick={onDone}
                  className="w-full h-12 rounded-full bg-[#22C55E] text-white font-bold flex items-center justify-center gap-2"
                >
                  <Check className="w-4 h-4" /> Volver a servicios disponibles
                </button>
              )}
            </div>
          )}
        </div>

        {/* Contacto seguro en la app tipo inDrive (Llamar en app y Mensaje interno sin exponer número ni WhatsApp) */}
        {current.status !== 'finalizado' && (
          <div className="grid grid-cols-2 gap-2.5 pt-1" data-testid="driver-contact-actions">
            <button
              type="button"
              onClick={() => {
                if (clientPhone) window.location.href = `tel:${clientPhone}`;
                else voiceCall.startCall();
              }}
              className="h-12 rounded-2xl bg-slate-50 dark:bg-muted border border-slate-200/80 dark:border-border flex items-center justify-center gap-2 text-[#0F172A] dark:text-white text-xs font-extrabold active:scale-95 transition-transform"
              data-testid="driver-call-btn"
            >
              <PhoneCallOriginalIcon className="w-6 h-6 flex-shrink-0" />
              <span>Llamar</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setChatOpen((v) => !v);
                setUnreadCount(0);
                setMsgAlert(null);
              }}
              className="relative h-12 rounded-2xl bg-[#EAF2FF] dark:bg-[#1E6BFF]/20 border border-[#1463FF]/25 text-[#0B439C] dark:text-sky-300 flex items-center justify-center gap-2 text-xs font-extrabold active:scale-95 transition-transform"
              data-testid="driver-open-chat-btn"
            >
              <ChatMessageOriginalIcon className="w-6 h-6 flex-shrink-0" />
              <span>Mensaje</span>
              {unreadCount > 0 && (
                <span
                  className="absolute -top-1.5 -right-1.5 min-w-[20px] h-5 px-1.5 rounded-full bg-rose-500 text-white text-[10px] font-black flex items-center justify-center shadow"
                  data-testid="driver-unread-badge"
                >
                  {unreadCount}
                </span>
              )}
            </button>

            {clientPhone && <ClientWhatsAppButton phone={clientPhone} />}
          </div>
        )}

        {chatOpen && (
          <div ref={chatSectionRef} data-testid="driver-service-chat-box">
            <ServiceChat serviceId={current.id} senderType="movil" senderName={mobile.name} />
          </div>
        )}

        {(current.evidence_pickup_photo || current.evidence_delivery_photo) && (
          <div className="bg-muted/50 rounded-2xl p-3 border border-border">
            <p className="text-sm font-bold text-foreground mb-2">Evidencia del servicio</p>
            <div className="grid grid-cols-2 gap-3">
              {current.evidence_pickup_photo && (
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Recogida</p>
                  <ResolvedAvatar
                    photo={current.evidence_pickup_photo}
                    name="Recogida"
                    className="w-full aspect-square rounded-xl bg-muted"
                  />
                </div>
              )}
              {current.evidence_delivery_photo && (
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Entrega</p>
                  <ResolvedAvatar
                    photo={current.evidence_delivery_photo}
                    name="Entrega"
                    className="w-full aspect-square rounded-xl bg-muted"
                  />
                </div>
              )}
            </div>
          </div>
        )}

        <div className="pt-1">
          <ReassignService serviceId={current.id} mobileId={mobile.id} onCancelled={onDone} />
        </div>
      </div>

      {showRating && current.status === 'finalizado' && (
        <ServiceRatingModal
          serviceId={current.id}
          role="movil"
          targetName={current.client_name}
          targetPhoto={current.client_photo}
          onDone={() => {
            setShowRating(false);
            onDone();
          }}
        />
      )}

      <InAppVoiceCallModal call={voiceCall} />
    </div>
  );
}
import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useNewServiceAlert, triggerInstantServiceAlert, markInitialServiceIdsSeen } from '@/hooks/useNewServiceAlert';
import { toast } from '@/components/ui/use-toast';
import { Package, Car, Coins, Loader2, Bike, ShieldAlert, Info, Wallet, Clock, Star, MessageCircle } from 'lucide-react';
import { canWork, isPassActive, passExpiry, getPassRemainingInfo, getMinRecharge, PASS_DURATION_HOURS } from '@/lib/recharge';
import { DRIVER_TIERS, getServicePriorityVisibility } from '@/lib/driverTier';
import Radar from '@/components/driver/Radar';
import ServiceDetailModal from '@/components/mobile/ServiceDetailModal';
import ServiceBaseNotice from '@/components/mobile/ServiceBaseNotice';
import ClientAvatar from '@/components/shared/ClientAvatar';
import { preloadStorageUrls } from '@/components/shared/ResolvedAvatar';
import PassengerTrustBadge from '@/components/shared/PassengerTrustBadge';
import ServiceRouteStops from '@/components/shared/ServiceRouteStops';
import { fetchPassengerStatsMap } from '@/lib/passengerStats';
import { calcSegments, calibrateRouteMetrics, estimateKm } from '@/lib/routeEstimate';
import { fetchRoute, seedSavedRoute } from '@/lib/mapRoute';
import { useMapboxToken } from '@/hooks/useMapboxToken';
import { shortAddress, addressWithBarrio } from '@/lib/shortAddress';
import { isServiceForDriver, getDriverCategory } from '@/lib/serviceMatch';

const fmtCOP = (n) => 'COL$' + Number(n || 0).toLocaleString('es-CO');
// Un servicio solo se considera disponible si fue creado en los últimos 10 min;
// los pendientes viejos que nadie tomó ya expiraron y una limpieza los borra.
const AVAILABILITY_WINDOW_MS = 10 * 60 * 1000;
const PAYMENT_LABELS = {
  efectivo: 'Efectivo',
  transferencia: 'Transferencia',
  nequi: 'Nequi',
  daviplata: 'DaviPlata',
  bancolombia: 'Bancolombia',
  paga_con_llave: 'Paga con llave',
  redimido_puntos: '🎁 Redimido por puntos',
};
function distance(lat1, lng1, lat2, lng2) {
  if (lat1 == null || lat2 == null) return null;
  const R = 6371, dLat = (lat2 - lat1) * Math.PI / 180, dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180) * Math.cos(lat2*Math.PI/180) * Math.sin(dLng/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

function minsAgo(dateStr, now) {
  if (!dateStr) return 0;
  // created_date llega sin zona horaria (UTC real); forzamos 'Z' para que el
  // navegador no lo interprete como hora local y el cálculo no quede en 0.
  const d = new Date(dateStr.endsWith('Z') ? dateStr : dateStr + 'Z');
  return Math.max(0, Math.floor((now - d.getTime()) / 60000));
}

function shortAddr(addr) {
  if (!addr) return '—';
  return shortAddress(addr) || addr;
}

export default function AvailableServices({ mobile, tierInfo, onAccept, onCountChange, query, onRecharge, onOpenPriority, muted, activeServices = [] }) {
  const [services, setServices] = useState([]);
  const [passengerStats, setPassengerStats] = useState({});
  const [routeMetricsMap, setRouteMetricsMap] = useState({});
  const [coverageZone, setCoverageZone] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);
  const token = useMapboxToken();
  // Reloj que actualiza los minutos en aire de cada tarjeta y expira servicios a los 10 min.
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 10000);
    return () => clearInterval(t);
  }, []);

  const loadInFlightRef = useRef(false);

  const load = async () => {
    if (loadInFlightRef.current) return;
    loadInFlightRef.current = true;
    try {
      const since = new Date(Date.now() - AVAILABILITY_WINDOW_MS).toISOString();
      const svcs = await base44.entities.Service.filter(
        { status: 'pendiente', created_date: { $gte: since } },
        '-created_date',
        30
      );
      const list = Array.isArray(svcs) ? svcs : svcs?.items || [];
      preloadStorageUrls(list.map((s) => s?.client_photo).filter(Boolean));
      if (loading) {
        markInitialServiceIdsSeen(list);
      }
      setServices(list);
      if (list.length > 0) {
        fetchPassengerStatsMap(list)
          .then((m) => {
            preloadStorageUrls(
              Object.values(m || {})
                .map((v) => v?.photo)
                .filter(Boolean)
            );
            setPassengerStats((prev) => ({ ...prev, ...m }));
          })
          .catch(() => {});
      }
    } catch (e) {
      console.error('Load error:', e);
    } finally {
      loadInFlightRef.current = false;
      setLoading(false);
    }
  };

  useEffect(() => {
    base44.entities.CoverageZone.list('-created_date', 1)
      .then((zones) => {
        const zList = Array.isArray(zones) ? zones : zones?.items || [];
        setCoverageZone(zList[0] || null);
      })
      .catch(() => {});
    load();
    const unsub = base44.entities.Service.subscribe((event) => {
      const evData = event?.data;
      const evId = event?.id || evData?.id;
      // Actualización e notificación sonora en 0ms apenas entra un servicio nuevo
      if (event?.type === 'create' && evData && evData.pickup_address) {
        if (evData.status === 'pendiente') {
          const matchesVehicle = isServiceForDriver(evData, mobile);
          if (matchesVehicle && !(evData.rejected_by || []).includes(mobile?.id)) {
            triggerInstantServiceAlert(evData, muted, {
              lat: mobile?.current_lat,
              lng: mobile?.current_lng,
            });
          }
          if (evData.client_photo) preloadStorageUrls([evData.client_photo]);
          setServices((prev) =>
            prev.some((x) => x.id === evData.id) ? prev : [evData, ...prev]
          );
          fetchPassengerStatsMap([evData])
            .then((m) => {
              preloadStorageUrls(
                Object.values(m || {})
                  .map((v) => v?.photo)
                  .filter(Boolean)
              );
              setPassengerStats((prev) => ({ ...prev, ...m }));
            })
            .catch(() => {});
        }
        return;
      }
      if (event?.type === 'update' && evData && evData.pickup_address) {
        if (evData.status !== 'pendiente') {
          setServices((prev) => prev.filter((x) => x.id !== evData.id));
        } else {
          const matchesVehicle = isServiceForDriver(evData, mobile);
          if (matchesVehicle && !(evData.rejected_by || []).includes(mobile?.id)) {
            triggerInstantServiceAlert(evData, muted, {
              lat: mobile?.current_lat,
              lng: mobile?.current_lng,
            });
          }
          setServices((prev) => {
            const exists = prev.some((x) => x.id === evData.id);
            return exists
              ? prev.map((x) => (x.id === evData.id ? { ...x, ...evData } : x))
              : [evData, ...prev];
          });
        }
        return;
      }
      if (event?.type === 'delete' && evId) {
        setServices((prev) => prev.filter((x) => x.id !== evId));
        return;
      }
      load().catch(() => {});
    });

    // Respaldo liviano cada 8s para ahorrar datos móviles (la suscripción en tiempo real actualiza en 0ms)
    const fastSync = setInterval(() => {
      if (typeof document === 'undefined' || document.visibilityState === 'visible') {
        load().catch(() => {});
      }
    }, 8000);
    const onFocusOrVisible = () => {
      if (typeof document === 'undefined' || document.visibilityState === 'visible') {
        load().catch(() => {});
      }
    };
    window.addEventListener('focus', onFocusOrVisible);
    document.addEventListener('visibilitychange', onFocusOrVisible);

    return () => {
      clearInterval(fastSync);
      window.removeEventListener('focus', onFocusOrVisible);
      document.removeEventListener('visibilitychange', onFocusOrVisible);
      unsub();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mobile?.id, mobile?.vehicle_type, mobile?.driver_category, muted]);

  const reject = async (s) => {
    try {
      await base44.entities.Service.update(s.id, { rejected_by: [...(s.rejected_by || []), mobile.id] });
      base44.functions.invoke('driverPerformance', {
        action: 'record_event',
        mobile_id: mobile.id,
        service_id: s.id,
        event_type: 'request_rejected',
      }).catch(() => {});
      load();
    } catch (e) {
      toast({ title: 'Error al rechazar', description: 'Intenta de nuevo', variant: 'destructive' });
    }
  };

  const isInCoverage = (address) => {
    if (!address) return true;
    if (!coverageZone || !coverageZone.active || !coverageZone.neighborhoods?.length) return true;
    const lower = address.toLowerCase();
    return coverageZone.neighborhoods.some(n => lower.includes(n.toLowerCase()));
  };

  const currentTier = tierInfo?.current || DRIVER_TIERS[0];

  const baseCandidates = services
    .filter((s) => {
      if (!s.created_date) return true;
      const toUtc = (v) => {
        if (!v) return 0;
        const r = String(v).trim();
        const iso = /([zZ]|[+-]\d{2}:?\d{2})$/.test(r) ? r : `${r.replace(' ', 'T')}Z`;
        return new Date(iso).getTime() || 0;
      };
      const refMs =
        s.cancelled_by === 'conductor' && s.updated_date
          ? Math.max(toUtc(s.created_date), toUtc(s.updated_date))
          : toUtc(s.created_date);
      return !refMs || now - refMs < AVAILABILITY_WINDOW_MS;
    })
    .filter(s => !(s.rejected_by || []).includes(mobile.id))
    .filter(s => isInCoverage(s.pickup_address))
    .filter(s => isServiceForDriver(s, mobile))
    .filter(s => {
      if (!query) return true;
      const q = query.toLowerCase();
      return (
        (s.pickup_address || '').toLowerCase().includes(q) ||
        (s.destination_address || '').toLowerCase().includes(q) ||
        (s.client_name || '').toLowerCase().includes(q) ||
        (s.stops || []).some((st) => (st?.address || '').toLowerCase().includes(q))
      );
    });

  // Prioridad progresiva por nivel (Oro: 0s, Plata: 4s, Bronce: 8s).
  // Las ofertas en ventana de prioridad para niveles superiores se liberan automáticamente al cumplirse los segundos.
  const queuedByPriority = baseCandidates.filter(
    (s) => !getServicePriorityVisibility(s.created_date, currentTier, now).visible
  );

  useEffect(() => {
    if (queuedByPriority.length === 0) return;
    const fastTick = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(fastTick);
  }, [queuedByPriority.length]);

  const available = baseCandidates
    .filter((s) => getServicePriorityVisibility(s.created_date, currentTier, now).visible)
    .map(s => ({ ...s, _dist: distance(mobile.current_lat, mobile.current_lng, s.pickup_lat, s.pickup_lng) }))
    .sort((a, b) => (a._dist ?? Infinity) - (b._dist ?? Infinity));

  const availableIdsKey = available.map((s) => s.id).join(',');
  const drvCoordKey =
    mobile.current_lat != null && mobile.current_lng != null
      ? `${Number(mobile.current_lat).toFixed(3)},${Number(mobile.current_lng).toFixed(3)}`
      : '';

  useEffect(() => {
    if (!token || available.length === 0) return;
    let alive = true;
    const drvLat = mobile.current_lat;
    const drvLng = mobile.current_lng;

    available.slice(0, 8).forEach((s) => {
      if (routeMetricsMap[s.id]?.drvKey === drvCoordKey) return;
      const pLat = s.pickup_lat;
      const pLng = s.pickup_lng;
      const dLat = s.destination_lat;
      const dLng = s.destination_lng;
      if (pLat == null || pLng == null) return;
      seedSavedRoute(s);

      const validStops = (s.stops || [])
        .filter((st) => st?.lat != null && st?.lng != null)
        .map((st) => [Number(st.lat), Number(st.lng)]);

      const p1 =
        drvLat != null && drvLng != null
          ? fetchRoute(token, [drvLat, drvLng], [pLat, pLng])
          : Promise.resolve(null);
      const p2 =
        dLat != null && dLng != null
          ? fetchRoute(token, [pLat, pLng], [dLat, dLng], validStops)
          : Promise.resolve(null);

      Promise.all([p1, p2])
        .then(([r1, r2]) => {
          if (!alive) return;
          setRouteMetricsMap((prev) => ({
            ...prev,
            [s.id]: { seg1: r1, seg2: r2, drvKey: drvCoordKey },
          }));
        })
        .catch(() => {});
    });

    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token, availableIdsKey, drvCoordKey]);

  useEffect(() => { onCountChange?.(available.length); }, [available.length, onCountChange]);

  useNewServiceAlert(available, loading, muted);

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-[#0091D5]" /></div>;

  const puedeTrabajar = canWork(mobile);
  const paseActivo = isPassActive(mobile);
  const vence = passExpiry(mobile);
  const minAmount = getMinRecharge(mobile.vehicle_type);

  if (!puedeTrabajar && activeServices.length === 0) {
    return (
      <div className="text-center py-12 px-4">
        <div className="w-16 h-16 rounded-2xl bg-[#0091D5]/10 flex items-center justify-center mx-auto mb-3">
          <Wallet className="w-8 h-8 text-[#0091D5]" />
        </div>
        <p className="text-foreground font-bold mb-1">
          {mobile.pass_vence_en
            ? `Tus ${PASS_DURATION_HOURS} horas laborales se cumplieron (Saldo en $0)`
            : `Activa tu pase de ${PASS_DURATION_HOURS} horas laborales`}
        </p>
        <p className="text-sm text-muted-foreground mb-4 mx-auto max-w-xs">
          {mobile.pass_vence_en
            ? `Tu saldo se renovó a $0. Debes volver a recargar ${fmtCOP(minAmount)} para poder seguir tomando servicios.`
            : `Recarga el pase de ${PASS_DURATION_HOURS} horas laborales (${fmtCOP(minAmount)}, sin comisión por porcentaje) para tomar servicios.`}
        </p>
        <button onClick={onRecharge} className="h-11 px-6 rounded-full bg-gradient-to-r from-[#0091D5] to-[#00B8D4] text-white font-bold text-sm shadow-lg">
          Recargar pase de {PASS_DURATION_HOURS}h
        </button>
      </div>
    );
  }

  // Contador en vivo de las 14 horas del pase activo
  const passCountdown = getPassRemainingInfo(mobile, now);
  const minsVence = paseActivo && vence ? Math.floor((vence.getTime() - Date.now()) / 60000) : null;
  const avisoVence = minsVence != null && minsVence > 0 && minsVence <= 60;

  // Mensajeros: eligen libremente, sin regla de distancia, hasta 3 servicios en curso.
  // Moto y carro: máximo 2; el 2do se puede tomar cuando está a ≤ 1 km de dejar el primero.
  const isCourier = getDriverCategory(mobile) === 'mensajero';
  const maxActive = isCourier ? 3 : 2;
  const limitReached = activeServices.length >= maxActive;
  const limitMessage = `Ya tienes ${maxActive} servicios activos. Finaliza uno para tomar otro.`;
  const firstActive = activeServices[0];
  const drvRefLat = mobile.current_lat ?? firstActive?.pickup_lat;
  const drvRefLng = mobile.current_lng ?? firstActive?.pickup_lng;
  const kmToFinish =
    firstActive?.destination_lat != null && drvRefLat != null && drvRefLng != null
      ? distance(drvRefLat, drvRefLng, firstActive.destination_lat, firstActive.destination_lng)
      : null;
  const within1km = kmToFinish == null || kmToFinish <= 1;
  const canTakeMore = isCourier
    ? !limitReached
    : activeServices.length === 0 || (activeServices.length === 1 && within1km);

  const openCard = (s) => {
    setSelected(s);
    // Registrar que el conductor vio el servicio únicamente cuando abre la tarjeta y ve todas sus especificaciones
    if (s?.id && mobile?.id) {
      const currentViewed = Array.isArray(s.viewed_by) ? s.viewed_by : [];
      if (!currentViewed.includes(mobile.id)) {
        const nextViewed = Array.from(new Set([...currentViewed, mobile.id]));
        setServices((prev) =>
          prev.map((item) => (item.id === s.id ? { ...item, viewed_by: nextViewed } : item))
        );
        base44.entities.Service.update(s.id, { viewed_by: nextViewed }).catch(() => {});
      }
    }
  };

  return (
    <>
      <div className="space-y-3">
        {paseActivo && passCountdown.active && (
          <div
            onClick={onRecharge}
            className="rounded-2xl bg-emerald-500/12 border border-emerald-500/30 px-3.5 py-2.5 flex items-center justify-between gap-2 cursor-pointer active:scale-[0.99] transition-transform"
            data-testid="available-services-16h-banner"
          >
            <div className="min-w-0">
              <p className="text-xs font-extrabold text-emerald-700 dark:text-emerald-300">
                ⏱️ Pase {PASS_DURATION_HOURS}h activo · Sin comisión
              </p>
              <p className="text-[11px] text-muted-foreground truncate">
                Tienes {passCountdown.formatted} restantes para sacar todos los servicios
              </p>
            </div>
            <span className="font-mono text-xs font-black px-2.5 py-1 rounded-xl bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 flex-shrink-0">
              {passCountdown.formatted}
            </span>
          </div>
        )}
        {avisoVence && (
          <div className="mx-1 rounded-xl bg-amber-50 dark:bg-amber-500/15 border border-amber-200 dark:border-amber-500/30 px-3 py-2 text-amber-700 dark:text-amber-300 text-xs font-medium text-center">
            Tu pase de {PASS_DURATION_HOURS}h laborales vence en {minsVence} min. Al cumplirse, tu saldo volverá a $0 y deberás recargar para seguir tomando servicios.
          </div>
        )}
        {/* Avisos según regla del 2do servicio */}
        {limitReached ? (
          <div className="text-center py-10">
            <ShieldAlert className="w-10 h-10 text-primary/40 mx-auto mb-2" />
            <p className="text-sm text-foreground font-medium mb-1">Límite de servicios alcanzado</p>
            <p className="text-sm text-muted-foreground">{limitMessage}</p>
          </div>
        ) : !isCourier && activeServices.length === 1 ? (
          within1km ? (
            <div className="bg-[#3DDC84]/15 rounded-2xl p-3 text-sm text-foreground flex items-start gap-2 border border-[#3DDC84]/35">
              <Info className="w-4 h-4 text-[#3DDC84] flex-shrink-0 mt-0.5" />
              <span>¡Estás a <strong>{kmToFinish.toFixed(1)} km</strong> de finalizar! Puedes tomar <strong>1 servicio más</strong>.</span>
            </div>
          ) : (
            <div className="bg-[#F59E0B]/15 rounded-2xl p-3 text-sm text-foreground flex items-start gap-2 border border-[#F59E0B]/35">
              <Info className="w-4 h-4 text-[#F59E0B] flex-shrink-0 mt-0.5" />
              <span>Acércate a <strong>1 km</strong> del destino de tu servicio en curso (vas a {kmToFinish != null ? `${kmToFinish.toFixed(1)} km` : '—'}) para tomar otro.</span>
            </div>
          )
        ) : null}

        {/* Lista de disponibles */}
        {!limitReached && (
          available.length === 0 ? (
            !muted ? (
              <div className="text-center py-10">
                <div className="flex justify-center mb-4">
                  <Radar active />
                </div>
                <h2 className="text-foreground font-bold text-base">Buscando servicios disponibles</h2>
                <p className="text-muted-foreground text-sm mt-1">Te avisaremos cuando haya una solicitud</p>
              </div>
            ) : (
              <div className="text-center py-16">
                <Bike className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                <p className="text-muted-foreground text-sm">No hay solicitudes cerca de ti</p>
              </div>
            )
          ) : (
            <div className="space-y-3">
              {available.map(s => {
                const drvLat = mobile.current_lat ?? s.pickup_lat;
                const drvLng = mobile.current_lng ?? s.pickup_lng;
                const vType = mobile.vehicle_type || s.vehicle_type || 'moto';
                const sType = s.service_type || 'transporte';
                const validStops = (s.stops || []).filter((st) => st?.lat != null && st?.lng != null);
                const routeEntry = routeMetricsMap[s.id];

                const straight1 = estimateKm(drvLat, drvLng, s.pickup_lat, s.pickup_lng);
                const cal1 = calibrateRouteMetrics({
                  routeInfo: routeEntry?.seg1 || null,
                  straightKm: straight1,
                  stopsCount: 0,
                  vehicleType: vType,
                  serviceType: sType,
                });

                const fallbackSegs = calcSegments(
                  drvLat,
                  drvLng,
                  s.pickup_lat,
                  s.pickup_lng,
                  s.destination_lat,
                  s.destination_lng,
                  vType,
                  sType,
                  s.stops
                );

                const straight2 = estimateKm(s.pickup_lat, s.pickup_lng, s.destination_lat, s.destination_lng);
                const cal2 = calibrateRouteMetrics({
                  routeInfo: routeEntry?.seg2 || null,
                  straightKm: straight2,
                  stopsCount: validStops.length,
                  vehicleType: vType,
                  serviceType: sType,
                });

                const pickupKmRoad = cal1.distanceKm ?? fallbackSegs.seg1Km;
                const pickupMinRoad = cal1.durationMin ?? fallbackSegs.seg1Min;
                const destKmRoad = cal2.distanceKm ?? fallbackSegs.seg2Km;
                const destMinRoad = cal2.durationMin ?? fallbackSegs.seg2Min;
                const pStats = passengerStats[s.id];
                const tripsCount = Number(pStats?.trips ?? 0);
                const ratingVal =
                  pStats?.rating != null && Number(pStats.rating) > 0
                    ? Number(pStats.rating).toFixed(1)
                    : '5.0';
                const elapsedMins = minsAgo(s.created_date, now);
                // En un domicilio de NEXT Negocios quien pide el servicio es el comercio, no su cliente.
                const isNegocio = s.origin === 'negocios';
                const businessName = s.business_name || 'Negocio aliado';
                return (
                  <div
                    key={s.id}
                    onClick={() => openCard(s)}
                    className="bg-card rounded-3xl p-3 border border-border shadow-sm active:scale-[0.99] transition-transform cursor-pointer flex items-center gap-2.5 overflow-hidden"
                  >
                    {/* Columna izquierda: Avatar + nombre + estrella + viajes + minutos al aire */}
                    <div className="w-[88px] flex-shrink-0 flex flex-col items-center text-center">
                      <ClientAvatar
                        photo={isNegocio ? s.business_logo : s.client_photo || pStats?.photo}
                        name={isNegocio ? businessName : s.client_name}
                        size="xl"
                        className="w-16 h-16 border-2 border-slate-200 dark:border-border shadow-xs"
                      />
                      <p
                        className={`text-foreground text-[12.5px] font-extrabold leading-tight mt-1.5 w-full ${
                          isNegocio ? 'line-clamp-2 break-words' : 'truncate'
                        }`}
                      >
                        {isNegocio ? businessName : s.client_name || 'Cliente'}
                      </p>
                      {!isNegocio && (
                        <>
                          <div className="flex items-center justify-center gap-1 mt-0.5">
                            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                            <span className="text-[11.5px] font-extrabold text-foreground">{ratingVal}</span>
                          </div>
                          <span className="mt-1 px-2 py-0.5 rounded-full bg-[#1E6BFF]/12 text-[#1E6BFF] dark:text-sky-300 text-[10.5px] font-extrabold leading-tight whitespace-nowrap">
                            {tripsCount.toLocaleString('es-CO')} {tripsCount === 1 ? 'viaje' : 'viajes'}
                          </span>
                        </>
                      )}
                      <span
                        className="mt-1 inline-flex items-center justify-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-800 dark:text-emerald-300 text-[10.5px] font-extrabold whitespace-nowrap"
                        data-testid="service-elapsed-minutes"
                      >
                        <Clock className="w-3 h-3 text-emerald-700 dark:text-emerald-300 flex-shrink-0" />
                        Hace {elapsedMins} min
                      </span>
                    </div>

                    {/* Columna derecha: Precio + A X min + Ruta compacta + Píldoras en una sola fila */}
                    <div className="flex-1 min-w-0 flex flex-col justify-between">
                      <div className="flex items-center justify-between gap-1.5 mb-1 min-w-0">
                        <div className="min-w-0">
                          <p className="text-[#1E6BFF] dark:text-[#38BDF8] text-[20px] font-black leading-none tracking-tight truncate">
                            {fmtCOP(s.fare || 5000)}
                          </p>
                          {s.origin === 'whatsapp' && (
                            <span
                              data-testid="whatsapp-fixed-price-badge"
                              className="mt-1 inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/35 text-emerald-700 dark:text-emerald-300 text-[10px] font-extrabold leading-tight"
                            >
                              <MessageCircle className="w-3 h-3 flex-shrink-0" />
                              Precio fijo · Pedido por WhatsApp
                            </span>
                          )}
                        </div>
                        {pickupMinRoad != null && (
                          <span className="px-2.5 py-0.5 rounded-full bg-[#1E6BFF]/12 text-[#1E6BFF] dark:text-sky-300 text-[11px] font-extrabold flex-shrink-0 whitespace-nowrap">
                            A {Math.max(1, Math.round(Number(pickupMinRoad)))} min
                          </span>
                        )}
                      </div>

                      <ServiceBaseNotice value={s.order_value} format={fmtCOP} compact />

                      <div className="mb-2">
                        <ServiceRouteStops
                          compact
                          // El comercio escribe cada dirección con su barrio: se muestran completas
                          fullAddress={isNegocio}
                          pickupAddress={isNegocio ? addressWithBarrio(s.pickup_address) : shortAddr(s.pickup_address)}
                          destinationAddress={isNegocio ? addressWithBarrio(s.destination_address) : shortAddr(s.destination_address)}
                          pickupBarrio={s.pickup_barrio}
                          destinationBarrio={s.destination_barrio}
                          stops={s.stops}
                          pickupEtaMin={pickupMinRoad}
                          pickupKm={pickupKmRoad}
                          destEtaMin={destMinRoad}
                          destKm={destKmRoad}
                        />
                      </div>

                      <div className="flex items-center gap-1.5 flex-nowrap">
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-extrabold bg-[#1E6BFF] text-white shadow-xs whitespace-nowrap">
                          <Coins className="w-3 h-3 flex-shrink-0" />
                          {s.payment_method === 'redimido_puntos'
                            ? 'Por puntos'
                            : PAYMENT_LABELS[s.payment_method] || s.payment_method}
                        </span>
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-extrabold bg-[#1E6BFF]/12 text-[#0B3C8C] dark:text-sky-200 whitespace-nowrap">
                          {s.service_type === 'mensajeria' ? (
                            <>
                              <Package className="w-3 h-3 flex-shrink-0" /> Mensajería
                            </>
                          ) : (
                            <>
                              <Car className="w-3 h-3 flex-shrink-0" /> Transporte
                            </>
                          )}
                        </span>
                        {Array.isArray(s.stops) &&
                          s.stops.filter((st) => (st?.address || '').trim()).length > 0 && (
                            <span className="inline-flex items-center gap-0.5 px-2 py-1 rounded-full text-[10.5px] font-extrabold bg-amber-500/20 text-amber-700 dark:text-amber-300 whitespace-nowrap">
                              +{s.stops.filter((st) => (st?.address || '').trim()).length}
                            </span>
                          )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )
        )}
      </div>

      {selected && (
        <ServiceDetailModal
          service={selected}
          passengerStats={passengerStats[selected.id]}
          mobile={mobile}
          canTakeMore={canTakeMore}
          kmToFinish={kmToFinish}
          limitMessage={isCourier ? limitMessage : null}
          onClose={() => setSelected(null)}
          onAccept={onAccept}
        />
      )}
    </>
  );
}
import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';
import { XCircle, Loader2 } from 'lucide-react';
import { safeInvoke } from '@/lib/api-helpers';
import { useBackButton } from '@/hooks/useBackButton';

const REASONS = [
  { value: 'sin_combustible', label: 'Sin combustible' },
  { value: 'llanta_pinchada', label: 'Llanta pinchada' },
  { value: 'emergencia', label: 'Emergencia' },
  { value: 'vehiculo_no_enciende', label: 'El vehículo no enciende' },
  { value: 'celular_sin_bateria', label: 'Celular a punto de apagarse' },
];

export default function ReassignService({ serviceId, mobileId, onCancelled }) {
  const [open, setOpen] = useState(false);
  useBackButton(() => setOpen(false), open);
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);

  const cancel = async () => {
    setLoading(true);
    try {
      await safeInvoke('reassignService', { service_id: serviceId, mobile_id: mobileId, reason });
      setOpen(false);
      if (onCancelled) onCancelled();
    } catch (err) {
      toast({ title: 'No se pudo liberar el servicio', description: err.message || 'Intenta de nuevo', variant: 'destructive' });
    } finally { setLoading(false); }
  };

  if (!open) {
    return (
      <Button variant="outline" className="w-full h-10 border-destructive/30 text-destructive hover:bg-destructive/10" onClick={() => setOpen(true)}>
        <XCircle className="w-4 h-4 mr-2" />Liberar servicio
      </Button>
    );
  }

  return (
    <div className="bg-destructive/10 rounded-xl p-4 border border-destructive/20">
      <p className="font-semibold text-sm text-destructive mb-1">Liberar servicio</p>
      <p className="text-xs text-muted-foreground mb-3">El servicio vuelve a estar disponible para que lo tome un conductor (incluido tú).</p>
      <Select onValueChange={setReason} value={reason}>
        <SelectTrigger className="h-10 bg-card mb-2"><SelectValue placeholder="Motivo" /></SelectTrigger>
        <SelectContent>
          {REASONS.map(r => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}
        </SelectContent>
      </Select>
      <div className="flex gap-2">
        <Button variant="outline" size="sm" className="flex-1 h-9" onClick={() => setOpen(false)}>Volver</Button>
        <Button size="sm" className="flex-1 h-9 bg-destructive hover:bg-destructive/90 text-destructive-foreground" disabled={!reason || loading} onClick={cancel}>
          {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}Confirmar
        </Button>
      </div>
    </div>
  );
}
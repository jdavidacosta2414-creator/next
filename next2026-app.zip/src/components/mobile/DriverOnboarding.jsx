import React, { useState, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { safeInvoke } from '@/lib/api-helpers';
import { compressImage } from '@/lib/image';
import TermsContent from '@/components/mobile/TermsContent';
import { FileText, MapPin, Bell, ScanFace, Loader2, CheckCircle2, AlertTriangle, ArrowRight, Camera, ShieldCheck } from 'lucide-react';

const STEPS = [
  { id: 'terminos', label: 'Términos', icon: FileText },
  { id: 'permisos', label: 'Permisos', icon: MapPin },
  { id: 'selfie', label: 'Verificación', icon: ScanFace },
];

export default function DriverOnboarding({ mobile, onComplete }) {
  const startStep = !mobile.terms_accepted ? 'terminos' : !mobile.identity_verified ? 'selfie' : 'terminos';
  const [step, setStep] = useState(startStep);
  const [accepted, setAccepted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [selfieUri, setSelfieUri] = useState('');
  const [locationGranted, setLocationGranted] = useState(false);
  const selfieRef = useRef(null);

  const goTo = (s) => { setError(''); setStep(s); };

  const acceptTerms = async () => {
    setLoading(true);
    setError('');
    try {
      const updated = await base44.entities.Mobile.update(mobile.id, { terms_accepted: true });
      goTo('permisos');
      if (onComplete) onComplete(updated);
    } catch (e) {
      setError('No se pudo guardar la aceptación. Intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  const requestPermissions = async () => {
    setLoading(true);
    setError('');
    try {
      // Notificaciones
      if ('Notification' in window && Notification.permission === 'default') {
        try { await Notification.requestPermission(); } catch (e) {}
      }
      // Ubicación
      await new Promise((resolve) => {
        if (!navigator.geolocation) { resolve(); return; }
        navigator.geolocation.getCurrentPosition(
          async (pos) => {
            setLocationGranted(true);
            try {
              await base44.entities.Mobile.update(mobile.id, {
                current_lat: pos.coords.latitude,
                current_lng: pos.coords.longitude,
              });
            } catch (e) {}
            resolve();
          },
          () => resolve(),
          { enableHighAccuracy: true, timeout: 8000 }
        );
      });
      goTo('selfie');
    } catch (e) {
      setError('No se pudieron solicitar los permisos.');
    } finally {
      setLoading(false);
    }
  };

  const handleSelfie = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLoading(true);
    setError('');
    try {
      const compressed = await compressImage(file, 768, 0.7);
      const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file: compressed });
      setSelfieUri(file_uri);
    } catch (err) {
      setError('No se pudo procesar la foto. Intenta de nuevo.');
    } finally {
      setLoading(false);
      if (e.target) e.target.value = '';
    }
  };

  const verifyIdentity = async () => {
    if (!selfieUri) { setError('Primero toma tu selfie'); return; }
    setLoading(true);
    setError('');
    try {
      // TEMPORAL: verificación facial con IA desactivada para poder probar la interfaz.
      const updated = await base44.entities.Mobile.update(mobile.id, { identity_verified: true });
      if (onComplete) onComplete(updated);
    } catch (err) {
      setError('No se pudo verificar tu identidad. Intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  const currentIndex = STEPS.findIndex((s) => s.id === step);

  return (
    <div className="theme-day min-h-screen bg-background flex flex-col max-w-md mx-auto w-full">
      {/* Indicador de pasos */}
      <div className="px-6 pt-6 pb-4">
        <div className="flex items-center justify-between mb-2">
          {STEPS.map((s, i) => {
            const Icon = s.icon;
            const active = i === currentIndex;
            const done = i < currentIndex;
            return (
              <React.Fragment key={s.id}>
                <div className="flex flex-col items-center gap-1.5">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${active ? 'bg-gradient-to-br from-[#1E6BFF] to-[#00E5FF] text-white' : done ? 'bg-[#00E5FF]/20 text-[#00E5FF]' : 'bg-white/5 text-[#5A6478]'}`}>
                    {done ? <CheckCircle2 className="w-5 h-5" /> : <Icon className="w-5 h-5" />}
                  </div>
                  <span className={`text-xs ${active ? 'text-white font-medium' : 'text-[#5A6478]'}`}>{s.label}</span>
                </div>
                {i < STEPS.length - 1 && <div className={`flex-1 h-0.5 rounded-full ${i < currentIndex ? 'bg-[#00E5FF]' : 'bg-white/10'}`} />}
              </React.Fragment>
            );
          })}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 pb-6 no-scrollbar">
        {step === 'terminos' && (
          <div className="flex flex-col h-full">
            <h1 className="text-white text-xl font-bold mb-1">Términos y Condiciones</h1>
            <p className="text-[#8B95A8] text-sm mb-4">Revisa y acepta los términos para continuar</p>
            <div className="flex-1 bg-[#121829] rounded-2xl border border-white/8 p-4 overflow-y-auto no-scrollbar mb-4">
              <TermsContent />
            </div>
            {error && <div className="p-3 rounded-xl bg-red-500/10 text-red-400 text-sm mb-3">{error}</div>}
            <label className="flex items-start gap-3 mb-4 cursor-pointer">
              <input type="checkbox" checked={accepted} onChange={(e) => setAccepted(e.target.checked)} className="mt-1 w-5 h-5 accent-[#00E5FF]" />
              <span className="text-white text-sm">He leído y acepto los Términos y Condiciones y la Política de Tratamiento de Datos Personales de NEXT.</span>
            </label>
            <button
              onClick={acceptTerms}
              disabled={!accepted || loading}
              className="w-full h-14 bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white font-bold rounded-full flex items-center justify-center gap-2 disabled:opacity-40 shadow-lg shadow-[#1E6BFF]/30"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <>Aceptar y continuar <ArrowRight className="w-5 h-5" /></>}
            </button>
          </div>
        )}

        {step === 'permisos' && (
          <div className="flex flex-col h-full">
            <h1 className="text-white text-xl font-bold mb-1">Permisos de la app</h1>
            <p className="text-[#8B95A8] text-sm mb-5">Necesitamos estos permisos para asignarte servicios cercanos</p>
            <div className="space-y-3 mb-6">
              <PermissionCard icon={MapPin} title="Ubicación en tiempo real" desc="Para mostrar servicios cerca de ti y trazar la ruta al cliente." granted={locationGranted} />
              <PermissionCard icon={Bell} title="Notificaciones" desc="Para avisarte de inmediato cuando llegue una nueva solicitud." />
              <PermissionCard icon={ShieldCheck} title="Verificación de identidad" desc="La Central revisa tu foto y tus documentos para seguridad de todos." />
            </div>
            {error && <div className="p-3 rounded-xl bg-red-500/10 text-red-400 text-sm mb-3">{error}</div>}
            <button
              onClick={requestPermissions}
              disabled={loading}
              className="w-full h-14 bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white font-bold rounded-full flex items-center justify-center gap-2 disabled:opacity-50 shadow-lg shadow-[#1E6BFF]/30"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <>Permitir y continuar <ArrowRight className="w-5 h-5" /></>}
            </button>
          </div>
        )}

        {step === 'selfie' && (
          <div className="flex flex-col h-full" data-photo-picker="true">
            <h1 className="text-white text-xl font-bold mb-1">Verificación de identidad</h1>
            <p className="text-[#8B95A8] text-sm mb-5">Toma una selfie o súbela para confirmar que eres tú</p>
            <div className="flex-1 flex flex-col items-center justify-center">
              <div className="w-48 h-48 rounded-full border-4 border-dashed border-[#00E5FF]/40 flex items-center justify-center mb-5 overflow-hidden bg-white/5">
                {selfieUri ? (
                  <div className="relative w-full h-full">
                    <div className="absolute inset-0 flex items-center justify-center"><CheckCircle2 className="w-12 h-12 text-[#00E5FF]" /></div>
                  </div>
                ) : (
                  <ScanFace className="w-16 h-16 text-[#00E5FF]/50" />
                )}
              </div>
              {selfieUri ? (
                <p className="text-white text-sm mb-1 font-medium">Selfie capturada</p>
              ) : (
                <p className="text-[#8B95A8] text-sm mb-1 text-center px-6">Mira a la cámara con buena luz y sin accesorios (gorra, gafas oscuras).</p>
              )}
              {error && (
                <div className="mt-3 p-3 rounded-xl bg-red-500/10 text-red-400 text-sm flex items-start gap-2 max-w-xs">
                  <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />{error}
                </div>
              )}
            </div>
            <div className="space-y-2 mt-4">
              <button
                onClick={verifyIdentity}
                disabled={loading || !selfieUri}
                className="w-full h-14 bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white font-bold rounded-full flex items-center justify-center gap-2 disabled:opacity-40 shadow-lg shadow-[#1E6BFF]/30"
              >
                {loading ? <><Loader2 className="w-5 h-5 animate-spin" /> Verificando...</> : <>Verificar identidad <ArrowRight className="w-5 h-5" /></>}
              </button>
              <div className="relative overflow-hidden w-full h-12 rounded-full border border-white/10 text-white font-medium text-sm flex items-center justify-center gap-2 cursor-pointer">
                <Camera className="w-4 h-4" /> {selfieUri ? 'Volver a tomar' : 'Tomar o elegir selfie'}
                <input
                  ref={selfieRef}
                  type="file"
                  accept="image/*"
                  onChange={handleSelfie}
                  onClick={() => {
                    setSelfieUri('');
                    setError('');
                    if (typeof window !== 'undefined') {
                      window.__nextFilePickerOpenUntil = Date.now() + 60000;
                    }
                  }}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function PermissionCard({ icon: Icon, title, desc, granted }) {
  return (
    <div className="flex items-start gap-3 p-4 rounded-2xl bg-[#121829] border border-white/8">
      <div className="w-10 h-10 rounded-xl bg-[#00E5FF]/10 flex items-center justify-center flex-shrink-0">
        <Icon className="w-5 h-5 text-[#00E5FF]" />
      </div>
      <div className="flex-1">
        <p className="text-white font-medium text-sm">{title}</p>
        <p className="text-[#8B95A8] text-xs mt-0.5">{desc}</p>
      </div>
      {granted && <CheckCircle2 className="w-5 h-5 text-[#3DDC84] flex-shrink-0" />}
    </div>
  );
}
import React from 'react';
import { Home, History, User, Wallet } from 'lucide-react';
import { cn } from '@/lib/utils';

const NAV_ITEMS = [
  { id: 'servicios', label: 'Inicio', icon: Home },
  { id: 'historial', label: 'Historial', icon: History },
  { id: 'ganancias', label: 'Billetera', icon: Wallet },
  { id: 'perfil', label: 'Perfil', icon: User },
];

export default function BottomNav({ active, onChange }) {
  return (
    <nav className="fixed bottom-0 inset-x-0 z-30 bg-[#0B0F1A]/95 backdrop-blur-lg border-t border-white/8">
      <div className="max-w-md mx-auto grid grid-cols-4 px-2">
        {NAV_ITEMS.map((item) => {
          const isActive = active === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => onChange(item.id)}
              className={cn(
                'flex flex-col items-center justify-center gap-1 py-2.5 transition-colors relative',
                isActive ? 'text-[#00E5FF]' : 'text-[#5A6478] hover:text-white'
              )}
            >
              {isActive && (
                <span className="absolute top-0 w-8 h-0.5 rounded-full bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF]" />
              )}
              <Icon className={cn('w-5 h-5', isActive && 'drop-shadow-[0_0_6px_rgba(0,229,255,0.6)]')} />
              <span className="text-[10px] font-medium">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
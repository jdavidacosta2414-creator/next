import React, { useState, useEffect, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { Wallet, TrendingUp, CheckCircle, Calendar, Loader2, BarChart3, ArrowUpCircle, TrendingDown, Package } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import DateRangePicker from '@/components/shared/DateRangePicker';

const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');
const today = () => new Date().toISOString().split('T')[0];

export default function DriverEarnings({ mobile }) {
  const [services, setServices] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [range, setRange] = useState({ from: new Date(), to: new Date() });

  useEffect(() => {
    (async () => {
      try {
        const [all, txns] = await Promise.all([
          base44.entities.Service.filter({ mobile_id: mobile.id, status: 'finalizado' }, '-created_date', 200),
          base44.entities.WalletTransaction.filter({ mobile_id: mobile.id }, '-created_date', 100),
        ]);
        setServices(all);
        setTransactions(txns);
      } catch (e) {
        console.error('Earnings load error:', e);
      } finally {
        setLoading(false);
      }
    })();
  }, [mobile.id]);

  const todayServices = services.filter(s => s.created_date?.startsWith(today()));
  const todayTotal = todayServices.reduce((sum, s) => sum + (s.collected_amount || s.fare || 5000), 0);
  const totalTotal = services.reduce((sum, s) => sum + (s.collected_amount || s.fare || 5000), 0);
  const weekAgo = new Date(Date.now() - 7 * 86400000).toISOString();
  const weekServices = services.filter(s => s.created_date >= weekAgo);
  const weekTotal = weekServices.reduce((sum, s) => sum + (s.collected_amount || s.fare || 5000), 0);

  const filteredHistory = useMemo(() => {
    return services.filter(s => {
      const d = new Date(s.created_date);
      return (!range?.from || d >= range.from) && (!range?.to || d <= new Date(range.to.getTime() + 86400000));
    });
  }, [services, range]);

  const filteredTxns = useMemo(() => {
    return transactions.filter(t => {
      const d = new Date(t.created_date);
      return (!range?.from || d >= range.from) && (!range?.to || d <= new Date(range.to.getTime() + 86400000));
    });
  }, [transactions, range]);

  // Estadísticas
  const avgPerService = services.length > 0 ? Math.round(totalTotal / services.length) : 0;
  const dayTotals = {};
  services.forEach(s => {
    const day = new Date(s.created_date).toLocaleDateString('es-CO', { weekday: 'long' });
    dayTotals[day] = (dayTotals[day] || 0) + (s.collected_amount || s.fare || 5000);
  });
  const bestDay = Object.entries(dayTotals).sort((a, b) => b[1] - a[1])[0];

  const twoWeeksAgo = new Date(Date.now() - 14 * 86400000).toISOString();
  const lastWeekServices = services.filter(s => s.created_date >= twoWeeksAgo && s.created_date < weekAgo);
  const lastWeekTotal = lastWeekServices.reduce((sum, s) => sum + (s.collected_amount || s.fare || 5000), 0);
  const weekChange = lastWeekTotal > 0 ? Math.round(((weekTotal - lastWeekTotal) / lastWeekTotal) * 100) : 0;

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>;

  return (
    <div className="space-y-4">
      <Tabs defaultValue="historial">
        <TabsList className="w-full grid grid-cols-3 mb-4 h-11">
          <TabsTrigger value="historial" className="text-xs font-medium">Historial</TabsTrigger>
          <TabsTrigger value="saldo" className="text-xs font-medium">Mi saldo</TabsTrigger>
          <TabsTrigger value="estadisticas" className="text-xs font-medium">Estadísticas</TabsTrigger>
        </TabsList>

        {/* Historial tab */}
        <TabsContent value="historial" className="space-y-3">
          <div className="flex items-center gap-3 bg-card rounded-xl p-3 border border-border">
            <Calendar className="w-4 h-4 text-muted-foreground" />
            <DateRangePicker range={range} onChange={setRange} />
          </div>
          {filteredHistory.length === 0 ? (
            <div className="text-center py-8"><CheckCircle className="w-10 h-10 text-muted-foreground/30 mx-auto mb-2" /><p className="text-sm text-muted-foreground">No tienes ganancias en este rango de fechas</p></div>
          ) : filteredHistory.map(s => (
            <div key={s.id} className="bg-card rounded-xl p-3 shadow-sm border border-border flex items-center justify-between">
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-foreground truncate">{s.client_name}</p>
                <p className="text-xs text-muted-foreground truncate">{s.pickup_address}</p>
                <p className="text-xs text-muted-foreground">{new Date(s.created_date).toLocaleDateString('es-CO', { day: 'numeric', month: 'short' })}</p>
              </div>
              <div className="text-right flex-shrink-0 ml-2">
                <p className="text-sm font-bold text-primary">{fmtCOP(s.collected_amount || s.fare || 5000)}</p>
                {s.commission > 0 && <p className="text-xs text-destructive">Comisión: {fmtCOP(s.commission)}</p>}
              </div>
            </div>
          ))}
        </TabsContent>

        {/* Mi saldo tab */}
        <TabsContent value="saldo" className="space-y-4">
          <div className="bg-gradient-to-br from-primary to-primary/80 rounded-2xl p-5 text-primary-foreground shadow-sm">
            <div className="flex items-center gap-2 mb-2">
              <Wallet className="w-5 h-5" />
              <span className="text-sm font-medium opacity-90">Saldo disponible</span>
            </div>
            <p className="text-3xl font-bold">{fmtCOP(mobile.balance ?? 0)}</p>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-card rounded-2xl p-4 shadow-sm border border-border">
              <div className="flex items-center gap-1.5 mb-1">
                <Calendar className="w-4 h-4 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">Ganancias de hoy</span>
              </div>
              <p className="text-xl font-bold text-foreground">{fmtCOP(todayTotal)}</p>
              <p className="text-xs text-muted-foreground">{todayServices.length} servicios</p>
            </div>
            <div className="bg-card rounded-2xl p-4 shadow-sm border border-border">
              <div className="flex items-center gap-1.5 mb-1">
                <TrendingUp className="w-4 h-4 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">Esta semana</span>
              </div>
              <p className="text-xl font-bold text-foreground">{fmtCOP(weekTotal)}</p>
              <p className="text-xs text-muted-foreground">{weekServices.length} servicios</p>
            </div>
          </div>
          <div className="bg-card rounded-2xl p-4 shadow-sm border border-border">
            <div className="flex items-center gap-1.5 mb-1">
              <Package className="w-4 h-4 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">Total acumulado</span>
            </div>
            <p className="text-2xl font-bold text-foreground">{fmtCOP(totalTotal)}</p>
            <p className="text-xs text-muted-foreground">{services.length} servicios completados</p>
          </div>
          {/* Movimientos */}
          <div>
            <h3 className="text-sm font-semibold text-muted-foreground mb-3">Movimientos de saldo</h3>
            {filteredTxns.length === 0 ? (
              <p className="text-center text-sm text-muted-foreground py-4">Sin movimientos</p>
            ) : filteredTxns.slice(0, 10).map(t => (
              <div key={t.id} className="bg-card rounded-xl p-3 shadow-sm border border-border flex items-center gap-3 mb-2">
                <div className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 ${t.type === 'recarga' ? 'bg-success/15' : 'bg-destructive/15'}`}>
                  {t.type === 'recarga' ? <ArrowUpCircle className="w-5 h-5 text-success" /> : <TrendingDown className="w-5 h-5 text-destructive" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{t.description}</p>
                  <p className="text-xs text-muted-foreground">{new Date(t.created_date).toLocaleDateString('es-CO', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</p>
                </div>
                <span className={`text-sm font-bold flex-shrink-0 ${t.type === 'recarga' ? 'text-success' : 'text-destructive'}`}>
                  {t.type === 'recarga' ? '+' : '-'}{fmtCOP(t.amount)}
                </span>
              </div>
            ))}
          </div>
        </TabsContent>

        {/* Estadísticas tab */}
        <TabsContent value="estadisticas" className="space-y-3">
          <div className="bg-card rounded-2xl p-4 shadow-sm border border-border">
            <div className="flex items-center gap-2 mb-1">
              <BarChart3 className="w-4 h-4 text-primary" />
              <span className="text-xs text-muted-foreground">Promedio por servicio</span>
            </div>
            <p className="text-2xl font-bold text-primary">{fmtCOP(avgPerService)}</p>
          </div>
          {bestDay && (
            <div className="bg-card rounded-2xl p-4 shadow-sm border border-border">
              <span className="text-xs text-muted-foreground">Día con más ingresos</span>
              <p className="text-lg font-bold text-foreground capitalize">{bestDay[0]}</p>
              <p className="text-sm text-primary">{fmtCOP(bestDay[1])}</p>
            </div>
          )}
          <div className="bg-card rounded-2xl p-4 shadow-sm border border-border">
            <span className="text-xs text-muted-foreground">Esta semana vs. semana anterior</span>
            <div className="flex items-center gap-4 mt-2">
              <div className="flex-1">
                <p className="text-xs text-muted-foreground">Esta semana</p>
                <p className="text-lg font-bold text-foreground">{fmtCOP(weekTotal)}</p>
              </div>
              <div className="flex-1">
                <p className="text-xs text-muted-foreground">Semana anterior</p>
                <p className="text-lg font-bold text-muted-foreground">{fmtCOP(lastWeekTotal)}</p>
              </div>
              <div className={`px-3 py-1 rounded-lg text-sm font-bold ${weekChange >= 0 ? 'bg-success/15 text-success' : 'bg-destructive/15 text-destructive'}`}>
                {weekChange >= 0 ? '+' : ''}{weekChange}%
              </div>
            </div>
            {/* Gráfico simple de barras */}
            <div className="flex items-end gap-2 mt-4 h-24">
              {[weekServices.length, lastWeekServices.length].map((count, i) => (
                <div key={i} className="flex-1 flex flex-col items-center gap-1">
                  <div
                    className={`w-full rounded-t-md ${i === 0 ? 'bg-primary' : 'bg-muted-foreground/30'}`}
                    style={{ height: `${Math.max(10, (count / Math.max(weekServices.length, lastWeekServices.length, 1)) * 100)}%` }}
                  />
                  <span className="text-xs text-muted-foreground">{i === 0 ? 'Esta' : 'Anterior'}</span>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
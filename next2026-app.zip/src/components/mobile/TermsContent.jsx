import React from 'react';

// Contenido completo de Términos y Condiciones de NEXT.
// Reutilizable en el onboarding de primer ingreso y en el perfil del conductor.
export default function TermsContent() {
  return (
    <div className="space-y-5 text-sm leading-relaxed">
      <header>
        <h2 className="text-white font-bold text-base">Términos y Condiciones de Uso</h2>
        <p className="text-[#8B95A8] text-xs mt-1">Última actualización: Septiembre de 2026</p>
        <p className="text-[#8B95A8] text-xs">Entidad Operadora: NEXT TECNOLOGÍA S.A.S. (En constitución)</p>
        <p className="text-[#8B95A8] text-xs">Domicilio: Valledupar, Cesar, Colombia.</p>
      </header>

      <Section title="1. Términos y Condiciones de Uso para Usuarios (Pasajeros y Remitentes)">
        <p>NEXT es una plataforma tecnológica de intermediación digital desarrollada por NEXT TECNOLOGÍA S.A.S., cuyo único objeto es conectar de manera eficiente a usuarios solicitantes ("Usuarios") con conductores y repartidores independientes ("Colaboradores") para la prestación de servicios privados de transporte individual y/o mensajería exprés urbana en la ciudad de Valledupar y sus áreas de influencia. NEXT TECNOLOGÍA S.A.S. no es una empresa de transporte público, no opera flotillas de vehículos ni actúa como transportador directo.</p>
        <Sub title="1.2. Registro y Capacidad Legal">
          <p>Para acceder a la plataforma, el Usuario debe ser mayor de edad (18 años) según la legislación colombiana y proporcionar información veraz, exacta y actualizada (Nombre, Cédula, Teléfono y Correo Electrónico). El uso de cuentas por parte de menores de edad sin supervisión de un adulto titular está estrictamente prohibido.</p>
        </Sub>
        <Sub title="1.3. Tarifas y Pagos">
          <p><strong className="text-white">Tarifa Sugerida:</strong> La plataforma calcula una tarifa estimada basada en la distancia y tiempo del trayecto. El Usuario y el Colaborador pueden acordar la tarifa final mediante el mecanismo de subasta/oferta integrado en la app.</p>
          <p><strong className="text-white">Medios de Pago:</strong> El pago de los servicios se realiza directamente entre el Usuario y el Colaborador en efectivo o transferencia electrónica directa (Nequi / Bancolombia), según lo pactado previamente en la solicitud.</p>
        </Sub>
        <Sub title="1.4. Mensajería y Encomiendas (Condiciones de Envío)">
          <p><strong className="text-white">Objetos Prohibidos:</strong> Se prohíbe el envío de sustancias ilícitas, armas de fuego, explosivos, material biológico, animales vivos, dinero en efectivo en montos superiores a 1 SMLMV, joyas de alto valor o artículos de ilícito comercio bajo las leyes de la República de Colombia.</p>
          <p><strong className="text-white">Declaración de Valor y Envasado:</strong> El Usuario remitente es responsable de empacar y sellar adecuadamente el paquete. Todo paquete debe ser inspeccionado visualmente al momento de la entrega al repartidor.</p>
        </Sub>
        <Sub title="1.5. Exención de Responsabilidad">
          <p>NEXT no se hace responsable por pérdidas, daños o retrasos derivados de causas de fuerza mayor, caso fortuito, estado de las vías o el incumplimiento individual por parte de los Colaboradores independientes, sin perjuicio de las investigaciones internas y sanciones de bloqueo de cuenta que NEXT aplique.</p>
        </Sub>
      </Section>

      <Section title="2. Términos y Condiciones para Conductores y Repartidores ('Colaboradores')">
        <Sub title="2.1. Calidad de Colaborador Independiente">
          <p>El Colaborador declara expresamente que su relación con NEXT TECNOLOGÍA S.A.S. es de naturaleza estrictamente mercantil y civil. No existe vínculo de subordinación, laboralidad ni relación de patrono-empleado. El Colaborador mantiene autonomía absoluta sobre sus horarios, zonas de trabajo y la decisión de aceptar o rechazar solicitudes.</p>
        </Sub>
        <Sub title="2.2. Requisitos de Vinculación y Documentación">
          <p>Para activar la cuenta en NEXT, el Colaborador debe cargar y mantener vigentes los siguientes documentos:</p>
          <ul className="list-disc pl-5 space-y-1 text-[#A0A8B8]">
            <li>Cédula de Ciudadanía o Cédula de Extranjería válida.</li>
            <li>Licencia de conducción vigente correspondiente a la categoría del vehículo (A2 para motos, B1/C1 para carros/taxis).</li>
            <li>Licencia de tránsito (Tarjeta de propiedad del vehículo).</li>
            <li>SOAT vigente registrado en RUNT.</li>
            <li>Certificado de Revisión Técnico-Mecánica (cuando aplique).</li>
            <li>Planilla de pago a la Seguridad Social en calidad de Independiente (Salud, Pensión y ARL) según la normativa vigente.</li>
          </ul>
        </Sub>
        <Sub title="2.2.1. Verificación de Antecedentes Judiciales">
          <p>Como medida de seguridad para los Usuarios, NEXT verifica los antecedentes judiciales de todos los Colaboradores que se registran en la plataforma, consultando las fuentes oficiales disponibles en la República de Colombia. Con el registro, el Colaborador autoriza expresamente esta consulta.</p>
          <p>En caso de que el Colaborador presente antecedentes o anotaciones judiciales, <strong className="text-white">no se le permitirá el acceso a la aplicación</strong>: su registro será rechazado y se le notificará que no fue válido, pudiendo intentarlo nuevamente más adelante.</p>
        </Sub>
        <Sub title="2.3. Esquema Financiero: Pase de 14 Horas Laborales (Sin Comisión por Porcentaje)">
          <p><strong className="text-white">Modalidad Única de Pase por Recarga:</strong> NEXT opera exclusivamente bajo la modalidad de Pase de <strong className="text-white">14 horas laborales</strong>, sin cobro ni descuento de porcentaje sobre los servicios realizados. El Colaborador recibe el 100% del valor acordado en cada viaje o entrega.</p>
          <ul className="list-disc pl-5 space-y-1 text-[#A0A8B8]">
            <li><strong className="text-white">Tarifa del Pase para Motocicleta:</strong> <strong className="text-white">$7.000 COP</strong> por recarga, que habilita <strong className="text-white">14 horas laborales</strong> continuas desde su activación.</li>
            <li><strong className="text-white">Tarifa del Pase para Automóvil:</strong> <strong className="text-white">$10.000 COP</strong> por recarga, que habilita <strong className="text-white">14 horas laborales</strong> continuas desde su activación.</li>
            <li><strong className="text-white">Renovación Automática del Saldo a $0:</strong> Apenas se cumplan las <strong className="text-white">14 horas</strong> contadas desde que se activa la recarga, el saldo del Colaborador en la aplicación se renueva automáticamente a <strong className="text-white">$0</strong> y la plataforma le informará que debe volver a recargar para poder seguir tomando servicios.</li>
          </ul>
          <p><strong className="text-white">Medio de Pago y Verificación:</strong> La recarga se realiza mediante transferencia a las cuentas habilitadas de NEXT (Nequi, Banco Nu o llave breve). El Colaborador sube el comprobante de la transferencia y la Central de NEXT la verifica para activar el pase de 14 horas laborales.</p>
          <p><strong className="text-white">Naturaleza del Pago:</strong> El pago del pase de 14 horas laborales corresponde al pago anticipado por el derecho de uso temporal de la plataforma tecnológica y no constituye depósito bancario ni captación masiva de dinero.</p>
        </Sub>
        <Sub title="2.4. Causal de Suspensión o Bloqueo Definitivo de Cuenta">
          <p>NEXT se reserva el derecho de inactivar temporal o permanentemente la cuenta del Colaborador por:</p>
          <ul className="list-disc pl-5 space-y-1 text-[#A0A8B8]">
            <li>Presentar documentación falsa o vencida.</li>
            <li>Calificación promedio de usuarios inferior a 4.2 / 5.0 estrellas.</li>
            <li>Cobrar valores superiores a los pactados en la app.</li>
            <li>Permitir el uso de la cuenta por parte de terceros no autorizados.</li>
            <li>Incurrir en conductas verbales o físicas que atenten contra la seguridad e integridad de los Usuarios.</li>
          </ul>
        </Sub>
      </Section>

      <Section title="3. Política de Tratamiento de Datos Personales (Habeas Data - Ley 1581 de 2012)">
        <Sub title="3.1. Responsable del Tratamiento">
          <p>Razón Social: NEXT TECNOLOGÍA S.A.S.</p>
          <p>Correo de Contacto: legal@nextapp.com.co / soporte@nextapp.com.co</p>
          <p>Ciudad: Valledupar, Cesar.</p>
        </Sub>
        <Sub title="3.2. Finalidad de la Recolección de Datos">
          <p>Los datos personales recolectados (Nombres, Cédula, Teléfono, Ubicación GPS en tiempo real, Foto y Datos de Vehículo) serán utilizados para:</p>
          <ul className="list-disc pl-5 space-y-1 text-[#A0A8B8]">
            <li>Validar la identidad de Usuarios y Colaboradores.</li>
            <li>Consultar los antecedentes judiciales de los Colaboradores que se registran, como requisito para aprobar su acceso a la plataforma.</li>
            <li>Permitir la geolocalización precisa para la asignación y rastreo de viajes o encomiendas.</li>
            <li>Procesar las recargas del pase diario y verificar los comprobantes de transferencia.</li>
            <li>Enviar notificaciones operativas vía SMS, WhatsApp o Push sobre el estado de los servicios.</li>
            <li>Atender requerimientos judiciales o administrativos de autoridades competentes de la República de Colombia.</li>
          </ul>
        </Sub>
        <Sub title="3.3. Derechos del Titular (Derechos ARCO)">
          <p>El titular de los datos tiene derecho a Conocer, Actualizar, Rectificar y Solicitar la Supresión de sus datos personales de las bases de datos de NEXT. Para ejercer estos derechos, puede enviar una solicitud formal al correo habeasdata@nextapp.com.co, la cual será resuelta en un término máximo de 10 días hábiles.</p>
        </Sub>
      </Section>

      <Section title="4. Acuerdo Comercial B2B para Restaurantes y Comercios Aliados">
        <Sub title="4.1. Objeto del Acuerdo">
          <p>El presente acuerdo marco de servicios tiene por objeto afiliar al COMERCIO ALIADO al ecosistema de mensajería express de NEXT para el despacho prioritario de sus domicilios y entregas a clientes finales en Valledupar.</p>
        </Sub>
        <Sub title="4.2. Modalidad de Operación">
          <p><strong className="text-white">Integración del Pedido:</strong> El COMERCIO ALIADO gestiona la venta de sus productos directamente con sus clientes y utiliza la app de NEXT (módulo B2B) para solicitar la motocicleta asignada.</p>
          <p><strong className="text-white">Tiempo de Respuesta:</strong> NEXT garantiza la disponibilidad de la flota activa de repartidores previa solicitud en la plataforma.</p>
        </Sub>
        <Sub title="4.3. Liquidación y Facturación">
          <p><strong className="text-white">Cobro por Envíos:</strong> El valor de cada envío se calcula según la matriz de distancias por zonas dentro de la zona urbana de Valledupar.</p>
          <p><strong className="text-white">Facturación:</strong> Las partes acordarán si el pago de los domicilios se realiza contra entrega en efectivo/Nequi por envío o mediante facturación consolidada semanal para empresas corporativas.</p>
        </Sub>
      </Section>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <section className="space-y-2">
      <h3 className="text-white font-semibold text-sm">{title}</h3>
      <div className="space-y-2">{children}</div>
    </section>
  );
}

function Sub({ title, children }) {
  return (
    <div className="space-y-1.5">
      <p className="text-[#00E5FF] font-medium text-xs uppercase tracking-wide">{title}</p>
      <div className="space-y-1.5 text-[#A0A8B8]">{children}</div>
    </div>
  );
}
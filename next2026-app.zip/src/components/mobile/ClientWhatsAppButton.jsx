import React from 'react';
import { WhatsAppOriginalIcon, buildWhatsAppDirectUrl } from '@/components/shared/OriginalActionIcons';

// WhatsApp del cliente en un pedido de mensajería: abre el chat directo con su número.
export default function ClientWhatsAppButton({ phone }) {
  return (
    <a
      href={buildWhatsAppDirectUrl({ phone })}
      data-testid="driver-client-whatsapp-btn"
      className="col-span-2 h-12 rounded-2xl bg-muted border border-border flex items-center justify-center gap-2 text-foreground text-xs font-extrabold active:scale-95 transition-transform"
    >
      <WhatsAppOriginalIcon className="w-6 h-6 flex-shrink-0" />
      <span className="truncate">WhatsApp del cliente · {phone}</span>
    </a>
  );
}
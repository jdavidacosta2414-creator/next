import React from 'react';
import { MapPin } from 'lucide-react';

// Logo Waze (mascota sonriente sobre fondo cian).
function WazeLogo({ className }) {
  return (
    <svg viewBox="0 0 48 48" className={className} xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <rect width="48" height="48" rx="11" fill="#33CCFF" />
      <circle cx="24" cy="20" r="12" fill="#fff" />
      <circle cx="20" cy="18.5" r="2" fill="#3a3a3a" />
      <circle cx="28" cy="18.5" r="2" fill="#3a3a3a" />
      <path d="M19.5 23.5 Q24 27 28.5 23.5" stroke="#3a3a3a" strokeWidth="1.8" fill="none" strokeLinecap="round" />
      <circle cx="18.5" cy="31" r="2.8" fill="#fff" stroke="#3a3a3a" strokeWidth="1.2" />
      <circle cx="29.5" cy="31" r="2.8" fill="#fff" stroke="#3a3a3a" strokeWidth="1.2" />
    </svg>
  );
}

// Logo Mapbox (pin vectorial sobre fondo azul oscuro).
function MapboxLogo({ className }) {
  return (
    <svg viewBox="0 0 48 48" className={className} xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <rect width="48" height="48" rx="11" fill="#1E6BFF" />
      <path d="M24 9c-6.6 0-12 5.4-12 12 0 8.7 10.4 18.6 11.1 19.2.5.4 1.3.4 1.8 0 .7-.6 11.1-10.5 11.1-19.2 0-6.6-5.4-12-12-12z" fill="#ffffff" />
      <circle cx="24" cy="21" r="4.5" fill="#1E6BFF" />
    </svg>
  );
}

export default function NavigationButtons({ address, lat, lng, label }) {
  const encoded = encodeURIComponent(address);
  const hasCoords = lat != null && lng != null;
  const wazeUrl = hasCoords
    ? `https://www.waze.com/ul?ll=${lat},${lng}&navigate=yes`
    : `https://www.waze.com/ul?q=${encoded}&navigate=yes`;
  const mapsUrl = hasCoords
    ? `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`
    : `https://www.google.com/maps/search/?api=1&query=${encoded}`;

  return (
    <div className="bg-card rounded-2xl p-4 border border-border">
      <p className="text-xs font-semibold text-muted-foreground mb-1 flex items-center gap-1.5">
        <MapPin className="w-3.5 h-3.5 text-primary flex-shrink-0" />{label}
      </p>
      <p className="text-sm font-medium text-foreground mb-3 break-words">{address}</p>
      <div className="grid grid-cols-2 gap-3">
        <a
          href={wazeUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 h-12 rounded-xl bg-muted border border-border px-3 hover:bg-muted/80 active:scale-95 transition-transform"
          title="Abrir en Waze"
        >
          <WazeLogo className="w-8 h-8 flex-shrink-0" />
          <span className="text-sm font-bold text-foreground">Waze</span>
        </a>
        <a
          href={mapsUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 h-12 rounded-xl bg-muted border border-border px-3 hover:bg-muted/80 active:scale-95 transition-transform"
          title="Abrir en Mapa"
        >
          <MapboxLogo className="w-8 h-8 flex-shrink-0" />
          <span className="text-sm font-bold text-foreground">Mapa</span>
        </a>
      </div>
    </div>
  );
}
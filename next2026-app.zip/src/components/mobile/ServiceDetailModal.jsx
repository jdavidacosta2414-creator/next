import React, { useState, useEffect, useMemo, useRef } from 'react';
import MapboxMap, { MapboxMarker, MapboxDrivingRoute, MapboxFitBounds } from '@/components/shared/MapboxMap';
import { pickupWavingPinEl, destinationPinEl, vehicleMarkerEl, stopPinEl } from '@/lib/mapboxMarkers';
import { Loader2, Package, Users, Check, Wallet, Navigation, MessageCircle, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from '@/components/ui/use-toast';
import TripExtras from '@/components/shared/TripExtras';
import ClientAvatar from '@/components/shared/ClientAvatar';
import { preloadStorageUrls } from '@/components/shared/ResolvedAvatar';
import PassengerTrustBadge from '@/components/shared/PassengerTrustBadge';
import ServiceRouteStops from '@/components/shared/ServiceRouteStops';
import ServiceBaseNotice from '@/components/mobile/ServiceBaseNotice';
import { fetchPassengerStatsMap } from '@/lib/passengerStats';
import { fmtKm, fmtMin, calcSegments, calibrateRouteMetrics, estimateKm } from '@/lib/routeEstimate';
import { shortAddress } from '@/lib/shortAddress';
import { seedSavedRoute } from '@/lib/mapRoute';
import { useBackButton } from '@/hooks/useBackButton';

const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');

const PAYMENT_LABELS = {
  efectivo: 'Efectivo',
  transferencia: 'Transferencia',
  nequi: 'Nequi',
  daviplata: 'DaviPlata',
  bancolombia: 'Bancolombia',
  paga_con_llave: 'Paga con llave',
  redimido_puntos: '🎁 Redimido por puntos (Se abona a tu Cartera)',
};

const pickupEl = () => pickupWavingPinEl('', 'Punto de recogida', false);
const destEl = () => destinationPinEl('', 'Punto de llegada', false);
const driverEl = (vt) => () => vehicleMarkerEl(vt === 'carro' ? '🚗' : '🛵', '#1E6BFF', 34);

function RoutePreview({
  driverLat,
  driverLng,
  pickupLat,
  pickupLng,
  destLat,
  destLng,
  stops = [],
  seg1Info,
  seg2Info,
  onSeg1Info,
  onSeg2Info,
  vehicleType,
  expanded = false,
  onToggleExpand,
}) {
  const validStopCoords = useMemo(
    () =>
      (stops || [])
        .filter((s) => s?.lat != null && s?.lng != null)
        .map((s) => [Number(s.lat), Number(s.lng)]),
    [stops]
  );

  const positions = useMemo(() => {
    const pts = [];
    if (driverLat != null) pts.push([driverLat, driverLng]);
    if (pickupLat != null) pts.push([pickupLat, pickupLng]);
    validStopCoords.forEach((wp) => pts.push(wp));
    if (destLat != null) pts.push([destLat, destLng]);
    return pts;
  }, [driverLat, driverLng, pickupLat, pickupLng, destLat, destLng, validStopCoords]);

  if (pickupLat == null || destLat == null) {
    return (
      <div className="flex items-center justify-center h-full min-h-40 bg-muted">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  const hasDriver = driverLat != null;

  return (
    <div className="relative overflow-hidden h-full w-full cursor-pointer">
      <MapboxMap
        center={hasDriver ? [driverLat, driverLng] : [pickupLat, pickupLng]}
        zoom={13.5}
        pitch={0}
        className="h-full w-full"
        onMapClick={() => onToggleExpand?.()}
      >
        {hasDriver && <MapboxMarker lat={driverLat} lng={driverLng} el={driverEl(vehicleType)} interactive={false} />}
        <MapboxMarker lat={pickupLat} lng={pickupLng} el={pickupEl} anchor="bottom" interactive={false} />
        {(stops || []).map((st, idx) =>
          st?.lat != null && st?.lng != null ? (
            <MapboxMarker
              key={`stop-${idx}`}
              lat={st.lat}
              lng={st.lng}
              el={() => stopPinEl(idx + 1, shortAddr(st.address), false)}
              anchor="bottom"
              interactive={false}
            />
          ) : null
        )}
        <MapboxMarker lat={destLat} lng={destLng} el={destEl} anchor="bottom" interactive={false} />
        {hasDriver && (
          <MapboxDrivingRoute
            from={[driverLat, driverLng]}
            to={[pickupLat, pickupLng]}
            color="#0284C7"
            width={5}
            opacity={0.88}
            onRouteInfo={onSeg1Info}
          />
        )}
        <MapboxDrivingRoute
          from={[pickupLat, pickupLng]}
          to={[destLat, destLng]}
          waypoints={validStopCoords}
          color="#1E6BFF"
          width={6}
          opacity={0.95}
          onRouteInfo={onSeg2Info}
        />
        <MapboxFitBounds
          positions={positions}
          padding={expanded ? 65 : { top: 56, bottom: 48, left: 48, right: 48 }}
          singleZoom={15}
          fitKey={expanded ? 'expanded' : 'compact'}
        />
      </MapboxMap>

      {/* Badge tramo 1: Conductor → Recogida */}
      {hasDriver && seg1Info?.distanceKm != null && (
        <div className="absolute top-3 left-3 bg-[#062B6E]/95 text-white text-xs font-extrabold px-3 py-1.5 rounded-xl shadow-lg border border-sky-400/35 z-[500] pointer-events-none">
          A recogida: {fmtMin(seg1Info.durationMin)} · {fmtKm(seg1Info.distanceKm)}
        </div>
      )}
      {/* Badge tramo 2: Recogida → Destino */}
      {seg2Info?.distanceKm != null && (
        <div className="absolute top-3 right-3 bg-[#1E6BFF] text-white text-xs font-extrabold px-3 py-1.5 rounded-xl shadow-lg z-[500] pointer-events-none">
          Viaje: {fmtMin(seg2Info.durationMin)} · {fmtKm(seg2Info.distanceKm)}
        </div>
      )}
    </div>
  );
}

export default function ServiceDetailModal({
  service,
  passengerStats: initialStats,
  mobile,
  canTakeMore = true,
  kmToFinish = null,
  limitMessage = null,
  onClose,
  onAccept,
}) {
  const [accepting, setAccepting] = useState(null);
  const [customFare, setCustomFare] = useState('');
  const [skipping] = useState(false);
  const [pStats, setPStats] = useState(initialStats || null);
  const [mapExpanded, setMapExpanded] = useState(false);
  // La postulación tarda unos segundos: si mientras tanto el conductor cerró este detalle (y quizá abrió otro), no se cierra nada al terminar.
  const openRef = useRef(true);
  useEffect(() => {
    openRef.current = true;
    return () => {
      openRef.current = false;
    };
  }, []);

  // La X y el botón físico "Atrás" del celular: si el mapa está ampliado vuelven al detalle; si no, cierran el modal.
  const closeOrCollapse = () => {
    if (mapExpanded) setMapExpanded(false);
    else onClose?.();
    return true;
  };
  useBackButton(closeOrCollapse, true);

  useEffect(() => {
    if (service?.client_photo) preloadStorageUrls([service.client_photo]);
    if (initialStats) {
      if (initialStats.photo) preloadStorageUrls([initialStats.photo]);
      setPStats(initialStats);
      return;
    }
    if (!service?.id) return;
    fetchPassengerStatsMap([service])
      .then((m) => {
        const st = m[service.id] || { trips: 0, rating: null };
        if (st.photo) preloadStorageUrls([st.photo]);
        setPStats(st);
      })
      .catch(() => {});
  }, [service, initialStats]);

  useEffect(() => {
    if (!service?.id || !mobile?.id) return;
    base44.entities.Service.get(service.id)
      .then((fresh) => {
        const viewed = Array.isArray(fresh?.viewed_by) ? fresh.viewed_by : service.viewed_by || [];
        if (viewed.includes(mobile.id)) return;
        return base44.entities.Service.update(service.id, {
          viewed_by: Array.from(new Set([...viewed, mobile.id])),
        });
      })
      .catch(() => {});
  }, [service?.id, mobile?.id]);

  seedSavedRoute(service);
  const fare = service.fare || 5000;
  const isNegocio = service.origin === 'negocios';
  const isWhatsAppFixedPrice = service.origin === 'whatsapp' || isNegocio;
  const offers = useMemo(
    () => [
      Math.round((fare + 2000) / 500) * 500,
      Math.round((fare + 4000) / 500) * 500,
      Math.round((fare + 8000) / 500) * 500,
    ],
    [fare]
  );

  const [seg1Info, setSeg1Info] = useState(null);
  const [seg2Info, setSeg2Info] = useState(null);

  const vType = mobile?.vehicle_type || service?.vehicle_type || 'moto';
  const sType = service?.service_type || 'transporte';
  const drvLat = mobile?.current_lat ?? service?.pickup_lat;
  const drvLng = mobile?.current_lng ?? service?.pickup_lng;
  const validStopsCount = (service?.stops || []).filter((s) => s?.lat != null && s?.lng != null).length;

  const fallbackSegs = useMemo(
    () =>
      calcSegments(
        drvLat,
        drvLng,
        service?.pickup_lat,
        service?.pickup_lng,
        service?.destination_lat,
        service?.destination_lng,
        vType,
        sType,
        service?.stops
      ),
    [
      drvLat,
      drvLng,
      vType,
      sType,
      service?.pickup_lat,
      service?.pickup_lng,
      service?.destination_lat,
      service?.destination_lng,
      service?.stops,
    ]
  );

  const calSeg1 = useMemo(
    () =>
      calibrateRouteMetrics({
        routeInfo: seg1Info,
        straightKm: estimateKm(drvLat, drvLng, service?.pickup_lat, service?.pickup_lng),
        stopsCount: 0,
        vehicleType: vType,
        serviceType: sType,
      }),
    [seg1Info, drvLat, drvLng, service?.pickup_lat, service?.pickup_lng, vType, sType]
  );

  const calSeg2 = useMemo(
    () =>
      calibrateRouteMetrics({
        routeInfo: seg2Info,
        straightKm: estimateKm(
          service?.pickup_lat,
          service?.pickup_lng,
          service?.destination_lat,
          service?.destination_lng
        ),
        stopsCount: validStopsCount,
        vehicleType: vType,
        serviceType: sType,
      }),
    [
      seg2Info,
      service?.pickup_lat,
      service?.pickup_lng,
      service?.destination_lat,
      service?.destination_lng,
      validStopsCount,
      vType,
      sType,
    ]
  );

  const pickupEtaMin = calSeg1.durationMin ?? fallbackSegs.seg1Min;
  const pickupKm = calSeg1.distanceKm ?? fallbackSegs.seg1Km;
  const destEtaMin = calSeg2.durationMin ?? fallbackSegs.seg2Min;
  const destKm = calSeg2.distanceKm ?? fallbackSegs.seg2Km;

  const handleAccept = async (proposedFare) => {
    if (!canTakeMore) {
      toast({
        title: limitMessage ? 'Límite de servicios alcanzado' : 'Servicio en curso activo',
        description:
          limitMessage ||
          (kmToFinish != null
            ? `Estás a ${kmToFinish.toFixed(1)} km de dejar tu primer servicio. Puedes tomar otro cuando estés a 1 km o menos.`
            : 'Debes estar a máximo 1 km de dejar tu primer servicio para tomar otro.'),
        variant: 'destructive',
      });
      return;
    }
    const finalFare = isWhatsAppFixedPrice ? fare : proposedFare || fare;
    const isCounter = !isWhatsAppFixedPrice && proposedFare && proposedFare !== fare;
    setAccepting(finalFare);
    try {
      if (isWhatsAppFixedPrice) {
        // Precio fijo (pedido de la Central por WhatsApp o de un negocio aliado): no hay oferta ni contraoferta.
        // Quien acepta queda postulado; al cerrar la ventana de postulaciones la app lo asigna al postulado más cercano a la recogida.
        const res = await base44.functions.invoke('claimService', {
          service_id: service.id,
          mobile_id: mobile.id,
          lat: mobile.current_lat,
          lng: mobile.current_lng,
        });
        if (res?.data?.assigned) {
          toast({
            title: '¡Servicio asignado a precio fijo!',
            description: `Tomaste el servicio pedido por ${isNegocio ? service.business_name || 'un negocio aliado' : 'WhatsApp'} por ${fmtCOP(fare)}.`,
          });
          onAccept?.(res.data.service || null);
        } else {
          const who = service.service_type === 'mensajeria' ? 'mensajero' : 'conductor';
          toast({
            title: 'Este servicio ya no está disponible',
            description:
              res?.data?.reason === 'closer_driver'
                ? `Te postulaste, pero se le asignó a otro ${who} que estaba más cerca.`
                : 'Ya fue tomado o cancelado.',
            variant: 'destructive',
          });
        }
        if (openRef.current) onClose();
        return;
      }
      await base44.functions.invoke('submitDriverOffer', {
        service_id: service.id,
        mobile_id: mobile.id,
        lat: mobile.current_lat,
        lng: mobile.current_lng,
        offered_fare: finalFare,
      });
      toast({
        title: isCounter ? 'Oferta enviada' : 'Te postulaste al servicio',
        description: isCounter
          ? 'El pasajero decidirá si acepta tu tarifa.'
          : 'El pasajero verá tu oferta entre las más cercanas.',
      });
      onAccept?.(null);
      onClose();
    } catch (err) {
      toast({ title: isWhatsAppFixedPrice ? 'No se pudo tomar el servicio' : 'No se pudo enviar la oferta', description: err.message || 'Intenta de nuevo', variant: 'destructive' });
    } finally {
      setAccepting(null);
    }
  };

  const submitCustom = () => {
    const val = Number(customFare);
    if (!val || val < 1000) {
      toast({ title: 'Tarifa inválida', description: 'Ingresa un valor mayor a $1.000', variant: 'destructive' });
      return;
    }
    handleAccept(val);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-background max-w-md mx-auto w-full h-[100dvh] overflow-hidden">
      {/* Mapa superior interactivo: tocar amplía a pantalla completa; volver atrás regresa al panel */}
      <div className={`relative w-full overflow-hidden transition-all duration-200 ${mapExpanded ? 'flex-1 h-full' : 'h-[42dvh] flex-shrink-0'}`}>
        <RoutePreview
          driverLat={mobile.current_lat}
          driverLng={mobile.current_lng}
          pickupLat={service.pickup_lat}
          pickupLng={service.pickup_lng}
          destLat={service.destination_lat}
          destLng={service.destination_lng}
          stops={service.stops}
          seg1Info={
            pickupKm != null && pickupEtaMin != null
              ? { distanceKm: pickupKm, durationMin: pickupEtaMin }
              : seg1Info
          }
          seg2Info={
            destKm != null && destEtaMin != null
              ? { distanceKm: destKm, durationMin: destEtaMin }
              : seg2Info
          }
          onSeg1Info={setSeg1Info}
          onSeg2Info={setSeg2Info}
          vehicleType={mobile.vehicle_type}
          expanded={mapExpanded}
          onToggleExpand={() => setMapExpanded((v) => !v)}
        />
        <button
          type="button"
          onClick={closeOrCollapse}
          aria-label="Cerrar"
          className="absolute bottom-7 right-3 z-[500] w-10 h-10 rounded-full bg-[#062B6E]/95 text-white border border-sky-400/35 shadow-lg flex items-center justify-center active:scale-95 transition-transform"
        >
          <X className="w-5 h-5 stroke-[2.6]" />
        </button>
      </div>

      {!mapExpanded && (
        <div className="relative z-20 -mt-4 flex-1 min-h-0 flex flex-col justify-between rounded-t-[28px] border-t border-border bg-card px-4 pt-3 pb-4 shadow-[0_-10px_35px_rgba(0,0,0,0.28)] overflow-y-auto no-scrollbar gap-3">
          <div className="w-10 h-1.5 rounded-full bg-muted mx-auto flex-shrink-0" />

          {/* Pasajero + Tarifa principal */}
          <div className="bg-muted/60 border border-border/70 rounded-2xl p-3.5 space-y-3 flex-shrink-0">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0 flex-1">
                <ClientAvatar photo={service.client_photo || pStats?.photo} name={service.client_name} size="md" />
                <div className="min-w-0 flex-1">
                  <p className="text-foreground font-extrabold text-base leading-tight truncate">
                    {service.client_name || 'Pasajero'}
                  </p>
                  <div className="mt-0.5">
                    <PassengerTrustBadge stats={pStats} />
                  </div>
                </div>
              </div>

              <div className="text-right flex-shrink-0">
                <span className="text-2xl font-black text-[#1E6BFF] dark:text-[#38BDF8] block leading-none">
                  {fmtCOP(fare)}
                </span>
                {isWhatsAppFixedPrice && (
                  <span
                    data-testid="modal-whatsapp-fixed-price-badge"
                    className="mt-1 inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/35 text-emerald-700 dark:text-emerald-300 text-[10px] font-extrabold"
                  >
                    <MessageCircle className="w-3 h-3" /> Precio fijo · {isNegocio ? 'Negocio' : 'WhatsApp'}
                  </span>
                )}
                <span className="text-[11px] font-bold text-foreground/75 block mt-1">
                  {PAYMENT_LABELS[service.payment_method] || service.payment_method}
                </span>
              </div>
            </div>

            {service.origin === 'whatsapp' && service.service_type !== 'mensajeria' && (
              <div className="rounded-xl bg-emerald-500/12 border border-emerald-500/35 px-3 py-2 flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 flex-shrink-0" />
                <p className="text-xs font-extrabold text-emerald-800 dark:text-emerald-300 leading-snug">
                  {`Precio fijo (${fmtCOP(fare)}) porque este servicio fue montado por la Central por pedido de WhatsApp.`}
                </p>
              </div>
            )}

            <ServiceBaseNotice value={service.order_value} format={fmtCOP} />

            {/* Ruta con direcciones y distancias bien legibles */}
            <div className="pt-2.5 border-t border-border/70">
              <ServiceRouteStops
                pickupAddress={service.pickup_address}
                destinationAddress={service.destination_address}
                pickupBarrio={service.pickup_barrio}
                destinationBarrio={service.destination_barrio}
                stops={service.stops}
                showLetterBadges
                pickupEtaMin={pickupEtaMin}
                pickupKm={pickupKm}
                destEtaMin={destEtaMin}
                destKm={destKm}
              />
            </div>

            {/* Etiquetas de método de pago, tipo de servicio, paradas y recorrido total */}
            <div className="flex items-center justify-between gap-2 pt-2 border-t border-border/70 flex-wrap">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-extrabold bg-[#1E6BFF] text-white shadow-xs">
                  <Wallet className="w-3.5 h-3.5" />
                  {PAYMENT_LABELS[service.payment_method] || service.payment_method}
                </span>

                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-extrabold bg-[#062B6E]/12 dark:bg-[#1E6BFF]/20 text-[#0B439C] dark:text-sky-200 border border-[#1E6BFF]/30">
                  {service.service_type === 'mensajeria' ? (
                    <>
                      <Package className="w-3.5 h-3.5" /> Mensajería
                    </>
                  ) : (
                    <>
                      <Users className="w-3.5 h-3.5" /> Viaje
                    </>
                  )}
                </span>

                {/* Teléfono oculto por seguridad */}

                {Array.isArray(service.stops) && service.stops.filter((st) => (st?.address || '').trim()).length > 0 && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-extrabold bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-500/35">
                    📍 {service.stops.filter((st) => (st?.address || '').trim()).length}{' '}
                    {service.stops.filter((st) => (st?.address || '').trim()).length === 1 ? 'parada' : 'paradas'}
                  </span>
                )}
              </div>

              {(pickupKm != null || destKm != null) && (
                <span className="inline-flex items-center gap-1 text-xs text-foreground font-extrabold">
                  <Navigation className="w-3.5 h-3.5 text-[#1E6BFF]" />
                  {fmtMin((pickupEtaMin || 0) + (destEtaMin || 0))} · {fmtKm((pickupKm || 0) + (destKm || 0))} totales
                </span>
              )}
            </div>

            <TripExtras service={service} variant="light" />
          </div>

          {/* Botones de acción amplios con los colores de NEXT */}
          <div className="flex-shrink-0 flex flex-col gap-2.5">
            <button
              type="button"
              onClick={() => handleAccept(fare)}
              disabled={!!accepting || skipping}
              className="w-full h-14 rounded-2xl bg-gradient-to-r from-[#062B6E] via-[#0B439C] to-[#1E6BFF] text-white font-extrabold text-base flex items-center justify-center gap-2.5 disabled:opacity-60 shadow-lg shadow-[#1E6BFF]/30 active:scale-[0.99] transition-transform"
            >
              {accepting === fare ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  {isWhatsAppFixedPrice && (
                    <span className="text-sm leading-tight">Postulado · asignando al más cercano…</span>
                  )}
                </>
              ) : (
                <>
                  <Check className="w-5 h-5 stroke-[2.8]" />
                  <span>
                    {isWhatsAppFixedPrice
                      ? `Aceptar precio fijo por ${fmtCOP(fare)}`
                      : `Aceptar por ${fmtCOP(fare)}`}
                  </span>
                </>
              )}
            </button>

            {!isWhatsAppFixedPrice && (
              <>
                <p className="text-center text-xs text-foreground/85 font-extrabold uppercase tracking-wider">
                  Ofrece tu tarifa
                </p>

                <div className="grid grid-cols-3 gap-2.5">
                  {offers.map((o) => (
                    <button
                      key={o}
                      type="button"
                      onClick={() => handleAccept(o)}
                      disabled={!!accepting || skipping}
                      className="h-12 rounded-2xl bg-[#1E6BFF]/12 dark:bg-[#1E6BFF]/22 border-2 border-[#1E6BFF]/45 text-[#0B439C] dark:text-white font-extrabold text-sm flex items-center justify-center disabled:opacity-60 active:scale-95 transition-transform"
                    >
                      {accepting === o ? <Loader2 className="w-4 h-4 animate-spin" /> : fmtCOP(o)}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-2.5">
                  <input
                    type="number"
                    inputMode="numeric"
                    placeholder="Escribe otra tarifa (COP)"
                    value={customFare}
                    onChange={(e) => setCustomFare(e.target.value)}
                    disabled={!!accepting || skipping}
                    className="flex-1 min-w-0 h-12 rounded-2xl border-2 border-border bg-muted/70 px-3.5 text-foreground text-sm font-bold placeholder:text-foreground/55 focus:outline-none focus:border-[#1E6BFF]"
                  />
                  <button
                    type="button"
                    onClick={submitCustom}
                    disabled={!!accepting || skipping || !customFare}
                    className="h-12 px-5 rounded-2xl bg-[#1E6BFF] text-white font-extrabold text-sm disabled:opacity-50 shadow-md shadow-[#1E6BFF]/25 active:scale-95 transition-transform flex-shrink-0"
                  >
                    {accepting && accepting !== fare && accepting !== offers[0] && accepting !== offers[1] && accepting !== offers[2] ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      'Ofrecer'
                    )}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function shortAddr(addr) {
  if (!addr) return '—';
  return shortAddress(addr) || addr;
}
import React from 'react';
import { Wallet } from 'lucide-react';

// Base en efectivo que el mensajero debe llevar para pagar el pedido al comercio.
// Solo aparece cuando el negocio indicó un valor.
export default function ServiceBaseNotice({ value, format, compact = false }) {
  const base = Number(value || 0);
  if (!(base > 0)) return null;

  return (
    <div
      data-testid="service-base-notice"
      className={
        compact
          ? 'flex items-center gap-2 min-w-0 mb-1.5 pb-1.5 border-b border-border'
          : 'flex items-center gap-3 min-w-0 rounded-2xl bg-primary/10 border border-primary/25 p-3'
      }
    >
      <div
        className={`rounded-full bg-primary text-primary-foreground flex items-center justify-center flex-shrink-0 ${
          compact ? 'w-7 h-7' : 'w-10 h-10'
        }`}
      >
        <Wallet className={compact ? 'w-3.5 h-3.5' : 'w-5 h-5'} />
      </div>
      <div className="min-w-0">
        <p className={`font-extrabold text-primary leading-tight ${compact ? 'text-[11px]' : 'text-xs'}`}>
          Base que debe llevar
        </p>
        <p className={`font-black text-foreground leading-tight truncate ${compact ? 'text-[15px]' : 'text-lg'}`}>
          {format(base)}
        </p>
      </div>
    </div>
  );
}
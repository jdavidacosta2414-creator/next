import { useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { DEFAULT_CITY } from '@/lib/appCity';

// Sigue el GPS del conductor en vivo y mantiene un latido constante en la entidad Mobile
// mientras esté conectado, para que solo los conductores realmente conectados en tiempo real
// aparezcan en los mapas de Pasajero y Central.
export function useDriverTracking(
  mobileId,
  connected,
  initialLat = null,
  initialLng = null,
  onLocationChange = null
) {
  const lastPushRef = useRef(0);
  const onLocRef = useRef(onLocationChange);
  onLocRef.current = onLocationChange;
  const lastPosRef = useRef(
    initialLat != null && initialLng != null
      ? { lat: Number(initialLat), lng: Number(initialLng) }
      : null
  );

  useEffect(() => {
    if (initialLat != null && initialLng != null && !lastPosRef.current) {
      lastPosRef.current = { lat: Number(initialLat), lng: Number(initialLng) };
    }
  }, [initialLat, initialLng]);

  useEffect(() => {
    if (!mobileId || !connected) return;

    let watchId = null;
    let alive = true;

    const pushPresence = async (lat, lng) => {
      if (!alive) return;
      const finalLat = lat ?? lastPosRef.current?.lat ?? DEFAULT_CITY.lat;
      const finalLng = lng ?? lastPosRef.current?.lng ?? DEFAULT_CITY.lng;
      lastPosRef.current = { lat: finalLat, lng: finalLng };
      lastPushRef.current = Date.now();
      onLocRef.current?.(finalLat, finalLng);
      try {
        await base44.entities.Mobile.update(mobileId, {
          current_lat: finalLat,
          current_lng: finalLng,
          // Con la app a la vista, el servicio nuevo se avisa dentro de la app y no se envía además la notificación al celular.
          app_open_at: document.visibilityState === 'visible' ? Date.now() : 0,
        });
      } catch {
        // se reintentará en el próximo latido
      }
    };

    // Al conectarse o abrir la app, reportar presencia de inmediato
    if (navigator.geolocation?.getCurrentPosition) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          pushPresence(pos.coords.latitude, pos.coords.longitude);
        },
        () => {
          pushPresence(lastPosRef.current?.lat, lastPosRef.current?.lng);
        },
        { enableHighAccuracy: true, maximumAge: 10000, timeout: 8000 }
      );
    } else {
      pushPresence(lastPosRef.current?.lat, lastPosRef.current?.lng);
    }

    // Latido constante cada 25s para mantener activa la presencia en tiempo real aunque esté quieto
    const heartbeat = setInterval(() => {
      const last = lastPosRef.current;
      pushPresence(last?.lat, last?.lng);
    }, 25000);

    // Al volver a la app se reporta de inmediato; al salir (otra app o pantalla apagada) se quita la marca de "app a la vista".
    const onVisibility = () => {
      const last = lastPosRef.current;
      pushPresence(last?.lat, last?.lng);
    };
    document.addEventListener('visibilitychange', onVisibility);

    try {
      if (navigator.geolocation?.watchPosition) {
        watchId = navigator.geolocation.watchPosition(
          (pos) => {
            const lat = pos.coords.latitude;
            const lng = pos.coords.longitude;
            const now = Date.now();
            const last = lastPosRef.current;
            const moved = !last || haversineMeters(last.lat, last.lng, lat, lng) > 8;
            lastPosRef.current = { lat, lng };
            if (moved) {
              onLocRef.current?.(lat, lng);
            }
            if (moved && now - lastPushRef.current >= 4000) {
              pushPresence(lat, lng);
            }
          },
          () => {},
          { enableHighAccuracy: true, maximumAge: 8000, timeout: 20000 }
        );
      }
    } catch {}

    return () => {
      alive = false;
      clearInterval(heartbeat);
      document.removeEventListener('visibilitychange', onVisibility);
      if (watchId != null && navigator.geolocation?.clearWatch) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, [mobileId, connected]);
}

function haversineMeters(la1, lo1, la2, lo2) {
  const R = 6371000;
  const dLat = ((la2 - la1) * Math.PI) / 180;
  const dLng = ((lo2 - lo1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((la1 * Math.PI) / 180) *
      Math.cos((la2 * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
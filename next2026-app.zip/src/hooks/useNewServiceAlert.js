import { useRef, useEffect } from 'react';
import { getUnlockedAudioContext, showSystemPushNotification } from '@/components/shared/ServiceMessageAlertBanner';

// Conjunto global de IDs de servicios ya alertados en esta sesión para evitar duplicados
// y permitir disparar la alerta en 0ms desde la suscripción en tiempo real.
const alertedServiceIds = new Set();
let lastAlertTimestamp = 0;

// El conductor puede silenciar el tono de los servicios nuevos desde Configuración (la vibración sigue).
const MUTE_KEY = 'next-service-alert-muted';
export function isServiceAlertMuted() {
  try {
    return localStorage.getItem(MUTE_KEY) === '1';
  } catch {
    return false;
  }
}
export function setServiceAlertMuted(muted) {
  try {
    localStorage.setItem(MUTE_KEY, muted ? '1' : '0');
  } catch {}
}

function haversineKm(lat1, lng1, lat2, lng2) {
  if (lat1 == null || lng1 == null || lat2 == null || lng2 == null) return null;
  const R = 6371;
  const dLat = ((Number(lat2) - Number(lat1)) * Math.PI) / 180;
  const dLng = ((Number(lng2) - Number(lng1)) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((Number(lat1) * Math.PI) / 180) *
      Math.cos((Number(lat2) * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// Reproduce de inmediato el tono de alerta ("pin pin pin") + vibración
export function playAlert() {
  const nowMs = Date.now();
  if (nowMs - lastAlertTimestamp < 600) return;
  lastAlertTimestamp = nowMs;

  try {
    const ctx = isServiceAlertMuted() ? null : getUnlockedAudioContext();
    if (ctx) {
      const baseTime = ctx.currentTime;
      for (let i = 0; i < 3; i++) {
        const start = i * 0.22;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.frequency.setValueAtTime(1047, baseTime + start);
        osc.type = 'sine';
        gain.gain.setValueAtTime(0.001, baseTime + start);
        gain.gain.linearRampToValueAtTime(0.38, baseTime + start + 0.012);
        gain.gain.exponentialRampToValueAtTime(0.01, baseTime + start + 0.14);
        osc.start(baseTime + start);
        osc.stop(baseTime + start + 0.15);
      }
    }
  } catch {
    // AudioContext no disponible
  }
  try {
    navigator.vibrate?.([220, 80, 220, 80, 260]);
  } catch {}
}

// Dispara la alerta y notificación push en 0ms para un servicio cercano apenas llega por evento en tiempo real
export function triggerInstantServiceAlert(service, muted = false, driverCoords = null) {
  if (muted || !service?.id) return false;
  if (alertedServiceIds.has(service.id)) return false;

  let distKm = null;
  if (
    driverCoords?.lat != null &&
    driverCoords?.lng != null &&
    service.pickup_lat != null &&
    service.pickup_lng != null
  ) {
    distKm = haversineKm(
      driverCoords.lat,
      driverCoords.lng,
      service.pickup_lat,
      service.pickup_lng
    );
    // Filtrar servicios fuera del radio cercano (5 km)
    if (distKm != null && distKm > 5) {
      return false;
    }
  }

  alertedServiceIds.add(service.id);
  playAlert();

  const fareTxt = service.fare ? `$${Number(service.fare).toLocaleString('es-CO')}` : '';
  const distTxt =
    distKm != null && Number.isFinite(distKm) ? ` · A ${Math.max(0.1, distKm).toFixed(1)} km` : '';
  const vehIcon = service.vehicle_type === 'carro' ? '🚗' : '🛵';

  showSystemPushNotification({
    title: `${vehIcon} ¡Nuevo servicio cerca! ${fareTxt}${distTxt}`.trim(),
    body: `${service.pickup_address || 'Recogida'} → ${service.destination_address || 'Destino'}`,
    tag: `next-svc-${service.id}`,
    vibrate: [240, 80, 240, 80, 300],
  });

  return true;
}

export function markInitialServiceIdsSeen(services = []) {
  (services || []).forEach((s) => {
    if (s?.id) alertedServiceIds.add(s.id);
  });
}

// Hook: detecta al instante cualquier nuevo ID de servicio disponible (o aumento de contador)
// y dispara sonido + vibración en 0ms.
export function useNewServiceAlert(countOrList, loading, muted) {
  const prevCount = useRef(null);
  const initializedRef = useRef(false);

  const list = Array.isArray(countOrList) ? countOrList : null;
  const count = list ? list.length : Number(countOrList || 0);
  const idsKey = list ? list.map((s) => s?.id).filter(Boolean).join(',') : String(count);

  useEffect(() => {
    if (loading) return;

    if (!initializedRef.current) {
      initializedRef.current = true;
      if (list) {
        markInitialServiceIdsSeen(list);
      }
      prevCount.current = count;
      return;
    }

    if (muted) {
      if (list) markInitialServiceIdsSeen(list);
      prevCount.current = count;
      return;
    }

    if (list) {
      const unseen = list.filter((s) => s?.id && !alertedServiceIds.has(s.id));
      if (unseen.length > 0) {
        unseen.forEach((s) => alertedServiceIds.add(s.id));
        playAlert();
      }
    } else if (prevCount.current !== null && count > prevCount.current) {
      playAlert();
    }

    prevCount.current = count;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [idsKey, loading, muted]);
}
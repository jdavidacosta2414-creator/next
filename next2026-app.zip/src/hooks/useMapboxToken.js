import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';

export const DEFAULT_MAPBOX_TOKEN =
  'pk.eyJ1IjoiamVzdXMxNTI0IiwiYSI6ImNtdngyeHY5aDA0c2ozMHBwemtzeG9lODYifQ.Z6gdehNB3sLWvauvUieoLQ';

const TOKEN_CACHE_KEY = 'next_mapbox_token_v1';
let cachedToken = (() => {
  try {
    return (typeof window !== 'undefined' && window.localStorage.getItem(TOKEN_CACHE_KEY)) || DEFAULT_MAPBOX_TOKEN;
  } catch {
    return DEFAULT_MAPBOX_TOKEN;
  }
})();
let fetchPromise = null;

export function getGoogleApiKey() {
  return null;
}

// Hook que devuelve el token público de Mapbox al instante en 0ms sin bloquear datos móviles
export function useMapboxToken() {
  const [token, setToken] = useState(cachedToken);

  useEffect(() => {
    let mounted = true;

    const timer = setTimeout(() => {
      if (!fetchPromise) {
        fetchPromise = base44.functions
          .invoke('getMapboxToken', {})
          .then((res) => {
            if (res.data?.mapboxToken) {
              cachedToken = res.data.mapboxToken;
              try {
                window.localStorage.setItem(TOKEN_CACHE_KEY, cachedToken);
              } catch {}
            }
            return cachedToken;
          })
          .catch(() => cachedToken);
      }

      fetchPromise.then((t) => {
        if (mounted && t && t !== token) setToken(t);
      });
    }, 5000);

    return () => {
      mounted = false;
      clearTimeout(timer);
    };
  }, []);

  return token;
}
import { useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { getStoredDismissedNotifs } from '@/components/pasajero/PasajeroNotificaciones';
import { syncMyReferralCodeOwner } from '@/lib/referrals';
import { preloadStorageUrls } from '@/components/shared/ResolvedAvatar';
import { pickActiveDriverProfile } from '@/lib/driverProfiles';

const fmtCOP = (n) => '$' + Number(n || 0).toLocaleString('es-CO');

export function usePassengerBackgroundSync({
  user,
  checkUserAuth,
  mobileProfile,
  setMobileProfile,
  notifCount,
  setNotifCount,
  showNotif,
  setPendingClientRating,
  setForm,
  setRecentServices,
  toast,
}) {
  const notifiedTransfersRef = useRef(new Set());
  const notifiedApprovedPtsRef = useRef(new Set());

  useEffect(() => {
    const syncBadge = () => {
      const dismissed = getStoredDismissedNotifs(user);
      if (dismissed.includes('welcome') && notifCount === 1 && !showNotif) {
        setNotifCount(0);
      }
    };
    syncBadge();
    window.addEventListener('next-notifs-updated', syncBadge);
    return () => window.removeEventListener('next-notifs-updated', syncBadge);
  }, [user, notifCount, showNotif, setNotifCount]);

  useEffect(() => {
    if (!user) return;
    setForm((f) => ({
      ...f,
      client_name: f.client_name || user.display_name || mobileProfile?.name || user.full_name || '',
      client_phone: f.client_phone || user.phone || mobileProfile?.phone || '',
    }));
  }, [user, mobileProfile, setForm]);

  useEffect(() => {
    if (user?.photo_url) preloadStorageUrls([user.photo_url]);
  }, [user?.photo_url]);

  // Diferir consultas secundarias para que el mapa y el buscador de ruta carguen de inmediato sin bloqueo
  useEffect(() => {
    const timer = setTimeout(() => {
      base44.entities.Service.filter(
        { status: 'finalizado' },
        {
          sort: '-created_date',
          limit: 30,
          fields: ['vehicle_type', 'fare', 'pickup_lat', 'pickup_lng', 'destination_lat', 'destination_lng'],
        }
      )
        .then((res) => setRecentServices(res?.items || (Array.isArray(res) ? res : [])))
        .catch(() => {});
    }, 1200);
    return () => clearTimeout(timer);
  }, [setRecentServices]);

  useEffect(() => {
    if (!user?.id) return;
    const t = setTimeout(() => {
      syncMyReferralCodeOwner({ user, mobile: mobileProfile }).catch(() => {});
    }, 1500);
    return () => clearTimeout(t);
  }, [user, mobileProfile]);

  useEffect(() => {
    if (!user?.id) return;
    let initialized = false;
    let unsub = null;
    const checkApprovedPoints = async () => {
      try {
        const page = await base44.entities.PointsTransaction.filter(
          {
            user_id: user.id,
            status: 'aprobado',
            type: { $in: ['compra_confirmada', 'referido_aprobado'] },
          },
          { sort: '-created_date', limit: 20 }
        );
        const list = (page?.items || []).filter((t) => Number(t.amount) > 0);
        const dismissed = getStoredDismissedNotifs(user);
        const unreadApproved = list.filter((t) => !dismissed.includes(`points-tx-${t.id}-aprobado`)).length;
        const welcomeUnread = dismissed.includes('welcome') ? 0 : 1;
        setNotifCount((prev) => Math.max(prev, unreadApproved + welcomeUnread));

        if (initialized) {
          list.forEach((tx) => {
            if (!notifiedApprovedPtsRef.current.has(tx.id)) {
              if (tx.type === 'referido_aprobado') {
                toast({
                  title: `¡Ganaste +${tx.amount} puntos por referido! 🤝`,
                  description: `Central aprobó tu referido${tx.referred_user_name ? ` (${tx.referred_user_name})` : ''} y acreditó +${tx.amount} puntos a tu cuenta.`,
                });
              } else {
                toast({
                  title: `¡Central aprobó tus +${tx.amount} puntos! 🎉`,
                  description: `Se acreditaron +${tx.amount} puntos por tu compra en ${tx.business_name || 'nuestro anunciante aliado'}.`,
                });
              }
            }
          });
        }
        notifiedApprovedPtsRef.current = new Set(list.map((t) => t.id));
        initialized = true;
      } catch {}
    };
    const timer = setTimeout(() => {
      checkApprovedPoints();
      unsub = base44.entities.PointsTransaction.subscribe(() => checkApprovedPoints().catch(() => {}));
    }, 1400);
    return () => {
      clearTimeout(timer);
      if (typeof unsub === 'function') unsub();
    };
  }, [user?.id]);

  useEffect(() => {
    if (!user?.id) return;
    let initialized = false;
    let unsub = null;
    const checkTransfers = async () => {
      try {
        const page = await base44.entities.PassengerWalletTx.filter(
          { user_id: user.id, type: 'retiro', status: 'transferido' },
          { sort: '-created_date', limit: 10 }
        );
        const list = page.items || [];
        if (initialized) {
          list.forEach((tx) => {
            if (!notifiedTransfersRef.current.has(tx.id)) {
              toast({
                title: '¡Tus puntos han sido redimidos! 💸',
                description: `Verifica la transferencia de ${fmtCOP(tx.amount)} en tu cuenta ${tx.bank_type || ''} (${tx.account_number || ''}). Tu billetera quedó en $0.`,
              });
            }
          });
        }
        notifiedTransfersRef.current = new Set(list.map((t) => t.id));
        initialized = true;
      } catch {}
    };
    const timer = setTimeout(() => {
      checkTransfers();
      unsub = base44.entities.PassengerWalletTx.subscribe(() => checkTransfers().catch(() => {}));
    }, 1600);
    return () => {
      clearTimeout(timer);
      if (typeof unsub === 'function') unsub();
    };
  }, [user?.id]);

  useEffect(() => {
    if (!user?.id) return;
    let unsub = null;
    const checkUnratedTrip = async () => {
      try {
        const list = await base44.entities.Service.filter(
          { created_by_id: user.id, status: 'finalizado' },
          '-created_date',
          3
        );
        const items = list?.items || list || [];
        const thirtyMinAgo = Date.now() - 30 * 60 * 1000;
        const unrated = items.find((s) => {
          const ts = new Date(s.updated_date || s.created_date || 0).getTime();
          return (
            s.rating == null &&
            s.mobile_id &&
            ts >= thirtyMinAgo &&
            !localStorage.getItem(`next_dismissed_rating_${s.id}`)
          );
        });
        setPendingClientRating(unrated || null);
      } catch {}
    };
    const timer = setTimeout(() => {
      checkUnratedTrip();
      unsub = base44.entities.Service.subscribe(() => checkUnratedTrip().catch(() => {}));
    }, 1800);
    return () => {
      clearTimeout(timer);
      if (typeof unsub === 'function') unsub();
    };
  }, [user?.id, setPendingClientRating]);

  useEffect(() => {
    if (!user?.email) return;
    let active = true;
    const timer = setTimeout(() => {
      base44.entities.Mobile.filter({ email: user.email })
        .then(async (res) => {
          const list = res?.items || (Array.isArray(res) ? res : []);
          const mob = pickActiveDriverProfile(list);
          if (!active || !mob) return;
          setMobileProfile(mob);
          try {
            window.localStorage.setItem('next_cached_mobile_v1', JSON.stringify(mob));
          } catch {}
          if (mob.photo_url) preloadStorageUrls([mob.photo_url]);
          const userPatch = {};
          const mobPhoto = mob.photo_url || '';
          if (!user.photo_url && mobPhoto) userPatch.photo_url = mobPhoto;
          if (!user.display_name && mob.name) userPatch.display_name = mob.name;
          if (!user.phone && mob.phone) userPatch.phone = mob.phone;
          if (!user.cedula && mob.cedula) userPatch.cedula = mob.cedula;
          if (Object.keys(userPatch).length > 0) {
            try {
              await base44.auth.updateMe(userPatch);
              await checkUserAuth?.();
            } catch {}
          } else if (!mob.photo_url && user.photo_url) {
            try {
              const updatedMob = await base44.entities.Mobile.update(mob.id, { photo_url: user.photo_url });
              if (active) setMobileProfile(updatedMob);
            } catch {}
          }
        })
        .catch(() => {});
    }, 900);
    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [user?.email]);
}
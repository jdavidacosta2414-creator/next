import { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';

const ACTIVE_STATUSES = ['pendiente', 'asignado', 'en_camino', 'recogida'];
const TEN_MIN_MS = 10 * 60 * 1000;

function parseUtcMs(val) {
  if (!val) return 0;
  const raw = String(val).trim();
  const iso = /([zZ]|[+-]\d{2}:?\d{2})$/.test(raw) ? raw : `${raw.replace(' ', 'T')}Z`;
  const ms = new Date(iso).getTime();
  return Number.isFinite(ms) ? ms : 0;
}

function getPendingStartMs(s) {
  if (!s) return 0;
  const createdMs = parseUtcMs(s.created_date);
  const updatedMs = parseUtcMs(s.updated_date);
  if (s.cancelled_by === 'conductor' && updatedMs > createdMs) {
    return updatedMs;
  }
  return createdMs;
}

export function usePassengerActiveService({
  user,
  searchParams,
  setSearchParams,
  setStep,
  toast,
  onServiceEnded,
}) {
  const [buscandoId, setBuscandoId] = useState(
    () => searchParams.get('service') || localStorage.getItem('next_active_service_id') || null
  );
  const [activeService, setActiveService] = useState(null);
  const backedOutRef = useRef(false);
  const expiredNotifiedIdsRef = useRef(new Set());
  const endedServiceIdsRef = useRef(new Set());
  const prevStatusByServiceRef = useRef({});
  const notifiedDriverCancelRef = useRef(new Set());
  const onServiceEndedRef = useRef(onServiceEnded);
  onServiceEndedRef.current = onServiceEnded;

  const notifyDriverCancelledAndReassigning = (svc) => {
    if (!svc?.id) return;
    const storageFlag = `next_driver_cancel_notified_${svc.id}`;
    if (notifiedDriverCancelRef.current.has(svc.id) || localStorage.getItem(storageFlag) === '1') {
      return;
    }
    notifiedDriverCancelRef.current.add(svc.id);
    try {
      localStorage.setItem(storageFlag, '1');
    } catch {}
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        const ctx = new AudioCtx();
        [523.25, 392.0, 659.25].forEach((freq, i) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.value = freq;
          gain.gain.setValueAtTime(0.001, ctx.currentTime + i * 0.14);
          gain.gain.exponentialRampToValueAtTime(0.24, ctx.currentTime + i * 0.14 + 0.03);
          gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.14 + 0.22);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(ctx.currentTime + i * 0.14);
          osc.stop(ctx.currentTime + i * 0.14 + 0.24);
        });
      }
    } catch {}
    try {
      navigator.vibrate?.([280, 120, 280]);
    } catch {}
    try {
      const raw = localStorage.getItem('next_arrival_notifs_v1');
      const list = raw ? JSON.parse(raw) || [] : [];
      const notifId = `driver-cancelled-${svc.id}`;
      if (!list.some((n) => n.id === notifId)) {
        list.unshift({
          id: notifId,
          service_id: svc.id,
          title: '⚠️ El conductor canceló el servicio',
          body: svc.client_cancel_detail || 'El conductor canceló el servicio. Estamos buscando otro conductor cercano para ti.',
          date: new Date().toISOString(),
        });
        localStorage.setItem('next_arrival_notifs_v1', JSON.stringify(list.slice(0, 25)));
        window.dispatchEvent(new CustomEvent('next-notifs-updated'));
      }
    } catch {}
    toast({
      title: '⚠️ El conductor canceló el servicio',
      description: 'Estamos buscando a otro conductor cercano para atender tu solicitud.',
      variant: 'destructive',
    });
  };

  const clearActiveService = (endedId = null) => {
    const idToIgnore = endedId || buscandoId || activeService?.id || localStorage.getItem('next_active_service_id');
    if (idToIgnore) {
      endedServiceIdsRef.current.add(idToIgnore);
    }
    localStorage.removeItem('next_active_service_id');
    setActiveService(null);
    setBuscandoId(null);
    setSearchParams({});
  };

  const notifyAndExpireService = (svc) => {
    if (!svc?.id || expiredNotifiedIdsRef.current.has(svc.id)) return;
    const currentTrackedId = buscandoId || activeService?.id || localStorage.getItem('next_active_service_id');
    if (currentTrackedId && svc.id !== currentTrackedId) return;

    expiredNotifiedIdsRef.current.add(svc.id);
    localStorage.setItem(`next_expired_notified_${svc.id}`, '1');
    if (localStorage.getItem('next_active_service_id') === svc.id) {
      localStorage.removeItem('next_active_service_id');
    }
    if (svc.status === 'pendiente') {
      base44.entities.Service.update(svc.id, {
        status: 'cancelado',
        cancel_reason: 'sin_conductor',
        client_cancel_detail: 'Eliminado automáticamente después de 10 minutos sin conductor.',
      }).catch(() => {});
    }
    setActiveService((prev) => (prev?.id === svc.id ? null : prev));
    setBuscandoId((prev) => (prev === svc.id ? null : prev));
    setStep((prev) => (prev === 'buscando' ? 'home' : prev));
    setSearchParams({});
    onServiceEndedRef.current?.();
    toast({
      title: 'Solicitud eliminada (10 min)',
      description:
        'Pasaron 10 minutos buscando conductor y nadie tomó el servicio. Fue eliminado automáticamente.',
    });
  };

  const svcQueryParam = searchParams.get('service') || '';

  useEffect(() => {
    let cancelled = false;

    const handleServiceRecord = (s) => {
      if (cancelled) return;
      if (!s || endedServiceIdsRef.current.has(s.id)) {
        return;
      }

      const currentTrackedId =
        svcQueryParam || buscandoId || localStorage.getItem('next_active_service_id');
      if (currentTrackedId && s.id !== currentTrackedId) {
        return;
      }

      if (s.status === 'pendiente') {
        const startMs = getPendingStartMs(s);
        if (startMs > 0) {
          const age = Date.now() - startMs;
          if (age >= TEN_MIN_MS) {
            notifyAndExpireService(s);
            return;
          }
        }
      }

      if (
        s.status === 'cancelado' &&
        s.cancel_reason === 'sin_conductor' &&
        !localStorage.getItem(`next_expired_notified_${s.id}`)
      ) {
        notifyAndExpireService(s);
        return;
      }

      if (ACTIVE_STATUSES.includes(s.status)) {
        const prevStatus = prevStatusByServiceRef.current[s.id];
        if (['asignado', 'en_camino', 'recogida'].includes(s.status)) {
          notifiedDriverCancelRef.current.delete(s.id);
          try {
            localStorage.removeItem(`next_driver_cancel_notified_${s.id}`);
          } catch {}
        } else if (
          s.status === 'pendiente' &&
          (['asignado', 'en_camino', 'recogida'].includes(prevStatus) || s.cancelled_by === 'conductor')
        ) {
          backedOutRef.current = false;
          notifyDriverCancelledAndReassigning(s);
        }
        prevStatusByServiceRef.current[s.id] = s.status;
        localStorage.setItem('next_active_service_id', s.id);
        setBuscandoId((prev) => (prev === s.id ? prev : s.id));
        setActiveService((prev) => (prev && prev.id === s.id ? { ...prev, ...s } : s));
        if (!backedOutRef.current) {
          setStep(s.status === 'pendiente' ? 'buscando' : 'seguimiento');
        }
      } else {
        endedServiceIdsRef.current.add(s.id);
        const wasTrackingThis =
          buscandoId === s.id ||
          activeService?.id === s.id ||
          localStorage.getItem('next_active_service_id') === s.id;
        if (localStorage.getItem('next_active_service_id') === s.id) {
          localStorage.removeItem('next_active_service_id');
        }
        if (wasTrackingThis) {
          setActiveService(null);
          setBuscandoId(null);
          setStep('home');
          onServiceEndedRef.current?.();
        }
      }
    };

    const syncActiveService = async () => {
      const storedId = localStorage.getItem('next_active_service_id');
      const targetId = svcQueryParam || buscandoId || storedId;

      try {
        let s = null;
        if (targetId && !endedServiceIdsRef.current.has(targetId)) {
          s = await base44.entities.Service.get(targetId).catch(() => null);
        }
        if (!s && user?.id && !targetId) {
          const res = await base44.entities.Service.filter(
            {
              created_by_id: user.id,
              status: { $in: ACTIVE_STATUSES },
            },
            { sort: '-created_date', limit: 1 }
          ).catch(() => ({ items: [] }));
          const list = res?.items || (Array.isArray(res) ? res : []);
          s = list[0] || null;
        }
        if (s) handleServiceRecord(s);
      } catch {}
    };

    syncActiveService();
    const unsub = base44.entities.Service.subscribe((ev) => {
      const id = ev?.id || ev?.data?.id;
      const trackedId = svcQueryParam || buscandoId || localStorage.getItem('next_active_service_id');
      if (trackedId) {
        if (id === trackedId) {
          if (ev?.data) {
            handleServiceRecord(ev.data);
          } else {
            syncActiveService();
          }
        }
        return;
      }
      const isMine = user?.id && ev?.data?.created_by_id === user.id;
      if (id && isMine && ACTIVE_STATUSES.includes(ev?.data?.status)) {
        handleServiceRecord(ev.data);
      }
    });
    const onVisible = () => {
      if (typeof document !== 'undefined' && document.visibilityState === 'visible') {
        syncActiveService();
      }
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      cancelled = true;
      unsub();
      document.removeEventListener('visibilitychange', onVisible);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [svcQueryParam, user?.id, buscandoId]);

  useEffect(() => {
    if (!activeService || activeService.status !== 'pendiente') return;
    const startMs = getPendingStartMs(activeService);
    if (!startMs) return;
    const expiresAt = startMs + TEN_MIN_MS;
    const remaining = expiresAt - Date.now();
    if (remaining <= 0) return;
    const timer = setTimeout(() => {
      notifyAndExpireService(activeService);
    }, remaining);
    return () => clearTimeout(timer);
  }, [activeService?.id, activeService?.status, activeService?.created_date, activeService?.updated_date]);

  return {
    buscandoId,
    setBuscandoId,
    activeService,
    setActiveService,
    backedOutRef,
    clearActiveService,
  };
}
import { useLayoutEffect, useRef } from 'react';
import createBackNavigationHistory from '@/lib/backNavigationHistory';
import bindNativeBackNavigation from '@/lib/nativeBackNavigation';
import { logBack, setBackDiagProvider } from '@/lib/backDiagnostics';

const handlers = [];
let historyNavigation = null;
let removeNativeListeners = null;
let fallbackBackHandler = null;
let pendingAction = null;

export function setFallbackBackHandler(handler) {
  fallbackBackHandler = typeof handler === 'function' ? handler : null;
}

setBackDiagProvider('registro_interno', () => ({
  manejadores: handlers.length,
  accion_pendiente: Boolean(pendingAction),
  respaldo_rutas: Boolean(fallbackBackHandler),
}));

export function executeTopBackHandler() {
  if (pendingAction) {
    logBack('BLOQUEADO', 'acción anterior aún pendiente');
    return true;
  }
  const ordered = [...handlers].sort((a, b) => b.priority - a.priority || b.order - a.order);
  const callbacks = ordered.map((entry) => entry.run);
  if (fallbackBackHandler) callbacks.push(fallbackBackHandler);
  for (let i = 0; i < callbacks.length; i += 1) {
    const result = callbacks[i]();
    if (result === false) continue;
    const isFallback = fallbackBackHandler && i === callbacks.length - 1;
    logBack('manejador', `${isFallback ? 'respaldo de ruta' : `#${i + 1} de ${handlers.length}`} → ${String(result)}`);
    if (result && typeof result.then === 'function') {
      logBack('acción pendiente', 'inicia');
      pendingAction = Promise.resolve(result).finally(() => {
        pendingAction = null;
        logBack('acción pendiente', 'terminó');
      });
    }
    return true;
  }
  logBack('manejador', 'ninguno lo manejó');
  return false;
}

export function initGlobalBackManager() {
  if (typeof window === 'undefined' || historyNavigation) return;
  historyNavigation = createBackNavigationHistory(window, executeTopBackHandler);
  removeNativeListeners = bindNativeBackNavigation(
    window,
    () => historyNavigation.handleNativeBack(),
    (enabled) => historyNavigation.setNativeSource(enabled)
  );
}

export function syncBackRoute() {
  initGlobalBackManager();
  historyNavigation?.syncRoute();
}

let registrationOrder = 0;

// Los paneles base usan prioridad menor; las ventanas abiertas se cierran primero.
export function useBackButton(onBack, enabled = true, { priority = 0 } = {}) {
  const callbackRef = useRef(onBack);
  callbackRef.current = onBack;

  useLayoutEffect(() => {
    if (!enabled || typeof window === 'undefined') return;
    initGlobalBackManager();
    const entry = {
      priority,
      order: ++registrationOrder,
      run: () => typeof callbackRef.current === 'function' ? callbackRef.current() : false,
    };
    handlers.push(entry);
    return () => {
      const index = handlers.indexOf(entry);
      if (index !== -1) handlers.splice(index, 1);
    };
  }, [enabled, priority]);
}

if (import.meta.hot) {
  import.meta.hot.dispose(() => {
    historyNavigation?.dispose();
    removeNativeListeners?.();
    historyNavigation = null;
    fallbackBackHandler = null;
    handlers.length = 0;
  });
}
import React, { useState, useEffect } from 'react';
import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate, useLocation, useNavigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import { ThemeProvider } from '@/lib/ThemeContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import ProtectedRoute from '@/components/ProtectedRoute';
import Welcome from '@/pages/Welcome';
import Splash from '@/pages/Splash';
import SplashImage from '@/components/SplashImage';
import RoleRoute from '@/components/RoleRoute';
import ErrorBoundary from '@/components/ErrorBoundary';
import { initGlobalBackManager, setFallbackBackHandler, syncBackRoute } from '@/hooks/useBackButton';
import { syncBootSplash } from '@/lib/bootSplash';

// Carga perezosa (lazy load) de paneles pesados para ahorrar datos móviles al iniciar la app
const RegisterEntry = React.lazy(() => import('@/pages/RegisterEntry'));
const ForgotPassword = React.lazy(() => import('@/pages/ForgotPassword'));
const ResetPassword = React.lazy(() => import('@/pages/ResetPassword'));
const Vinculate = React.lazy(() => import('@/pages/Vinculate'));
const VinculatePasajero = React.lazy(() => import('@/pages/VinculatePasajero'));
const VinculateConductor = React.lazy(() => import('@/pages/VinculateConductor'));
const CentralPanel = React.lazy(() => import('@/pages/CentralPanel'));
const AdminPanel = React.lazy(() => import('@/pages/AdminPanel'));
const AdminLogin = React.lazy(() => import('@/pages/AdminLogin'));
const CentralLogin = React.lazy(() => import('@/pages/CentralLogin'));
const PasajeroPanel = React.lazy(() => import('@/pages/PasajeroPanel'));
const MovilPanel = React.lazy(() => import('@/pages/MovilPanel'));
const Seguimiento = React.lazy(() => import('@/pages/Seguimiento'));

initGlobalBackManager();

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, user } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  // Preparar el gesto únicamente al navegar, nunca por cada toque ni cambio de usuario.
  useEffect(() => {
    if (location.pathname !== '/') syncBackRoute();
  }, [location.pathname, location.search, location.hash, location.key]);

  useEffect(() => {
    setFallbackBackHandler(() => {
      const p = window.location.pathname;
      if (p === '/vinculate/conductor' || p === '/vinculate/pasajero') {
        navigate(user ? '/cliente' : '/vinculate');
        return true;
      }
      if (p === '/vinculate') {
        navigate('/registro');
        return true;
      }
      if (p === '/login' || p === '/admin/login' || p === '/central/login') {
        navigate('/registro');
        return true;
      }
      if (p === '/forgot-password' || p === '/reset-password') {
        navigate('/login');
        return true;
      }
      // En las pantallas raíz de Pasajero (/cliente) y Conductor (/movil), bloquear que el botón físico "Atrás"
      // cambie de modo por accidente o saque al usuario de su modo actual.
      if (p === '/cliente' || p === '/movil' || p === '/central' || p === '/admin') {
        return true;
      }
      return false;
    });
    return () => setFallbackBackHandler(null);
  }, [navigate, user]);

  // La imagen de apertura de index.html sigue en pantalla solo mientras alguna vista la mantenga (SplashImage)
  useEffect(() => {
    syncBootSplash();
  }, []);

  // Mientras carga la sesión inicial, mostrar directamente la pantalla Splash a pantalla completa
  if (isLoadingPublicSettings || isLoadingAuth) {
    return <SplashImage />;
  }

  // Handle authentication errors
  if (authError && authError.type === 'user_not_registered') {
    return <UserNotRegisteredError />;
  }

  const isSplashRoute = location.pathname === '/';

  // En la ruta "/" se muestra la imagen de apertura a pantalla completa sin barras;
  // en el resto de la aplicación se respeta el margen superior seguro para la barra de estado del celular (APK).
  if (isSplashRoute) {
    return (
      <ErrorBoundary>
        <Routes>
          <Route path="/" element={<Splash />} />
        </Routes>
      </ErrorBoundary>
    );
  }

  return (
    <ErrorBoundary>
      <div className="apk-status-bar-strip" aria-hidden="true" />
      <div className="apk-safe-shell" data-testid="apk-safe-shell">
        <div id="apk-scroll-container" className="apk-safe-scroll">
          <React.Suspense fallback={<SplashImage />}>
            <Routes>
              <Route path="/" element={<Splash />} />
              <Route path="/registro" element={<RegisterEntry />} />
              <Route path="/vinculate" element={<Vinculate />} />
              <Route path="/vinculate/pasajero" element={<VinculatePasajero />} />
              <Route path="/vinculate/conductor" element={<VinculateConductor />} />
              <Route path="/login" element={<Welcome />} />
              <Route path="/admin/login" element={<AdminLogin />} />
              <Route path="/central/login" element={<CentralLogin />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route path="/reset-password" element={<ResetPassword />} />
              <Route path="/seguimiento/:id/:token" element={<Seguimiento />} />
              <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/" replace />} />}>
                <Route path="/central" element={<RoleRoute allowedRoles={['central', 'superadmin', 'admin']}><CentralPanel /></RoleRoute>} />
                <Route path="/admin" element={<RoleRoute allowedRoles={['admin', 'superadmin']}><AdminPanel /></RoleRoute>} />
                <Route path="/movil" element={<RoleRoute allowedRoles={['movil', 'user', 'cliente', 'admin', 'superadmin']}><MovilPanel /></RoleRoute>} />
                <Route path="/cliente" element={<RoleRoute allowedRoles={['movil', 'user', 'cliente', 'admin', 'superadmin']}><PasajeroPanel /></RoleRoute>} />
              </Route>
              <Route path="*" element={<PageNotFound />} />
            </Routes>
          </React.Suspense>
        </div>
      </div>
    </ErrorBoundary>
  );
};


function App() {
  useEffect(() => {
    initGlobalBackManager();
  }, []);

  // Sincronizar la altura real visible del WebView (--app-vh) en todos los tamaños de celular (pequeños, medianos y grandes)
  useEffect(() => {
    if (typeof window === 'undefined' || typeof document === 'undefined') return;
    let maxSeenHeight = window.innerHeight || 0;
    const root = document.documentElement;
    const vv = window.visualViewport;
    const syncViewportHeight = () => {
      const inner = window.innerHeight || root.clientHeight || 0;
      const h = vv?.height ? Math.min(inner, Math.round(vv.height)) : inner;
      if (!h) return;
      // Si el cambio es por apertura del teclado virtual (>140px menos), conservar la altura base de la pantalla
      // y reservar el espacio del teclado (--keyboard-inset) para que los campos de texto nunca queden tapados.
      if (h > maxSeenHeight || maxSeenHeight - h < 140) {
        maxSeenHeight = h;
        root.style.setProperty('--app-vh', `${h}px`);
        root.style.setProperty('--keyboard-inset', '0px');
        root.classList.remove('keyboard-open');
      } else {
        root.style.setProperty('--keyboard-inset', `${maxSeenHeight - h}px`);
        root.classList.add('keyboard-open');
        const el = document.activeElement;
        if (el && /^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName)) {
          setTimeout(() => el.scrollIntoView({ block: 'center', behavior: 'smooth' }), 60);
        }
      }
    };
    // Al enfocar un campo, desplazarlo a la zona visible una vez abierto el teclado
    const onFocusIn = (e) => {
      const el = e.target;
      if (!el || !/^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName)) return;
      setTimeout(() => {
        syncViewportHeight();
        el.scrollIntoView({ block: 'center', behavior: 'smooth' });
      }, 350);
    };
    syncViewportHeight();
    window.addEventListener('resize', syncViewportHeight);
    vv?.addEventListener('resize', syncViewportHeight);
    document.addEventListener('focusin', onFocusIn);
    window.addEventListener('orientationchange', () => {
      maxSeenHeight = 0;
      setTimeout(syncViewportHeight, 120);
    });
    return () => {
      window.removeEventListener('resize', syncViewportHeight);
      vv?.removeEventListener('resize', syncViewportHeight);
      document.removeEventListener('focusin', onFocusIn);
    };
  }, []);

  return (
    <ThemeProvider>
      <AuthProvider>
        <QueryClientProvider client={queryClientInstance}>
          <Router>
            <ScrollToTop />
            <AuthenticatedApp />
          </Router>
          <Toaster />
        </QueryClientProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
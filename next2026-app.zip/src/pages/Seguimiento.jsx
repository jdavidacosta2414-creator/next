import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Loader2, CheckCircle2, XCircle, Clock, Bike } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import SeguimientoMapa from '@/components/seguimiento/SeguimientoMapa';
import SeguimientoPasos from '@/components/seguimiento/SeguimientoPasos';

const CLOSED = ['finalizado', 'cancelado', 'rechazado'];

function Mensaje({ icon: Icon, title, text }) {
  return (
    <div className="h-[100dvh] bg-background flex flex-col items-center justify-center text-center px-6">
      <Icon className="w-12 h-12 text-primary mb-3" />
      <h1 className="font-heading text-lg font-bold text-foreground">{title}</h1>
      <p className="text-sm text-muted-foreground mt-1 max-w-xs">{text}</p>
    </div>
  );
}

// Enlace público de seguimiento de un pedido de NEXT Negocios (sin cuenta ni menús de NEXT).
export default function Seguimiento() {
  const { id, token } = useParams();
  const [order, setOrder] = useState(null);
  const [problem, setProblem] = useState(null);
  const [route, setRoute] = useState(null);
  const closed = Boolean(order && CLOSED.includes(order.status));

  useEffect(() => {
    if (problem || closed) return;
    let alive = true;
    const load = async () => {
      try {
        const res = await base44.functions.invoke('negociosApi', { action: 'track', order_id: id, token });
        if (alive) setOrder(res.data);
      } catch (e) {
        const status = e?.response?.status;
        if (alive && status === 404) setProblem('not_found');
        if (alive && status === 410) setProblem('expired');
      }
    };
    load();
    const timer = setInterval(load, 8000);
    return () => {
      alive = false;
      clearInterval(timer);
    };
  }, [id, token, problem, closed]);

  useEffect(() => {
    if (problem !== 'not_found') return;
    const meta = document.createElement('meta');
    meta.name = 'prerender-status-code';
    meta.content = '404';
    document.head.appendChild(meta);
    return () => meta.remove();
  }, [problem]);

  if (problem === 'not_found') {
    return <Mensaje icon={XCircle} title="Enlace no válido" text="Revisa el enlace de seguimiento que te compartió el comercio." />;
  }
  if (problem === 'expired') {
    return <Mensaje icon={Clock} title="Este enlace ya caducó" text="El seguimiento de este pedido ya no está disponible." />;
  }
  if (!order) {
    return (
      <div className="h-[100dvh] bg-background flex items-center justify-center">
        <Loader2 className="w-7 h-7 animate-spin text-primary" />
      </div>
    );
  }
  if (order.status === 'finalizado') {
    return <Mensaje icon={CheckCircle2} title="Pedido entregado" text={`Tu pedido${order.business_name ? ` de ${order.business_name}` : ''} fue entregado. ¡Gracias!`} />;
  }
  if (closed) {
    return <Mensaje icon={XCircle} title="Pedido cancelado" text="Este pedido fue cancelado. Comunícate con el comercio para más información." />;
  }

  const etaMin = order.courier_location && route?.durationMin ? Math.max(1, Math.round(route.durationMin)) : null;

  return (
    <div className="h-[100dvh] bg-background flex flex-col">
      <header className="px-4 py-3 bg-card border-b border-border flex items-center justify-between">
        <span className="font-heading font-extrabold text-primary tracking-wide">NEXT</span>
        <span className="text-xs text-muted-foreground truncate ml-3">{order.business_name}</span>
      </header>

      <div className="flex-1 min-h-0">
        <SeguimientoMapa order={order} onRouteInfo={setRoute} />
      </div>

      <section className="bg-card border-t border-border rounded-t-3xl -mt-4 relative z-10 p-4 space-y-3 pb-[calc(1rem+env(safe-area-inset-bottom))]">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs text-muted-foreground">Estado del pedido</p>
            <p className="font-heading text-base font-bold text-foreground leading-tight">{order.status_label}</p>
          </div>
          {etaMin != null && (
            <div className="text-right flex-shrink-0">
              <p className="text-xs text-muted-foreground">{order.status === 'recogida' ? 'Llega en' : 'Recoge en'}</p>
              <p className="font-heading text-2xl font-extrabold text-primary leading-none">{etaMin} min</p>
            </div>
          )}
        </div>

        {order.courier && (
          <div className="flex items-center gap-2.5 rounded-2xl bg-muted px-3 py-2">
            <Bike className="w-5 h-5 text-primary flex-shrink-0" />
            <p className="text-sm text-foreground font-semibold truncate">
              {order.courier.name}
              {order.courier.plate ? ` · ${order.courier.plate}` : ''}
            </p>
          </div>
        )}

        <SeguimientoPasos status={order.status} />
        <p className="text-xs text-muted-foreground truncate">Entrega: {order.destination?.address}</p>
      </section>
    </div>
  );
}
import React, { useState } from 'react';
import { Navigate, useNavigate, Link } from 'react-router-dom';
import { Menu, X, UserPlus, CreditCard, Share2, FileText, Mail, Lock, Eye, EyeOff, ArrowRight, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { getHomeForRole } from '@/lib/roles';
import { toast } from '@/components/ui/use-toast';
import ThemeToggle from '@/components/ThemeToggle';
import OtpVerificationCard from '@/components/shared/OtpVerificationCard';
import { useBackButton } from '@/hooks/useBackButton';

const inputCls = 'w-full bg-white/5 border border-white/10 rounded-full pl-12 pr-4 h-14 text-white placeholder:text-[#5A6478] focus:outline-none focus:border-[#00E5FF]/60 transition-colors text-sm';

export default function Welcome() {
  const navigate = useNavigate();
  const { user, isAuthenticated, checkUserAuth } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);

  useBackButton(() => {
    if (menuOpen) {
      setMenuOpen(false);
      return true;
    }
    navigate('/registro');
    return true;
  }, true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [pendingOtp, setPendingOtp] = useState(false);
  const [otpCode, setOtpCode] = useState('');

  if (isAuthenticated && user) {
    const role = user.role;
    if (['admin', 'superadmin'].includes(role)) return <Navigate to="/admin" replace />;
    if (role === 'central') return <Navigate to="/central" replace />;
    return <Navigate to={getHomeForRole(role)} replace />;
  }

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    const cleanEmail = email.trim().toLowerCase();
    try {
      await base44.auth.loginViaEmailPassword(cleanEmail, password);
      await checkUserAuth();
    } catch (err) {
      const msg = (err.message || '').toLowerCase();
      if (msg.includes('verify') || msg.includes('verific')) {
        try {
          await base44.auth.resendOtp(cleanEmail);
        } catch {}
        setEmail(cleanEmail);
        setOtpCode('');
        setPendingOtp(true);
      } else if (msg.includes('not found') || msg.includes('no existe') || msg.includes('invalid')) {
        setError('Correo o contraseña incorrectos.');
      } else {
        setError(err.message || 'No se pudo iniciar sesión.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyPendingOtp = async () => {
    setError('');
    setLoading(true);
    try {
      const cleanEmail = email.trim().toLowerCase();
      const result = await base44.auth.verifyOtp({ email: cleanEmail, otpCode: otpCode.trim() });
      if (result?.access_token) base44.auth.setToken(result.access_token);
      await checkUserAuth();
    } catch (err) {
      setError('Código inválido o vencido. Toca "Reenviar código" para recibir uno nuevo.');
    } finally {
      setLoading(false);
    }
  };

  if (pendingOtp) {
    return (
      <OtpVerificationCard
        email={email}
        otpCode={otpCode}
        setOtpCode={setOtpCode}
        loading={loading}
        error={error}
        onVerify={handleVerifyPendingOtp}
        onBack={() => {
          setPendingOtp(false);
          setError('');
        }}
        submitLabel="Verificar e iniciar sesión"
        loadingLabel="Verificando..."
      />
    );
  }

  const handleShare = async () => {
    setMenuOpen(false);
    try {
      if (navigator.share) {
        await navigator.share({ title: 'NEXT', text: 'Transporte y mensajería', url: window.location.href });
      } else {
        await navigator.clipboard.writeText(window.location.href);
        toast({ title: 'Enlace copiado', description: 'Compartido en el portapapeles.' });
      }
    } catch (e) {}
  };

  const menuItems = [
    { icon: UserPlus, label: 'Vincúlate', action: () => { setMenuOpen(false); navigate('/registro'); } },
    { icon: CreditCard, label: 'Carnet corporativo', action: () => { setMenuOpen(false); toast({ title: 'Próximamente', description: 'Carnet corporativo estará disponible pronto.' }); } },
    { icon: Share2, label: 'Compartir', action: handleShare },
  ];

  return (
    <div className="theme-day min-h-screen bg-background relative overflow-hidden flex flex-col max-w-md mx-auto w-full">
      <div className="absolute inset-0 dot-world-bg opacity-60 pointer-events-none" />
      <div className="absolute -top-24 -right-24 w-72 h-72 rounded-full bg-[#1E6BFF]/20 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -left-20 w-72 h-72 rounded-full bg-[#00E5FF]/10 blur-3xl pointer-events-none" />

      <div className="absolute top-4 right-4 z-20 flex items-center gap-2">
        <ThemeToggle />
        <button onClick={() => setMenuOpen(true)} className="w-9 h-9 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white hover:bg-white/10" aria-label="Menú">
          <Menu className="w-5 h-5" />
        </button>
      </div>
<div className="relative z-10 flex flex-col items-center pt-20 pb-6 px-6">
        <div className="relative mb-3">
          <div className="absolute inset-0 blur-2xl bg-[#1E6BFF]/40 rounded-full" />
          <svg viewBox="0 0 48 48" className="relative w-16 h-16 mx-auto">
            <defs>
              <linearGradient id="welcomeGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#00E5FF" />
                <stop offset="100%" stopColor="#1E6BFF" />
              </linearGradient>
            </defs>
            <path d="M15 7 L29 24 L15 41 L15 34 L22 24 L15 14 Z" fill="url(#welcomeGrad)" />
            <path d="M27 7 L41 24 L27 41 L27 34 L34 24 L27 14 Z" fill="url(#welcomeGrad)" />
          </svg>
        </div>
        <h2 className="text-3xl font-extrabold text-white tracking-wide">NE<span className="text-[#1E6BFF]">X</span>T</h2>
        <p className="text-[10px] text-[#00E5FF] uppercase tracking-[0.32em] text-center mt-1 font-medium">El futuro del transporte y la mensajería</p>
      </div>

      <div className="relative z-10 flex-1 flex flex-col justify-center px-6">
        <div className="bg-[#121829] rounded-[28px] p-6 shadow-2xl border border-white/5">
          <p className="text-[#8B95A8] text-sm text-center mb-6">Ingresa tus credenciales para continuar</p>
          <form onSubmit={handleLogin} className="space-y-3">
            {error && <div className="p-3 rounded-2xl bg-red-500/10 text-red-400 text-sm text-center">{error}</div>}
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5A6478]" />
              <input type="email" className={inputCls} placeholder="Correo o número celular" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5A6478]" />
              <input type={showPassword ? 'text' : 'password'} className={inputCls + ' pr-12'} placeholder="Contraseña" value={password} onChange={(e) => setPassword(e.target.value)} required />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-[#5A6478]">{showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}</button>
            </div>
            <div className="text-left mt-1">
              <Link to="/forgot-password" className="text-[#00E5FF] text-sm font-medium">¿Olvidaste tu contraseña?</Link>
            </div>
            <button type="submit" disabled={loading} className="w-full h-14 bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white font-bold rounded-full flex items-center justify-center gap-2 disabled:opacity-50 shadow-lg shadow-[#1E6BFF]/30 mt-2">
              {loading ? <><Loader2 className="w-5 h-5 animate-spin" /> Ingresando...</> : <>INICIAR SESIÓN <ArrowRight className="w-5 h-5" /></>}
            </button>
          </form>
        </div>

        <p className="text-[#6B7382] text-xs text-center mt-6 leading-relaxed">
          Al continuar, aceptas nuestros <span className="text-[#00E5FF] font-medium">Términos de Uso</span> y <span className="text-[#00E5FF] font-medium">Política de privacidad</span>
        </p>
      </div>

      {menuOpen && (
        <div className="fixed inset-0 z-50 flex items-end" onClick={() => setMenuOpen(false)}>
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
          <div className="relative w-full max-w-md mx-auto bg-[#121829] rounded-t-[28px] p-6 pb-8 border-t border-white/10" onClick={(e) => e.stopPropagation()}>
            <div className="w-12 h-1.5 rounded-full bg-white/15 mx-auto mb-6" />
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-white font-bold text-lg">Menú</h3>
              <button onClick={() => setMenuOpen(false)} className="w-9 h-9 rounded-full bg-white/5 flex items-center justify-center text-white"><X className="w-5 h-5" /></button>
            </div>
            <div className="grid grid-cols-3 gap-4 mb-6">
              {menuItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button key={item.label} onClick={item.action} className="flex flex-col items-center gap-2">
                    <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-[#00E5FF] hover:bg-[#1E6BFF]/15 transition-colors">
                      <Icon className="w-7 h-7" />
                    </div>
                    <span className="text-white text-xs font-medium text-center leading-tight">{item.label}</span>
                  </button>
                );
              })}
            </div>
            <button onClick={() => { setMenuOpen(false); toast({ title: 'Próximamente', description: 'Términos y Condiciones estará disponible pronto.' }); }} className="w-full h-12 rounded-full bg-white/5 border border-white/10 text-white font-medium">Términos y Condiciones</button>
          </div>
        </div>
      )}
    </div>
  );
}
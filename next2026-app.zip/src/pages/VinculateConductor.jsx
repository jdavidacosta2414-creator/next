import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, Mail, Lock, User, Phone, CreditCard, Eye, EyeOff, Loader2, ArrowRight, AlertTriangle, Gift, ShieldCheck } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { safeInvoke } from '@/lib/api-helpers';
import { uploadRegistrationPhoto } from '@/lib/image';
import OtpVerificationCard, { registerOrSendOtp, checkDatabaseRegistration } from '@/components/shared/OtpVerificationCard';
import { getStoredReferralCode, registerReferralClaim, REFERRAL_POINTS } from '@/lib/referrals';
import { useBackButton } from '@/hooks/useBackButton';
import ConductorVehicleSection from '@/components/driver/ConductorVehicleSection';
import ConductorPhotoCapture from '@/components/driver/ConductorPhotoCapture';
import { checkDocument } from '@/lib/checkDocument';
import { signInExistingAccount } from '@/lib/existingAccount';
import {
  DRIVER_CATEGORIES,
  isProfileApproved,
  takenDriverCategories,
  openDriverCategory,
  requestDriverSection,
} from '@/lib/driverProfiles';

const inputCls = 'w-full bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-2xl pl-12 pr-4 h-14 text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-[#5A6478] focus:outline-none focus:border-[#1E6BFF] dark:focus:border-[#00E5FF]/60 transition-colors text-sm shadow-2xs';

const CONDUCTOR_DRAFT_KEY = 'next_conductor_reg_draft_v1';

function readConductorDraft() {
  if (typeof window === 'undefined') return {};
  try {
    const raw = window.sessionStorage.getItem(CONDUCTOR_DRAFT_KEY);
    return raw ? JSON.parse(raw) || {} : {};
  } catch {
    return {};
  }
}

export default function VinculateConductor() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const isLoggedIn = !!user;
  const initialDraft = readConductorDraft();
  const [firstName, setFirstName] = useState(initialDraft.firstName || '');
  const [lastName, setLastName] = useState(initialDraft.lastName || '');
  const [cedula, setCedula] = useState(initialDraft.cedula || '');
  const [phone, setPhone] = useState(initialDraft.phone || '');
  const [vehicleType, setVehicleType] = useState(initialDraft.vehicleType || 'moto');
  const [driverCategory, setDriverCategory] = useState(
    initialDraft.driverCategory || (initialDraft.vehicleType === 'carro' ? 'carro' : 'moto')
  );
  const [carSubtype, setCarSubtype] = useState(initialDraft.carSubtype || 'particular');
  const [vehicleBrand, setVehicleBrand] = useState(initialDraft.vehicleBrand || '');
  const [vehicleModel, setVehicleModel] = useState(initialDraft.vehicleModel || '');
  const [vehicleColor, setVehicleColor] = useState(initialDraft.vehicleColor || 'Blanco');
  const [vehicleYear, setVehicleYear] = useState(
    initialDraft.vehicleYear || String(new Date().getFullYear())
  );
  const [plate, setPlate] = useState(initialDraft.plate || '');
  const [plateType, setPlateType] = useState(initialDraft.plateType || 'amarilla');
  const [referral, setReferral] = useState(
    () => initialDraft.referral || getStoredReferralCode()
  );
  const [email, setEmail] = useState(initialDraft.email || '');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [profilePhoto, setProfilePhoto] = useState(initialDraft.profilePhoto || '');
  const [cedulaPhoto, setCedulaPhoto] = useState(initialDraft.cedulaPhoto || '');
  const [vehiclePhoto, setVehiclePhoto] = useState(initialDraft.vehiclePhoto || '');
  const [tarjetaPhoto, setTarjetaPhoto] = useState(initialDraft.tarjetaPhoto || '');
  const [photoErrors, setPhotoErrors] = useState({});
  const [soatPhoto, setSoatPhoto] = useState(initialDraft.soatPhoto || '');
  const [tecnoPhoto, setTecnoPhoto] = useState(initialDraft.tecnoPhoto || '');
  const [detectedExpiries, setDetectedExpiries] = useState({
    soat_expiry: '',
    tecno_expiry: '',
    vehicle_color: '',
  });

  const [error, setError] = useState('');
  const [issues, setIssues] = useState([]);
  const [loading, setLoading] = useState(false);
  const [photoLoading, setPhotoLoading] = useState(null);
  const [previews, setPreviews] = useState({
    perfil: '',
    cedula: '',
    vehiculo: '',
    tarjeta: '',
    soat: '',
    tecno: '',
  });
  const [step, setStep] = useState('form');
  const [otpCode, setOtpCode] = useState('');
  // Llega así quien ya es conductor y viene a registrarse en otra categoría con sus mismos datos.
  const addingCategory = new URLSearchParams(window.location.search).get('categoria') === 'nueva';
  // Registros de conductor que ya tiene esta cuenta: puede sumar otra categoría, pero no repetir una.
  const [myProfiles, setMyProfiles] = useState([]);
  const takenCategories = takenDriverCategories(myProfiles);

  const handleBack = () => {
    if (step === 'otp') {
      setStep('form');
      return true;
    }
    navigate(isLoggedIn ? (myProfiles.length ? '/movil' : '/cliente') : '/vinculate');
    return true;
  };

  useBackButton(handleBack, true);

  // Persistir borrador del registro en sessionStorage por si Android recarga el WebView al volver de la galería
  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      window.sessionStorage.setItem(
        CONDUCTOR_DRAFT_KEY,
        JSON.stringify({
          firstName,
          lastName,
          cedula,
          phone,
          vehicleType,
          driverCategory,
          carSubtype,
          vehicleBrand,
          vehicleModel,
          vehicleColor,
          vehicleYear,
          plate,
          plateType,
          referral,
          email,
          profilePhoto,
          cedulaPhoto,
          vehiclePhoto,
          tarjetaPhoto,
          soatPhoto,
          tecnoPhoto,
        })
      );
    } catch {}
  }, [
    firstName,
    lastName,
    cedula,
    phone,
    vehicleType,
    driverCategory,
    carSubtype,
    vehicleBrand,
    vehicleModel,
    vehicleColor,
    vehicleYear,
    plate,
    plateType,
    referral,
    email,
    profilePhoto,
    cedulaPhoto,
    vehiclePhoto,
    tarjetaPhoto,
    soatPhoto,
    tecnoPhoto,
  ]);

  useEffect(() => {
    if (!isLoggedIn) return;
    const rawName = (user?.display_name || user?.full_name || '').trim();
    if (rawName && !firstName && !lastName) {
      const parts = rawName.split(/\s+/);
      setFirstName(parts[0] || '');
      setLastName(parts.slice(1).join(' ') || '');
    }
    if (user?.phone && !phone) setPhone(user.phone);
    if (user?.cedula && !cedula) setCedula(user.cedula);
    if (user?.photo_url && !profilePhoto) {
      setProfilePhoto(user.photo_url);
      if (/^https?:\/\//.test(user.photo_url)) {
        setPreviews((prev) => ({ ...prev, perfil: user.photo_url }));
      } else {
        base44.integrations.Core.CreateFileSignedUrl({ file_uri: user.photo_url })
          .then(({ signed_url }) => {
            if (signed_url) setPreviews((prev) => ({ ...prev, perfil: signed_url }));
          })
          .catch(() => {});
      }
    }
    (async () => {
      try {
        const existing = await base44.entities.Mobile.filter({ email: user.email });
        const taken = takenDriverCategories(existing);
        const free = DRIVER_CATEGORIES.filter((c) => !taken.includes(c));
        // Quien ya tiene un registro vigente solo sigue aquí si vino a registrarse en otra categoría.
        if (taken.length > 0 && (!addingCategory || free.length === 0)) {
          navigate('/movil', { replace: true });
          return;
        }
        setMyProfiles(existing);
        if (taken.includes(vehicleType === 'carro' ? 'carro' : driverCategory)) {
          // La categoría que traía el formulario ya está registrada: pasa a una que tenga libre.
          setDriverCategory(free[0]);
          setVehicleType(free[0] === 'carro' ? 'carro' : 'moto');
        }
      } catch (e) {}
    })();
  }, [isLoggedIn, user]);

  const handleSelectPhotoFile = async (file, kind) => {
    if (!file) return;
    setPhotoLoading(kind);
    setError('');
    setPhotoErrors((prev) => ({ ...prev, [kind]: '' }));
    try {
      const { file_uri, previewUrl } = await uploadRegistrationPhoto(file, 1280, 0.78);
      const check = await checkDocument({
        kind,
        file_uri,
        plate: plate.trim(),
        cedula: cedula.trim(),
        vehicle_type: vehicleType,
      });
      if (!check.ok) {
        setPhotoErrors((prev) => ({ ...prev, [kind]: check.message || 'Esta foto no es válida. Sube una correcta.' }));
        return;
      }
      if (kind === 'perfil') setProfilePhoto(file_uri);
      else if (kind === 'cedula') setCedulaPhoto(file_uri);
      else if (kind === 'tarjeta') setTarjetaPhoto(file_uri);
      else if (kind === 'soat') setSoatPhoto(file_uri);
      else if (kind === 'tecno') setTecnoPhoto(file_uri);
      else if (kind === 'vehiculo') setVehiclePhoto(file_uri);
      setPreviews((prev) => ({ ...prev, [kind]: previewUrl }));
    } catch (err) {
      setError('No se pudo procesar la foto. Intenta de nuevo.');
    } finally {
      setPhotoLoading(null);
    }
  };

  const handleClearPhoto = (kind) => {
    if (kind === 'perfil') setProfilePhoto('');
    else if (kind === 'cedula') setCedulaPhoto('');
    else if (kind === 'tarjeta') setTarjetaPhoto('');
    else if (kind === 'soat') setSoatPhoto('');
    else if (kind === 'tecno') setTecnoPhoto('');
    else if (kind === 'vehiculo') setVehiclePhoto('');
    setPreviews((prev) => ({ ...prev, [kind]: '' }));
  };

  const verifyPhotos = async () => {
    const enteredPlate = plate.trim().toUpperCase().replace(/[\s.\-]/g, '');
    const result = await safeInvoke('verifyDriverPhotos', {
      cedula_url: cedulaPhoto,
      tarjeta_url: tarjetaPhoto,
      vehicle_url: vehiclePhoto,
      soat_url: vehicleType === 'carro' ? soatPhoto : '',
      tecno_url: vehicleType === 'carro' ? tecnoPhoto : '',
      vehicle_type: vehicleType,
      car_subtype: vehicleType === 'carro' ? carSubtype : '',
      plate_type: vehicleType === 'carro' ? plateType : '',
      plate: enteredPlate,
      cedula: cedula.trim(),
    });
    const v = result?.verification || result;
    if (!v) throw new Error('No se pudo verificar los documentos');

    const fails = [];
    if (v.cedula_ok === false) {
      fails.push('La foto de la cédula no es válida, no es legible o no corresponde a una cédula colombiana real.');
    }
    if (v.cedula_ok !== false && v.cedula_number_match === false) {
      fails.push(
        v.cedula_number
          ? `El número de la cédula en la foto (${v.cedula_number}) no coincide con el número ingresado (${cedula.trim()}).`
          : 'No se pudo leer el número de la cédula en la foto para confirmar que coincide con el ingresado.'
      );
    }
    if (v.tarjeta_ok === false) {
      fails.push('La foto de la tarjeta de propiedad no es válida o no es legible.');
    }
    if (v.plate_match === false) {
      fails.push(
        v.extracted_plate
          ? `La placa en la tarjeta de propiedad (${v.extracted_plate}) no coincide con la placa ingresada (${enteredPlate}).`
          : `No se pudo confirmar que la placa de la tarjeta de propiedad coincida con ${enteredPlate}.`
      );
    }
    if (v.vehicle_ok === false) {
      fails.push(
        vehicleType === 'carro'
          ? 'La foto del vehículo no corresponde a un carro real.'
          : 'La foto del vehículo no corresponde a una motocicleta real.'
      );
    }
    if (v.vehicle_plate_visible === false) {
      fails.push(
        vehicleType === 'carro'
          ? 'En la foto del carro debe verse claramente la placa física del vehículo.'
          : 'En la foto de la moto debe verse claramente la placa física de la motocicleta.'
      );
    } else if (v.vehicle_plate_match === false) {
      fails.push(
        v.vehicle_extracted_plate
          ? `La placa visible en la foto del vehículo (${v.vehicle_extracted_plate}) no concuerda con la placa registrada (${enteredPlate}).`
          : `La placa en la foto del vehículo no concuerda con la placa registrada (${enteredPlate}).`
      );
    }
    if (vehicleType === 'carro') {
      if (v.soat_ok === false) {
        fails.push('La imagen del SOAT no corresponde a una póliza SOAT colombiana auténtica y legible.');
      } else if (v.soat_vigente === false) {
        fails.push(
          v.soat_expiry_date
            ? `El SOAT figura vencido (${v.soat_expiry_date}). No puedes trabajar con el SOAT vencido.`
            : 'El SOAT no está vigente o no se logra leer su fecha de vencimiento. No puedes trabajar con documentos vencidos.'
        );
      } else if (v.soat_plate_match === false) {
        fails.push(`La placa en el SOAT no coincide con la placa registrada (${enteredPlate}).`);
      }

      if (v.tecno_ok === false) {
        fails.push('La imagen de la Tecnomecánica no corresponde a un Certificado de Revisión Técnico-Mecánica auténtico y legible.');
      } else if (v.tecno_vigente === false) {
        fails.push(
          v.tecno_expiry_date
            ? `La Revisión Técnico-Mecánica figura vencida (${v.tecno_expiry_date}). No puedes trabajar con la tecnomecánica vencida.`
            : 'La Revisión Técnico-Mecánica no está vigente o no se logra leer su fecha de vencimiento. No puedes trabajar con documentos vencidos.'
        );
      } else if (v.tecno_plate_match === false) {
        fails.push(`La placa en la Tecnomecánica no coincide con la placa registrada (${enteredPlate}).`);
      }
    }

    if (Array.isArray(v.issues)) {
      v.issues.forEach((it) => {
        if (it && !fails.includes(it)) fails.push(it);
      });
    }

    const baseOk =
      Boolean(v.cedula_ok) &&
      v.cedula_number_match !== false &&
      Boolean(v.tarjeta_ok) &&
      Boolean(v.plate_match) &&
      Boolean(v.vehicle_ok) &&
      Boolean(v.vehicle_plate_visible) &&
      Boolean(v.vehicle_plate_match);

    const carDocsOk =
      vehicleType !== 'carro' ||
      (Boolean(v.soat_ok) &&
        Boolean(v.soat_vigente) &&
        Boolean(v.soat_plate_match) &&
        Boolean(v.tecno_ok) &&
        Boolean(v.tecno_vigente) &&
        Boolean(v.tecno_plate_match));

    return {
      ok: baseOk && carDocsOk,
      fails,
      soat_expiry: v.soat_expiry_date || '',
      tecno_expiry: v.tecno_expiry_date || '',
      vehicle_color:
        v.vehicle_color ||
        (vehicleType === 'carro' && carSubtype === 'taxi'
          ? 'Amarillo'
          : ''),
    };
  };

  const createProfile = async (expiries = detectedExpiries, openCategories = false) => {
    const fullName = (firstName + ' ' + lastName).trim();
    const modelLabel =
      vehicleType === 'carro'
        ? `${vehicleModel.trim()} ${vehicleYear}`.trim()
        : vehicleModel.trim();
    const detectedColor =
      vehicleColor.trim() ||
      expiries?.vehicle_color ||
      (vehicleType === 'carro' && carSubtype === 'taxi'
        ? 'Amarillo'
        : 'Blanco');

    const res = await safeInvoke('registerConductor', {
      name: fullName,
      cedula: cedula.trim(),
      phone: phone.trim(),
      plate: plate.trim().toUpperCase(),
      plate_type: vehicleType === 'carro' ? plateType : undefined,
      vehicle_type: vehicleType,
      driver_category: vehicleType === 'carro' ? 'carro' : driverCategory,
      car_subtype: vehicleType === 'carro' ? carSubtype : undefined,
      vehicle_brand: vehicleBrand.trim(),
      vehicle_model: modelLabel,
      vehicle_color: detectedColor || undefined,
      vehicle_year: vehicleType === 'carro' ? Number(vehicleYear) : undefined,
      vehicle_photo: vehiclePhoto,
      verification_photo: cedulaPhoto,
      tarjeta_photo: tarjetaPhoto,
      soat_photo: vehicleType === 'carro' ? soatPhoto : undefined,
      tecno_photo: vehicleType === 'carro' ? tecnoPhoto : undefined,
      soat_expiry: vehicleType === 'carro' ? expiries?.soat_expiry : undefined,
      tecno_expiry: vehicleType === 'carro' ? expiries?.tecno_expiry : undefined,
      photo_url: profilePhoto,
    });
    const cleanRef = referral.trim().toUpperCase();
    if (cleanRef) {
      try {
        const me = user || (await base44.auth.me());
        await base44.auth.updateMe({ referral_code: cleanRef }).catch(() => {});
        await registerReferralClaim({
          referralCode: cleanRef,
          newUser: me,
          newUserName: fullName,
          newRole: 'conductor',
          newMobileId: res?.mobile?.id,
        });
      } catch {}
    }
    try {
      window.sessionStorage.removeItem(CONDUCTOR_DRAFT_KEY);
      window.localStorage.setItem('next_user_explicit_mode', 'conductor');
    } catch {}
    // Si ya trabaja en otra categoría, el panel abre "Mis categorías" para ver el estado del nuevo registro.
    if (openCategories) requestDriverSection('categorias');
    window.location.href = '/movil';
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setIssues([]);
    if (!firstName.trim() || !lastName.trim() || !cedula.trim() || !phone.trim()) {
      setError('Completa todos los campos personales');
      return;
    }
    if (!vehicleBrand.trim() || !vehicleModel.trim()) {
      setError('Completa la marca y línea/modelo del vehículo');
      return;
    }
    if (vehicleType === 'carro') {
      const yr = Number(vehicleYear);
      if (!yr || yr < 2003) {
        setError('Para carros solo se permiten modelos del año 2003 en adelante');
        return;
      }
      if (!carSubtype) {
        setError('Selecciona si tu vehículo es Carro particular o Taxi');
        return;
      }
      if (!plateType) {
        setError('Selecciona si tu placa es Placa amarilla o Placa blanca');
        return;
      }
    }
    if (!plate.trim()) {
      setError('La placa del vehículo es obligatoria');
      return;
    }
    if (!profilePhoto || !cedulaPhoto || !tarjetaPhoto || !vehiclePhoto) {
      setError('Debes subir la foto de perfil, cédula, tarjeta de propiedad y foto del vehículo mostrando la placa');
      return;
    }
    if (vehicleType === 'carro' && (!soatPhoto || !tecnoPhoto)) {
      setError('Para registrar un carro debes anexar la foto del SOAT y la Tecnomecánica vigentes');
      return;
    }
    if (!isLoggedIn && password.length < 6) {
      setError('La contraseña debe tener al menos 6 caracteres');
      return;
    }

    setLoading(true);
    try {
      const cleanEmail = email.trim().toLowerCase();
      const category = vehicleType === 'carro' ? 'carro' : driverCategory;
      let loggedIn = isLoggedIn;
      let profiles = myProfiles;
      const checkRegistration = (withEmail) =>
        checkDatabaseRegistration({
          email: withEmail ? cleanEmail : '',
          cedula: cedula.trim(),
          plate: plate.trim().toUpperCase(),
          scope: 'conductor',
          driverCategory: category,
        });
      // 1) Validar primero en la base de datos el correo, la cédula (por categoría) y la placa
      let dbCheck = await checkRegistration(!loggedIn);
      if (dbCheck?.exists && dbCheck?.verified && dbCheck.field === 'email') {
        // El correo ya tiene cuenta en NEXT: se entra con ella y el registro sigue con esa cuenta.
        await signInExistingAccount(cleanEmail, password);
        loggedIn = true;
        profiles = await base44.entities.Mobile.filter({ email: cleanEmail });
        if (takenDriverCategories(profiles).includes(category)) {
          // Ya está registrado en esta categoría: entra a ese registro en lugar de crear otro.
          openDriverCategory(category);
          return;
        }
        dbCheck = await checkRegistration(false);
      }
      if (dbCheck?.exists && dbCheck?.verified) {
        setError(
          dbCheck.error ||
            'Este correo, cédula o placa ya se encuentra registrado en la base de datos y no puede volver a registrarse.'
        );
        return;
      }

      // 2) Si no está registrado en la base de datos, verificar fotos y enviar el código OTP al correo
      const otpPromise = !loggedIn
        ? registerOrSendOtp(cleanEmail, password, {
            cedula: cedula.trim(),
            plate: plate.trim().toUpperCase(),
            scope: 'conductor',
            driverCategory: category,
          })
        : Promise.resolve({ status: 'logged_in', email: cleanEmail });

      const [verification] = await Promise.all([verifyPhotos(), otpPromise]);
      if (!verification.ok) {
        setIssues(verification.fails.length ? verification.fails : ['Los documentos o la placa del vehículo no superaron la validación de seguridad.']);
        setError('Revisa y corrige los documentos señalados. No se permite trabajar con documentos vencidos o fotos que no correspondan.');
        return;
      }
      const expiries = {
        soat_expiry: verification.soat_expiry || '',
        tecno_expiry: verification.tecno_expiry || '',
        vehicle_color: verification.vehicle_color || '',
      };
      setDetectedExpiries(expiries);

      if (loggedIn) {
        await createProfile(expiries, profiles.some(isProfileApproved));
        return;
      }
      setEmail(cleanEmail);
      setOtpCode('');
      setStep('otp');
    } catch (err) {
      const msg = (err.message || '').toLowerCase();
      if (err.code === 'ALREADY_REGISTERED' || msg.includes('already') || msg.includes('exists') || msg.includes('registrad')) {
        setError(err.message || 'Este correo electrónico ya está registrado en la base de datos. No puede volver a registrarse.');
      } else {
        if (msg.includes('ya tienes un perfil')) {
          window.location.href = '/movil';
          return;
        }
        setError(err.response?.data?.error || err.message || 'No se pudo completar el registro');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async () => {
    setError('');
    setLoading(true);
    const cleanEmail = email.trim().toLowerCase();
    try {
      const result = await base44.auth.verifyOtp({ email: cleanEmail, otpCode: otpCode.trim() });
      if (result?.access_token) base44.auth.setToken(result.access_token);
      await createProfile(detectedExpiries);
    } catch (err) {
      setError(err.response?.data?.error || err.message || 'El código ingresado es incorrecto o venció. Usa "Reenviar código".');
    } finally {
      setLoading(false);
    }
  };

  if (step === 'otp') {
    return (
      <OtpVerificationCard
        email={email}
        otpCode={otpCode}
        setOtpCode={setOtpCode}
        loading={loading}
        error={error}
        onVerify={handleVerify}
        onBack={handleBack}
        submitLabel="Verificar y registrar"
        loadingLabel="Registrando..."
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#F4F7FB] dark:bg-[#0B0F1A] flex flex-col px-6 py-8 max-w-md mx-auto w-full">
      <button
        type="button"
        onClick={handleBack}
        aria-label="Volver"
        className="w-10 h-10 rounded-full bg-white dark:bg-[#161C28] shadow-sm flex items-center justify-center text-slate-900 dark:text-white mb-5 self-start border border-slate-200/70 dark:border-white/10"
      >
        <ArrowLeft className="w-5 h-5" />
      </button>

      <h1 className="text-slate-900 dark:text-white text-2xl font-bold mb-1">
        Vincúlate como conductor
      </h1>
      <p className="text-slate-500 dark:text-[#8B95A8] text-sm mb-6">
        Verificación estricta de documentos vigentes y placa del vehículo
      </p>

      <form onSubmit={handleSubmit} className="flex-1 space-y-3.5">
        {error && (
          <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}
        {issues.length > 0 && (
          <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs space-y-1.5">
            <p className="font-bold text-sm text-amber-200">Problemas detectados en la verificación:</p>
            {issues.map((it, i) => (
              <p key={i} className="leading-relaxed">• {it}</p>
            ))}
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          <div className="relative">
            <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5A6478]" />
            <input className={inputCls} placeholder="Nombres" value={firstName} onChange={(e) => setFirstName(e.target.value)} required />
          </div>
          <div className="relative">
            <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5A6478]" />
            <input className={inputCls} placeholder="Apellidos" value={lastName} onChange={(e) => setLastName(e.target.value)} required />
          </div>
        </div>
        <div className="relative">
          <CreditCard className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5A6478]" />
          <input className={inputCls} placeholder="Número de cédula" value={cedula} onChange={(e) => setCedula(e.target.value)} required />
        </div>
        <div className="relative">
          <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5A6478]" />
          <input type="tel" className={inputCls} placeholder="Número de contacto" value={phone} onChange={(e) => setPhone(e.target.value)} required />
        </div>

        <ConductorVehicleSection
          vehicleType={vehicleType}
          setVehicleType={setVehicleType}
          driverCategory={driverCategory}
          setDriverCategory={setDriverCategory}
          takenCategories={takenCategories}
          carSubtype={carSubtype}
          setCarSubtype={setCarSubtype}
          vehicleBrand={vehicleBrand}
          setVehicleBrand={setVehicleBrand}
          vehicleModel={vehicleModel}
          setVehicleModel={setVehicleModel}
          vehicleColor={vehicleColor}
          setVehicleColor={setVehicleColor}
          vehicleYear={vehicleYear}
          setVehicleYear={setVehicleYear}
          plate={plate}
          setPlate={setPlate}
          plateType={plateType}
          setPlateType={setPlateType}
          inputCls={inputCls}
        />

        <div className="relative">
          <Gift className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5A6478]" />
          <input
            className={inputCls}
            placeholder={`Código de referido (opcional · +${REFERRAL_POINTS} pts)`}
            value={referral}
            onChange={(e) => setReferral(e.target.value.toUpperCase())}
          />
        </div>

        {/* Registros fotográficos con cámara o galería */}
        <div className="space-y-3 pt-2">
          <div className="flex items-center justify-between">
            <p className="text-xs font-extrabold uppercase tracking-wider text-[#0284C7] dark:text-[#00E5FF]">
              Registros fotográficos obligatorios
            </p>
            <span className="text-[11px] text-slate-500 dark:text-[#8B95A8] flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-[#0284C7] dark:text-[#00E5FF]" /> Verificación IA activa
            </span>
          </div>

          <ConductorPhotoCapture
            kind="perfil"
            label="Foto de perfil (selfie)"
            subtitle="Una selfie normal donde se vea bien tu rostro. Sin gafas oscuras, gorra ni tapabocas."
            badge="Obligatorio"
            value={profilePhoto}
            previewUrl={previews.perfil}
            loading={photoLoading === 'perfil'}
            cameraFacing="user"
            onSelectFile={handleSelectPhotoFile}
            onClear={handleClearPhoto}
            errors={photoErrors}
          />

          <ConductorPhotoCapture
            kind="cedula"
            label="Foto de la cédula de ciudadanía"
            subtitle="Documento colombiano original y completamente legible."
            badge="Obligatorio"
            value={cedulaPhoto}
            previewUrl={previews.cedula}
            loading={photoLoading === 'cedula'}
            cameraFacing="environment"
            onSelectFile={handleSelectPhotoFile}
            onClear={handleClearPhoto}
            errors={photoErrors}
          />

          <ConductorPhotoCapture
            kind="tarjeta"
            label="Foto de la tarjeta de propiedad"
            subtitle={`Licencia de tránsito legible. La placa debe coincidir con ${plate || 'la ingresada'}.`}
            badge="Obligatorio"
            value={tarjetaPhoto}
            previewUrl={previews.tarjeta}
            loading={photoLoading === 'tarjeta'}
            cameraFacing="environment"
            onSelectFile={handleSelectPhotoFile}
            onClear={handleClearPhoto}
            errors={photoErrors}
          />

          {vehicleType === 'carro' && (
            <>
              <ConductorPhotoCapture
                kind="soat"
                label="Foto del SOAT vigente"
                subtitle="La aplicación verificará que sea un SOAT real, corresponda a la placa y esté vigente."
                badge="Exigido en Carro"
                value={soatPhoto}
                previewUrl={previews.soat}
                loading={photoLoading === 'soat'}
                cameraFacing="environment"
                onSelectFile={handleSelectPhotoFile}
                onClear={handleClearPhoto}
                errors={photoErrors}
              />

              <ConductorPhotoCapture
                kind="tecno"
                label="Foto de la Tecnomecánica vigente"
                subtitle="Certificado de Revisión Técnico-Mecánica vigente. Con documentos vencidos no podrás trabajar."
                badge="Exigido en Carro"
                value={tecnoPhoto}
                previewUrl={previews.tecno}
                loading={photoLoading === 'tecno'}
                cameraFacing="environment"
                onSelectFile={handleSelectPhotoFile}
                onClear={handleClearPhoto}
                errors={photoErrors}
              />
            </>
          )}

          <ConductorPhotoCapture
            kind="vehiculo"
            label={
              vehicleType === 'carro'
                ? 'Foto del carro (que se vea la placa)'
                : 'Foto de la moto (que se vea la placa)'
            }
            subtitle={
              vehicleType === 'carro'
                ? `Toma o sube la foto de tu carro donde se vea claramente la placa ${plate || ''} para confirmar que concuerda.`
                : `Toma o sube la foto de tu moto donde se vea claramente la placa ${plate || ''} como evidencia del vehículo.`
            }
            badge="Placa visible"
            value={vehiclePhoto}
            previewUrl={previews.vehiculo}
            loading={photoLoading === 'vehiculo'}
            cameraFacing="environment"
            onSelectFile={handleSelectPhotoFile}
            onClear={handleClearPhoto}
            errors={photoErrors}
          />
        </div>

        {!isLoggedIn && (
          <>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5A6478]" />
              <input
                type="email"
                className={inputCls}
                placeholder="Correo electrónico"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (error && error.toLowerCase().includes('correo')) setError('');
                }}
                onBlur={async () => {
                  const clean = email.trim().toLowerCase();
                  if (!clean || !clean.includes('@')) return;
                  try {
                    const res = await checkDatabaseRegistration({ email: clean, scope: 'conductor' });
                    if (res?.exists && res?.verified) {
                      setError(res.error || 'Este correo electrónico ya está registrado en la base de datos.');
                    }
                  } catch {}
                }}
                required
              />
            </div>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5A6478]" />
              <input type={showPassword ? 'text' : 'password'} className={inputCls + ' pr-12'} placeholder="Contraseña" value={password} onChange={(e) => setPassword(e.target.value)} required />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-[#5A6478]">
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </>
        )}

        <p className="text-[11px] text-slate-500 dark:text-[#8B95A8] text-center leading-relaxed pt-1">
          Tus documentos se almacenan de forma privada y la aplicación verifica automáticamente que la placa y las vigencias sean reales antes de habilitar tu cuenta.
        </p>

        <button
          type="submit"
          disabled={loading}
          className="w-full h-14 bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white font-bold rounded-full flex items-center justify-center gap-2 disabled:opacity-50 mt-2 shadow-lg shadow-[#1E6BFF]/30"
        >
          {loading ? (
            <><Loader2 className="w-5 h-5 animate-spin" /> Verificando documentos y placa...</>
          ) : isLoggedIn ? (
            'Verificar y registrarme como conductor'
          ) : (
            'Verificar documentos y crear cuenta'
          )}
        </button>
        {!isLoggedIn && (
          <p className="text-center text-sm text-slate-500 dark:text-[#8B95A8] pt-2">
            ¿Ya tienes cuenta? <Link to="/login" className="text-[#1E6BFF] dark:text-[#00E5FF] font-bold">Inicia sesión</Link>
          </p>
        )}
      </form>
    </div>
  );
}
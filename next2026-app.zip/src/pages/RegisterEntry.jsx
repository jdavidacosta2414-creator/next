import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronDown, ArrowRight, Shield, Clock, HeartHandshake, BadgeCheck, Mail } from 'lucide-react';
import { captureReferralFromUrl } from '@/lib/referrals';

const BANNER = 'https://media.base44.com/images/public/6ab13aed46d61158e305a1ce/ad9140ad7_1000048560.jpg';

// Paleta referencia (morado + verde)
const PURPLE = '#8B31E0';
const MAGENTA = '#d946ef';
const GREEN = '#10B981';

const FEATURES = [
  { icon: Shield, label: 'Viajes seguros' },
  { icon: Clock, label: 'Llegamos a tiempo' },
  { icon: HeartHandshake, label: 'Pensado en la gente' },
  { icon: BadgeCheck, label: 'Fácil, rápido y confiable' },
];

// Entrada de registro: banner de seguridad + número de celular.
export default function RegisterEntry() {
  const navigate = useNavigate();
  const [phone, setPhone] = useState('');
  useEffect(() => {
    captureReferralFromUrl();
  }, []);

  const formatPhone = (v) => v.replace(/\D/g, '').slice(0, 10).replace(/(\d{3})(\d{3})(\d{0,4})/, '$1 $2 $3').trim();

  const handleContinue = () => {
    if (phone.replace(/\D/g, '').length < 7) return;
    navigate('/vinculate', { state: { phone: '+57 ' + phone.replace(/\D/g, '') } });
  };

  return (
    <div className="min-h-screen bg-background flex flex-col max-w-md mx-auto w-full">
      {/* Banner oscuro con imagen + mensaje de seguridad */}
      <div className="relative w-full h-[48vh] overflow-hidden bg-black">
        <img src={BANNER} alt="" aria-hidden className="absolute inset-0 w-full h-full object-cover object-center" />
        {/* Difuminado inferior hacia el fondo actual */}
        <div className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-b from-transparent via-background/60 to-background" />
      </div>

      {/* Tarjeta de registro */}
      <div className="flex-1 bg-background px-6 pt-2 pb-8 flex flex-col relative z-10">
        <h2 className="text-2xl font-extrabold text-foreground">NEXT</h2>
        <p className="text-muted-foreground text-sm mt-1 mb-6">Ingresa tu celular para continuar con tu registro.</p>

        <label className="text-xs font-bold text-foreground mb-1.5">Numero de telefono</label>
        <div className="flex items-center gap-2 h-14 rounded-2xl border border-border bg-muted px-4 focus-within:border-primary transition-colors">
          <span className="text-2xl">🇨🇴</span>
          <span className="text-foreground font-bold">+57</span>
          <span className="text-muted-foreground text-sm hidden xs:inline">Colombia</span>
          <ChevronDown className="w-4 h-4 text-foreground" />
          <div className="w-px h-7 bg-border mx-1" />
          <input
            type="tel"
            inputMode="numeric"
            autoFocus
            value={formatPhone(phone)}
            onChange={(e) => setPhone(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleContinue()}
            placeholder="999 999 9999"
            className="flex-1 min-w-0 bg-transparent outline-none text-foreground placeholder:text-muted-foreground text-lg"
          />
        </div>

        <button
          onClick={handleContinue}
          disabled={phone.replace(/\D/g, '').length < 7}
          className="mt-6 w-full h-14 rounded-2xl bg-primary text-primary-foreground font-bold flex items-center justify-center gap-2 disabled:opacity-40 shadow-lg shadow-primary/25"
        >
          Continuar <ArrowRight className="w-5 h-5" />
        </button>

        <p className="text-center text-xs text-muted-foreground mt-4">Usaremos este numero para identificar tu cuenta.</p>

        <button
          onClick={() => navigate('/login')}
          className="mt-5 mx-auto flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-primary transition-colors"
        >
          <Mail className="w-4 h-4" />
          ¿Ya tienes cuenta? Inicia sesión por correo
        </button>
      </div>
    </div>
  );
}
import React, { useState, useEffect, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { isPickupInCoverage } from '@/lib/coverage';
import LocationMap from '@/components/client/LocationMap';
import PasajeroDrawer from '@/components/pasajero/PasajeroDrawer';
import RutaModal from '@/components/pasajero/RutaModal';
import PasajeroConfigSheet from '@/components/pasajero/PasajeroConfigSheet';
import BuscandoConductores from '@/components/pasajero/BuscandoConductores';
import SeguimientoConductor from '@/components/pasajero/SeguimientoConductor';
import InfoConductorModal from '@/components/pasajero/InfoConductorModal';
import ServiceRatingModal from '@/components/shared/ServiceRatingModal';
import PaymentMethodModal from '@/components/pasajero/PaymentMethodModal';
import NextFloatingBubble from '@/components/shared/NextFloatingBubble';
import { getStoredDismissedNotifs } from '@/components/pasajero/PasajeroNotificaciones';
import PasajeroBottomNav from '@/components/pasajero/PasajeroBottomNav';
import PasajeroSubViews from '@/components/pasajero/PasajeroSubViews';
import {
  PasajeroTopHeader,
  PasajeroMapCenterArea,
  PasajeroHomeBottomSheet,
} from '@/components/pasajero/PasajeroMapOverlayControls';
import { useToast } from '@/components/ui/use-toast';
import { useMapboxToken } from '@/hooks/useMapboxToken';
import { usePassengerActiveService } from '@/hooks/usePassengerActiveService';
import { usePassengerBackgroundSync } from '@/hooks/usePassengerBackgroundSync';
import { useBackButton } from '@/hooks/useBackButton';
import { DEFAULT_CITY } from '@/lib/appCity';
import { calculateSuggestedFare, getVehicleSpeedProfile } from '@/lib/routeEstimate';
import { reverseGeocodeValledupar, normalizeColombiaCoords } from '@/lib/geocode';
import { barrioFor, lookupBarrio } from '@/lib/barrio';
import { FARE_MIN, VEHICLES, CONTENT_TYPES, PAYMENTS } from '@/lib/pasajeroOptions';
import { formatColombianStreetAddress, isCoordinateString, isIncompleteStreetAddress, shortAddress } from '@/lib/shortAddress';
import { preloadStorageUrls } from '@/components/shared/ResolvedAvatar';

const fmtCOP = (n) => '$' + Number(n).toLocaleString('es-CO');

export default function PasajeroPanel() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { user, checkUserAuth } = useAuth();
  const { toast } = useToast();
  const [mobileProfile, setMobileProfile] = useState(() => {
    try {
      const raw = typeof window !== 'undefined' ? window.localStorage.getItem('next_cached_mobile_v1') : null;
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (parsed && (!user?.email || parsed.email === user.email)) {
        if (parsed.photo_url) preloadStorageUrls([parsed.photo_url]);
        return parsed;
      }
    } catch {}
    return null;
  });
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [routeOpen, setRouteOpen] = useState(false);
  const [routeInitialField, setRouteInitialField] = useState('destination');
  const [step, setStep] = useState('home');
  const [showHistorial, setShowHistorial] = useState(false);
  const [showBilletera, setShowBilletera] = useState(false);
  const [showPuntos, setShowPuntos] = useState(false);
  const [showObjetos, setShowObjetos] = useState(false);
  const [showNotif, setShowNotif] = useState(false);
  const [notifCount, setNotifCount] = useState(() => {
    const dismissed = getStoredDismissedNotifs(user);
    return dismissed.includes('welcome') ? 0 : 1;
  });

  const [showPerfil, setShowPerfil] = useState(false);
  const [showCompartir, setShowCompartir] = useState(false);
  const [showSeguridad, setShowSeguridad] = useState(false);
  const [showConfig, setShowConfig] = useState(false);
  const [showAyuda, setShowAyuda] = useState(false);
  const [showSoporte, setShowSoporte] = useState(false);
  const [showValoraciones, setShowValoraciones] = useState(false);
  const [showPay, setShowPay] = useState(false);
  const [pendingClientRating, setPendingClientRating] = useState(null);
  const resetRouteRef = useRef(null);
  const {
    buscandoId,
    setBuscandoId,
    activeService,
    setActiveService,
    backedOutRef,
    clearActiveService,
  } = usePassengerActiveService({
    user,
    searchParams,
    setSearchParams,
    setStep,
    toast,
    onServiceEnded: () => resetRouteRef.current?.(),
  });
  const [infoOpen, setInfoOpen] = useState(false);
  const [driverInfo, setDriverInfo] = useState(null);
  const [form, setForm] = useState({
    client_name: user?.display_name || user?.full_name || '', client_phone: user?.phone || '', pickup_address: '', destination_address: '',
    service_type: 'transporte', vehicle_type: 'moto', payment_method: 'efectivo', fare: FARE_MIN.moto,
    content_type: '', content_description: '', mode: 'movilidad',
  });

  const [coords, setCoords] = useState(() => {
    try {
      const raw = typeof window !== 'undefined' ? window.localStorage.getItem('next_last_gps_coords_v1') : null;
      if (raw) {
        const parsed = JSON.parse(raw);
        const c = normalizeColombiaCoords(parsed?.lat, parsed?.lng);
        if (c) return c;
      }
    } catch {}
    return null;
  });
  const [pickupTouched, setPickupTouched] = useState(false);
  const pickupTouchedRef = useRef(false);
  const [pickupPoint, setPickupPoint] = useState(() => {
    try {
      const raw = typeof window !== 'undefined' ? window.localStorage.getItem('next_last_gps_coords_v1') : null;
      if (raw) {
        const parsed = JSON.parse(raw);
        const c = normalizeColombiaCoords(parsed?.lat, parsed?.lng);
        if (c) return c;
      }
    } catch {}
    return { lat: DEFAULT_CITY.lat, lng: DEFAULT_CITY.lng };
  });
  const [destPoint, setDestPoint] = useState(null);
  const [pickupPlace, setPickupPlace] = useState(null);
  const [destPlace, setDestPlace] = useState(null);
  const [stops, setStops] = useState([]);
  const [pickupUnverified, setPickupUnverified] = useState(false);
  const [destUnverified, setDestUnverified] = useState(false);
  const [resolvingPickup, setResolvingPickup] = useState(false);
  const [resolvingDest, setResolvingDest] = useState(false);
  const pickupGeoReqIdRef = useRef(0);
  const destGeoReqIdRef = useRef(0);
  const stopGeoReqIdRef = useRef(0);
  const skipPickupGeoRef = useRef(false);
  const skipDestGeoRef = useRef(false);
  const redeemPresetFareRef = useRef(null);

  useEffect(() => {
    pickupTouchedRef.current = pickupTouched;
  }, [pickupTouched]);
  const [routeKm, setRouteKm] = useState(null);
  const [routeMin, setRouteMin] = useState(null);
  const [recentServices, setRecentServices] = useState([]);
  const [pickMode, setPickMode] = useState(null);
  const [mapInteracting, setMapInteracting] = useState(false);
  const [mapExpanded, setMapExpanded] = useState(false);
  const [mapFitKey, setMapFitKey] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const token = useMapboxToken();
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const [freeRidesAvailable, setFreeRidesAvailable] = useState(0);

  // Viajes gratis NEXT CLUB disponibles al configurar la carrera
  useEffect(() => {
    if (step !== 'config' || !user?.id) return;
    base44.entities.ClubFreeRide.count({ user_id: user.id, status: 'disponible' })
      .then((n) => setFreeRidesAvailable(n || 0))
      .catch(() => setFreeRidesAvailable(0));
  }, [step, user?.id]);

  // Al cambiar de paso o abrir el modal de ruta, restaurar los paneles del mapa
  useEffect(() => {
    setMapExpanded(false);
  }, [step, pickMode, routeOpen]);

  const subViewStackRef = useRef([]);
  const pickModeOriginRef = useRef('route');

  const getCurrentSubViewKey = () => {
    if (showSoporte) return 'soporte';
    if (showValoraciones) return 'valoraciones';
    if (showSeguridad) return 'seguridad';
    if (showObjetos) return 'objetos';
    if (showAyuda) return 'ayuda';
    if (showConfig) return 'config';
    if (showCompartir) return 'compartir';
    if (showBilletera) return 'billetera';
    if (showPuntos) return 'puntos';
    if (showHistorial) return 'historial';
    if (showNotif) return 'notif';
    if (showPerfil) return 'perfil';
    return null;
  };

  const applySubViewKey = (key) => {
    setShowHistorial(key === 'historial');
    setShowBilletera(key === 'billetera');
    setShowPuntos(key === 'puntos');
    setShowObjetos(key === 'objetos');
    setShowNotif(key === 'notif');
    setShowCompartir(key === 'compartir');
    setShowSeguridad(key === 'seguridad');
    setShowConfig(key === 'config');
    setShowAyuda(key === 'ayuda');
    setShowSoporte(key === 'soporte');
    setShowValoraciones(key === 'valoraciones');
    setShowPerfil(key === 'perfil');
  };

  const openPassengerSubView = (nextKey) => {
    setDrawerOpen(false);
    const currentKey = getCurrentSubViewKey();
    if (!nextKey) {
      subViewStackRef.current = [];
      applySubViewKey(null);
      return;
    }
    if (currentKey && currentKey !== nextKey) {
      subViewStackRef.current = [...subViewStackRef.current.filter((k) => k !== nextKey), currentKey];
    }
    applySubViewKey(nextKey);
  };

  const goBackPassengerSubView = () => {
    const stack = subViewStackRef.current;
    if (stack.length > 0) {
      const prevKey = stack[stack.length - 1];
      subViewStackRef.current = stack.slice(0, -1);
      applySubViewKey(prevKey);
      return true;
    }
    applySubViewKey(null);
    return true;
  };

  const navStateRef = useRef({});
  navStateRef.current = {
    drawerOpen,
    showPay,
    infoOpen,
    pickMode,
    routeOpen,
    activeSubView: getCurrentSubViewKey(),
    step,
    buscandoId,
    mapExpanded,
  };

  // Siempre habilitado (true) desde que monta PasajeroPanel para que quede en el fondo de la pila LIFO
  // y ningún modal hijo quede por debajo del manejador del panel.
  useBackButton(() => {
    const st = navStateRef.current;
    if (st.drawerOpen) {
      setDrawerOpen(false);
      return true;
    }
    if (st.showPay) {
      setShowPay(false);
      return true;
    }
    if (st.infoOpen) {
      setInfoOpen(false);
      return true;
    }
    if (st.pickMode) {
      setPickMode(null);
      if (pickModeOriginRef.current === 'route') {
        setRouteOpen(true);
      }
      return true;
    }
    if (st.routeOpen) {
      setRouteOpen(false);
      return true;
    }
    if (st.activeSubView) {
      return goBackPassengerSubView();
    }
    if (st.mapExpanded) {
      setMapExpanded(false);
      return true;
    }
    if (st.step === 'config') {
      resetRouteRef.current?.();
      return true;
    }
    if (st.step === 'buscando' || st.step === 'seguimiento') {
      backedOutRef.current = true;
      setStep('home');
      return true;
    }
    return false;
  }, true, { priority: -100 });

  // Sincronizar puntos y direcciones del viaje activo únicamente mientras está en el paso 'buscando' usando las coordenadas guardadas
  useEffect(() => {
    if (step !== 'buscando' || !buscandoId || !activeService || activeService.status !== 'pendiente') return;
    if (activeService.pickup_lat != null && activeService.pickup_lng != null) {
      setPickupPoint({
        lat: Number(activeService.pickup_lat),
        lng: Number(activeService.pickup_lng),
      });
    }

    if (activeService.destination_lat != null && activeService.destination_lng != null) {
      setDestPoint({
        lat: Number(activeService.destination_lat),
        lng: Number(activeService.destination_lng),
      });
    }

    if (Array.isArray(activeService.stops) && activeService.stops.length > 0) {
      setStops(activeService.stops);
    }

    setForm((f) => ({
      ...f,
      pickup_address: activeService.pickup_address || f.pickup_address,
      destination_address: activeService.destination_address || f.destination_address,
    }));
    setMapFitKey((k) => k + 1);
  }, [activeService?.id, activeService?.status, step, token]);

  useEffect(() => {
    let bestAccuracy = coords ? 80 : Infinity;
    let watchId = null;
    let stopWatchTimer = null;

    const applyGpsPoint = (rawLat, rawLng, accuracy = 30) => {
      const acc = Number.isFinite(Number(accuracy)) ? Number(accuracy) : 50;
      // En datos móviles (4G), descartar triangulación de antena celular imprecisa (> 120m)
      // si ya tenemos una coordenada más precisa o guardada del GPS.
      if (acc > 120 && bestAccuracy <= 120) {
        return;
      }
      if (acc > bestAccuracy * 1.4 && bestAccuracy <= 60) {
        return;
      }
      bestAccuracy = Math.min(bestAccuracy, acc);

      const c = normalizeColombiaCoords(rawLat, rawLng) || {
        lat: parseFloat(rawLat),
        lng: parseFloat(rawLng),
      };
      setCoords(c);
      if (acc <= 100) {
        try {
          window.localStorage.setItem('next_last_gps_coords_v1', JSON.stringify(c));
        } catch {}
      }
      if (!pickupTouchedRef.current) {
        const reqId = (pickupGeoReqIdRef.current += 1);
        setPickupPoint(c);
        setMapFitKey((k) => k + 1);
        setResolvingPickup(true);
        reverseGeocodeValledupar(c.lat, c.lng, token)
          .then((addr) => {
            if (addr && !pickupTouchedRef.current && reqId === pickupGeoReqIdRef.current) {
              skipPickupGeoRef.current = true;
              setForm((f) => ({ ...f, pickup_address: addr }));
              setPickupPlace({
                place_id: `gps_${c.lat}_${c.lng}`,
                name: addr,
                formatted_address: `${addr}, Valledupar, Cesar, Colombia`,
                lat: c.lat,
                lng: c.lng,
                location_type: 'ROOFTOP',
                isPrecise: true,
                needsConfirmation: false,
                verified: true,
              });
            }
          })
          .catch(() => {})
          .finally(() => {
            if (reqId === pickupGeoReqIdRef.current) {
              setResolvingPickup(false);
            }
          });
      }
    };

    if (!pickupTouchedRef.current && pickupPoint?.lat != null && pickupPoint?.lng != null) {
      const initReqId = (pickupGeoReqIdRef.current += 1);
      setResolvingPickup(true);
      reverseGeocodeValledupar(pickupPoint.lat, pickupPoint.lng, token)
        .then((addr) => {
          if (addr && !pickupTouchedRef.current && initReqId === pickupGeoReqIdRef.current) {
            skipPickupGeoRef.current = true;
            setForm((f) => ({ ...f, pickup_address: addr }));
            setPickupPlace({
              place_id: `gps_${pickupPoint.lat}_${pickupPoint.lng}`,
              name: addr,
              formatted_address: `${addr}, Valledupar, Cesar, Colombia`,
              lat: pickupPoint.lat,
              lng: pickupPoint.lng,
              location_type: 'ROOFTOP',
              isPrecise: true,
              needsConfirmation: false,
              verified: true,
            });
          }
        })
        .catch(() => {})
        .finally(() => {
          if (initReqId === pickupGeoReqIdRef.current) {
            setResolvingPickup(false);
          }
        });
    }

    if (!navigator.geolocation) return;
    // Usar exclusivamente GPS de alta precisión para evitar saltos por antena 4G
    navigator.geolocation.getCurrentPosition(
      (p) => applyGpsPoint(p.coords.latitude, p.coords.longitude, p.coords.accuracy),
      () => {},
      { timeout: 12000, enableHighAccuracy: true, maximumAge: 0 }
    );
    try {
      watchId = navigator.geolocation.watchPosition(
        (p) => {
          applyGpsPoint(p.coords.latitude, p.coords.longitude, p.coords.accuracy);
          if (p.coords.accuracy && p.coords.accuracy <= 25 && watchId != null) {
            navigator.geolocation.clearWatch(watchId);
            watchId = null;
          }
        },
        () => {},
        { timeout: 15000, enableHighAccuracy: true, maximumAge: 0 }
      );
      stopWatchTimer = setTimeout(() => {
        if (watchId != null) {
          navigator.geolocation.clearWatch(watchId);
          watchId = null;
        }
      }, 15000);
    } catch {}

    return () => {
      if (stopWatchTimer) clearTimeout(stopWatchTimer);
      if (watchId != null && navigator.geolocation) {
        try {
          navigator.geolocation.clearWatch(watchId);
        } catch {}
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const reverseGeocode = async (lat, lng) => {
    return reverseGeocodeValledupar(lat, lng, token);
  };

  const locateMe = () =>
    new Promise((resolve) => {
      if (!navigator.geolocation) {
        resolve(null);
        return;
      }
      navigator.geolocation.getCurrentPosition(
        async (p) => {
          const c =
            normalizeColombiaCoords(p.coords.latitude, p.coords.longitude) || {
              lat: parseFloat(p.coords.latitude),
              lng: parseFloat(p.coords.longitude),
            };
          const reqId = (pickupGeoReqIdRef.current += 1);
          setCoords(c);
          try {
            window.localStorage.setItem('next_last_gps_coords_v1', JSON.stringify(c));
          } catch {}
          setPickupPoint(c);
          setPickupTouched(true);
          setPickupUnverified(false);
          setResolvingPickup(true);
          setMapFitKey((k) => k + 1);
          try {
            const addr = await reverseGeocode(c.lat, c.lng);
            const finalAddr = addr || form.pickup_address || 'Mi ubicación actual';
            const resolvedPlace = {
              place_id: `gps_${c.lat}_${c.lng}`,
              name: finalAddr,
              formatted_address: `${finalAddr}, Colombia`,
              lat: c.lat,
              lng: c.lng,
              location_type: 'ROOFTOP',
              isPrecise: true,
              needsConfirmation: false,
              verified: true,
            };
            if (reqId === pickupGeoReqIdRef.current) {
              setPickupPlace(resolvedPlace);
              if (addr) {
                skipPickupGeoRef.current = true;
                set('pickup_address', addr);
              }
            }
            resolve({ address: finalAddr, lat: c.lat, lng: c.lng, ...resolvedPlace });
          } finally {
            if (reqId === pickupGeoReqIdRef.current) {
              setResolvingPickup(false);
            }
          }
        },
        () => resolve(null),
        { timeout: 10000, enableHighAccuracy: true, maximumAge: 0 }
      );
    });

  // Al cancelar o finalizar un servicio: borrar destino, paradas y ruta del mapa y volver a marcar la ubicación actual del pasajero
  const resetRouteToMyLocation = () => {
    clearActiveService(buscandoId || activeService?.id);
    backedOutRef.current = false;
    setStep('home');
    setPickMode(null);
    setRouteOpen(false);
    setStops([]);
    setDestPoint(null);
    setPickupPlace(null);
    setDestPlace(null);
    setDestUnverified(false);
    setPickupUnverified(false);
    setPickupTouched(false);
    pickupTouchedRef.current = false;
    setRouteKm(null);
    setRouteMin(null);

    const myPt = coords || { lat: DEFAULT_CITY.lat, lng: DEFAULT_CITY.lng };
    const reqId = (pickupGeoReqIdRef.current += 1);
    setPickupPoint(myPt);
    setResolvingPickup(true);
    setForm((f) => ({
      ...f,
      pickup_address: '',
      destination_address: '',
    }));
    setMapFitKey((k) => k + 1);

    reverseGeocodeValledupar(myPt.lat, myPt.lng, token)
      .then((addr) => {
        if (addr && !pickupTouchedRef.current && reqId === pickupGeoReqIdRef.current) {
          skipPickupGeoRef.current = true;
          setForm((f) => ({ ...f, pickup_address: addr, destination_address: '' }));
          setPickupPlace({
            place_id: `gps_${myPt.lat}_${myPt.lng}`,
            name: addr,
            formatted_address: `${addr}, Valledupar, Cesar, Colombia`,
            lat: myPt.lat,
            lng: myPt.lng,
            location_type: 'ROOFTOP',
            isPrecise: true,
            needsConfirmation: false,
            verified: true,
          });
        }
      })
      .catch(() => {})
      .finally(() => {
        if (reqId === pickupGeoReqIdRef.current) {
          setResolvingPickup(false);
        }
      });

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (p) => {
          const fresh =
            normalizeColombiaCoords(p.coords.latitude, p.coords.longitude) || {
              lat: p.coords.latitude,
              lng: p.coords.longitude,
            };
          setCoords(fresh);
          try {
            window.localStorage.setItem('next_last_gps_coords_v1', JSON.stringify(fresh));
          } catch {}
          if (!pickupTouchedRef.current) {
            const freshReqId = (pickupGeoReqIdRef.current += 1);
            setPickupPoint(fresh);
            setResolvingPickup(true);
            setMapFitKey((k) => k + 1);
            reverseGeocodeValledupar(fresh.lat, fresh.lng, token)
              .then((addr) => {
                if (addr && !pickupTouchedRef.current && freshReqId === pickupGeoReqIdRef.current) {
                  skipPickupGeoRef.current = true;
                  setForm((f) => ({ ...f, pickup_address: addr, destination_address: '' }));
                  setPickupPlace({
                    place_id: `gps_${fresh.lat}_${fresh.lng}`,
                    name: addr,
                    formatted_address: `${addr}, Valledupar, Cesar, Colombia`,
                    lat: fresh.lat,
                    lng: fresh.lng,
                    location_type: 'ROOFTOP',
                    isPrecise: true,
                    needsConfirmation: false,
                    verified: true,
                  });
                }
              })
              .catch(() => {})
              .finally(() => {
                if (freshReqId === pickupGeoReqIdRef.current) {
                  setResolvingPickup(false);
                }
              });
          }
        },
        () => {},
        { timeout: 8000, enableHighAccuracy: true }
      );
    }
  };
  resetRouteRef.current = resetRouteToMyLocation;

  // Tocar cualquier parte del mapa:
  // - En pickMode: ubica el pin activo en el punto tocado de forma estable (sin cerrar ni trabarse) y alterna la vista limpia si vuelve a tocar.
  // - En home / config / buscando: alterna mapExpanded para desplegar el mapa a pantalla completa y volver al tamaño normal al tocar de nuevo.
  const handleMapClick = async (pt) => {
    if (!pickMode) {
      setMapExpanded((v) => !v);
      return;
    }
    if (!pt || pt.lat == null || pt.lng == null) return;
    const { lat, lng } = pt;
    const currentTarget = pickMode;
    if (currentTarget.startsWith('stop_')) {
      const idx = Number(currentTarget.replace('stop_', ''));
      const reqId = (stopGeoReqIdRef.current += 1);
      setStops((prev) =>
        prev.map((s, i) => (i === idx ? { ...s, lat, lng, unverified: false, needsSelection: false } : s))
      );
      const addr = await reverseGeocode(lat, lng);
      if (addr && reqId === stopGeoReqIdRef.current) {
        setStops((prev) =>
          prev.map((s, i) =>
            i === idx
              ? {
                  ...s,
                  lat,
                  lng,
                  address: addr,
                  formatted_address: `${addr}, Valledupar, Cesar, Colombia`,
                  unverified: false,
                  needsSelection: false,
                }
              : s
          )
        );
      }
      return;
    }
    if (currentTarget === 'pickup') {
      const reqId = (pickupGeoReqIdRef.current += 1);
      setPickupPoint({ lat, lng });
      setPickupTouched(true);
      setPickupUnverified(false);
      setResolvingPickup(true);
      try {
        const addr = await reverseGeocode(lat, lng);
        if (addr && reqId === pickupGeoReqIdRef.current) {
          skipPickupGeoRef.current = true;
          set('pickup_address', addr);
          setPickupPlace({
            place_id: `pin_pickup_${lat}_${lng}`,
            name: addr,
            formatted_address: `${addr}, Valledupar, Cesar, Colombia`,
            lat: parseFloat(lat),
            lng: parseFloat(lng),
            location_type: 'ROOFTOP',
            isPrecise: true,
            needsConfirmation: false,
            verified: true,
          });
        }
      } finally {
        if (reqId === pickupGeoReqIdRef.current) {
          setResolvingPickup(false);
        }
      }
    } else {
      const reqId = (destGeoReqIdRef.current += 1);
      setDestPoint({ lat, lng });
      setDestUnverified(false);
      setResolvingDest(true);
      try {
        const addr = await reverseGeocode(lat, lng);
        if (addr && reqId === destGeoReqIdRef.current) {
          skipDestGeoRef.current = true;
          set('destination_address', addr);
          setDestPlace({
            place_id: `pin_dest_${lat}_${lng}`,
            name: addr,
            formatted_address: `${addr}, Valledupar, Cesar, Colombia`,
            lat: parseFloat(lat),
            lng: parseFloat(lng),
            location_type: 'ROOFTOP',
            isPrecise: true,
            needsConfirmation: false,
            verified: true,
          });
        }
      } finally {
        if (reqId === destGeoReqIdRef.current) {
          setResolvingDest(false);
        }
      }
    }
  };

  const handlePickupDrag = async ({ lat, lng }) => {
    const c = normalizeColombiaCoords(lat, lng) || { lat: parseFloat(lat), lng: parseFloat(lng) };
    const reqId = (pickupGeoReqIdRef.current += 1);
    setPickupPoint(c);
    setPickupTouched(true);
    setPickupUnverified(false);
    setResolvingPickup(true);
    try {
      const addr = await reverseGeocode(c.lat, c.lng);
      if (addr && reqId === pickupGeoReqIdRef.current) {
        skipPickupGeoRef.current = true;
        set('pickup_address', addr);
        setPickupPlace({
          place_id: `pin_pickup_${c.lat}_${c.lng}`,
          name: addr,
          formatted_address: `${addr}, Colombia`,
          lat: c.lat,
          lng: c.lng,
          location_type: 'ROOFTOP',
          isPrecise: true,
          needsConfirmation: false,
        });
      }
    } finally {
      if (reqId === pickupGeoReqIdRef.current) {
        setResolvingPickup(false);
      }
    }
  };
  const handleDestDrag = async ({ lat, lng }) => {
    const c = normalizeColombiaCoords(lat, lng) || { lat: parseFloat(lat), lng: parseFloat(lng) };
    const reqId = (destGeoReqIdRef.current += 1);
    setDestPoint(c);
    setDestUnverified(false);
    setResolvingDest(true);
    try {
      const addr = await reverseGeocode(c.lat, c.lng);
      if (addr && reqId === destGeoReqIdRef.current) {
        skipDestGeoRef.current = true;
        set('destination_address', addr);
        setDestPlace({
          place_id: `pin_dest_${c.lat}_${c.lng}`,
          name: addr,
          formatted_address: `${addr}, Colombia`,
          lat: c.lat,
          lng: c.lng,
          location_type: 'ROOFTOP',
          isPrecise: true,
          needsConfirmation: false,
        });
      }
    } finally {
      if (reqId === destGeoReqIdRef.current) {
        setResolvingDest(false);
      }
    }
  };
  const handleStopDrag = async (idx, { lat, lng }) => {
    const c = normalizeColombiaCoords(lat, lng) || { lat: parseFloat(lat), lng: parseFloat(lng) };
    const reqId = (stopGeoReqIdRef.current += 1);
    setStops((prev) => prev.map((s, i) => (i === idx ? { ...s, lat: c.lat, lng: c.lng, unverified: false } : s)));
    const addr = await reverseGeocode(c.lat, c.lng);
    if (addr && reqId === stopGeoReqIdRef.current) {
      setStops((prev) => prev.map((s, i) => (i === idx ? { ...s, lat: c.lat, lng: c.lng, address: addr, unverified: false } : s)));
    }
  };

  // No geocodificar en cada pulsación de tecla: las coordenadas se resuelven al seleccionar sugerencia o al pulsar Continuar/Buscar conductor.

  usePassengerBackgroundSync({
    user,
    checkUserAuth,
    mobileProfile,
    setMobileProfile,
    notifCount,
    setNotifCount,
    showNotif,
    setPendingClientRating,
    setForm,
    setRecentServices,
    toast,
  });

  // Duración estimada calibrada según Moto, Carro o Mensajería
  const calibratedRouteMin = React.useMemo(() => {
    if (routeKm == null && routeMin == null) return null;
    const profile = getVehicleSpeedProfile(form.vehicle_type, form.service_type);
    const speedMin = routeKm != null ? (routeKm / profile.avgSpeedKmh) * 60 : null;
    const dirMin = routeMin != null ? routeMin * profile.directionsFactor : null;
    const blended =
      dirMin != null && speedMin != null
        ? dirMin * 0.6 + speedMin * 0.4
        : dirMin ?? speedMin;
    return blended != null ? Math.max(1, Math.round(blended)) : null;
  }, [routeKm, routeMin, form.vehicle_type, form.service_type]);

  const suggestedFare = calculateSuggestedFare({
    vehicleType: form.vehicle_type,
    distanceKm: routeKm,
    durationMin: calibratedRouteMin ?? routeMin,
    historicalServices: recentServices,
  });

  useEffect(() => {
    setForm((f) => {
      if (f.payment_method === 'redimido_puntos' && redeemPresetFareRef.current) {
        return { ...f, fare: redeemPresetFareRef.current };
      }
      return { ...f, fare: suggestedFare };
    });
  }, [suggestedFare]);

  // Con la ruta ya elegida se adelanta la consulta del barrio de cada punto,
  // así está lista cuando el pasajero pide el servicio.
  useEffect(() => {
    if (step !== 'config') return;
    [pickupPoint, destPoint, ...stops].forEach((point) => lookupBarrio(point));
  }, [step, pickupPoint, destPoint, stops]);

  const handleServiceSelect = (key) => {
    if (key === 'carro') {
      const nextSuggested = calculateSuggestedFare({ vehicleType: 'carro', distanceKm: routeKm, durationMin: routeMin, historicalServices: recentServices });
      setForm((f) => ({ ...f, mode: 'movilidad', vehicle_type: 'carro', service_type: 'transporte', fare: nextSuggested }));
    } else if (key === 'moto') {
      const nextSuggested = calculateSuggestedFare({ vehicleType: 'moto', distanceKm: routeKm, durationMin: routeMin, historicalServices: recentServices });
      setForm((f) => ({ ...f, mode: 'movilidad', vehicle_type: 'moto', service_type: 'transporte', fare: nextSuggested }));
    } else {
      const nextSuggested = calculateSuggestedFare({ vehicleType: 'moto', distanceKm: routeKm, durationMin: routeMin, historicalServices: recentServices });
      setForm((f) => ({ ...f, mode: 'delivery', vehicle_type: 'moto', service_type: 'mensajeria', fare: nextSuggested }));
    }
  };
  const serviceKey = form.service_type === 'mensajeria' ? 'mensajeria' : form.vehicle_type === 'carro' ? 'carro' : 'moto';
  const selectedVehicle = VEHICLES.find((v) => v.key === serviceKey) || VEHICLES[0];
  const adjustFare = (delta) => set('fare', Math.max(FARE_MIN[form.vehicle_type], Number(form.fare || 0) + delta));

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true); setError('');
    try {
      let finalPickupAddr =
        pickupPlace?.name ||
        formatColombianStreetAddress(form.pickup_address) ||
        shortAddress(form.pickup_address) ||
        (form.pickup_address || '').trim();
      let finalPickupPoint =
        (pickupPlace?.lat != null && pickupPlace?.lng != null
          ? { lat: parseFloat(pickupPlace.lat), lng: parseFloat(pickupPlace.lng) }
          : null) ||
        pickupPoint ||
        coords || { lat: DEFAULT_CITY.lat, lng: DEFAULT_CITY.lng };

      if (!finalPickupAddr && finalPickupPoint) {
        const rev = await reverseGeocode(finalPickupPoint.lat, finalPickupPoint.lng);
        if (rev) {
          finalPickupAddr = rev;
          set('pickup_address', finalPickupAddr);
        } else {
          finalPickupAddr = 'Cra. 9 # 16-20';
        }
      }

      let finalDestAddr =
        destPlace?.name ||
        formatColombianStreetAddress(form.destination_address) ||
        shortAddress(form.destination_address) ||
        (form.destination_address || '').trim();
      let finalDestPoint =
        (destPlace?.lat != null && destPlace?.lng != null
          ? { lat: parseFloat(destPlace.lat), lng: parseFloat(destPlace.lng) }
          : null) || destPoint;

      if (!finalDestPoint || finalDestPoint.lat == null || finalDestPoint.lng == null) {
        setError('Selecciona una opción de la lista o marca el punto en el mapa.');
        setLoading(false);
        return;
      }

      if (finalDestPoint && !finalDestAddr) {
        const revDest = await reverseGeocode(finalDestPoint.lat, finalDestPoint.lng);
        if (revDest) {
          finalDestAddr = revDest;
          set('destination_address', finalDestAddr);
        }
      }
      if (!finalDestAddr) { setError('Indica a dónde vas.'); setLoading(false); return; }

      finalPickupPoint =
        normalizeColombiaCoords(finalPickupPoint?.lat, finalPickupPoint?.lng) || finalPickupPoint;
      finalDestPoint =
        normalizeColombiaCoords(finalDestPoint?.lat, finalDestPoint?.lng) || finalDestPoint;

      if (form.service_type === 'mensajeria' && !form.content_type) { setError('Selecciona qué vas a enviar.'); setLoading(false); return; }
      const cov = await isPickupInCoverage(finalPickupAddr);
      if (!cov.ok) { setError('Lo sentimos, no cubrimos esa zona. Contáctanos por WhatsApp.'); setLoading(false); return; }

      const isPointsRide = form.payment_method === 'redimido_puntos';
      const fareAmount = Number(form.fare || 5000);
      if (isPointsRide) {
        if (!user?.id) {
          setError('Inicia sesión para redimir tus puntos en una carrera.');
          setLoading(false);
          return;
        }
        const ptsAgg = await base44.entities.PointsTransaction.aggregate({
          query: { user_id: user.id },
          sum: 'amount',
        });
        const currentPoints = ptsAgg.rows?.[0]?.sum_amount || 0;
        if (currentPoints < fareAmount) {
          setError(
            `Puntos insuficientes: necesitas ${fareAmount.toLocaleString('es-CO')} puntos (${fmtCOP(fareAmount)}) y tienes ${currentPoints.toLocaleString('es-CO')} puntos.`
          );
          setLoading(false);
          return;
        }
      }

      const resolvedStops = [];
      for (const st of stops) {
        let addr = (st?.address || '').trim();
        let lat = st?.lat;
        let lng = st?.lng;
        if (!addr && (lat == null || lng == null)) continue;
        if (lat != null && lng != null && (!addr || isIncompleteStreetAddress(addr))) {
          const revStop = await reverseGeocode(lat, lng);
          if (revStop) addr = revStop;
        }
        if (addr && lat != null && lng != null) {
          resolvedStops.push({ address: addr, lat: parseFloat(lat), lng: parseFloat(lng) });
        }
      }

      // Barrio de la recogida, del destino y de cada parada (normalmente ya consultado al elegir la ruta)
      const [pickupBarrio, destBarrio, ...stopBarrios] = await Promise.all([
        barrioFor(finalPickupAddr, finalPickupPoint),
        barrioFor(finalDestAddr, finalDestPoint),
        ...resolvedStops.map((st) => barrioFor(st.address, st)),
      ]);
      stopBarrios.forEach((barrio, i) => {
        if (barrio) resolvedStops[i].barrio = barrio;
      });

      const clientPhoto = user?.photo_url || mobileProfile?.photo_url || null;
      const svc = await base44.entities.Service.create({
        client_name: form.client_name || 'Pasajero', client_phone: form.client_phone,
        client_photo: clientPhoto,
        pickup_address: finalPickupAddr, destination_address: finalDestAddr,
        ...(pickupBarrio ? { pickup_barrio: pickupBarrio } : {}),
        ...(destBarrio ? { destination_barrio: destBarrio } : {}),
        ...(resolvedStops.length > 0 ? { stops: resolvedStops } : {}),
        service_type: form.service_type, vehicle_type: form.vehicle_type, payment_method: form.payment_method,
        points_redeemed: isPointsRide ? fareAmount : 0,
        fare: fareAmount, origin: 'link', status: 'pendiente', rejected_by: [],
        ...(form.service_type === 'mensajeria' ? { content_type: form.content_type, content_description: form.content_description || null } : {}),
        ...(finalPickupPoint
          ? { pickup_lat: parseFloat(finalPickupPoint.lat), pickup_lng: parseFloat(finalPickupPoint.lng) }
          : {}),
        ...(finalDestPoint
          ? { destination_lat: parseFloat(finalDestPoint.lat), destination_lng: parseFloat(finalDestPoint.lng) }
          : {}),
        ...(driverInfo ? {
          passenger_count: driverInfo.passenger_count,
          need_extra_space: driverInfo.need_extra_space,
          need_charger: driverInfo.need_charger,
          with_pet: driverInfo.with_pet,
          driver_comment: driverInfo.driver_comment || null,
        } : {}),
      });
      if (isPointsRide && user?.id) {
        await base44.entities.PointsTransaction.create({
          user_id: user.id,
          user_name: form.client_name || user.display_name || user.full_name || 'Pasajero',
          amount: -fareAmount,
          type: 'canje',
          description: `Carrera redimida por puntos (${fmtCOP(fareAmount)}): ${finalPickupAddr} → ${finalDestAddr}`,
        });
      }
      redeemPresetFareRef.current = null;
      if (form.use_free_ride && freeRidesAvailable > 0 && form.service_type === 'transporte' && form.vehicle_type === 'moto') {
        try {
          const fr = await base44.functions.invoke('clubApplyFreeRide', { service_id: svc.id });
          toast({
            description: fr.data?.to_pay > 0
              ? `Viaje gratis aplicado. Pagas solo la diferencia: ${fmtCOP(fr.data.to_pay)}`
              : 'Viaje gratis aplicado: este viaje no te cuesta nada.',
          });
        } catch (e) {
          toast({ description: e?.response?.data?.error || 'No se pudo aplicar el viaje gratis.' });
        }
        set('use_free_ride', false);
      }
      backedOutRef.current = false;
      localStorage.setItem('next_active_service_id', svc.id);
      setActiveService(svc);
      setSearchParams({ service: svc.id });
      base44.functions.invoke('notifyNearbyDrivers', { service_id: svc.id }).catch(() => {});
      setBuscandoId(svc.id);
      setStep('buscando');
    } finally { setLoading(false); }
  };

  const continueRoute = async (modalData = null) => {
    const rawDest =
      modalData && typeof modalData.destinationAddress === 'string'
        ? modalData.destinationAddress
        : form.destination_address;
    const rawPickup =
      modalData && typeof modalData.pickupAddress === 'string'
        ? modalData.pickupAddress
        : form.pickup_address;
    const rawStops =
      modalData && Array.isArray(modalData.stops) ? modalData.stops : stops;

    let cleanDest =
      formatColombianStreetAddress(rawDest) ||
      shortAddress(rawDest) ||
      (rawDest || '').trim();

    if (!cleanDest && !destPoint && !modalData?.destPlace) {
      toast({ description: 'Escribe tu dirección o marca el punto de llegada para continuar.' });
      return;
    }

    let cleanPickup =
      formatColombianStreetAddress(rawPickup) ||
      shortAddress(rawPickup) ||
      (rawPickup || '').trim();

    if (cleanPickup) {
      setPickupTouched(true);
      pickupTouchedRef.current = true;
    }

    // Guardar de inmediato las direcciones exactas que escribió o seleccionó el usuario y cerrar el modal sin demora
    setForm((f) => ({
      ...f,
      pickup_address: cleanPickup || f.pickup_address,
      destination_address: cleanDest || f.destination_address,
    }));
    setRouteOpen(false);
    setStep('config');

    // Usar siempre las coordenadas guardadas de la sugerencia seleccionada o del pin en el mapa (sin geocodificar texto suelto)
    const basePt = pickupPoint || coords || { lat: DEFAULT_CITY.lat, lng: DEFAULT_CITY.lng };
    if (modalData?.pickupPlace?.lat != null && modalData?.pickupPlace?.lng != null) {
      const c =
        normalizeColombiaCoords(modalData.pickupPlace.lat, modalData.pickupPlace.lng) || {
          lat: parseFloat(modalData.pickupPlace.lat),
          lng: parseFloat(modalData.pickupPlace.lng),
        };
      setPickupPlace(modalData.pickupPlace);
      setPickupPoint(c);
      setPickupUnverified(Boolean(modalData.pickupPlace.needsConfirmation));
    } else if (!cleanPickup) {
      reverseGeocode(basePt.lat, basePt.lng).then((rev) => {
        if (rev) {
          set('pickup_address', rev);
          setPickupUnverified(false);
        }
      });
    } else if (pickupPlace?.lat != null && pickupPlace?.lng != null) {
      setPickupPoint({ lat: parseFloat(pickupPlace.lat), lng: parseFloat(pickupPlace.lng) });
      setPickupUnverified(Boolean(pickupPlace.needsConfirmation));
    }

    if (modalData?.destPlace?.lat != null && modalData?.destPlace?.lng != null) {
      const c =
        normalizeColombiaCoords(modalData.destPlace.lat, modalData.destPlace.lng) || {
          lat: parseFloat(modalData.destPlace.lat),
          lng: parseFloat(modalData.destPlace.lng),
        };
      setDestPlace(modalData.destPlace);
      setDestPoint(c);
      setDestUnverified(Boolean(modalData.destPlace.needsConfirmation));
    } else if (destPlace?.lat != null && destPlace?.lng != null) {
      setDestPoint({ lat: parseFloat(destPlace.lat), lng: parseFloat(destPlace.lng) });
      setDestUnverified(Boolean(destPlace.needsConfirmation));
    }

    if (rawStops.length > 0) {
      const validStops = rawStops
        .filter((st) => st?.lat != null && st?.lng != null && (st?.address || '').trim())
        .map((st) => ({
          ...st,
          address: (st.address || '').trim(),
          lat: parseFloat(st.lat),
          lng: parseFloat(st.lng),
          unverified: false,
          needsSelection: false,
        }));
      setStops(validStops);
    }
    setMapFitKey((k) => k + 1);
  };

  const hideMapPanels = mapInteracting || mapExpanded;

  return (
    <div className="pasajero-theme relative h-[100dvh] w-full max-w-md mx-auto overflow-hidden bg-card flex flex-col">
      {/* Mapa de fondo a pantalla completa: tocar cualquier parte del mapa alterna la vista ampliada */}
      <div className="absolute inset-0 z-0">
        <LocationMap
          gps={coords}
          pickup={
            step === 'buscando' && activeService?.pickup_lat != null && activeService?.pickup_lng != null
              ? { lat: Number(activeService.pickup_lat), lng: Number(activeService.pickup_lng) }
              : pickupPoint
          }
          destination={
            step === 'buscando' && activeService?.destination_lat != null && activeService?.destination_lng != null
              ? { lat: Number(activeService.destination_lat), lng: Number(activeService.destination_lng) }
              : step === 'home' && !pickMode && !routeOpen
              ? null
              : destPoint
          }
          stops={
            step === 'buscando' && Array.isArray(activeService?.stops) && activeService.stops.length > 0
              ? activeService.stops
              : step === 'home' && !pickMode && !routeOpen
              ? []
              : stops
          }
          pickupAddress={
            step === 'buscando' && activeService?.pickup_address
              ? activeService.pickup_address
              : form.pickup_address
          }
          destinationAddress={
            step === 'buscando' && activeService?.destination_address
              ? activeService.destination_address
              : step === 'home' && !pickMode && !routeOpen
              ? ''
              : form.destination_address
          }
          resolvingPickup={resolvingPickup}
          resolvingDestination={resolvingDest}
          vehicleType={form.vehicle_type}
          onRouteInfo={(info) => { setRouteKm(info?.distanceKm ?? null); setRouteMin(info?.durationMin ?? null); }}
          pickMode={pickMode}
          locked={(step === 'config' || step === 'buscando') && !pickMode}
          onMapClick={handleMapClick}
          onPickupDrag={step === 'config' || step === 'buscando' ? undefined : handlePickupDrag}
          onDestinationDrag={step === 'config' || step === 'buscando' ? undefined : handleDestDrag}
          onStopDrag={step === 'config' || step === 'buscando' ? undefined : handleStopDrag}
          onPinBubbleClick={
            step === 'config' || step === 'buscando'
              ? undefined
              : (field) => {
                  setRouteInitialField(typeof field === 'string' ? field : 'pickup');
                  setRouteOpen(true);
                }
          }
          onInteractStart={() => setMapInteracting(true)}
          onInteractEnd={() => setMapInteracting(false)}
          hideRouteBadge={step === 'config' || step === 'buscando'}
          hidePickupPin={false}
          fitKey={mapFitKey}
          className="h-full w-full rounded-none border-0"
        />
      </div>

      {!pickMode && step === 'home' && (
        <PasajeroTopHeader hidden={hideMapPanels} onOpenDrawer={() => setDrawerOpen(true)} />
      )}

      <PasajeroMapCenterArea
        pickMode={pickMode}
        step={step}
        hidePanels={hideMapPanels}
        isDragging={mapInteracting}
        stops={stops}
        routeKm={routeKm}
        routeMin={calibratedRouteMin ?? routeMin}
        pickupAddress={form.pickup_address}
        destinationAddress={form.destination_address}
        pickupUnverified={pickupUnverified}
        destUnverified={destUnverified}
        onBackFromPickMode={() => {
          setPickMode(null);
          if (pickModeOriginRef.current === 'route') setRouteOpen(true);
        }}
        onConfirmPickMode={() => {
          setPickMode(null);
          if (pickModeOriginRef.current === 'route') setRouteOpen(true);
        }}
        onLocateMe={
          step === 'config' && !pickMode
            ? () => setMapFitKey((k) => k + 1)
            : locateMe
        }
        onOpenDrawer={() => setDrawerOpen(true)}
        onOpenRoute={() => {
          setRouteInitialField('pickup');
          setRouteOpen(true);
        }}
        onPickMode={(m) => {
          pickModeOriginRef.current = 'config';
          setPickMode(m);
          setMapFitKey((k) => k + 1);
        }}
      />

      {!pickMode && step === 'home' && (
        <PasajeroHomeBottomSheet
          hidden={hideMapPanels}
          activeService={activeService}
          serviceKey={serviceKey}
          onSelectService={handleServiceSelect}
          pickupAddress={form.pickup_address}
          destinationAddress={form.destination_address}
          onOpenRoute={() => {
            setRouteInitialField('destination');
            setRouteOpen(true);
          }}
          onResumeActiveService={() => {
            backedOutRef.current = false;
            setBuscandoId(activeService.id);
            setStep(activeService.status === 'pendiente' ? 'buscando' : 'seguimiento');
          }}
        />
      )}

      {!pickMode && !routeOpen && step === 'home' && !hideMapPanels && (
        <div className="relative z-[2050] flex-shrink-0">
          <PasajeroBottomNav
            active={showHistorial ? 'viajes' : showNotif ? 'notif' : showPerfil ? 'perfil' : 'inicio'}
            hasNotifs={notifCount > 0}
            onHome={() => {
              openPassengerSubView(null);
              setStep('home');
            }}
            onViajes={() => openPassengerSubView('historial')}
            onNotificaciones={() => openPassengerSubView('notif')}
            onPerfil={() => openPassengerSubView('perfil')}
          />
        </div>
      )}

      {!pickMode && step === 'config' && (
        <PasajeroConfigSheet
          onClose={resetRouteToMyLocation}
          mapInteracting={hideMapPanels}
          submit={submit}
          selectedVehicle={selectedVehicle}
          suggestedFare={suggestedFare}
          form={form}
          set={set}
          pickupPlace={pickupPlace}
          destPlace={destPlace}
          stops={stops}
          onEditStops={() => {
            setRouteInitialField('destination');
            setRouteOpen(true);
          }}
          onEditPickup={() => {
            setRouteInitialField('pickup');
            setRouteOpen(true);
          }}
          onEditDestination={() => {
            setRouteInitialField('destination');
            setRouteOpen(true);
          }}
          pickupUnverified={pickupUnverified}
          destUnverified={destUnverified}
          onAdjustOnMap={(target) => {
            pickModeOriginRef.current = 'config';
            setPickMode(typeof target === 'string' ? target : destUnverified ? 'destination' : 'pickup');
            setMapFitKey((k) => k + 1);
          }}
          contentTypes={CONTENT_TYPES}
          adjustFare={adjustFare}
          fareMin={FARE_MIN}
          error={error}
          setShowPay={setShowPay}
          payments={PAYMENTS}
          loading={loading}
          setInfoOpen={setInfoOpen}
          freeRidesAvailable={freeRidesAvailable}
        />
      )}

      {step === 'buscando' && buscandoId && (
        <BuscandoConductores
          serviceId={buscandoId}
          mapExpanded={hideMapPanels}
          onAssigned={() => {
            backedOutRef.current = false;
            setStep('seguimiento');
          }}
          onLocateMe={() => setMapFitKey((k) => k + 1)}
          onOpenDrawer={() => setDrawerOpen(true)}
          onCancel={resetRouteToMyLocation}
        />
      )}

      {step === 'seguimiento' && buscandoId && (
        <SeguimientoConductor
          serviceId={buscandoId}
          onFinish={(opts) => {
            if (opts?.clearActive) {
              resetRouteToMyLocation();
            } else {
              backedOutRef.current = true;
              setStep('home');
            }
          }}
          onReassigned={() => {
            backedOutRef.current = false;
            setStep('buscando');
          }}
        />
      )}

      {step === 'home' && !activeService && !showHistorial && !routeOpen && !pickMode && pendingClientRating && (
        <ServiceRatingModal
          serviceId={pendingClientRating.id}
          role="cliente"
          targetName={pendingClientRating.mobile_name}
          targetPhoto={pendingClientRating.mobile_photo}
          onDone={() => {
            localStorage.setItem(`next_dismissed_rating_${pendingClientRating.id}`, '1');
            setPendingClientRating(null);
          }}
        />
      )}

      {drawerOpen && (
        <PasajeroDrawer
          user={user}
          mobileProfile={mobileProfile}
          onClose={() => setDrawerOpen(false)}
          onBilletera={() => openPassengerSubView('billetera')}
          onHistorial={() => openPassengerSubView('historial')}
          onValoraciones={() => openPassengerSubView('valoraciones')}
          onPuntos={() => openPassengerSubView('puntos')}
          onObjetos={() => openPassengerSubView('objetos')}
          onNotificaciones={() => openPassengerSubView('notif')}
          onPerfil={() => openPassengerSubView('perfil')}
          onCompartir={() => openPassengerSubView('compartir')}
          onSeguridad={() => openPassengerSubView('seguridad')}
          onConfiguracion={() => openPassengerSubView('config')}
          onAyuda={() => openPassengerSubView('ayuda')}
          onSoporte={() => openPassengerSubView('soporte')}
        />
      )}

      <PasajeroSubViews
        user={user}
        mobileProfile={mobileProfile}
        setMobileProfile={setMobileProfile}
        setForm={setForm}
        buscandoId={buscandoId}
        activeService={activeService}
        setBuscandoId={setBuscandoId}
        setActiveService={setActiveService}
        backedOutRef={backedOutRef}
        setSearchParams={setSearchParams}
        setStep={setStep}
        setRouteOpen={setRouteOpen}
        onResetRoute={resetRouteToMyLocation}
        redeemPresetFareRef={redeemPresetFareRef}
        fareMin={FARE_MIN}
        openSubView={openPassengerSubView}
        goBackSubView={goBackPassengerSubView}
        showHistorial={showHistorial}
        setShowHistorial={setShowHistorial}
        showBilletera={showBilletera}
        setShowBilletera={setShowBilletera}
        showPuntos={showPuntos}
        setShowPuntos={setShowPuntos}
        showObjetos={showObjetos}
        setShowObjetos={setShowObjetos}
        showNotif={showNotif}
        setShowNotif={setShowNotif}
        setNotifCount={setNotifCount}
        showCompartir={showCompartir}
        setShowCompartir={setShowCompartir}
        showSeguridad={showSeguridad}
        setShowSeguridad={setShowSeguridad}
        showConfig={showConfig}
        setShowConfig={setShowConfig}
        showAyuda={showAyuda}
        setShowAyuda={setShowAyuda}
        showSoporte={showSoporte}
        setShowSoporte={setShowSoporte}
        showPerfil={showPerfil}
        setShowPerfil={setShowPerfil}
        showValoraciones={showValoraciones}
      />

      {infoOpen && (
        <InfoConductorModal
          initial={driverInfo}
          onSubmit={(info) => { setDriverInfo(info); setInfoOpen(false); }}
          onClose={() => setInfoOpen(false)}
        />
      )}
      {showPay && (
        <PaymentMethodModal
          value={form.payment_method}
          onSelect={(v) => { set('payment_method', v); setShowPay(false); }}
          onClose={() => setShowPay(false)}
        />
      )}
      {routeOpen && (
        <RutaModal
          initialActiveField={routeInitialField}
          pickupAddress={form.pickup_address}
          destinationAddress={form.destination_address}
          pickupPlace={pickupPlace}
          destPlace={destPlace}
          userCoords={coords}
          stops={stops}
          onPickupChange={(v) => {
            setPickupTouched(true);
            setPickupPlace(null);
            set('pickup_address', v);
          }}
          onDestinationChange={(v) => {
            setDestPlace(null);
            set('destination_address', v);
          }}
          onUseCurrentLocation={locateMe}
          onAddStop={() =>
            setStops((prev) => (prev.length >= 3 ? prev : [...prev, { address: '', lat: null, lng: null, unverified: true }]))
          }
          onRemoveStop={(idx) => setStops((prev) => prev.filter((_, i) => i !== idx))}
          onStopChange={(idx, val) => {
            setStops((prev) => prev.map((s, i) => (i === idx ? { ...s, address: val, unverified: true } : s)));
          }}
          onStopSelect={(idx, p) => {
            setStops((prev) =>
              prev.map((s, i) =>
                i === idx
                  ? {
                      address: p.name,
                      place_id: p.place_id,
                      formatted_address: p.formatted_address,
                      lat: parseFloat(p.lat),
                      lng: parseFloat(p.lng),
                      unverified: Boolean(p.needsConfirmation),
                    }
                  : s
              )
            );
          }}
          onPickupSelect={(p) => {
            skipPickupGeoRef.current = true;
            setPickupTouched(true);
            setPickupPlace(p);
            setPickupUnverified(Boolean(p.needsConfirmation));
            set('pickup_address', p.name);
            setPickupPoint({ lat: parseFloat(p.lat), lng: parseFloat(p.lng) });
          }}
          onDestinationSelect={(p) => {
            skipDestGeoRef.current = true;
            setDestPlace(p);
            setDestUnverified(Boolean(p.needsConfirmation));
            set('destination_address', p.name);
            setDestPoint({ lat: parseFloat(p.lat), lng: parseFloat(p.lng) });
          }}
          pickupUnverified={pickupUnverified}
          destUnverified={destUnverified}
          onPickMode={(m) => {
            if (m?.startsWith('stop_')) {
              const idx = Number(m.replace('stop_', ''));
              const existing = stops[idx];
              if (!existing || existing.lat == null || existing.lng == null) {
                const startPt = pickupPoint || coords || { lat: DEFAULT_CITY.lat, lng: DEFAULT_CITY.lng };
                setStops((prev) =>
                  prev.map((s, i) => (i === idx ? { ...s, lat: startPt.lat, lng: startPt.lng, unverified: false } : s))
                );
                reverseGeocode(startPt.lat, startPt.lng).then((addr) => {
                  if (addr) {
                    setStops((prev) =>
                      prev.map((s, i) => (i === idx ? { ...s, address: addr, unverified: false } : s))
                    );
                  }
                });
              }
            } else if (m === 'destination' && !destPoint) {
              const startDest = pickupPoint || coords || { lat: DEFAULT_CITY.lat, lng: DEFAULT_CITY.lng };
              setDestPoint(startDest);
              reverseGeocode(startDest.lat, startDest.lng).then((addr) => {
                if (addr) {
                  skipDestGeoRef.current = true;
                  set('destination_address', addr);
                  setDestPlace({
                    place_id: `pin_dest_${startDest.lat}_${startDest.lng}`,
                    name: addr,
                    formatted_address: `${addr}, Valledupar, Cesar, Colombia`,
                    lat: startDest.lat,
                    lng: startDest.lng,
                    location_type: 'ROOFTOP',
                    isPrecise: true,
                    needsConfirmation: false,
                    verified: true,
                  });
                }
              });
            }
            pickModeOriginRef.current = 'route';
            setPickMode(m);
            setMapFitKey((k) => k + 1);
          }}
          onClose={() => setRouteOpen(false)}
          onContinue={continueRoute}
          routeKm={routeKm}
        />
      )}

      {step === 'home' && (
        <NextFloatingBubble
          role="pasajero"
          isConnected={true}
          activeService={activeService}
          pendingCount={0}
          onReturnToActive={() => {
          setDrawerOpen(false);
          setShowHistorial(false);
          setShowNotif(false);
          setShowPerfil(false);
          setShowBilletera(false);
          setShowPuntos(false);
          setShowObjetos(false);
          setShowCompartir(false);
          setShowSeguridad(false);
          setShowConfig(false);
          setShowAyuda(false);
          setShowSoporte(false);
          if (activeService) {
            backedOutRef.current = false;
            setBuscandoId(activeService.id);
            setStep(activeService.status === 'pendiente' ? 'buscando' : 'seguimiento');
          }
        }}
        />
      )}
    </div>
  );
}
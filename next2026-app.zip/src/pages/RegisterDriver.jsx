import React, { useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import {
  Mail, Lock, User, Phone, Loader2, Camera, Eye, EyeOff,
  CreditCard, Car, Bike, ArrowRight, X
} from 'lucide-react';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';
import { toast } from '@/components/ui/use-toast';
import ThemeToggle from '@/components/ThemeToggle';
import NextLogo from '@/components/NextLogo';
import { uploadRegistrationPhoto } from '@/lib/image';

const inputCls = 'w-full bg-[#181818] border border-[#2a2a2a] rounded-2xl pl-12 pr-4 h-14 text-white placeholder:text-[#6B7280] focus:outline-none focus:border-[#1E6BFF] transition-colors text-sm';

export default function RegisterDriver() {
  const { user } = useAuth();
  const isLoggedIn = !!user;

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [cedula, setCedula] = useState('');
  const [phone, setPhone] = useState('');
  const [vehicleType, setVehicleType] = useState('moto');
  const [vehicleModel, setVehicleModel] = useState('');
  const [plate, setPlate] = useState('');
  const [cedulaPhoto, setCedulaPhoto] = useState('');
  const [cedulaPreview, setCedulaPreview] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [photoLoading, setPhotoLoading] = useState(false);
  const [showOtp, setShowOtp] = useState(false);
  const [otpCode, setOtpCode] = useState('');

  const photoInputRef = useRef(null);

  const handlePhoto = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPhotoLoading(true);
    setError('');
    try {
      const { file_uri, previewUrl } = await uploadRegistrationPhoto(file, 1024, 0.78);
      setCedulaPhoto(file_uri);
      setCedulaPreview(previewUrl);
    } catch (err) {
      setError('No se pudo procesar la foto. Intenta de nuevo.');
    } finally {
      setPhotoLoading(false);
      if (photoInputRef.current) photoInputRef.current.value = '';
    }
  };

  const createProfile = async () => {
    setError('');
    setLoading(true);
    try {
      await base44.functions.invoke('registerDriver', {
        name: name.trim(),
        cedula: cedula.trim(),
        phone: phone.trim(),
        plate: plate.trim().toUpperCase(),
        vehicle_type: vehicleType,
        vehicle_model: vehicleModel.trim(),
        verification_photo: cedulaPhoto,
      });
      toast({ title: '¡Registro exitoso!', description: 'Ya puedes empezar a recibir servicios.' });
      window.location.href = '/login';
    } catch (err) {
      const msg =
        err?.response?.data?.error ||
        err?.data?.error ||
        err?.message ||
        'Error al registrar el perfil de conductor';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (!name.trim() || !plate.trim()) {
      setError('Nombre y placa son obligatorios');
      return;
    }
    if (!cedulaPhoto) {
      setError('La foto de la cédula es obligatoria');
      return;
    }

    if (isLoggedIn) {
      await createProfile();
      return;
    }

    if (password.length < 6) {
      setError('La contraseña debe tener al menos 6 caracteres');
      return;
    }

    setLoading(true);
    try {
      await base44.auth.register({ email, password });
      setShowOtp(true);
    } catch (err) {
      setError(err.message || 'Error al crear la cuenta');
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async () => {
    setError('');
    setLoading(true);
    try {
      const result = await base44.auth.verifyOtp({ email, otpCode });
      if (result?.access_token) {
        base44.auth.setToken(result.access_token);
      }
      await createProfile();
    } catch (err) {
      setError(err.message || 'Código de verificación inválido');
    } finally {
      setLoading(false);
    }
  };

  // Paso OTP (usuarios nuevos) — mismo tema NEXT
  if (showOtp) {
    return (
      <div className="theme-day min-h-screen bg-background flex flex-col px-6 py-8">
        <div className="flex justify-end mb-8">
          <ThemeToggle />
        </div>
        <div className="flex-1 flex flex-col items-center justify-center">
          <NextLogo size="md" className="mb-10" />
          <h1 className="text-white text-2xl font-bold mb-2">Verifica tu correo</h1>
          <p className="text-[#9CA3AF] text-sm mb-8 text-center">Enviamos un código a {email}</p>
          {error && (
            <div className="mb-6 p-3 rounded-xl bg-red-500/10 text-red-400 text-sm w-full max-w-sm">{error}</div>
          )}
          <div className="flex justify-center mb-8">
            <InputOTP maxLength={6} value={otpCode} onChange={setOtpCode} autoFocus autoComplete="one-time-code">
              <InputOTPGroup>
                <InputOTPSlot index={0} />
                <InputOTPSlot index={1} />
                <InputOTPSlot index={2} />
                <InputOTPSlot index={3} />
                <InputOTPSlot index={4} />
                <InputOTPSlot index={5} />
              </InputOTPGroup>
            </InputOTP>
          </div>
          <button
            onClick={handleVerify}
            disabled={loading || otpCode.length < 6}
            className="w-full max-w-sm h-14 bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-black font-bold rounded-2xl flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {loading ? (
              <><Loader2 className="w-5 h-5 animate-spin" /> Verificando...</>
            ) : (
              <>Verificar y registrar <ArrowRight className="w-5 h-5" /></>
            )}
          </button>
        </div>
      </div>
    );
  }

  // Formulario de registro
  return (
    <div className="theme-day min-h-screen bg-background flex flex-col px-6 py-8 max-w-md mx-auto">
      <div className="flex justify-end mb-6">
        <ThemeToggle />
      </div>

      <div className="flex justify-center mb-8">
        <NextLogo size="sm" />
      </div>

      <form onSubmit={handleSubmit} className="space-y-3.5 flex-1">
        {error && (
          <div className="p-3 rounded-xl bg-red-500/10 text-red-400 text-sm">{error}</div>
        )}

        {/* Nombre completo */}
        <div className="relative">
          <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B7280]" />
          <input
            className={inputCls}
            placeholder="Nombre completo"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>

        {/* Número de cédula */}
        <div className="relative">
          <CreditCard className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B7280]" />
          <input
            className={inputCls}
            placeholder="Número de cédula"
            value={cedula}
            onChange={(e) => setCedula(e.target.value)}
          />
        </div>

        {!isLoggedIn && (
          <>
            {/* Correo electrónico */}
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B7280]" />
              <input
                type="email"
                className={inputCls}
                placeholder="Correo electrónico"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            {/* Contraseña */}
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B7280]" />
              <input
                type={showPassword ? 'text' : 'password'}
                className={inputCls + ' pr-12'}
                placeholder="Contraseña"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-[#6B7280]"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </>
        )}

        {/* Número de celular */}
        <div className="relative">
          <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B7280]" />
          <input
            type="tel"
            className={inputCls}
            placeholder="Número de celular"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
          />
        </div>

        {/* Tipo de vehículo */}
        <div>
          <p className="text-[#9CA3AF] text-sm mb-2">Tipo de vehículo</p>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setVehicleType('moto')}
              className={`flex items-center justify-center gap-2 h-12 rounded-2xl border-2 transition-all ${vehicleType === 'moto' ? 'border-[#1E6BFF] bg-[#1E6BFF]/10' : 'border-[#2a2a2a] bg-[#181818]'}`}
            >
              <Bike className={`w-5 h-5 ${vehicleType === 'moto' ? 'text-[#1E6BFF]' : 'text-[#6B7280]'}`} />
              <span className={`font-medium text-sm ${vehicleType === 'moto' ? 'text-white' : 'text-[#6B7280]'}`}>Moto</span>
            </button>
            <button
              type="button"
              onClick={() => setVehicleType('carro')}
              className={`flex items-center justify-center gap-2 h-12 rounded-2xl border-2 transition-all ${vehicleType === 'carro' ? 'border-[#1E6BFF] bg-[#1E6BFF]/10' : 'border-[#2a2a2a] bg-[#181818]'}`}
            >
              <Car className={`w-5 h-5 ${vehicleType === 'carro' ? 'text-[#1E6BFF]' : 'text-[#6B7280]'}`} />
              <span className={`font-medium text-sm ${vehicleType === 'carro' ? 'text-white' : 'text-[#6B7280]'}`}>Carro</span>
            </button>
          </div>
        </div>

        {/* Modelo del vehículo */}
        <div className="relative">
          <Car className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B7280]" />
          <input
            className={inputCls}
            placeholder="Modelo del vehículo"
            value={vehicleModel}
            onChange={(e) => setVehicleModel(e.target.value)}
          />
        </div>

        {/* Placa del vehículo */}
        <div className="relative">
          <CreditCard className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B7280]" />
          <input
            className={inputCls}
            placeholder="Placa del vehículo"
            value={plate}
            onChange={(e) => setPlate(e.target.value)}
            required
          />
        </div>

        {/* Registro fotográfico de la cédula */}
        {cedulaPhoto ? (
          <div className="relative" data-photo-picker="true">
            <img src={cedulaPreview || cedulaPhoto} alt="Cédula" className="w-full h-40 object-cover rounded-2xl border-2 border-[#1E6BFF]" />
            <button
              type="button"
              onClick={() => { setCedulaPhoto(''); setCedulaPreview(''); }}
              className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1.5 shadow-lg z-20"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div
            data-photo-picker="true"
            className={`relative overflow-hidden w-full h-40 flex flex-col items-center justify-center gap-2 border-2 border-dashed border-[#1E6BFF] rounded-2xl bg-transparent transition-colors cursor-pointer ${photoLoading ? 'opacity-50 pointer-events-none' : 'hover:bg-[#1E6BFF]/5'}`}
          >
            {photoLoading ? (
              <Loader2 className="w-8 h-8 animate-spin text-[#1E6BFF]" />
            ) : (
              <Camera className="w-8 h-8 text-[#1E6BFF]" />
            )}
            <span className="font-bold text-white">Registro fotográfico de la cédula</span>
            <span className="text-sm text-[#6B7280]">Toma o sube la foto de tu documento</span>
            <input
              ref={photoInputRef}
              type="file"
              accept="image/*"
              onChange={handlePhoto}
              onClick={() => {
                if (typeof window !== 'undefined') {
                  window.__nextFilePickerOpenUntil = Date.now() + 60000;
                }
              }}
              disabled={photoLoading}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
            />
          </div>
        )}

        {/* Crear cuenta */}
        <button
          type="submit"
          disabled={loading || !cedulaPhoto}
          className="w-full h-14 bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-black font-bold rounded-2xl flex items-center justify-center gap-2 disabled:opacity-50 mt-2"
        >
          {loading ? (
            <><Loader2 className="w-5 h-5 animate-spin" /> Registrando...</>
          ) : (
            'Crear cuenta'
          )}
        </button>

        <p className="text-center text-sm text-[#9CA3AF] pt-2">
          ¿Ya tienes cuenta?{' '}
          <Link to="/" className="text-[#1E6BFF] font-medium">Inicia sesión</Link>
        </p>
      </form>
    </div>
  );
}
import React from 'react';
import { useNavigate, useLocation, Navigate } from 'react-router-dom';
import { Fingerprint, ShieldCheck } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import OnboardingCard from '@/components/OnboardingCard';

export default function QuickLogin() {
  const navigate = useNavigate();
  const location = useLocation();
  const { role } = location.state || {};

  if (!role) {
    return <Navigate to="/" replace />;
  }

  const goToDestination = () => {
    if (role === 'conductor') {
      navigate('/registro-movil');
    } else {
      navigate('/login');
    }
  };

  const handleActivate = () => {
    toast({ title: 'Ingreso rápido activado', description: 'La próxima vez entrarás más rápido.' });
    goToDestination();
  };

  return (
    <OnboardingCard className="justify-center">
      {/* Ícono de huella */}
      <div className="flex justify-center mb-8">
        <div className="w-20 h-20 rounded-2xl border-2 border-[#00E5FF] flex items-center justify-center bg-gray-100 dark:bg-[#0D0D0D]">
          <Fingerprint className="w-10 h-10 text-[#00E5FF]" />
        </div>
      </div>

      {/* Texto */}
      <h1 className="text-gray-900 dark:text-white text-2xl font-bold text-center mb-2">Ingreso rápido y seguro</h1>
      <p className="text-gray-500 dark:text-[#A0A0A0] text-center text-sm mb-10">Ya no tendrás que esperar el código cada vez</p>

      {/* Puntos informativos */}
      <div className="space-y-5 mb-10">
        <div className="flex items-start gap-3">
          <Fingerprint className="w-5 h-5 text-[#00E5FF] flex-shrink-0 mt-0.5" />
          <p className="text-gray-900 dark:text-white text-sm leading-relaxed">
            Ingresa con tu huella, rostro o PIN.{' '}
            <span className="text-gray-500 dark:text-[#8B8C94]">No guardamos ninguno de estos datos.</span>
          </p>
        </div>
        <div className="flex items-start gap-3">
          <ShieldCheck className="w-5 h-5 text-[#00E5FF] flex-shrink-0 mt-0.5" />
          <p className="text-gray-900 dark:text-white text-sm leading-relaxed">
            Tu clave solo se guarda en este dispositivo,{' '}
            <span className="text-gray-500 dark:text-[#8B8C94]">de forma segura.</span>
          </p>
        </div>
      </div>

      {/* Botón activar */}
      <button
        onClick={handleActivate}
        className="w-full h-14 bg-[#00E5FF] text-black font-bold rounded-2xl mb-4"
      >
        Activar ingreso rápido
      </button>

      <button onClick={goToDestination} className="text-gray-500 dark:text-[#A0A0A0] text-sm text-center">
        Ahora no
      </button>
    </OnboardingCard>
  );
}
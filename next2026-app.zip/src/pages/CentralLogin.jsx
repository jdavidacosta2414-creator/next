import React, { useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { Mail, Lock, Eye, EyeOff, ShieldCheck, Loader2, ArrowRight, Headset } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';

// Login dedicado de Central: página web independiente con su propio acceso,
// conectada a la misma base de la aplicación. Solo admite cuentas con rol
// central (o admin/superadmin); cualquier otra cuenta recibe un error claro.
export default function CentralLogin() {
  const navigate = useNavigate();
  const { user, isAuthenticated, checkUserAuth } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Si ya hay sesión válida para Central, ir directo al panel.
  if (isAuthenticated && user) {
    if (['central', 'admin', 'superadmin'].includes(user.role)) return <Navigate to="/central" replace />;
    // Sesión de otro rol: no la usamos aquí, mostramos el formulario.
  }

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await base44.auth.loginViaEmailPassword(email, password);
      await checkUserAuth();
      // checkUserAuth actualiza el contexto; leemos el rol fresco del usuario.
      const me = await base44.auth.me();
      if (!['central', 'admin', 'superadmin'].includes(me.role)) {
        // La cuenta no tiene acceso a Central: cerrar sesión y mostrar error.
        await base44.auth.logout();
        throw new Error('Esta cuenta no tiene acceso a Central.');
      }
      navigate('/central', { replace: true });
    } catch (err) {
      const msg = (err.message || '').toLowerCase();
      if (msg.includes('no tiene acceso')) {
        setError(err.message);
      } else if (msg.includes('not found') || msg.includes('no existe') || msg.includes('invalid')) {
        setError('Correo o contraseña incorrectos.');
      } else {
        setError(err.message || 'No se pudo iniciar sesión.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex bg-background text-foreground">
      {/* Panel izquierdo: branding operativo de Central */}
      <div className="hidden md:flex md:w-2/5 lg:w-1/3 relative flex-col justify-between p-10"
        style={{ background: 'linear-gradient(160deg, #0a0d11 0%, #0a1a3a 45%, #0a3a5a 100%)' }}>
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #00E5FF, #1E6BFF)' }}>
            <svg viewBox="0 0 48 48" className="w-7 h-7">
              <path d="M15 7 L29 24 L15 41 L15 34 L22 24 L15 14 Z" fill="white" />
              <path d="M27 7 L41 24 L27 41 L27 34 L34 24 L27 14 Z" fill="white" opacity="0.85" />
            </svg>
          </div>
          <div>
            <p className="text-[10px] text-white/60 uppercase tracking-[0.25em] font-medium">Transporte y mensajería</p>
            <p className="text-2xl font-bold text-white tracking-wide">NEXT</p>
          </div>
        </div>

        <div>
          <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-5" style={{ backgroundColor: 'rgba(0,229,255,0.12)' }}>
            <Headset className="w-7 h-7 text-[#00E5FF]" />
          </div>
          <h1 className="text-3xl lg:text-4xl font-bold text-white leading-tight mb-3">
            Central de<br />operaciones.
          </h1>
          <p className="text-white/70 text-sm leading-relaxed max-w-xs">
            Despacha servicios, supervisa conductores en vivo y gestiona recargas y tarifas desde un solo lugar.
          </p>
        </div>

        <p className="text-white/40 text-xs">© {new Date().getFullYear()} NEXT. Todos los derechos reservados.</p>
      </div>

      {/* Panel derecho: formulario de acceso */}
      <div className="flex-1 flex items-center justify-center p-6 lg:p-10">
        <div className="w-full max-w-sm">
          <p className="text-xs text-muted-foreground uppercase tracking-[0.2em] font-medium mb-2">Central de operaciones</p>
          <h2 className="text-3xl font-bold text-foreground mb-1">Ingreso de Central</h2>
          <p className="text-muted-foreground text-sm mb-8">Usa tu correo y contraseña de Central.</p>

          <form onSubmit={handleLogin} className="space-y-4">
            {error && (
              <div className="p-3 rounded-xl bg-destructive/15 text-destructive text-sm text-center">{error}</div>
            )}

            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Correo</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-muted-foreground" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full h-12 rounded-xl border border-border bg-card pl-11 pr-4 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/10 transition"
                  placeholder="central@next.com"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Contraseña</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-muted-foreground" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full h-12 rounded-xl border border-border bg-card pl-11 pr-11 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/10 transition"
                  placeholder="••••••••"
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showPassword ? <EyeOff className="w-4.5 h-4.5" /> : <Eye className="w-4.5 h-4.5" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full h-12 rounded-xl text-white font-bold text-sm flex items-center justify-center gap-2 disabled:opacity-50 transition shadow-lg"
              style={{ background: 'linear-gradient(135deg, #1E6BFF, #0091D5)' }}
            >
              {loading ? <><Loader2 className="w-5 h-5 animate-spin" /> Ingresando...</> : <><ShieldCheck className="w-5 h-5" /> Iniciar sesión <ArrowRight className="w-4 h-4" /></>}
            </button>
          </form>

          <p className="text-center text-xs text-gray-400 mt-6">Acceso restringido a cuentas de Central autorizadas.</p>
        </div>
      </div>
    </div>
  );
}
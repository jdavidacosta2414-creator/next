import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeft, Mail, Lock, Eye, EyeOff, Gift, Loader2, ArrowRight, ShieldCheck, Info, User } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import ProfilePhotoUpload from '@/components/shared/ProfilePhotoUpload';
import OtpVerificationCard, { registerOrSendOtp, checkDatabaseRegistration } from '@/components/shared/OtpVerificationCard';
import { getStoredReferralCode, registerReferralClaim, REFERRAL_POINTS } from '@/lib/referrals';
import { useBackButton } from '@/hooks/useBackButton';

const fieldCls = 'w-full bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-2xl pl-12 pr-4 h-14 text-gray-900 dark:text-white placeholder:text-gray-400 dark:placeholder:text-[#6B6B6B] focus:outline-none focus:border-[#1E6BFF] dark:focus:border-[#00E5FF] transition-colors text-sm';

export default function VinculatePasajero() {
  const navigate = useNavigate();
  const location = useLocation();
  const phone = location.state?.phone || '';
  const [photo, setPhoto] = useState('');
  const [name, setName] = useState('');
  const [referral, setReferral] = useState(() => getStoredReferralCode());
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState('form');
  const [otpCode, setOtpCode] = useState('');

  useBackButton(() => {
    if (step === 'otp') {
      setStep('form');
      return true;
    }
    navigate('/vinculate', { state: { phone } });
    return true;
  }, true);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const cleanEmail = email.trim().toLowerCase();
    if (!name.trim()) { setError('Ingresa tu nombre completo'); return; }
    if (!cleanEmail) { setError('Ingresa tu correo electrónico'); return; }
    if (password.length < 6) { setError('La contraseña debe tener al menos 6 caracteres'); return; }
    setLoading(true);
    try {
      const result = await registerOrSendOtp(cleanEmail, password, { scope: 'pasajero' });
      if (result?.status === 'signed_in') {
        // El correo ya tenía cuenta en NEXT: entra directo con ella.
        try {
          window.localStorage.setItem('next_user_explicit_mode', 'pasajero');
        } catch {}
        window.location.href = '/cliente';
        return;
      }
      setEmail(cleanEmail);
      setOtpCode('');
      setStep('otp');
    } catch (err) {
      const msg = (err.message || '').toLowerCase();
      if (err.code === 'ALREADY_REGISTERED' || msg.includes('already') || msg.includes('exists') || msg.includes('registrad')) {
        setError(err.message || 'Este correo electrónico ya está registrado en la base de datos. Por favor inicia sesión.');
      } else {
        setError(err.message || 'No se pudo enviar el código de verificación');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async () => {
    setError('');
    setLoading(true);
    const cleanEmail = email.trim().toLowerCase();
    try {
      const result = await base44.auth.verifyOtp({ email: cleanEmail, otpCode: otpCode.trim() });
      if (result?.access_token) base44.auth.setToken(result.access_token);
      const cleanReferral = referral.trim().toUpperCase();
      try {
        await base44.auth.updateMe({
          display_name: name.trim(),
          phone,
          photo_url: photo || undefined,
          referral_code: cleanReferral || undefined,
          onboarded: true,
        });
      } catch (e) {}
      if (cleanReferral) {
        try {
          await base44.functions.invoke('clubApplyReferral', { code: cleanReferral });
        } catch (e) {}
      }
      try {
        window.localStorage.setItem('next_user_explicit_mode', 'pasajero');
      } catch {}
      window.location.href = '/cliente';
    } catch (err) {
      setError('El código ingresado es incorrecto o venció. Solicita uno nuevo con "Reenviar código".');
    } finally {
      setLoading(false);
    }
  };

  if (step === 'otp') {
    return (
      <OtpVerificationCard
        email={email}
        otpCode={otpCode}
        setOtpCode={setOtpCode}
        loading={loading}
        error={error}
        onVerify={handleVerify}
        onBack={() => setStep('form')}
        submitLabel="Verificar y continuar"
        loadingLabel="Verificando..."
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#F4F7FB] dark:bg-[#0B0F1A] flex flex-col px-6 py-8 max-w-md mx-auto w-full">
      <button onClick={() => navigate('/vinculate', { state: { phone } })} className="w-10 h-10 rounded-full bg-white dark:bg-[#161C28] shadow-sm flex items-center justify-center text-gray-900 dark:text-white mb-6 self-start">
        <ArrowLeft className="w-5 h-5" />
      </button>

      <h1 className="text-gray-900 dark:text-white text-xl font-bold mb-1">Perfil de pasajero</h1>
      <p className="text-gray-500 dark:text-[#A0A0A0] text-sm mb-6">Completa tus datos para pedir viajes con una cuenta verificada.</p>

      <form onSubmit={handleSubmit} className="flex-1 flex flex-col">
        <div className="bg-white dark:bg-[#161C28] rounded-3xl border border-gray-100 dark:border-white/8 shadow-sm p-6 mb-4">
          <ProfilePhotoUpload value={photo} onChange={setPhoto} />
          <p className="text-center text-sm font-semibold text-gray-900 dark:text-white mt-4">Foto de perfil</p>
          <p className="text-center text-xs text-gray-500 dark:text-[#8B95A8] mt-1">Tómate una selfie normal donde se vea bien tu rostro, sin gafas oscuras, gorra ni tapabocas.</p>
        </div>

        <div className="bg-white dark:bg-[#161C28] rounded-3xl border border-gray-100 dark:border-white/8 shadow-sm p-6 flex-1 flex flex-col">
          <h2 className="text-gray-900 dark:text-white font-bold mb-4">Datos personales</h2>
          {error && <div className="mb-4 p-3 rounded-xl bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-400 text-sm text-center">{error}</div>}

          <label className="text-xs font-medium text-gray-500 dark:text-[#A0A0A0] mb-1.5">Nombre completo</label>
          <div className="relative mb-4">
            <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input className={fieldCls} placeholder="Nombre completo" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>

          <label className="text-xs font-medium text-gray-500 dark:text-[#A0A0A0] mb-1.5">Correo electrónico</label>
          <div className="relative mb-4">
            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="email"
              className={fieldCls}
              placeholder="correo@ejemplo.com"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                if (error && error.toLowerCase().includes('correo')) setError('');
              }}
              onBlur={async () => {
                const clean = email.trim().toLowerCase();
                if (!clean || !clean.includes('@')) return;
                try {
                  const res = await checkDatabaseRegistration({ email: clean, scope: 'pasajero' });
                  if (res?.exists && res?.verified) {
                    setError(res.error || 'Este correo electrónico ya está registrado en la base de datos.');
                  }
                } catch {}
              }}
              required
            />
          </div>

          <label className="text-xs font-medium text-gray-500 dark:text-[#A0A0A0] mb-1.5">Contraseña</label>
          <div className="relative mb-4">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input type={showPassword ? 'text' : 'password'} className={fieldCls + ' pr-12'} placeholder="Mínimo 6 caracteres" value={password} onChange={(e) => setPassword(e.target.value)} required />
            <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400">{showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}</button>
          </div>

          <label className="text-xs font-medium text-gray-500 dark:text-[#A0A0A0] mb-1.5">Código de referido (opcional)</label>
          <div className="relative mb-3">
            <Gift className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input className={fieldCls} placeholder="Código de referido" value={referral} onChange={(e) => setReferral(e.target.value)} />
          </div>
          <div className="flex items-start gap-2 mb-6">
            <Info className="w-4 h-4 text-gray-400 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-gray-500 dark:text-[#8B95A8]">
              Si un pasajero te invitó, escribe su código de NEXT CLUB: tú recibes +{REFERRAL_POINTS} puntos y quien te invitó también.
            </p>
          </div>

          <button type="submit" disabled={loading} className="w-full h-14 bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-white font-bold rounded-full flex items-center justify-center gap-2 disabled:opacity-50 shadow-lg shadow-[#1E6BFF]/20">
            {loading ? <><Loader2 className="w-5 h-5 animate-spin" /> Creando...</> : <>Crear perfil <ArrowRight className="w-5 h-5" /></>}
          </button>
        </div>

        <div className="flex items-center justify-center gap-2 mt-4 text-xs text-gray-500 dark:text-[#8B95A8] text-center px-4">
          <ShieldCheck className="w-4 h-4 text-[#00C853] flex-shrink-0" />
          <span>Tus datos están protegidos y solo se usarán para mejorar tu experiencia.</span>
        </div>
      </form>
    </div>
  );
}
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import { getHomeForRole } from '@/lib/roles';
import SplashImage from '@/components/SplashImage';
import { preloadPanel } from '@/lib/preloadPanel';

// Tiempo mínimo de la imagen de apertura, contado desde que el celular empezó a abrir la app:
// lo que la app tarda en cargar ya cuenta dentro de ese tiempo, no se le suma una espera aparte.
// Si la pantalla siguiente aún no termina de descargar, la misma imagen sigue hasta que esté lista.
const SPLASH_MIN_MS = 1000;

// Pantalla a la que se entra cuando termina la imagen de apertura
function getDestination(user, isAuthenticated) {
  if (!isAuthenticated || !user) return '/registro';
  if (['central', 'admin', 'superadmin'].includes(user.role)) return '/central';
  return getHomeForRole(user.role);
}

// Pantalla de apertura: siempre muestra la imagen a pantalla completa al abrir la app
// y luego redirige a la interfaz correspondiente (pasajero, conductor, central o registro).
export default function Splash() {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const destination = getDestination(user, isAuthenticated);

  // Mientras se lee la imagen de apertura, se va descargando la pantalla a la que se va a entrar
  useEffect(() => {
    preloadPanel(destination);
  }, [destination]);

  useEffect(() => {
    const alreadyShownBoot =
      typeof window !== 'undefined' &&
      window.sessionStorage?.getItem('next_boot_splash_shown_v2') === '1';
    // performance.now() es el tiempo que lleva la app desde que empezó a abrir
    const delayMs = alreadyShownBoot ? 0 : Math.max(0, SPLASH_MIN_MS - performance.now());

    const t = setTimeout(() => {
      try {
        window.sessionStorage?.setItem('next_boot_splash_shown_v2', '1');
      } catch {}
      navigate(destination, { replace: true });
    }, delayMs);
    return () => clearTimeout(t);
  }, [navigate, destination]);

  return <SplashImage />;
}
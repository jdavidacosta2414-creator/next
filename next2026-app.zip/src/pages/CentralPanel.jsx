import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/lib/AuthContext';
import { useBackButton } from '@/hooks/useBackButton';
import { LogOut } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import NextLogo from '@/components/NextLogo';
import ThemeToggle from '@/components/ThemeToggle';
import PendingServices from '@/components/central/PendingServices';
import MobilesList from '@/components/central/MobilesList';
import WalletManager from '@/components/central/PlanillaManager';
import RechargeApprovals from '@/components/central/RechargeApprovals';
import LinkGenerator from '@/components/central/LinkGenerator';
import DailyDashboard from '@/components/central/DailyDashboard';
import MobileRanking from '@/components/central/MobileRanking';
import CoverageZoneManager from '@/components/central/CoverageZoneManager';
import CentralSidebar from '@/components/central/CentralSidebar';
import CentralTopbar from '@/components/central/CentralTopbar';
import CentralNotificationsBell from '@/components/central/CentralNotificationsBell';
import OverviewDesktop from '@/components/central/OverviewDesktop';
import ReportsView from '@/components/central/ReportsView';
import ClientsView from '@/components/central/ClientsView';
import CourierView from '@/components/central/CourierView';
import IncidencesView from '@/components/central/IncidencesView';
import { debounce } from '@/lib/debounce';
import CentralChatView from '@/components/central/CentralChatView';
import AdminAdvertisements from '@/components/admin/AdminAdvertisements';
import AdminPuntos from '@/components/admin/AdminPuntos';
import AdminNivelesRendimiento from '@/components/admin/AdminNivelesRendimiento';

const TABS = [
  { v: 'dashboard', label: 'Resumen' },
  { v: 'pendientes', label: 'Servicios' },
  { v: 'moviles', label: 'Móviles' },
  { v: 'chat', label: 'Chat' },
  { v: 'clientes', label: 'Clientes' },
  { v: 'mensajeria', label: 'Mensajería' },
  { v: 'ranking', label: 'Ranking' },
  { v: 'niveles_rendimiento', label: 'Niveles y rendimiento' },
  { v: 'reportes', label: 'Reportes' },
  { v: 'incidencias', label: 'Incidencias' },
  { v: 'recargas', label: 'Recargas' },
  { v: 'publicidad', label: 'Publicidad' },
  { v: 'puntos', label: 'Puntos y compras' },
  { v: 'planilla', label: 'Saldo' },
  { v: 'zona', label: 'Zona' },
  { v: 'link', label: 'Link' },
];

const LABELS = Object.fromEntries(TABS.map(t => [t.v, t.label]));

export default function CentralPanel() {
  const { logout } = useAuth();
  const [tab, setTab] = useState('dashboard');
  const tabHistoryRef = useRef([]);
  const [desktop, setDesktop] = useState(false);

  const changeTab = (nextTab) => {
    if (!nextTab || nextTab === tab) return;
    tabHistoryRef.current = [...tabHistoryRef.current.slice(-14), tab];
    setTab(nextTab);
  };

  useBackButton(() => {
    if (tabHistoryRef.current.length > 0) {
      const prev = tabHistoryRef.current.pop();
      setTab(prev);
      return true;
    }
    if (tab !== 'dashboard') {
      setTab('dashboard');
      return true;
    }
    return false;
  }, true, { priority: -100 });
  const [pendingCount, setPendingCount] = useState(0);
  const [pendingPointsCount, setPendingPointsCount] = useState(0);
  const [pendingMobilesCount, setPendingMobilesCount] = useState(0);

  useEffect(() => {
    const mql = window.matchMedia('(min-width: 1024px)');
    const onChange = () => setDesktop(mql.matches);
    mql.addEventListener('change', onChange);
    setDesktop(mql.matches);
    return () => mql.removeEventListener('change', onChange);
  }, []);

  useEffect(() => {
    const load = async () => {
      try {
        const [count, ptsPending, claimsPending, mobsPending] = await Promise.all([
          base44.entities.Service.count({ status: 'pendiente' }),
          base44.entities.PointsTransaction.count({ status: 'pendiente' }),
          base44.entities.RewardClaim.count({ status: 'pendiente' }),
          base44.entities.Mobile.count({ approval_status: 'pendiente' }),
        ]);
        setPendingCount(count);
        setPendingPointsCount((ptsPending || 0) + (claimsPending || 0));
        setPendingMobilesCount(mobsPending || 0);
      } catch (e) {}
    };
    load();
    const debounced = debounce(() => load().catch(() => {}), 500);
    const unsubSvc = base44.entities.Service.subscribe(() => debounced());
    const unsubPts = base44.entities.PointsTransaction.subscribe(() => debounced());
    const unsubClaims = base44.entities.RewardClaim.subscribe(() => debounced());
    const unsubMobs = base44.entities.Mobile.subscribe(() => debounced());
    return () => { debounced.cancel(); unsubSvc(); unsubPts(); unsubClaims(); unsubMobs(); };
  }, []);

  const renderSection = () => {
    switch (tab) {
      case 'dashboard': return desktop ? <OverviewDesktop /> : <DailyDashboard onNavigate={changeTab} />;
      case 'pendientes': return <PendingServices />;
      case 'moviles': return <MobilesList />;
      case 'chat': return <CentralChatView />;
      case 'clientes': return <ClientsView />;
      case 'mensajeria': return <CourierView />;
      case 'ranking': return <MobileRanking />;
      case 'niveles_rendimiento': return <AdminNivelesRendimiento />;
      case 'reportes': return <ReportsView />;
      case 'incidencias': return <IncidencesView />;
      case 'recargas': return <RechargeApprovals />;
      case 'publicidad': return <AdminAdvertisements />;
      case 'puntos': return <AdminPuntos />;
      case 'planilla': return <WalletManager />;
      case 'zona': return <CoverageZoneManager />;
      case 'link': return <LinkGenerator />;
      default: return null;
    }
  };

  // Layout móvil (compacto, sin cambios respecto al panel actual)
  if (!desktop) {
    return (
      <div className="theme-day min-h-screen bg-background overflow-x-hidden">
        <header className="bg-[#0D0D0D] border-b border-[#1F1F1F] sticky top-0 z-10">
          <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <NextLogo size="sm" withGlow={false} />
              <div className="hidden sm:block">
                <p className="text-[10px] text-[#1E6BFF] uppercase tracking-[0.2em] font-medium">Central de despacho</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <CentralNotificationsBell onOpenIncidencias={() => changeTab('incidencias')} />
              <ThemeToggle />
              <button onClick={() => logout()} className="text-[#8B8C94] hover:text-white flex items-center gap-1 text-sm">
                <LogOut className="w-4 h-4" />Salir
              </button>
            </div>
          </div>
        </header>
        <main className="max-w-2xl mx-auto px-4 py-4">
          <div className="flex gap-1.5 overflow-x-auto pb-3 mb-4 -mx-4 px-4" style={{ scrollbarWidth: 'none' }}>
            {TABS.map(t => (
              <button key={t.v} onClick={() => changeTab(t.v)}
                className={`h-9 px-4 rounded-xl text-sm font-medium whitespace-nowrap flex-shrink-0 transition inline-flex items-center gap-1.5 ${tab === t.v ? 'bg-gradient-to-r from-[#1E6BFF] to-[#00E5FF] text-[#FFFFFF]' : 'bg-[#0D0D0D] text-[#8B8C94] border border-[#1F1F1F]'}`}>
                <span>{t.label}</span>
                {t.v === 'moviles' && pendingMobilesCount > 0 && (
                  <span className="px-1.5 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-400 text-[#0B0F1A]">
                    {pendingMobilesCount}
                  </span>
                )}
              </button>
            ))}
          </div>
          {renderSection()}
        </main>
      </div>
    );
  }

  // Layout escritorio (dashboard web)
  return (
    <div className="theme-day min-h-screen bg-background flex overflow-x-hidden">
      <CentralSidebar active={tab} onChange={changeTab} pendingCount={pendingCount} pendingPointsCount={pendingPointsCount} pendingMobilesCount={pendingMobilesCount} />
      <div className="flex-1 flex flex-col min-w-0 h-screen">
        <CentralTopbar title={LABELS[tab] || 'Resumen'} onOpenIncidencias={() => changeTab('incidencias')} />
        <main className="flex-1 overflow-y-auto thin-scroll p-4 lg:p-6">
            {renderSection()}
        </main>
      </div>
    </div>
  );
}
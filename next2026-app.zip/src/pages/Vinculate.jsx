import React, { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeft, User, Bike, ChevronRight, ShieldCheck } from 'lucide-react';
import NextLogoMark from '@/components/NextLogoMark';
import { captureReferralFromUrl } from '@/lib/referrals';
import { useBackButton } from '@/hooks/useBackButton';

// Selección de rol: ¿Cómo deseas usar NEXT?
export default function Vinculate() {
  const navigate = useNavigate();
  const location = useLocation();
  const phone = location.state?.phone;
  useEffect(() => {
    captureReferralFromUrl();
  }, []);

  useBackButton(() => {
    navigate(phone ? '/registro' : '/login');
    return true;
  }, true);

  const go = (role) =>
    navigate(role === 'pasajero' ? '/vinculate/pasajero' : '/vinculate/conductor', { state: { phone } });

  return (
    <div className="min-h-screen bg-[#F4F7FB] dark:bg-[#0B0F1A] flex flex-col px-6 py-8 max-w-md mx-auto w-full">
      <button
        onClick={() => navigate(phone ? '/registro' : '/login')}
        className="w-10 h-10 rounded-full bg-white dark:bg-[#161C28] shadow-sm flex items-center justify-center text-gray-900 dark:text-white mb-8 self-start"
      >
        <ArrowLeft className="w-5 h-5" />
      </button>

      <div className="flex flex-col items-center mb-8">
        <div className="w-24 h-24 rounded-full bg-[#E8F4FF] dark:bg-[#1E6BFF]/15 flex items-center justify-center mb-5">
          <NextLogoMark size={56} withGlow />
        </div>
        <h1 className="text-xl font-bold text-center text-gray-900 dark:text-white">
          ¿Cómo deseas usar <span className="text-[#1E6BFF] dark:text-[#00E5FF]">NEXT</span>?
        </h1>
        <p className="text-sm text-gray-500 dark:text-[#A0A0A0] text-center mt-2 max-w-xs">
          Puedes iniciar como pasajero o completar tu registro para trabajar como conductor.
        </p>
      </div>

      <div className="space-y-4 flex-1">
        <button
          onClick={() => go('pasajero')}
          className="w-full flex items-center gap-4 p-4 rounded-3xl bg-white dark:bg-[#161C28] border border-gray-100 dark:border-white/8 shadow-sm text-left hover:shadow-md transition-shadow"
        >
          <div className="w-14 h-14 rounded-2xl bg-[#E8F4FF] dark:bg-[#1E6BFF]/15 flex items-center justify-center flex-shrink-0">
            <User className="w-7 h-7 text-[#1E6BFF] dark:text-[#00E5FF]" />
          </div>
          <div className="flex-1">
            <p className="font-bold text-gray-900 dark:text-white">Soy pasajero</p>
            <p className="text-xs text-gray-500 dark:text-[#8B95A8]">Solicita viajes de manera rápida, segura y confiable.</p>
          </div>
          <div className="w-9 h-9 rounded-full border border-gray-200 dark:border-white/15 flex items-center justify-center flex-shrink-0">
            <ChevronRight className="w-5 h-5 text-gray-900 dark:text-white" />
          </div>
        </button>

        <button
          onClick={() => go('conductor')}
          className="w-full flex items-center gap-4 p-4 rounded-3xl bg-white dark:bg-[#161C28] border border-gray-100 dark:border-white/8 shadow-sm text-left hover:shadow-md transition-shadow"
        >
          <div className="w-14 h-14 rounded-2xl bg-[#E8F4FF] dark:bg-[#1E6BFF]/15 flex items-center justify-center flex-shrink-0">
            <Bike className="w-7 h-7 text-[#1E6BFF] dark:text-[#00E5FF]" />
          </div>
          <div className="flex-1">
            <p className="font-bold text-gray-900 dark:text-white">Soy conductor</p>
            <p className="text-xs text-gray-500 dark:text-[#8B95A8]">Completa tu registro y comienza a ganar manejando.</p>
          </div>
          <div className="w-9 h-9 rounded-full border border-gray-200 dark:border-white/15 flex items-center justify-center flex-shrink-0">
            <ChevronRight className="w-5 h-5 text-gray-900 dark:text-white" />
          </div>
        </button>
      </div>

      <div className="flex items-center justify-center gap-2 mt-8 text-xs text-gray-500 dark:text-[#8B95A8] text-center px-4">
        <ShieldCheck className="w-4 h-4 text-[#00C853] flex-shrink-0" />
        <span>Tu seguridad es nuestra prioridad. Tus datos están protegidos.</span>
      </div>
    </div>
  );
}
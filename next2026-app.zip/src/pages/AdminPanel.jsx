import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useBackButton } from '@/hooks/useBackButton';
import AdminSidebar from '@/components/admin/AdminSidebar';
import AdminTopbar from '@/components/admin/AdminTopbar';
import AdminDashboard from '@/components/admin/AdminDashboard';
import AdminSolicitudes from '@/components/admin/AdminSolicitudes';
import LiveMap from '@/components/central/LiveMap';
import RealtimePanel from '@/components/central/RealtimePanel';
import MobilesList from '@/components/central/MobilesList';
import ClientsView from '@/components/central/ClientsView';
import ReportsView from '@/components/central/ReportsView';
import RechargeApprovals from '@/components/central/RechargeApprovals';
import CourierView from '@/components/central/CourierView';
import IncidencesView from '@/components/central/IncidencesView';
import MobileRanking from '@/components/central/MobileRanking';
import LostItemsView from '@/components/admin/LostItemsView';
import AdminAdvertisements from '@/components/admin/AdminAdvertisements';
import AdminPuntos from '@/components/admin/AdminPuntos';
import AdminNextClub from '@/components/admin/club/AdminNextClub';
import AdminNivelesRendimiento from '@/components/admin/AdminNivelesRendimiento';
import AdminNegocios from '@/components/admin/AdminNegocios';

// Mapeo de sección admin → componente.
// Las secciones con datos reales reutilizan los componentes del panel Central;
// las que aún no tienen datos muestran un placeholder.
export default function AdminPanel() {
  const [tab, setTab] = useState('dashboard');
  const tabHistoryRef = useRef([]);
  const [pendingCount, setPendingCount] = useState(0);
  const [lostCount, setLostCount] = useState(0);
  const [pendingMobilesCount, setPendingMobilesCount] = useState(0);

  const changeTab = (nextTab) => {
    if (!nextTab || nextTab === tab) return;
    tabHistoryRef.current = [...tabHistoryRef.current.slice(-14), tab];
    setTab(nextTab);
  };

  useBackButton(() => {
    if (tabHistoryRef.current.length > 0) {
      const prev = tabHistoryRef.current.pop();
      setTab(prev);
      return true;
    }
    if (tab !== 'dashboard') {
      setTab('dashboard');
      return true;
    }
    return false;
  }, true, { priority: -100 });

  useEffect(() => {
    const load = async () => {
      try {
        const [svcs, lost, mobs] = await Promise.all([
          base44.entities.Service.count({ status: 'pendiente' }),
          base44.entities.LostItemReport.count({ status: { $in: ['nuevo', 'en_gestion'] } }),
          base44.entities.Mobile.count({ approval_status: 'pendiente' }),
        ]);
        setPendingCount(svcs);
        setLostCount(lost);
        setPendingMobilesCount(mobs || 0);
      } catch (e) {}
    };
    load();
    const unsubSvc = base44.entities.Service.subscribe(() => load().catch(() => {}));
    const unsubLost = base44.entities.LostItemReport.subscribe(() => load().catch(() => {}));
    const unsubMob = base44.entities.Mobile.subscribe(() => load().catch(() => {}));
    return () => { unsubSvc(); unsubLost(); unsubMob(); };
  }, []);

  const renderSection = () => {
    switch (tab) {
      case 'dashboard': return <AdminDashboard />;
      case 'solicitudes': return <AdminSolicitudes />;
      case 'mapa': return <div className="h-[600px]"><LiveMap /></div>;
      case 'despachador': return <RealtimePanel />;
      case 'conductores': return <MobilesList />;
      case 'pasajeros': return <ClientsView />;
      case 'historial': return <ReportsView />;
      case 'recargas': return <RechargeApprovals />;
      case 'servicios': return <CourierView />;
      case 'cancelaciones': return <IncidencesView />;
      case 'objetos_perdidos': return <LostItemsView />;
      case 'calif_conductores': return <MobileRanking />;
      case 'niveles_rendimiento': return <AdminNivelesRendimiento />;
      case 'publicidad': return <AdminAdvertisements />;
      case 'puntos': return <AdminPuntos />;
      case 'next_club': return <AdminNextClub />;
      case 'negocios': return <AdminNegocios />;
      default: return <AdminDashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-[#0c0f14] flex overflow-x-hidden">
      <AdminSidebar active={tab} onChange={changeTab} pendingCount={pendingCount} lostCount={lostCount} pendingMobilesCount={pendingMobilesCount} />
      <div className="flex-1 flex flex-col min-w-0 h-screen">
        <AdminTopbar active={tab} />
        <main className="flex-1 overflow-y-auto thin-scroll p-4 lg:p-6">
          {renderSection()}
        </main>
      </div>
    </div>
  );
}
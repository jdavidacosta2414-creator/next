import React, { useState } from 'react';
import { useNavigate, useLocation, Navigate } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, User, Bike, Check } from 'lucide-react';
import NextLogo from '@/components/NextLogo';
import OnboardingCard from '@/components/OnboardingCard';

export default function RoleSelect() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const method = location.state?.method || 'phone';
  const phone = location.state?.phone;
  const [role, setRole] = useState('pasajero');

  if (!user) {
    return <Navigate to="/" replace />;
  }

  const handleContinue = async () => {
    try {
      await base44.auth.updateMe({ onboarded: true });
    } catch (e) {
      // No bloquear el flujo si falla
    }
    navigate('/ingreso-rapido', { state: { role, method, phone } });
  };

  return (
    <OnboardingCard>
      {/* Header */}
      <div className="flex items-center justify-between mb-10">
        <button onClick={() => navigate('/')} className="w-10 h-10 rounded-full bg-gray-100 dark:bg-[#1A1A1A] flex items-center justify-center text-gray-900 dark:text-white">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <NextLogo size="sm" withGlow={false} />
      </div>

      {/* Texto */}
      <h1 className="text-gray-900 dark:text-white text-2xl font-bold mb-2">¿Cómo quieres usar NEXT?</h1>
      <p className="text-gray-500 dark:text-[#A0A0A0] text-sm mb-8">Puedes cambiar de modo más adelante desde tu perfil</p>

      {/* Tarjetas de rol */}
      <div className="space-y-4 mb-8">
        <button
          onClick={() => setRole('pasajero')}
          className={`w-full flex items-center gap-4 p-4 rounded-2xl border-2 transition-all text-left ${role === 'pasajero' ? 'border-[#00E5FF] bg-[#00E5FF]/10' : 'border-gray-200 dark:border-[#1F1F1F] bg-gray-100 dark:bg-[#0D0D0D]'}`}
        >
          <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${role === 'pasajero' ? 'bg-[#00E5FF]' : 'bg-gray-200 dark:bg-[#1F1F1F]'}`}>
            <User className={`w-6 h-6 ${role === 'pasajero' ? 'text-black' : 'text-gray-400 dark:text-[#6B6B6B]'}`} />
          </div>
          <div className="flex-1">
            <p className="text-gray-900 dark:text-white font-bold">Soy pasajero</p>
            <p className="text-gray-500 dark:text-[#8B8C94] text-xs">Solicita transporte o mensajería y propón tu propia tarifa</p>
          </div>
          {role === 'pasajero' && (
            <div className="w-5 h-5 rounded-full bg-[#00E5FF] flex items-center justify-center flex-shrink-0">
              <Check className="w-3 h-3 text-black" />
            </div>
          )}
        </button>

        <button
          onClick={() => setRole('conductor')}
          className={`w-full flex items-center gap-4 p-4 rounded-2xl border-2 transition-all text-left ${role === 'conductor' ? 'border-[#00E5FF] bg-[#00E5FF]/10' : 'border-gray-200 dark:border-[#1F1F1F] bg-gray-100 dark:bg-[#0D0D0D]'}`}
        >
          <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${role === 'conductor' ? 'bg-[#00E5FF]' : 'bg-gray-200 dark:bg-[#1F1F1F]'}`}>
            <Bike className={`w-6 h-6 ${role === 'conductor' ? 'text-black' : 'text-gray-400 dark:text-[#6B6B6B]'}`} />
          </div>
          <div className="flex-1">
            <p className="text-gray-900 dark:text-white font-bold">Soy conductor</p>
            <p className="text-gray-500 dark:text-[#8B8C94] text-xs">Recibe solicitudes, acepta o negocia tarifas y genera ingresos</p>
          </div>
          {role === 'conductor' && (
            <div className="w-5 h-5 rounded-full bg-[#00E5FF] flex items-center justify-center flex-shrink-0">
              <Check className="w-3 h-3 text-black" />
            </div>
          )}
        </button>
      </div>

      {/* Botón continuar */}
      <button
        onClick={handleContinue}
        className="w-full h-14 bg-[#00E5FF] text-black font-bold rounded-2xl flex items-center justify-center mt-auto"
      >
        Continuar
      </button>
    </OnboardingCard>
  );
}
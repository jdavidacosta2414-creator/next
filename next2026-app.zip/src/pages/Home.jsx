import { Navigate } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import { getHomeForRole } from '@/lib/roles';

export default function Home() {
  const { user } = useAuth();
  return <Navigate to={getHomeForRole(user?.role)} replace />;
}
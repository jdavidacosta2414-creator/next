import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Loader2 } from 'lucide-react';
import DriverTopbar from '@/components/driver/DriverTopbar';
import DriverBottomNav from '@/components/driver/DriverBottomNav';
import DriverDrawer from '@/components/driver/DriverDrawer';
import DriverHome from '@/components/driver/DriverHome';
import DriverEarningsView from '@/components/driver/DriverEarningsView';
import DriverPriority from '@/components/driver/DriverPriority';
import DriverRendimiento from '@/components/driver/DriverRendimiento';
import DriverPerfilView from '@/components/driver/DriverPerfilView';
import DriverConfig from '@/components/driver/DriverConfig';
import DriverCiudad from '@/components/driver/DriverCiudad';
import DriverCartera from '@/components/driver/DriverCartera';
import DriverNotificaciones from '@/components/driver/DriverNotificaciones';
import DriverCompartir from '@/components/driver/DriverCompartir';
import DriverSeguridad from '@/components/driver/DriverSeguridad';
import DriverSoporte from '@/components/driver/DriverSoporte';
import DriverRecompensas from '@/components/driver/DriverRecompensas';
import DriverChaqueta from '@/components/driver/DriverChaqueta';
import DriverHistorial from '@/components/driver/DriverHistorial';
import AppAyuda from '@/components/shared/AppAyuda';
import { DRIVER_FAQS } from '@/lib/driverFaqs';
import ValoracionesView from '@/components/shared/ValoracionesView';
import DriverOnboarding from '@/components/mobile/DriverOnboarding';
import DriverPendingApproval from '@/components/mobile/DriverPendingApproval';
import AvailableServices from '@/components/mobile/AvailableServices';
import ActiveServicesList from '@/components/driver/ActiveServicesList';
import DriverServiceTabs from '@/components/driver/DriverServiceTabs';
import SearchingRadar from '@/components/driver/SearchingRadar';
import ActiveService from '@/components/mobile/ActiveService';
import ServiceRatingModal from '@/components/shared/ServiceRatingModal';
import NextFloatingBubble from '@/components/shared/NextFloatingBubble';
import { canWork, isPassActive, getMinRecharge, PASS_DURATION_HOURS, getCarDocsStatus } from '@/lib/recharge';
import { evaluateDriverTier, fetchDriverRecentActivity } from '@/lib/driverTier';
import { evaluateAndAutoCreditDriverRewards } from '@/lib/rewards';
import { useDriverTracking } from '@/hooks/useDriverTracking';
import { triggerInstantServiceAlert } from '@/hooks/useNewServiceAlert';
import { alertBusinessCancel } from '@/lib/businessCancelAlert';
import { useBackButton } from '@/hooks/useBackButton';
import ServiceMessageAlertBanner, {
  ensurePushNotificationPermission,
  playMessageChime,
} from '@/components/shared/ServiceMessageAlertBanner';
import { debounce } from '@/lib/debounce';
import { toast } from '@/components/ui/use-toast';
import { syncMyReferralCodeOwner } from '@/lib/referrals';
import { preloadStorageUrls } from '@/components/shared/ResolvedAvatar';
import { isServiceForDriver } from '@/lib/serviceMatch';
import { pickActiveDriverProfile, takeRequestedDriverSection } from '@/lib/driverProfiles';
import DriverCategorias from '@/components/driver/DriverCategorias';

const fmtCOP = (n) => Number(n || 0);
const todayStr = () => new Date().toLocaleDateString('en-CA', { timeZone: 'America/Bogota' });
const MOBILE_CACHE_KEY = 'next_cached_mobile_v1';

function readCachedMobile(email) {
  if (!email || typeof window === 'undefined') return null;
  try {
    const raw = window.localStorage.getItem(MOBILE_CACHE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (parsed && parsed.email === email && parsed.id) {
      preloadStorageUrls([
        parsed.photo_url,
        parsed.vehicle_photo,
        parsed.verification_photo,
        parsed.tarjeta_photo,
        parsed.soat_photo,
        parsed.tecno_photo,
      ]);
      return parsed;
    }
  } catch {}
  return null;
}

function saveCachedMobile(mob) {
  if (typeof window === 'undefined') return;
  try {
    if (mob && mob.id) {
      window.localStorage.setItem(MOBILE_CACHE_KEY, JSON.stringify(mob));
      preloadStorageUrls([
        mob.photo_url,
        mob.vehicle_photo,
        mob.verification_photo,
        mob.tarjeta_photo,
        mob.soat_photo,
        mob.tecno_photo,
      ]);
    }
  } catch {}
}

export default function MovilPanel() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const initialCachedMobile = readCachedMobile(user?.email);
  const [mobile, setMobile] = useState(() => initialCachedMobile);
  const [loading, setLoading] = useState(() => !initialCachedMobile);
  const [tab, setTab] = useState('inicio');
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [configOpen, setConfigOpen] = useState(false);
  const [section, setSection] = useState(null);
  const [activeServices, setActiveServices] = useState([]);
  const [managingActive, setManagingActive] = useState(null);
  const [autoOpenChatServiceId, setAutoOpenChatServiceId] = useState(null);
  const [globalPushBanner, setGlobalPushBanner] = useState(null);
  const globalSeenMsgIdsRef = useRef(new Set());
  const autoOpenedServiceIdsRef = useRef(new Set());
  const [unratedFinished, setUnratedFinished] = useState(null);
  const [serviceTab, setServiceTab] = useState('disponibles');
  const [availableCount, setAvailableCount] = useState(0);
  const [stats, setStats] = useState({ tripsToday: 0, earningsToday: 0 });
  const [totalEarnings, setTotalEarnings] = useState(0);
  const [totalTrips, setTotalTrips] = useState(0);
  const [totalReviews, setTotalReviews] = useState(0);
  const [avgRating, setAvgRating] = useState(0);
  const [tierInfo, setTierInfo] = useState(() => evaluateDriverTier({ recentTrips: 0, recentDays: 0 }));

  const driverHistoryRef = useRef([]);
  const driverNavRef = useRef({});

  driverNavRef.current = { drawerOpen, configOpen, section, managingActive, tab, serviceTab };

  const navigateDriver = useCallback((patch = {}) => {
    const cur = driverNavRef.current;
    const nextTab = patch.tab !== undefined ? patch.tab : cur.tab;
    const nextSection = patch.section !== undefined ? patch.section : cur.section;
    const nextConfigOpen = patch.configOpen !== undefined ? patch.configOpen : cur.configOpen;
    const nextManagingActive =
      patch.managingActive !== undefined ? patch.managingActive : cur.managingActive;
    const nextServiceTab = patch.serviceTab !== undefined ? patch.serviceTab : cur.serviceTab;

    const changed =
      nextTab !== cur.tab ||
      nextSection !== cur.section ||
      nextConfigOpen !== cur.configOpen ||
      nextManagingActive?.id !== cur.managingActive?.id ||
      Boolean(nextManagingActive) !== Boolean(cur.managingActive);

    if (changed) {
      driverHistoryRef.current = [
        ...driverHistoryRef.current.slice(-14),
        {
          tab: cur.tab,
          section: cur.section,
          configOpen: cur.configOpen,
          managingActive: cur.managingActive,
          serviceTab: cur.serviceTab,
        },
      ];
    }

    setDrawerOpen(false);
    if (patch.tab !== undefined) setTab(patch.tab);
    if (patch.section !== undefined) setSection(patch.section);
    if (patch.configOpen !== undefined) setConfigOpen(patch.configOpen);
    if (patch.managingActive !== undefined) setManagingActive(patch.managingActive);
    if (patch.serviceTab !== undefined) setServiceTab(patch.serviceTab);
  }, []);

  const goBackDriver = useCallback(() => {
    const st = driverNavRef.current;
    if (st.drawerOpen) {
      setDrawerOpen(false);
      return true;
    }
    const hist = driverHistoryRef.current;
    while (hist.length > 0) {
      const prev = hist.pop();
      const isDifferent =
        prev.tab !== st.tab ||
        prev.section !== st.section ||
        prev.configOpen !== st.configOpen ||
        prev.managingActive?.id !== st.managingActive?.id ||
        Boolean(prev.managingActive) !== Boolean(st.managingActive);
      if (isDifferent) {
        setTab(prev.tab || 'inicio');
        setSection(prev.section || null);
        setConfigOpen(Boolean(prev.configOpen));
        setManagingActive(prev.managingActive || null);
        if (prev.serviceTab) setServiceTab(prev.serviceTab);
        return true;
      }
    }
    if (st.configOpen) {
      setConfigOpen(false);
      return true;
    }
    if (st.section) {
      setSection(null);
      return true;
    }
    if (st.managingActive) {
      setManagingActive(null);
      return true;
    }
    if (st.tab !== 'inicio') {
      setTab('inicio');
      return true;
    }
    return false;
  }, []);

  // El panel nunca debe adelantarse al cierre de un modal o chat.
  useBackButton(goBackDriver, true, { priority: -100 });

  const notifiedPassExpiredRef = useRef(false);
  const lastTierDoneCountRef = useRef(-1);
  const lastRewardEvalKeyRef = useRef('');

  useEffect(() => {
    if (mobile?.id) saveCachedMobile(mobile);
  }, [mobile]);

  // Cargar perfil del conductor por email (y al pasar al siguiente día o vencer el pase, renovar su saldo a 0 e informarle).
  const loadMobile = useCallback(async () => {
    if (!user?.email) return;
    if (user?.photo_url) preloadStorageUrls([user.photo_url]);
    try {
      const mobs = await base44.entities.Mobile.filter({ email: user.email });
      if (mobs.length) {
        // La cuenta puede tener un registro por categoría: se trabaja con el que está en uso.
        let m = pickActiveDriverProfile(mobs);
        if (!isPassActive(m) && Number(m.balance || 0) > 0) {
          try {
            m = await base44.entities.Mobile.update(m.id, { balance: 0, pass_mode: 'pase' });
          } catch {
            m = { ...m, balance: 0, pass_mode: 'pase' };
          }
          if (!notifiedPassExpiredRef.current) {
            notifiedPassExpiredRef.current = true;
            toast({
              title: `Tus ${PASS_DURATION_HOURS} horas laborales se cumplieron`,
              description: `Se cumplieron tus ${PASS_DURATION_HOURS} horas desde la recarga y tu saldo pasó a $0. Recarga para activar otras ${PASS_DURATION_HOURS} horas a partir de ahora.`,
            });
          }
        }
        // Si el conductor estaba marcado como 'ocupado', mantenerlo siempre 'disponible' mientras esté conectado
        if (m.status === 'ocupado') {
          try {
            m = await base44.entities.Mobile.update(m.id, { status: 'disponible' });
          } catch {
            m = { ...m, status: 'disponible' };
          }
        }
        if (!m.photo_url && user?.photo_url) {
          try {
            m = await base44.entities.Mobile.update(m.id, { photo_url: user.photo_url });
          } catch {
            m = { ...m, photo_url: user.photo_url };
          }
        }
        saveCachedMobile(m);
        setMobile(m);
      }
    } catch (e) {}
  }, [user?.email, user?.photo_url]);

  const mobileRef = useRef(mobile);
  mobileRef.current = mobile;

  // Vigilancia continua + suscripción en tiempo real a cambios de saldo/pase de 14 horas del conductor.
  useEffect(() => {
    if (!mobile?.id) return;
    const mobId = mobile.id;
    const unsubMob = base44.entities.Mobile.subscribe((ev) => {
      if (ev?.id === mobId && ev?.data) {
        setMobile((prev) => {
          const merged = prev ? { ...prev, ...ev.data } : ev.data;
          saveCachedMobile(merged);
          return merged;
        });
      }
    });
    const checkExpiry = async () => {
      const curMob = mobileRef.current;
      if (curMob && !isPassActive(curMob) && Number(curMob.balance || 0) > 0) {
        try {
          const updated = await base44.entities.Mobile.update(mobId, { balance: 0, pass_mode: 'pase' });
          saveCachedMobile(updated);
          setMobile(updated);
        } catch {
          setMobile((prev) => (prev ? { ...prev, balance: 0, pass_mode: 'pase' } : prev));
        }
        if (!notifiedPassExpiredRef.current) {
          notifiedPassExpiredRef.current = true;
          toast({
            title: `Tus ${PASS_DURATION_HOURS} horas laborales se cumplieron`,
            description: `Se cumplieron tus ${PASS_DURATION_HOURS} horas desde la recarga y tu saldo pasó a $0. Recarga para activar otras ${PASS_DURATION_HOURS} horas.`,
          });
        }
      }
    };
    const interval = setInterval(checkExpiry, 25000);
    return () => {
      unsubMob();
      clearInterval(interval);
    };
  }, [mobile?.id]);

  useEffect(() => {
    (async () => {
      await loadMobile();
      setLoading(false);
    })();
  }, [loadMobile]);

  // Tras registrar otra categoría, el panel abre "Mis categorías" para ver el estado del nuevo registro.
  useEffect(() => {
    const requested = takeRequestedDriverSection();
    if (requested) setSection(requested);
  }, []);

  useEffect(() => {
    if (!mobile?.id) return;
    ensurePushNotificationPermission();
    syncMyReferralCodeOwner({ user, mobile }).catch(() => {});
  }, [user, mobile]);

  useEffect(() => {
    if (!globalPushBanner) return;
    const t = setTimeout(() => setGlobalPushBanner(null), 9000);
    return () => clearTimeout(t);
  }, [globalPushBanner]);

  const activeServicesRef = useRef(activeServices);
  activeServicesRef.current = activeServices;
  const activeServicesIdsKey = activeServices.map((s) => s.id).join(',');

  // Escucha global de mensajes de pasajeros para servicios activos cuando el conductor está en otra pestaña o lista
  useEffect(() => {
    if (!mobile?.id || !activeServicesIdsKey) return;
    const currentServices = activeServicesRef.current;
    const activeIds = new Set(currentServices.map((s) => s.id));
    // Pre-sembrar IDs existentes para alertar solo mensajes nuevos
    Promise.all(
      currentServices.map((s) =>
        base44.entities.ServiceMessage.filter({ service_id: s.id }, 'created_date', 50).catch(() => [])
      )
    ).then((lists) => {
      lists.forEach((res) => {
        const arr = Array.isArray(res) ? res : res?.items || [];
        arr.forEach((m) => m?.id && globalSeenMsgIdsRef.current.add(m.id));
      });
    });

    const unsubMsg = base44.entities.ServiceMessage.subscribe((ev) => {
      const msg = ev?.data;
      if (!msg?.id || msg.sender_type !== 'cliente') return;
      if (!activeIds.has(msg.service_id)) return;
      if (globalSeenMsgIdsRef.current.has(msg.id)) return;
      globalSeenMsgIdsRef.current.add(msg.id);

      // Si el conductor NO tiene abierto ese servicio en pantalla (ActiveService ya maneja su propia alerta),
      // disparar sonido + vibración + notificación push del sistema + banner superior para abrir el chat
      const isCurrentlyManagingThis =
        driverNavRef.current.tab === 'inicio' &&
        !driverNavRef.current.section &&
        !driverNavRef.current.configOpen &&
        driverNavRef.current.managingActive?.id === msg.service_id;

      if (!isCurrentlyManagingThis) {
        const svc = activeServicesRef.current.find((s) => s.id === msg.service_id);
        const senderTitle = `Mensaje de ${msg.sender_name || svc?.client_name || 'Pasajero'}`;
        playMessageChime(senderTitle, msg.message);
        setGlobalPushBanner({
          id: `msg-${msg.id}`,
          type: 'passenger_message',
          service: svc,
          title: senderTitle,
          message: msg.message,
        });
      }
    });
    return unsubMsg;
  }, [mobile?.id, activeServicesIdsKey]);

  const driverClaimsRef = useRef(new Map());
  const driverReferralsRef = useRef(new Set());

  useEffect(() => {
    if (!mobile?.id) return;
    let initClaims = false;
    const checkDriverClaims = async () => {
      try {
        const res = await base44.entities.RewardClaim.filter(
          { scope: 'conductor', mobile_id: mobile.id },
          '-created_date',
          20
        );
        const list = res?.items || (Array.isArray(res) ? res : []);
        if (initClaims) {
          list.forEach((c) => {
            const prevStatus = driverClaimsRef.current.get(c.id);
            if (!prevStatus && c.status === 'pendiente') {
              toast({
                title: '¡Has adquirido una recompensa! 🎁',
                description: `Adquiriste "${c.reward}". Revisa tus Notificaciones; Central la acreditará pronto.`,
              });
            } else if (prevStatus !== 'entregado' && c.status === 'entregado') {
              toast({
                title: '¡Recompensa aprobada por Central! 🏆',
                description: `Tu recompensa "${c.reward}" fue aprobada y acreditada en tu billetera.`,
              });
              loadMobile();
            }
          });
        }
        const nextMap = new Map();
        list.forEach((c) => nextMap.set(c.id, c.status));
        driverClaimsRef.current = nextMap;
        initClaims = true;
      } catch {}
    };
    checkDriverClaims();
    const unsubClaims = base44.entities.RewardClaim.subscribe(() => checkDriverClaims().catch(() => {}));
    return unsubClaims;
  }, [mobile?.id, loadMobile]);

  useEffect(() => {
    if (!mobile?.id && !user?.id) return;
    let initRefs = false;
    const checkDriverRefs = async () => {
      try {
        const page = await base44.entities.PointsTransaction.filter(
          { status: 'aprobado', type: 'referido_aprobado' },
          { sort: '-created_date', limit: 20 }
        );
        const list = (page?.items || []).filter(
          (tx) =>
            tx.referrer_mobile_id === mobile?.id ||
            tx.user_id === mobile?.id ||
            (user?.id && tx.user_id === user.id)
        );
        if (initRefs) {
          list.forEach((tx) => {
            if (!driverReferralsRef.current.has(tx.id)) {
              toast({
                title: `¡Ganaste +${tx.amount} puntos por referido! 🤝`,
                description: `Central aprobó tu referido${tx.referred_user_name ? ` (${tx.referred_user_name})` : ''} y abonó +${tx.amount} puntos a tu Billetera de Puntos.`,
              });
              loadMobile();
            }
          });
        }
        driverReferralsRef.current = new Set(list.map((t) => t.id));
        initRefs = true;
      } catch {}
    };
    checkDriverRefs();
    const unsubPts = base44.entities.PointsTransaction.subscribe(() => checkDriverRefs().catch(() => {}));
    return unsubPts;
  }, [mobile?.id, user?.id, loadMobile]);

  // Cargar servicio activo + estadísticas cuando hay perfil (seleccionando solo los campos necesarios para ahorrar datos móviles).
  const refreshData = useCallback(async () => {
    if (!mobile?.id) return;
    try {
      const [active, finishedList] = await Promise.all([
        base44.entities.Service.filter(
          { mobile_id: mobile.id, status: { $in: ['asignado', 'en_camino', 'recogida'] } },
          '-created_date', 5
        ),
        base44.entities.Service.filter(
          { mobile_id: mobile.id, status: 'finalizado' },
          {
            sort: '-created_date',
            limit: 150,
            fields: [
              'id',
              'fare',
              'collected_amount',
              'driver_rating',
              'client_name',
              'client_photo',
              'created_date',
              'updated_date',
            ],
          }
        ),
      ]);
      const activeList = Array.isArray(active) ? active : active?.items || [];
      setActiveServices(activeList);
      // Cuando el conductor tiene un servicio asignado nuevo, abrir automáticamente la vista del servicio con su mapa ampliado
      if (activeList.length > 0) {
        const newestActive = activeList[0];
        if (newestActive?.id && !autoOpenedServiceIdsRef.current.has(newestActive.id)) {
          autoOpenedServiceIdsRef.current.add(newestActive.id);
          setManagingActive(newestActive);
          setServiceTab('en_curso');
        } else {
          setManagingActive((prev) => (prev ? activeList.find((x) => x.id === prev.id) || prev : prev));
        }
      }
      const doneArr = Array.isArray(finishedList) ? finishedList : finishedList?.items || [];
      // Si el último servicio finalizado aún no ha sido calificado por el conductor, mostrar modal para calificar al pasajero.
      const pendingRate = doneArr.slice(0, 3).find((s) => s.driver_rating == null);
      setUnratedFinished(pendingRate || null);

      const tStr = todayStr();
      let sumAll = 0;
      let sumToday = 0;
      let countToday = 0;
      const toUtcBogotaDay = (raw) => {
        if (!raw) return '';
        const str = String(raw).trim();
        const iso = /([zZ]|[+-]\d{2}:?\d{2})$/.test(str) ? str : `${str.replace(' ', 'T')}Z`;
        const dt = new Date(iso);
        if (Number.isNaN(dt.getTime())) return '';
        return dt.toLocaleDateString('en-CA', { timeZone: 'America/Bogota' });
      };
      doneArr.forEach((s) => {
        const val = Number(s.collected_amount || s.fare || 0);
        sumAll += val;
        const createdDay = toUtcBogotaDay(s.created_date);
        const updatedDay = toUtcBogotaDay(s.updated_date);
        if (createdDay === tStr || updatedDay === tStr) {
          sumToday += val;
          countToday += 1;
        }
      });
      setTotalEarnings(sumAll);
      setTotalTrips(doneArr.length);
      setStats({ tripsToday: countToday, earningsToday: sumToday });

      // Solo recalcular nivel y promedio de estrellas cuando cambia el total de viajes finalizados
      if (lastTierDoneCountRef.current !== doneArr.length) {
        lastTierDoneCountRef.current = doneArr.length;
        const [ratingAgg, recentTier] = await Promise.all([
          base44.entities.Service.aggregate({
            query: { mobile_id: mobile.id, rating: { $gt: 0 } },
            groupBy: 'status',
            avg: ['rating'],
          }),
          fetchDriverRecentActivity(mobile.id),
        ]);
        const ratingRow = ratingAgg?.rows?.[0];
        setTotalReviews(ratingRow?.count || 0);
        setAvgRating(ratingRow?.avg_rating || 0);
        if (recentTier) setTierInfo(recentTier);
      }
    } catch (e) {}
  }, [mobile?.id]);

  useEffect(() => {
    refreshData();
    const debounced = debounce(() => refreshData().catch(() => {}), 80);
    const unsub = base44.entities.Service.subscribe((ev) => {
      const evData = ev?.data;
      // Alerta sonora + push inmediata en 0ms apenas entra un servicio nuevo disponible cerca de la ubicación del conductor.
      // Se decide con el estado actual del conductor (conectado, pase y ubicación), no con el de cuando abrió la app.
      const driver = mobileRef.current;
      if (
        ev?.type === 'create' &&
        evData?.status === 'pendiente' &&
        driver?.status !== 'offline' &&
        canWork(driver)
      ) {
        const matchesVehicle = isServiceForDriver(evData, driver);
        if (matchesVehicle && !(evData.rejected_by || []).includes(driver?.id)) {
          const alerted = triggerInstantServiceAlert(
            evData,
            false,
            driver?.current_lat != null && driver?.current_lng != null
              ? { lat: Number(driver.current_lat), lng: Number(driver.current_lng) }
              : null
          );
          if (alerted) {
            const fareStr = evData.fare ? `$${Number(evData.fare).toLocaleString('es-CO')}` : '';
            setGlobalPushBanner({
              id: `svc-${evData.id}`,
              type: 'new_service',
              service: evData,
              title: `🛵 ¡Nuevo servicio cerca! ${fareStr}`.trim(),
              message: `${evData.pickup_address || 'Recogida'} → ${evData.destination_address || 'Destino'}`,
            });
          }
        }
      }
      // Un negocio canceló un pedido que este mensajero tenía a su nombre: aviso con tono, vibración y mensaje
      // en cualquier pantalla, y el pedido deja de estar abierto.
      if (
        ev?.type === 'update' &&
        evData?.status === 'cancelado' &&
        evData.cancelled_by === 'negocio' &&
        evData.mobile_id === mobile?.id
      ) {
        alertBusinessCancel(
          evData,
          activeServicesRef.current.find((s) => s.id === evData.id)?.status === 'recogida'
        );
        if (driverNavRef.current.managingActive?.id === evData.id) setManagingActive(null);
        driverHistoryRef.current = driverHistoryRef.current.filter((h) => h.managingActive?.id !== evData.id);
      }
      // Solo refrescar activos/estadísticas del conductor si el evento le pertenece a este conductor
      if (evData?.mobile_id && evData.mobile_id === mobile?.id) {
        refreshData().catch(() => {});
        return;
      }
      if (!evData || !evData.mobile_id) {
        debounced();
      }
    });
    // Verificar cambio de día (00:00 Bogotá) para reiniciar en vivo el contador diario a $0
    let lastDay = todayStr();
    const dayTimer = setInterval(() => {
      const currentDay = todayStr();
      if (currentDay !== lastDay) {
        lastDay = currentDay;
        setStats({ tripsToday: 0, earningsToday: 0 });
        refreshData().catch(() => {});
      }
    }, 15000);
    return () => {
      debounced.cancel();
      unsub();
      clearInterval(dayTimer);
    };
  }, [refreshData]);

  // El día solo cuenta como "conectado" cuando el conductor tiene su recarga activa
  // y además toma al menos un servicio en el día (no basta con solo abrir la app).
  const hasTakenServiceToday = activeServices.length > 0 || stats.tripsToday > 0;
  const hasActiveRecharge = mobile ? canWork(mobile) : false;
  useEffect(() => {
    if (!mobile?.id || !hasActiveRecharge || !hasTakenServiceToday) return;
    const today = new Date().toLocaleDateString('en-CA', { timeZone: 'America/Bogota' });
    const evalKey = `${mobile.id}_${today}_${stats.tripsToday}`;
    if (lastRewardEvalKeyRef.current === evalKey) return;
    lastRewardEvalKeyRef.current = evalKey;
    (async () => {
      try {
        const res = await base44.entities.DriverCheckIn.filter({ mobile_id: mobile.id, date: today }, '-created_date', 1);
        const list = res?.items || res || [];
        if (!list.length) {
          await base44.entities.DriverCheckIn.create({ mobile_id: mobile.id, date: today });
        }
        // Evaluar y acreditar automáticamente bonos en Cartera si alcanzó 7, 10, 20 o 30 días conectados o meta de viajes
        const autoRes = await evaluateAndAutoCreditDriverRewards(mobile);
        if (autoRes.credited?.length > 0) {
          await loadMobile();
          autoRes.credited.forEach((c) => {
            toast({
              title: '¡Bono acreditado automáticamente en tu Cartera! 🎉',
              description: `Cumpliste tu meta y se abonó "${c.reward}" directamente a tu Cartera.`,
            });
          });
        }
      } catch {}
    })();
  }, [mobile?.id, hasActiveRecharge, hasTakenServiceToday, stats.tripsToday, loadMobile]);

  const handleDriverLocationChange = useCallback((lat, lng) => {
    setMobile((prev) => {
      if (!prev) return prev;
      if (
        prev.current_lat != null &&
        prev.current_lng != null &&
        Math.abs(Number(prev.current_lat) - Number(lat)) < 0.00004 &&
        Math.abs(Number(prev.current_lng) - Number(lng)) < 0.00004
      ) {
        return prev;
      }
      return { ...prev, current_lat: lat, current_lng: lng };
    });
  }, []);

  // Reportar GPS en vivo para que los mapas de Central y pasajero vean el movimiento
  // y actualizar las coordenadas locales del conductor al instante.
  useDriverTracking(
    mobile?.id,
    !!mobile && mobile.status !== 'offline',
    mobile?.current_lat,
    mobile?.current_lng,
    handleDriverLocationChange
  );

  // Desconexión automática al cerrar la app: si el conductor cierra o recarga
  // la página sin desconectarse, se marca offline de inmediato (keepalive).
  // En segundo plano NO se desconecta (sigue latiendo). No abandona servicios
  // en curso: la función backend lo impide.
  const disconnectRef = useRef(null);
  disconnectRef.current = mobile?.id && mobile.status !== 'offline'
    ? () => {
        try {
          base44.functions.fetch('/disconnectDriver', {
            method: 'POST',
            keepalive: true,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ mobile_id: mobile.id }),
          }).catch(() => {});
        } catch (e) {}
      }
    : null;
  useEffect(() => {
    const onUnload = (e) => {
      if (e.persisted) return; // bfcache: la app sigue en segundo plano
      const fn = disconnectRef.current;
      if (fn) fn();
    };
    window.addEventListener('pagehide', onUnload);
    window.addEventListener('beforeunload', onUnload);
    return () => {
      window.removeEventListener('pagehide', onUnload);
      window.removeEventListener('beforeunload', onUnload);
    };
  }, []);

  if (loading) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!mobile) {
    // Si el pasajero intenta pasar a modo conductor sin haberse registrado como conductor, enviarlo directo al registro de conductor.
    window.location.replace('/vinculate/conductor');
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background px-6 text-center">
        <Loader2 className="w-7 h-7 animate-spin text-primary mb-3" />
        <p className="text-foreground font-bold text-base mb-1">Redirigiendo a registro de conductor...</p>
        <p className="text-muted-foreground text-sm mb-5">Debes registrarte primero como conductor y subir tus documentos para que la Central te active.</p>
        <button onClick={() => navigate('/vinculate/conductor')}
          className="h-12 px-8 rounded-full bg-primary text-primary-foreground font-bold">
          Ir al registro de conductor
        </button>
      </div>
    );
  }

  // Si el conductor se registró pero la Central aún no ha verificado sus documentos ni lo ha activado (o fue rechazado),
  // mostrar la pantalla de espera de activación por la Central.
  if (mobile.approval_status === 'pendiente' || mobile.approval_status === 'rechazado') {
    return <DriverPendingApproval mobile={mobile} onRefresh={setMobile} />;
  }

  // Onboarding: términos + verificación de identidad.
  if (!mobile.terms_accepted || !mobile.identity_verified) {
    return <DriverOnboarding mobile={mobile} onComplete={setMobile} />;
  }

  const connected = mobile.status !== 'offline';
  const carDocs = getCarDocsStatus(mobile);
  const canTake = canWork(mobile);

  const toggleConnect = async () => {
    // No permitir desconectarse mientras hay un servicio en curso.
    if (connected && activeServices.length > 0) return;
    const next = connected ? 'offline' : 'disponible';
    try {
      const updated = await base44.entities.Mobile.update(mobile.id, { status: next });
      setMobile(updated);
    } catch (e) {}
  };

  const toggleBusy = async () => {
    if (!connected) return;
    const next = mobile.status === 'ocupado' ? 'disponible' : 'ocupado';
    try {
      const updated = await base44.entities.Mobile.update(mobile.id, { status: next });
      setMobile(updated);
    } catch (e) {}
  };

  if (section) {
    if (section === 'ayuda') {
      return (
        <AppAyuda
          faqs={DRIVER_FAQS}
          onBack={goBackDriver}
          onOpenSoporte={() => navigateDriver({ section: 'soporte' })}
          onOpenSeguridad={() => navigateDriver({ section: 'seguridad' })}
        />
      );
    }
    if (section === 'valoraciones') {
      return <ValoracionesView role="conductor" mobile={mobile} user={user} onBack={goBackDriver} />;
    }
    if (section === 'prioridad') {
      return (
        <DriverPriority
          mobile={mobile}
          tierInfo={tierInfo}
          totalTrips={totalTrips}
          totalReviews={totalReviews}
          avgRating={avgRating}
          onBack={goBackDriver}
          onOpenRendimiento={() => navigateDriver({ section: 'rendimiento' })}
        />
      );
    }
    if (section === 'rendimiento') {
      return (
        <DriverRendimiento
          mobile={mobile}
          tierInfo={tierInfo}
          avgRating={avgRating}
          totalReviews={totalReviews}
          onBack={goBackDriver}
          onOpenNiveles={() => navigateDriver({ section: 'prioridad' })}
        />
      );
    }
    const SECTION_MAP = {
      ciudad: DriverCiudad,
      cartera: DriverCartera,
      chaqueta: DriverChaqueta,
      historial: DriverHistorial,
      notificaciones: DriverNotificaciones,
      compartir: DriverCompartir,
      seguridad: DriverSeguridad,
      config: DriverConfig,
      soporte: DriverSoporte,
      recompensas: DriverRecompensas,
      categorias: DriverCategorias,
    };
    const Comp = SECTION_MAP[section];
    if (Comp) {
      return (
        <>
          <Comp
            mobile={mobile}
            user={user}
            onBack={goBackDriver}
            onNavigate={(nextSec) => navigateDriver({ section: nextSec })}
            onMobileUpdate={setMobile}
          />
          <NextFloatingBubble
            role="conductor"
            isConnected={connected}
            activeService={managingActive || activeServices[0] || null}
            pendingCount={availableCount}
            onReturnToActive={() => {
              navigateDriver({
                section: null,
                configOpen: false,
                tab: 'inicio',
                ...(activeServices[0] ? { managingActive: activeServices[0] } : {}),
              });
            }}
          />
        </>
      );
    }
  }

  if (configOpen) {
    return (
      <>
        <DriverConfig onBack={goBackDriver} />
        <NextFloatingBubble
          role="conductor"
          isConnected={connected}
          activeService={managingActive || activeServices[0] || null}
          pendingCount={availableCount}
          onReturnToActive={() => {
            navigateDriver({
              configOpen: false,
              tab: 'inicio',
              ...(activeServices[0] ? { managingActive: activeServices[0] } : {}),
            });
          }}
        />
      </>
    );
  }

  const handleOpenGlobalPushBanner = (banner) => {
    setGlobalPushBanner(null);
    setDrawerOpen(false);
    setSection(null);
    setConfigOpen(false);
    setTab('inicio');
    if (banner?.type === 'passenger_message' && banner.service) {
      setManagingActive(banner.service);
      setAutoOpenChatServiceId(banner.service.id);
      setServiceTab('en_curso');
    } else if (banner?.type === 'new_service') {
      setManagingActive(null);
      setServiceTab('disponibles');
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col max-w-md mx-auto w-full">
      <ServiceMessageAlertBanner
        alert={globalPushBanner}
        onOpen={handleOpenGlobalPushBanner}
        onDismiss={() => setGlobalPushBanner(null)}
      />
      {!(tab === 'inicio' && managingActive) && (
        <DriverTopbar
          status={mobile.status}
          totalEarnings={stats.earningsToday}
          onMenu={() => setDrawerOpen(true)}
          onToggleConnect={toggleConnect}
          onOpenEarnings={() => navigateDriver({ section: null, configOpen: false, tab: 'ingresos' })}
        />
      )}

      <div id="driver-main-scroll" className="flex-1 overflow-y-auto no-scrollbar">
        {tab === 'inicio' && (
          <DriverHome connected={connected} hasServices={activeServices.length > 0 || availableCount > 0}>
            {managingActive ? (
              <ActiveService
                service={managingActive}
                mobile={mobile}
                driverEarnings={stats.earningsToday}
                initialChatOpen={autoOpenChatServiceId === managingActive.id}
                onOpenEarnings={() => navigateDriver({ section: null, configOpen: false, tab: 'ingresos' })}
                onDone={() => {
                  setAutoOpenChatServiceId(null);
                  refreshData();
                  loadMobile();
                  setManagingActive(null);
                  setServiceTab('disponibles');
                }}
                onBack={() => {
                  setAutoOpenChatServiceId(null);
                  loadMobile();
                  goBackDriver();
                }}
              />
            ) : connected && (canTake || activeServices.length > 0) ? (
              <>
                <DriverServiceTabs
                  active={serviceTab}
                  onChange={setServiceTab}
                  disponiblesCount={connected ? availableCount : 0}
                  enCursoCount={activeServices.length}
                />
                {serviceTab === 'disponibles' ? (
                  <AvailableServices
                    mobile={mobile}
                    tierInfo={tierInfo}
                    onAccept={refreshData}
                    muted={!connected}
                    onCountChange={setAvailableCount}
                    activeServices={activeServices}
                    onRecharge={() => navigateDriver({ section: 'cartera' })}
                    onOpenPriority={() => navigateDriver({ section: 'prioridad' })}
                  />
                ) : (
                  <ActiveServicesList
                    activeServices={activeServices}
                    mobile={mobile}
                    onOpenActive={(s) => navigateDriver({ managingActive: s })}
                  />
                )}
              </>
            ) : connected && !canTake ? (
              carDocs.expired ? (
                <div className="text-center py-12 px-4">
                  <p className="text-red-500 font-extrabold mb-1">
                    Documentos del vehículo vencidos
                  </p>
                  <p className="text-muted-foreground text-sm mb-4 max-w-xs mx-auto leading-relaxed">
                    {carDocs.soatExpired && carDocs.tecnoExpired
                      ? 'Tu SOAT y tu Revisión Técnico-Mecánica están vencidos.'
                      : carDocs.soatExpired
                      ? `Tu SOAT se encuentra vencido (${mobile.soat_expiry}).`
                      : `Tu Revisión Técnico-Mecánica se encuentra vencida (${mobile.tecno_expiry}).`}{' '}
                    No puedes trabajar ni tomar servicios hasta tener tus documentos vigentes.
                  </p>
                  <button
                    onClick={() => navigateDriver({ tab: 'perfil', section: null })}
                    className="h-11 px-6 rounded-full bg-gradient-to-r from-[#0091D5] to-[#00B8D4] text-white font-bold text-sm shadow-lg"
                  >
                    Ver mis documentos en Perfil
                  </button>
                </div>
              ) : (
                <div className="text-center py-12 px-4">
                  <p className="text-foreground font-bold mb-1">
                    {mobile.pass_vence_en
                      ? `Tus ${PASS_DURATION_HOURS} horas laborales se cumplieron (Saldo en $0)`
                      : `Activa tu pase de ${PASS_DURATION_HOURS} horas laborales`}
                  </p>
                  <p className="text-muted-foreground text-sm mb-4 max-w-xs mx-auto leading-relaxed">
                    {mobile.pass_vence_en
                      ? `Tu saldo se renovó a $0 al cumplirse las ${PASS_DURATION_HOURS} horas. Debes volver a recargar ($${getMinRecharge(mobile.vehicle_type).toLocaleString('es-CO')} COP) para poder seguir tomando servicios.`
                      : `Recarga $${getMinRecharge(mobile.vehicle_type).toLocaleString('es-CO')} COP ($7.000 moto / $10.000 carro) para tener ${PASS_DURATION_HOURS} horas laborales sin descuento por porcentaje.`}
                  </p>
                  <button onClick={() => navigateDriver({ section: 'cartera' })} className="h-11 px-6 rounded-full bg-gradient-to-r from-[#0091D5] to-[#00B8D4] text-white font-bold text-sm shadow-lg">
                    Recargar pase de {PASS_DURATION_HOURS}h
                  </button>
                </div>
              )
            ) : (
              <SearchingRadar mode="offline" onConnect={toggleConnect} />
            )}
          </DriverHome>
        )}

        {tab === 'ingresos' && (
          <DriverEarningsView
            mobile={mobile}
            onMobileUpdate={setMobile}
            onOpenPriority={() => navigateDriver({ section: 'prioridad' })}
            onOpenHistorial={() => navigateDriver({ section: 'historial' })}
          />
        )}

        {tab === 'perfil' && (
          <DriverPerfilView
            mobile={mobile}
            user={user}
            tierInfo={tierInfo}
            totalTrips={totalTrips}
            avgRating={avgRating}
            onMobileUpdate={setMobile}
            onOpenNiveles={() => navigateDriver({ section: 'prioridad' })}
            onOpenRendimiento={() => navigateDriver({ section: 'rendimiento' })}
            onOpenHistorial={() => navigateDriver({ section: 'historial' })}
          />
        )}
      </div>

      <DriverBottomNav
        active={tab}
        onChange={(nextTab) => navigateDriver({ section: null, configOpen: false, tab: nextTab })}
      />

      {drawerOpen && (
        <DriverDrawer
          mobile={mobile}
          user={user}
          onClose={() => setDrawerOpen(false)}
          onNavigate={(s) => {
            if (s === 'perfil') {
              navigateDriver({ section: null, tab: 'perfil' });
            } else {
              navigateDriver({ section: s });
            }
          }}
        />
      )}

      {!managingActive && unratedFinished && (
        <ServiceRatingModal
          serviceId={unratedFinished.id}
          role="movil"
          targetName={unratedFinished.client_name}
          targetPhoto={unratedFinished.client_photo}
          onDone={() => {
            setUnratedFinished(null);
            refreshData();
          }}
        />
      )}

      {!(tab === 'inicio' && managingActive) && (
        <NextFloatingBubble
          role="conductor"
          isConnected={connected}
          activeService={managingActive || activeServices[0] || null}
          pendingCount={availableCount}
          onReturnToActive={() => {
            setDrawerOpen(false);
            setSection(null);
            setConfigOpen(false);
            setTab('inicio');
            if (activeServices[0]) {
              setManagingActive(activeServices[0]);
              setServiceTab('en_curso');
            }
          }}
        />
      )}
    </div>
  );
}